from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    #(?P<flow_page_number>[0-9]+)
    url(r'^csvFile/$', views.CsvFileReader.as_view(), name='CSV file'),
    url(r'^mapping/$', views.CsvMapping.as_view(), name='Mapping'),
    url(r'^user_list/$', views.user_list, name='user list'),
    url(r'^create_ingestion/$', views.create_ingestion, name='create ingestion'),
    url(r'^user_info/(?P<uid>[0-9]+)/$', views.user_info, name='user info'),
    url(r'^user_info/$', views.user_info_without_uid, name='user info'),
    url(r'^ingest_list/(?P<page_number>[0-9]+)/$', views.ingest_list, name='ingest list'),
    url(r'^ingest_list_report/(?P<page_number>[0-9]+)/$', views.ingest_list_report, name='report ingest list'),
    url(r'^ingest_source_detail/$', views.ingest_source_detail, name='ingest source detail'),
    url(r'^validate_regex/$', views.validate_regex, name='validate regex'),
    url(r'^ingest_name/$', views.mapping_data, name='ingest name'),
    url(r'^use_this_ingestion/$', views.use_this_ingestion, name='use this ingestion'),
    url(r'^show_stewards/$', views.ShowStewards.as_view(), name='show steward'),
    url(r'^show_data_manager/$', views.ShowDataManager.as_view(), name='show data manager'),
    url(r'^create_flow/$', views.CreateFlow.as_view(), name='Create Flow'),
    url(r'^show_flow/$', views.ShowFlow.as_view(), name='Show Flow'),
    url(r'^edit_flow/(?P<flow_name>[\w\-]+)/$', views.EditFlow.as_view(), name='Edit Flow'),
    url(r'^use_flow/(?P<flow_page_number>[0-9]+)/$', views.UseExistingFlow.as_view(), name='Use Existing Flow'),
    url(r'^use_flow/$', views.UseExistingFlow.as_view(), name='Use Existing Flow post method'),
    url(r'^dbConnection/$', views.DatabaseConnection.as_view(), name=' database connection'),
    url(r'^dbConnectionCheck/$', views.DatabaseConnectionCheck.as_view(), name=' database connection check'),
    url(r'^dbMapping/$', views.DatabaseMapping.as_view(), name='database mapping'),
    url(r'^show_mapping/$', views.ShowMapping.as_view(), name='show mapping'),
    url(r'^automapping/$', views.AutoMapping.as_view(), name='Auto mapping'),
    url(r'^delete/$', views.DeleteIngestion.as_view(), name='delete ingestion'),
    url(r'^flow/delete/$', views.DeleteFlow.as_view(), name='delete flow'),
    url(r'^current_ingestion/(?P<ingest_name>[\w\-]+)/$', views.CurrentIngestion.as_view(), name='current ingestion'),
    url(r'^source_finish/$', views.SourceFinish.as_view(), name='Finish source mapping'),
    # url(r'^source_unmapped_discard/$', views.DiscardUnmappedSources.as_view()),
    url(r'^delete_selected_source/$', views.DeleteSourceFromIngestion.as_view(), name='Delete Source From Ingestion'),
    url(r'^resume_flow/$', views.ResumeFlow.as_view(), name='Resume flow'),
    url(r'^show_ingestion_details/$', views.ShowIngestionDetails.as_view(), name='Ingestion details.'),
    url(r'^search_ingest_list/$', views.SearchIngestList.as_view(), name='Search ingest list')
]
