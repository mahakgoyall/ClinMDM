from rest_framework.views import APIView
from connections.getCSVHeader import headerCSV
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.db import connection
from datetime import datetime
from django.core.exceptions import SuspiciousFileOperation
import time
import os
import random
import string
import logging
import json
import re
from chardet.universaldetector import UniversalDetector
from validator.views import ValidatorClass
from fuzzywuzzy import fuzz
from web_curl_service.views import flow_flags
from standardization.views import Standardization
import psycopg2
import copy

logger = logging.getLogger("mdm_logging")


def override(interface_class):
    def overrider(method):
        assert (method.__name__ in dir(interface_class))
        return method

    return overrider


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, datetime):
        serial = obj.isoformat()
        return serial
    raise TypeError("Type not serializable")


def user_list(request):
    """

    :param request:
    :return:
    """
    try:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT user_id, role, username, to_char(last_login, 'YYYY-MM-DD   HH24:MI:SS') FROM "
                           "users where delete_flag != '1' ORDER BY created_date")
            var = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        json_dict = dict()
        counter = 0
        for tup in var:
            role = [int(i) for i in tup[1].split(',')]
            json_dict[str(counter)] = {'user_id': tup[0], 'role': role, 'name': tup[2], 'last_login': tup[3]}
            counter += 1
        return JsonResponse(json_dict)
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    return JsonResponse({'failure': 'Failure'})


def ingest_list_report(request, page_number):
    # logger.error(("  ROLE  :  " + str(type(request.session['role'][0]))))
    """

    :param request:
    :param page_number:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        if entity_name == 'org':
            where_string = "org' or entity = 'site' or entity = 'sponsor"
        else:
            where_string = entity_name

        total_pages = 0
        if 4 in request.session['role'] and 2 in request.session['role']:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT COUNT(*) FROM (SELECT ingest_name, uid, status_flag, data_manager_id, steward_id"
                               " FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND data_manager_id='{}' AND status_flag >= '7' AND delete_flag != '1'  "
                               " AND (entity = '{}') AND schedule_id is NULL or base_ingest_flag = 'base' "
                               "UNION SELECT ingest_name, uid, status_flag, data_manager_id, steward_id"
                               " FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND uid='{}' and data_manager_id != '{}' AND status_flag >='7' "
                               "AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                               "or base_ingest_flag = 'base' UNION "
                               " select ingest_name, uid, status_flag, data_manager_id, steward_id from ingestion "
                               "WHERE data_manager_id = '{}'"
                               " AND uid = '{}' AND delete_flag!='1' AND entity = '{}' "
                               "AND schedule_id is NULL or base_ingest_flag = 'base') A".format(request.session['user_id'], where_string,
                                                    request.session['user_id'],
                                                    request.session['user_id'], where_string,
                                                    request.session['user_id'],
                                                    request.session['user_id'], where_string,
                                                    int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for i in cursor.fetchall():
                total_pages += int(i[0])
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id"
                               " FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND data_manager_id='{}' AND status_flag >= '7' AND delete_flag != '1'  "
                               " AND (entity = '{}') AND schedule_id is NULL or base_ingest_flag = 'base' "
                               "UNION SELECT ingest_name, uid, status_flag, data_manager_id, steward_id"
                               " FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND uid='{}' and data_manager_id != '{}' AND status_flag >='7' "
                               "AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                               "or base_ingest_flag = 'base' UNION "
                               " select ingest_name, uid, status_flag, data_manager_id, steward_id from ingestion "
                               "WHERE data_manager_id = '{}'"
                               " AND uid = '{}' AND delete_flag!='1' AND entity = '{}' AND schedule_id is NULL "
                               "or base_ingest_flag = 'base'  limit 10 "
                               "offset '{}'".format(request.session['user_id'], where_string,  request.session['user_id'],
                                                    request.session['user_id'],where_string,request.session['user_id'],
                                                    request.session['user_id'],where_string,  int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # cursor = connection.cursor()
            # cursor.execute("SELECT
            # cursor.execute("SELECT ingest_name FROM ingestion WHERE S IN (SELECT ingest_id FROM "
            #                "ingestion_sources) AND uid='{}'".format(request.session['user_id']))
        elif 4 in request.session['role'] and 2 not in request.session['role']:
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    "ingestion_sources) AND data_manager_id='{}' AND status_flag >= '7' "
                    "AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                    "or base_ingest_flag = 'base'".format(request.session['user_id'], where_string))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id"
                               " FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND data_manager_id='{}' AND status_flag >= '7' "
                               "AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                               "or base_ingest_flag = 'base' "
                               "limit 10 offset '{}'".format(request.session['user_id'],where_string,
                                                             int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        elif 3 in request.session['role']:
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    "ingestion_sources) AND steward_id='{}' AND status_flag >= '7'"
                    " AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                    "or base_ingest_flag = 'base'".format(
                        request.session['user_id'], where_string))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT ingest_name, uid, status_flag, data_manager_id, steward_id FROM"
                    " ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    "ingestion_sources) AND steward_id='{}' AND status_flag >= '7'"
                    " AND delete_flag != '1' AND (entity = '{}') AND schedule_id is NULL "
                    "or base_ingest_flag = 'base'  limit 10 offset '{}'".format(
                        request.session['user_id'], where_string,
                        int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        else:
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    "ingestion_sources) AND uid='{}' AND status_flag >='7'"
                    " AND delete_flag != '1' AND (entity = '{}') "
                    "AND schedule_id is NULL or base_ingest_flag = 'base' ".format(request.session['user_id'], where_string))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id FROM"
                               " ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                               "ingestion_sources) AND uid='{}' AND status_flag >='7' AND delete_flag != '1' "
                               " AND (entity = '{}') AND schedule_id is NULL or base_ingest_flag = 'base' limit 10 "
                               "offset '{}'".format(request.session['user_id'],where_string,  int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

        data = cursor.fetchall()
        logger.error("data:" + str(data))
        response = list()
        for source_name_tuple in data:
            json_dict = dict()
            # logger.error(str(source_name_tuple))
            json_dict['ingest_name'] = source_name_tuple[0]
            json_dict['source_uid'] = source_name_tuple[1]
            json_dict['status_flag'] = source_name_tuple[2]
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT name FROM users where user_id = '{}' "
                               "and delete_flag != '1'".format(str(source_name_tuple[1])))
                json_dict['ingestion_created_by'] = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

            logger.error("data_manager:" + str(source_name_tuple[3]))
            if str(source_name_tuple[3]) == 'None':
                json_dict['data_manager_name'] = 'Unassigned'
                logger.error("unassigned data_manager")

            else:
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT name FROM users where user_id = '{}' "
                                   "and delete_flag != '1'".format(str(source_name_tuple[3])))
                    json_dict['data_manager_name'] = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            logger.error("steward:" + str(source_name_tuple[4]))
            if str(source_name_tuple[4]) == 'None':
                json_dict['steward_name'] = 'Unassigned'
                logger.error("unassigned steward")
            else:
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT name FROM users where user_id = '{}' "
                                   "and delete_flag != '1'".format(str(source_name_tuple[4])))
                    json_dict['steward_name'] = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            json_dict['sources'] = list()
            json_dict['is_mapped'] = list()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT source_name, data_mapping FROM  ingestion_sources WHERE ingest_id = "
                               "(SELECT ingest_id from ingestion WHERE ingest_name= '{}' AND "
                               "uid = '{}' AND delete_flag != '1' "
                               "AND (entity = '{}') )".format(source_name_tuple[0], source_name_tuple[1], where_string))
                var = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for i in var:
                json_dict['sources'].append(i[0])
                if i[1]:
                    json_dict['is_mapped'].append(True)
                else:
                    json_dict['is_mapped'].append(False)
            response.append(json_dict)
        ui = dict()
        ui['list'] = response
        ui['total'] = total_pages
        # cursor = connection.cursor()
        # cursor.execute("SELECT count(ingest_name) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
        #                "ingestion_sources) AND uid='{}'".format(request.session['user_id']))
        # ui['total'] = cursor.fetchall()[0][0]
        # logger.error(str(ui))
        return JsonResponse(ui)
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    return JsonResponse({'failure': 'Failure'})

class ShowIngestionDetails(APIView):

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingestion_name = data['ingest_name']
            logger.error('ingest name: ' + str(ingestion_name))
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'No data found in body'})
        ui_info = dict()
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_id, username, flow_id, status_flag from ingestion where ingest_name = '{}'".format(str(ingestion_name)))
            ingest_data = cursor.fetchall()[0]
            logger.error('ingest_id: ' + str(ingest_data))
            if ingest_data:
                ui_info['Status'] = ingest_data[3]
            cursor = connection.cursor()
            cursor.execute("select data_mapping from ingestion_sources where ingest_id = '{}'"
                           .format(ingest_data[0]))
            data_mapping = cursor.fetchall()[0][0]
            if data_mapping:
                ui_info['Data Mapping'] = data_mapping
            cursor = connection.cursor()
            cursor.execute("select flow_name, rule from flow where ingest_id = '{}' and flow_id = '{}' and key = 'rule'"
                           .format(ingest_data[0], ingest_data[2]))
            flow_data = cursor.fetchall()
            if flow_data:
                rules_data = get_rules_and_validation_from_string(flow_data[0][0], ingest_data[1], request, 0)
                ui_info['Validation Rules'] = rules_data['validation_rules']
                ui_info['Matching Rules'] = json.loads(flow_data[0][1])
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure' : 'Database Failure'})
        return JsonResponse(ui_info)


def ingest_list(request, page_number, ingest_search=None):
    # logger.error(("  ROLE  :  " + str(type(request.session['role'][0]))))
    """

    :param request:
    :param page_number:
    :return:
    """
    try:
        if ingest_search == None:
            ingest_search = ''
        total_pages = 0
        entity_name = request.META['HTTP_ENTITY']
        where_string = ''
        if entity_name == 'org':
            where_string = "org' or entity = 'site' or entity = 'sponsor"
        else:
            where_string = entity_name
        logger.error(str(entity_name))

        cursor = connection.cursor()
        cursor.execute("delete from ingestion_sources where ingest_id in (select ingest_id from ingestion "
                       " where uid = '{}' and status_flag < '2') and "
                       " status_flag is NULL".format(request.session['user_id']))
        connection.commit()

        if 4 in request.session['role'] and 2 in request.session['role']:
            logger.error("if 4 and 2 case")
            try:
                cursor = connection.cursor()
                logger.error("SELECT COUNT(*) FROM ("
                               " SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date  FROM "
                               " ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                               " AND delete_flag != '1' {} AND entity = '{}' AND "
                               "(schedule_id is NULL or base_ingest_flag = 'base')  "
                               " UNION SELECT ingest_name, uid, status_flag, data_manager_id, "
                               " steward_id , created_date FROM "
                               " ingestion WHERE  uid='{}' and data_manager_id != '{}' {} AND delete_flag != '1' "
                               " AND entity = '{}' AND (schedule_id is NULL or base_ingest_flag = 'base') "
                               " UNION select ingest_name, uid, status_flag, data_manager_id, "
                               " steward_id, created_date from ingestion WHERE data_manager_id = '{}'"
                               " AND uid = '{}' {} AND entity = '{}' AND delete_flag!='1' AND (schedule_id is NULL "
                               " or base_ingest_flag = 'base') order by created_date "
                                " ) A ".format(request.session['user_id'], ingest_search, where_string,
                                                       request.session['user_id'],
                                                       request.session['user_id'], ingest_search,  where_string,
                                                       request.session['user_id'], request.session['user_id'],
                                                       ingest_search,
                                                       where_string))
                # cursor.execute("SELECT count(*) FROM ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                #                "AND delete_flag != '1' AND entity = '{}'"
                #                " UNION SELECT count(*) FROM ingestion WHERE  uid='{}' and "
                #                "data_manager_id != '{}' AND entity = '{}' "
                #                "AND delete_flag != '1'  ".format(request.session['user_id'],
                #                                                  where_string, request.session['user_id'],
                #                                                  request.session['user_id'],
                #                                                   where_string))

                cursor.execute("SELECT COUNT(*) FROM ("
                             " SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date  FROM "
                             " ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                             " AND delete_flag != '1' {} AND entity = '{}' AND (schedule_id is NULL "
                             " or base_ingest_flag = 'base')  "
                             " UNION SELECT ingest_name, uid, status_flag, data_manager_id, "
                             " steward_id , created_date FROM "
                             " ingestion WHERE  uid='{}' and data_manager_id != '{}' {} AND delete_flag != '1' "
                             " AND entity = '{}' AND (schedule_id is NULL or base_ingest_flag = 'base') "
                             " UNION select ingest_name, uid, status_flag, data_manager_id, "
                             " steward_id, created_date from ingestion WHERE data_manager_id = '{}'"
                             " AND uid = '{}' {} AND entity = '{}' AND delete_flag!='1' AND (schedule_id is NULL "
                             " or base_ingest_flag = 'base') order by created_date "
                             " ) A ".format(request.session['user_id'], ingest_search, where_string,
                                            request.session['user_id'],
                                            request.session['user_id'], ingest_search, where_string,
                                            request.session['user_id'], request.session['user_id'],
                                            ingest_search,
                                            where_string))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for i in cursor.fetchall():
                total_pages += int(i[0])

            try:
                cursor = connection.cursor()
                logger.error("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date  FROM "
                               " ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                               " AND delete_flag != '1' AND entity = '{}' {} AND (schedule_id is NULL "
                               " or base_ingest_flag = 'base') "
                               " UNION SELECT ingest_name, uid, status_flag, data_manager_id, "
                               " steward_id  , created_date FROM "
                               " ingestion WHERE  uid='{}' and data_manager_id != '{}' AND delete_flag != '1' "
                               " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') "
                               " UNION select ingest_name, uid, status_flag, data_manager_id, "
                               " steward_id, created_date from ingestion WHERE data_manager_id = '{}' "
                               " AND uid = '{}' AND entity = '{}' {} AND delete_flag!='1' AND (schedule_id is NULL "
                               " or base_ingest_flag = 'base') order by created_date limit 10 "
                               " offset '{}'".format(request.session['user_id'],
                                                     where_string, ingest_search,  request.session['user_id'],
                                                    request.session['user_id'], where_string, ingest_search,
                                                    request.session['user_id'], request.session['user_id'],
                                                    where_string, ingest_search,
                                                    int(page_number) * 10 - 10))

                # cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id  FROM "
                #                "ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                #                "AND delete_flag != '1' AND entity = '{}' "
                #                "UNION SELECT ingest_name, uid, status_flag, data_manager_id, "
                #                "steward_id  FROM "
                #                "ingestion WHERE  uid='{}' and data_manager_id != '{}' AND delete_flag != '1'"
                #                "AND entity = '{}'  limit 10 "
                #                "offset '{}'".format(request.session['user_id'], where_string, request.session['user_id'],
                #                                     request.session['user_id'],where_string, int(page_number) * 10 - 10))

                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date  FROM "
                             " ingestion WHERE  data_manager_id='{}' AND status_flag >= '4' "
                             " AND delete_flag != '1'  AND entity = '{}' {} AND (schedule_id is NULL "
                             " or base_ingest_flag = 'base') "
                             " UNION SELECT ingest_name, uid, status_flag, data_manager_id, "
                             " steward_id  , created_date FROM "
                             " ingestion WHERE  uid='{}' and data_manager_id != '{}' AND delete_flag != '1' "
                             " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') "
                             " UNION select ingest_name, uid, status_flag, data_manager_id, "
                             " steward_id, created_date from ingestion WHERE data_manager_id = '{}' "
                             " AND uid = '{}' AND entity = '{}' {} AND delete_flag!='1' AND (schedule_id is NULL "
                             " or base_ingest_flag = 'base') order by created_date limit 10 "
                             " offset '{}'".format(request.session['user_id'],
                                                   where_string, ingest_search, request.session['user_id'],
                                                   request.session['user_id'], where_string, ingest_search,
                                                   request.session['user_id'], request.session['user_id'],
                                                   where_string, ingest_search,
                                                   int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

        elif 4 in request.session['role'] and 2 not in request.session['role']:
            logger.error("elif 4 not 2 case")
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    " ingestion_sources) AND data_manager_id='{}' AND status_flag >= '4' AND delete_flag != '1' "
                    " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') ".format(
                        request.session['user_id'], where_string, ingest_search))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date"
                               " FROM ingestion WHERE "
                               " ingest_id IN (SELECT ingest_id FROM "
                               " ingestion_sources) AND data_manager_id='{}' AND status_flag >= '4' AND delete_flag != '1'  "
                               " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') "
                               " order by created_date"
                               " limit 10 offset '{}'".format(request.session['user_id'],where_string , ingest_search,
                                                             int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        elif 3 in request.session['role']:
            logger.error("elif 3 case")
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                    " ingestion_sources) AND steward_id='{}' AND status_flag >= '7' AND delete_flag != '1' "
                    " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') ".format(
                        request.session['user_id'], where_string, ingest_search))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT ingest_name, uid, status_flag, data_manager_id, steward_id , created_date FROM ingestion "
                    " WHERE ingest_id IN (SELECT ingest_id FROM "
                    " ingestion_sources) AND steward_id='{}' AND status_flag >= '7' AND delete_flag != '1' "
                    " AND entity = '{}' {} AND (schedule_id is NULL or base_ingest_flag = 'base') "
                    " order by created_date limit 10 offset '{}'".format(
                        request.session['user_id'], where_string, ingest_search,
                        int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        else:
            try:
                cursor = connection.cursor()
                logger.error("else case")
                # cursor.execute(
                #     "SELECT count(*) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
                #     "ingestion_sources) AND uid='{}'".format(request.session['user_id']))
                cursor.execute(
                    "SELECT count(*) FROM ingestion WHERE  uid='{}' "
                    " AND delete_flag != '1' AND entity = '{}' {} AND (schedule_id is NULL "
                    " or base_ingest_flag = 'base')".format(request.session['user_id'], where_string, ingest_search))
                total_pages = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                logger.error("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date"
                             " FROM ingestion"
                               " WHERE  uid='{}' AND delete_flag != '1' AND entity = '{}' {} "
                             " AND (schedule_id is NULL or base_ingest_flag = 'base') order by created_date "
                               " limit 10 offset '{}'".format(request.session['user_id'], where_string, ingest_search,
                                                              int(page_number) * 10 - 10))
                cursor.execute("SELECT ingest_name, uid, status_flag, data_manager_id, steward_id, created_date"
                               " FROM ingestion"
                               " WHERE  uid='{}' AND delete_flag != '1' AND entity = '{}' {} "
                               " AND (schedule_id is NULL or base_ingest_flag = 'base') order by created_date"
                               " limit 10 offset '{}'".format(request.session['user_id'],where_string, ingest_search,
                                                              int(page_number) * 10 - 10))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        data = cursor.fetchall()
        logger.error("data:" + str(data))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    try:
        response = list()
        for source_name_tuple in data:
            json_dict = dict()
            # logger.error(str(source_name_tuple))
            json_dict['ingest_name'] = source_name_tuple[0]
            json_dict['source_uid'] = source_name_tuple[1]
            json_dict['status_flag'] = source_name_tuple[2]
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT name FROM users where user_id = '{}' "
                               " and delete_flag != '1'".format(str(source_name_tuple[1])))
                json_dict['ingestion_created_by'] = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error("data_manager:" + str(source_name_tuple[3]))
            if str(source_name_tuple[3]) == 'None':
                json_dict['data_manager_name'] = 'Unassigned'
                logger.error("unassigned data_manager")

            else:
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT name FROM users where user_id = '{}'"
                                   " and delete_flag != '1'".format(str(source_name_tuple[3])))
                    json_dict['data_manager_name'] = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            logger.error("steward:" + str(source_name_tuple[4]))
            if str(source_name_tuple[4]) == 'None':
                json_dict['steward_name'] = 'Unassigned'
                logger.error("unassigned steward")
            else:
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT name FROM users where user_id = '{}' "
                                   "and delete_flag != '1'".format(str(source_name_tuple[4])))
                    json_dict['steward_name'] = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            json_dict['sources'] = list()
            json_dict['is_mapped'] = list()
            try:
                cursor = connection.cursor()
                logger.error("SELECT source_name, data_mapping FROM  ingestion_sources WHERE ingest_id = "
                               "(SELECT ingest_id from ingestion WHERE ingest_name= '{}' AND "
                               "uid = '{}' AND delete_flag != '1' "
                               "AND (entity = '{}') )".format(source_name_tuple[0], source_name_tuple[1], where_string))
                cursor.execute("SELECT source_name, data_mapping FROM  ingestion_sources WHERE ingest_id = "
                               "(SELECT ingest_id from ingestion WHERE ingest_name= '{}' AND "
                               "uid = '{}' AND delete_flag != '1' "
                               "AND (entity = '{}') )".format(source_name_tuple[0], source_name_tuple[1], where_string))
                var = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for i in var:
                json_dict['sources'].append(i[0])
                if i[1]:
                    json_dict['is_mapped'].append(True)
                else:
                    json_dict['is_mapped'].append(False)
            response.append(json_dict)
        ui = dict()
        ui['list'] = response
        ui['total'] = total_pages
        # cursor = connection.cursor()
        # cursor.execute("SELECT count(ingest_name) FROM ingestion WHERE ingest_id IN (SELECT ingest_id FROM "
        #                "ingestion_sources) AND uid='{}'".format(request.session['user_id']))
        # ui['total'] = cursor.fetchall()[0][0]
        # logger.error(str(ui))
        return JsonResponse(ui)
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    return JsonResponse({'failure': 'Failure'})


def ingest_source_detail(request):
    """

    :param request:
    :return:
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        source_name = data['source_name']
    except KeyError as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Cannot find source name in request'})
    try:
        logger.info("Source name to get details is: " + str(source_name))
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT source.conn_string FROM ingestion_sources AS source JOIN ingestion AS i ON"
                           " source.ingest_id= i.ingest_id WHERE i.ingest_name='{}'".format(source_name))
            var = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        json_dict = dict()
        counter = 0
        for tup in var:
            temp = (str(tup[0]).split('/')).pop()
            logger.error(temp)
            json_dict[str(counter)] = temp
            counter += 1
        return JsonResponse(json_dict)
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    return JsonResponse({'failure': 'Failure'})


def use_this_ingestion(request):
    """

    :param request:
    :return:
    """
    try:
        temp_string = ''
        entity_name = request.META['HTTP_ENTITY']
        if entity_name == 'investigator':
            temp_string = " = 'investigator' "
        elif entity_name == 'study':
            temp_string = " = 'study' "
        else:
            temp_string = "IN ('site', 'sponsor', 'org')"
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        source_name = data['source_name']
        request.session['ingest_name'] = data['source_name']
        request.session['source_user_id'] = data['source_uid']
        logger.error("session source user id is: " + str(request.session['source_user_id']))
    except KeyError as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Cannot find source name in request'})
    try:
        try:
            cursor = connection.cursor()
            logger.error("SELECT ingest_id, steward_id FROM ingestion WHERE ingest_name='{}' AND uid='{}' AND "
                           "delete_flag != '1' and entity  {}".format(source_name,
                                                                      request.session['source_user_id'], temp_string))
            cursor.execute("SELECT ingest_id, steward_id FROM ingestion WHERE ingest_name='{}' AND uid='{}' AND "
                           "delete_flag != '1' and entity  {}".format(source_name,
                                                                request.session['source_user_id'], temp_string))
            tup = cursor.fetchall()[0]
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        ingest_id = tup[0]
        steward_id = tup[1]
        logger.error("Line 387: " + str(steward_id))
        request.session['ingest_id'] = ingest_id
        request.session['steward_id'] = steward_id
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Cannot find ingest id'})
    return JsonResponse({'ok': 'Success'})


class CreateFlow(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            request.session['flow_name'] = data['flow_name']
            request.session['scope'] = data['scope']
            logger.error("FLOW SCOPE  : " + str(data['scope']))
            request.session['rules'] = dict()
            request.session['edit'] = False
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        # flow_flags(request.session['ingest_id'], request.session['user_id'], '5')
        logger.error("Successful flow creation")
        return JsonResponse({'ok': 'Success'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        pass


def get_rules_and_validation_from_string(flow_name, username, request=None, flag=1, entity_name=None, ingest_id=None, user_id=None):
    """

    :param flow_name:
    :param username:
    :param request:
    :param flag:
    :param entity_name:
    :param ingest_id:
    :param user_id:
    :return:
    """
    try:
        if request:
            entity_name = 'investigator'
            logger.error("in the get rules and validation from string function: " + str(entity_name))
    except Exception as e:
        logger.error("error in entity name in get rules and validation from string function!!!")
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Entity name not found'})
    rev_dict = dict()
    try:
        logger.error("in the rev dict area!!!")

        if entity_name == 'study':
            for k, v in settings.STUDY_COLUMN_DICT.items():
                rev_dict[v] = k
        elif entity_name == 'investigator':
            for k, v in settings.COLUMN_DICT.items():
                rev_dict[v] = k
        else:
            for k, v in settings.ORG_COLUMN_DICT.items():
                rev_dict[v] = k
        logger.error("rev dict: " + str(rev_dict))
        # for k, v in settings.COLUMN_DICT.items():
        #     rev_dict[v] = k
    except Exception as e:
        logger.error("error in entity name in get rules and validation from string function!!!")
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        connection.commit()
    try:
        if flag:
            try:
                logger.error('inside if flag')
                cursor = connection.cursor()
                logger.error("SELECT value, flow_id FROM flow WHERE username='{}' AND flow_name='{}' AND key='{}' "
                             "AND updated_date IS NULL and delete_flag='0'".format(
                    username, flow_name, 'validation'))
                cursor.execute("SELECT value, flow_id FROM flow WHERE username='{}' AND flow_name='{}' AND key='{}' "
                               "AND updated_date IS NULL and delete_flag='0'".format(
                    username, flow_name, 'validation'))
                value_and_flow = cursor.fetchall()[0]
                logger.error("if flag: " + str(value_and_flow))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                connection.commit()
            try:
                flow_id = value_and_flow[1]
                # request.session['flow_id'] = flow_id
                # cursor = connection.cursor()
                # cursor.execute("UPDATE ingestion SET flow_id='{}' WHERE ingest_id='{}'".format(flow_id,
                #                                                                                request.session['ingest_id']))
                validation_rules = value_and_flow[0]
                logger.error("validation rules: " + str(validation_rules))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                connection.commit()
        else:
            try:
                logger.error('else flag')
                cursor = connection.cursor()
                cursor.execute("SELECT value FROM flow WHERE flow_name='{}' AND key='validation' and "
                               "updated_date IS NULL and delete_flag='0'".format(flow_name))
                validation_rules = cursor.fetchall()[0][0]
                logger.error("else: " + str(validation_rules))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                connection.commit()
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        connection.commit()
    try:
        validation_rules = validation_rules.split(' and ')
        logger.error("validation_rules: "+ str(validation_rules))

        # Convert this v
        # last_name is not null and fst_name is not null and primary_mobile_num like '%+%' and
        # email_address ~ '[^@]+@[^@]+\.[^@]+'
        # last_name < '45' and fst_name is not null and primary_mobile_num like '%+%' and email_address ~ 'asd'
        # into this v
        # {u'LAST NAME': [u'Equals To', u'45'], u'FIRST NAME': [u'>', u'12'],
        # u'PRIMARY MOBILE NUMBER': [u'Contains', u'+'], u'EMAIL ADDRESS': [u'Regex', u'asd']},
        # u'FIRST NAME': [u'Not Null', u'12']
        rules = dict()
        rules['validation_rules'] = dict()
        for lst in validation_rules:
            if 'not null' in lst:
                k, v = lst.split(' is ')
                v = [v.strip()]
                logger.error("V:" + str(v))
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif '<' in lst:
                k, v = lst.split(' < ')
                v = ['<', v.strip()]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif '>' in lst:
                k, v = lst.split(' > ')
                v = ['>', v.strip()]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif '=' in lst:
                k, v = lst.split(' = ')
                v = ['Equals To', v.strip()]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif '!=' in lst:
                k, v = lst.split(' != ')
                v = ['Not Equals To', v.strip()]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif '~' in lst:
                k, v = lst.split(' ~ ')
                v = ['Regex', v.strip()]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v
            elif 'like' in lst:
                k, v = lst.split(' like ')
                v = ['Contains', v.strip('%')]
                rules['validation_rules'][rev_dict[k.lower().strip()]] = v

        logger.error("here")
        rules['matcher_rules'] = dict()
        if flag:
            try:
                cursor = connection.cursor()
                logger.error("SELECT value, rule FROM flow WHERE flow_name='{}' AND key='{}' and "
                               "updated_date IS NULL and delete_flag='0'".format(flow_name, 'rule'))
                cursor.execute("SELECT value, rule FROM flow WHERE flow_name='{}' AND key='{}' and "
                               "updated_date IS NULL and delete_flag='0'".format(flow_name, 'rule'))
                logger.error("this query works here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                data_ = cursor.fetchall()
                logger.error("data_ is:  " + str(data_))
                for idx, tup in enumerate(data_):
                    lst = tup[0].split(' and ')
                    lst = [rev_dict[i.strip()] for i in lst]
                    logger.error(str(lst))
                    rules['matcher_rules']['Rule ' + str(idx + 1)] = lst
                logger.error("Till here is code")
                logger.error("rules output: " + str(dict(rules, **json.loads(data_[0][1]))))
                return dict(rules, **json.loads(data_[0][1]))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                connection.commit()

        else:
            try:
                cursor = connection.cursor()
                logger.error("in else")
                logger.error("SELECT (value) FROM flow WHERE flow_name='{}' AND key='{}' and "
                               "updated_date IS NULL and delete_flag='0'".format(flow_name, 'rule'))
                cursor.execute("SELECT (value) FROM flow WHERE flow_name='{}' AND key='{}' and "
                               "updated_date IS NULL and delete_flag='0'".format(flow_name, 'rule'))
                logger.error("else part of query works here!!!!!!!!!!!!")

            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        ingest_id, user_id, json.dumps(k)))
                connection.commit()

        # Convert this v
        # fst_name and last_name
        # into this v
        # {u'Rule 1': [u'FIRST NAME', u'LAST NAME'], u'Rule 2': [u'LAST NAME']}

        data_ = cursor.fetchall()
        logger.error("data_ is:  " + str(data_))
        for idx, tup in enumerate(data_):
            lst = tup[0].split(' and ')
            lst = [rev_dict[i.strip()] for i in lst]
            logger.error(str(lst))
            rules['matcher_rules']['Rule ' + str(idx + 1)] = lst
        logger.error("rules output: " + str(rules))
        return rules
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                ingest_id, user_id, json.dumps(k)))
        connection.commit()


class ShowFlow(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error(entity_name)
            logger.error("flow list post called")
            data = json.loads(request.read().decode('utf-8'))
            if 'ingest_name' in data:
                var = data['ingest_name']
                username = request.session['username']
            else:
                var = data['flow_name']
                username = data['username']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        # try:
        #     entity_name = request.META['HTTP_ENTITY']
        #     logger.error(str(entity_name))
        # except Exception as e:
        #     logger.error("error in entity name in ShowFlow class!!!")
        #     return JsonResponse({'failure': 'Entity name not found'})
        try:
            if 'ingest_name' in data:
                # cursor = connection.cursor()
                # cursor.execute("SELECT VALUE FROM flow WHERE key='validation' AND flow_id=(SELECT flow_id FROM "
                #                "ingestion WHERE ingest_name='{}' AND username='{}')".format(var, username))
                # cursor = connection.cursor()
                # cursor.execute("SELECT VALUE FROM flow WHERE key='rule' AND flow_id=(SELECT flow_id FROM "
                #                "ingestion WHERE ingest_name='{}' AND username='{}')".format(var, username))
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT flow_id FROM ingestion WHERE ingest_name='{}' AND "
                                   "username='{}' where delete_flag = '0' and entity = '{}' ".format(var, username,
                                                                                                     entity_name))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                return JsonResponse(get_rules_and_validation_from_string(cursor.fetchall()[0][0], username, request,
                                                                         flag=0))
            else:
                logger.error(str(get_rules_and_validation_from_string(var, username, request)))
                return JsonResponse(get_rules_and_validation_from_string(var, username, request))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})


class EditFlow(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})

    @staticmethod
    def get(request, flow_name):
        """

        :param request:
        :param flow_name:
        :return:
        """
        try:
            username = request.session['username']
            cursor = connection.cursor()
            logger.error("username: " + str(username))
            try:
                logger.error("SELECT flow_id FROM flow WHERE username='{}' AND flow_name='{}' AND "
                               "key='{}' and updated_date IS NULL and delete_flag='0'".format(username,
                                                                                              flow_name, 'validation'))
                cursor.execute("SELECT flow_id FROM flow WHERE username='{}' AND flow_name='{}' AND "
                               "key='{}' and updated_date IS NULL and delete_flag='0'".format(username,
                                                                                              flow_name, 'validation'))
                logger.error("query run !!!!")
                flow_id = cursor.fetchall()
                # flow_id = cursor.fetchall()[0]
                logger.error("flow_id: " + str(flow_id))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error("flow_id: " + str(flow_id))
            rules = get_rules_and_validation_from_string(flow_name, username, request, flag=0)
            logger.error("rules: " + str(rules))
            request.session['rules'] = rules
            request.session['edit'] = True
            return JsonResponse(rules)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'You are not the owner of this flow.'})


class UseExistingFlow(APIView):
    """

    """

    @staticmethod
    def post(request=None, entity_name=None, steward_id=None, flow_id=None, flow_name=None, username=None, ingest_id=None, ingest_name=None,
             user_id=None, root_source_id=None, flow_scope=None, scheduler_flag=None, schedule_ingest_id=None):
        """

        :param request:
        :return:
        """
        try:
            if request:
                data = json.loads(request.read().decode('utf-8'))
                logger.error("data in the run flow: " + str(data))
                flow_name = data['flow_name']
                username = data['username']
                page_number = data['page']
                ingest_id = request.session.get('ingest_id', ingest_id),
                user_id = request.session.get('user_id', user_id),
            # logger.error("flow_name: " + flow_name)
            # logger.error("page_number: " + str(page_number))
            # logger.error("username: " + username)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, user_id, json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, user_id, json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        # try:
        #     entity_name = request.META['HTTP_ENTITY']
        #     logger.error(str(entity_name))
        # except Exception as e:
        #     logger.error("error in entity name in UseExistingFlow class!!!")
        #     return JsonResponse({'failure': 'Entity name not found'})
        try:
            if request:
                flow_flags(request.session.get('ingest_id', ingest_id), request.session.get('source_user_id', user_id), '5')
            elif schedule_ingest_id:
                flow_flags(schedule_ingest_id, user_id, '5')
            else:
                logger.error("here")
                flow_flags(ingest_id, user_id, '5')
            # logger.error(str(request.session['ingest_id']) + " " + str(request.session['source_user_id']))

            rules = get_rules_and_validation_from_string(flow_name, username, request, entity_name=entity_name, user_id=user_id, ingest_id=ingest_id)
            logger.error("rules in existing flow: " + str(rules))
            # request.session['rules'] = rules
            # request.session['edit'] = False
            # logger.error("now will call the post method of validator class")
            var = Standardization().get(request, ingest_id=ingest_id, entity_name=entity_name, schedule_ingest_id=schedule_ingest_id)
            logger.error("rules in existing flow: " + str(rules))
            var2 = ValidatorClass().post(request, rules=rules, entity_name=entity_name,flow_id=flow_id, edit_flag=False, uid=user_id,ingest_id=ingest_id,
                                         source_root_id=root_source_id, flow_name=flow_name, scope=flow_scope, username=username,
                                         ingest_name=ingest_name, dm_uid=user_id, scheduler_flag=scheduler_flag, schedule_ingest_id=schedule_ingest_id)
            logger.error(str((str(var2.content))))
            return JsonResponse(json.loads(var2.content.decode('utf-8')), safe=False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', ingest_id), request.session.get('user_id', user_id),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', ingest_id),
                    request.session.get('user_id', user_id), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})

    @staticmethod
    def get(request, flow_page_number = None):
        """

        :param request:
        :param flow_page_number:
        :return:
        """
        try:
            # flow_page_number = 1
            logger.error("page_number: " + str(flow_page_number))
            # data = json.loads(request.read().decode('utf-8'))
            # flow_page_number = data['page']
            uid = request.session['user_id']
            logger.error("here1")
            try:
                logger.error("select count(distinct(flow_name)) from flow where access_type = 'public' and "
                               " updated_date is NULL and delete_flag = '0'")
                cursor = connection.cursor()
                cursor.execute("select count(distinct(flow_name)) from flow where access_type = 'public' and "
                               " updated_date is NULL and delete_flag = '0'")
                total_public = cursor.fetchall()[0][0]
                logger.error("total public: "+ str(total_public))
                cursor.execute("select count(distinct(flow_name)) from flow where access_type = 'private' and "
                               "uid = '{}' and  updated_date is NULL and delete_flag = '0'".format(uid))
                total_private = cursor.fetchall()[0][0]
                logger.error("total private: "+ str(total_private))

                total = total_private + total_public
                logger.error("total: "+ str(total))

                # logger.error("SELECT DISTINCT(flow_name), username, '0' FROM flow WHERE access_type='public' and "
                #                "updated_date IS NULL and delete_flag = '0' limit 10 offset {}".format(int(flow_page_number) * 10 - 10))
                cursor = connection.cursor()
                cursor.execute("SELECT DISTINCT(flow_name), username, '0' FROM flow WHERE access_type='public' and "
                               "updated_date IS NULL and delete_flag = '0'")
                public_flow = cursor.fetchall()

                logger.error("data public: "+ str(public_flow))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # logger.error("here2: "+ str(public_flow))
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT DISTINCT(flow_name), username, '1' FROM flow WHERE access_type='private' AND "
                               "uid='{}' and updated_date IS NULL and delete_flag = '0' ".format(uid))
                private_flow = cursor.fetchall()
                logger.error("data private : " + str(private_flow))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                # logger.error("here3: " + str(private_flow))
                all_flows = private_flow + public_flow
                logger.error("all_flows: "+ str(all_flows))
                d = dict()
                # d['total'] = len(all_flows)
                d['total'] = int(total)
                lst = list()
                for tup in all_flows[(int(flow_page_number) - 1)*10 : int(flow_page_number) * 10 ]:
                    logger.error(str(tup[0]) + " and " + str(tup[1]))
                    try:
                        cursor = connection.cursor()
                        cursor.execute("SELECT uid, flow_engage_lock FROM flow WHERE flow_name='{}' AND delete_flag = '0' AND"
                                       " uid=(SELECT user_id::INT FROM users WHERE username='{}')".format(str(tup[0]),
                                                                                                          str(tup[1])))

                        data = cursor.fetchall()
                        logger.error("data after: "+ str(data))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error(str(data))
                    di = dict()
                    for t in data:
                        uid, flow_engage_lock = t
                        if flow_engage_lock == '1':
                            di['editable'] = False
                            break
                    else:
                        di['editable'] = True
                    di['flow_name'] = str(tup[0])
                    di['username'] = str(tup[1])
                    if tup[2] == "1":
                        di['access_type'] = "Private"
                    else:
                        di['access_type'] = "Public"
                    lst.append(di)
                d['list'] = lst
                return JsonResponse(d)
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})


class ShowStewards(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT username, user_id FROM users WHERE delete_flag != '1' AND "
                           "role LIKE '%3%' OR role LIKE '%1%' ")
            ui_information = list()
            for idx, tup in enumerate(cursor.fetchall()):
                ui_information.append({'username': tup[0], 'user_id': tup[1]})
            return JsonResponse(ui_information, safe=False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No steward to find'})

    # @staticmethod
    # def post(request):
    #     """
    #
    #     :param request:
    #     :return:
    #     """
    #     try:
    #         data = json.loads(request.read().decode('utf-8'))
    #         obj = data['steward_id']
    #         logger.error("obj: " + str(obj))
    #         steward_id = obj['user_id']
    #         logger.error("steward_id: " + str(steward_id))
    #         source_uid = data['source_uid']
    #         ingest_name = data['ingest_name']
    #     except Exception as e:
    #         logger.error(str(e))
    #         k = dict()
    #         k['Error'] = str(e).replace("'", '"')
    #         # k = json.dumps(k)
    #         cursor = connection.cursor()
    #         logger.error(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #         cursor.execute(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1),
    #                 request.session.get('user_id', -1), json.dumps(k)))
    #         connection.commit()
    #         return JsonResponse({'failure': 'No data found in body.'})
    #     try:
    #         request.session['steward_id'] = steward_id
    #         try:
    #             cursor = connection.cursor()
    #             cursor.execute("UPDATE ingestion SET steward_id='{}' WHERE ingest_id=(SELECT ingest_id FROM ingestion "
    #                            "WHERE ingest_name='{}' AND uid='{}' AND delete_flag='0')".format(steward_id, ingest_name,
    #                                                                                              source_uid))
    #         except Exception as e:
    #             logger.error(str(e))
    #             k = dict()
    #             k['Error'] = str(e).replace("'", '"')
    #             # k = json.dumps(k)
    #             cursor = connection.cursor()
    #             logger.error(
    #                 """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                     request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #             cursor.execute(
    #                 """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                     request.session.get('ingest_id', -1),
    #                     request.session.get('user_id', -1), json.dumps(k)))
    #             connection.commit()
    #     except Exception as e:
    #         logger.error(str(e))
    #         k = dict()
    #         k['Error'] = str(e).replace("'", '"')
    #         # k = json.dumps(k)
    #         cursor = connection.cursor()
    #         logger.error(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #         cursor.execute(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1),
    #                 request.session.get('user_id', -1), json.dumps(k)))
    #         connection.commit()
    #         return JsonResponse({'failure': 'Failure'})
    #     return JsonResponse({'ok': 'Success'})


class ShowDataManager(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        try:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT username, user_id FROM users WHERE  delete_flag != '1' AND (role like '%4%' "
                               "OR role like '%1%')")
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            ui_information = list()
            for idx, tup in enumerate(cursor.fetchall()):
                ui_information.append({'username': tup[0], 'user_id': tup[1]})
            return JsonResponse(ui_information, safe=False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No steward to find'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            data_manager_id = data['data_manager_id']
            request.session['data_manager_id'] = data_manager_id['user_id']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        return JsonResponse({'ok': 'Success'})


def mapping_data(request):
    """

    :param request:
    :return:
    """
    try:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_name FROM ingestion WHERE ingest_id='{}' AND uid='{}' "
                           "and delete_flag != '1'".format(request.session['ingest_id'], request.session['user_id']))
            var = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        logger.error("var is: " + str(var))
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT  source_name, conn_method,  data_mapping, header, source_id from ingestion_sources "
                           "where"
                           " ingest_id = '{}'".format(request.session['ingest_id']))
            # cursor.execute(
            #     "SELECT  source_name, conn_method,  header, source_id from ingestion_sources where"
            #     " ingest_id = '{}'".format(request.session['ingest_id']))
            var2 = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        logger.error("var2 is: " + str(var2))
        dicto = dict()
        dicto['ingest_name'] = var[0][0]
        dicto['sources'] = dict()

        for j in var2:
            logger.error(str(type(j[2])))
            dicto['sources'][j[0]] = {'source_id': str(j[4]), 'mapping': j[2], 'conn_method': str(j[1])}
            dicto['sources'][j[0]]['header'] = j[3].split(',')
        # dicto['keys_amazons3'] = request.session['objs']
        # for j in var2:
        #     source_name = str(j[0])
        #     dicto['sources'][source_name] = dict()
        #     for k, v in zip(['conn_method', 'mapping', 'header', 'source_id'], j[1:]):
        #         dicto['sources'][source_name][k] = v

        # = {'source_id': j[4], 'header': j[3].split(request.session['delimiter']),
        #                          'mapping': None, 'conn_method': j[1]}
        logger.error("Dict: " + str(dicto))
        return JsonResponse(dicto)
    except Exception as e:
        logger.error("Before here")
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Failure in mapping_data'})


def validate_regex(request):
    """

    :param request:
    :return:
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        regex_string = data['regex_string']
    except KeyError as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'regex string not found'})

    try:
        regex = re.compile(regex_string)
    except re.error as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Regex not valid'})
    return JsonResponse({'ok': 'Success'})


def user_info(request, uid):
    """

    :param request:
    :param uid:
    :return:
    """
    try:
        try:
            cursor = connection.cursor()
            logger.error("Entered here !!")
            cursor.execute("SELECT user_id, username, email_address, role, name, reset_flag FROM users "
                           "WHERE user_id='{}' and delete_flag != '1'".format(uid))
            var = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({"failure": 'Failure no uid comes from user without uid function'})
        if var:
            role = [int(i) for i in var[0][3].split(',')]
            request.session['role'] = role
            return JsonResponse({'user_id': var[0][0], 'username': var[0][1], 'email': var[0][2],
                                 'role': role, 'name': var[0][4], 'reset_flag': var[0][5]})
        else:
            return JsonResponse({"failure": 'SQL exception'})
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({"failure": 'Failure'})


def user_info_without_uid(request):
    """

    :param request:
    :return:
    """
    uid = request.session.get('user_id', -1)
    logger.error("uid info: " + str(uid))
    return user_info(request, uid)


def create_ingestion(request):
    """

    :param request:
    :param ingestion_name:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error(str(entity_name))
        data = json.loads(request.read().decode('utf-8'))
        logger.error("data: " + str(data))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Enter mandatory fields.'})

    _ingest_name = data['ingest_name']
    if _ingest_name:
        try:
            _ingest_name = data['ingest_name']
            # request.session['ingest_name'] = _ingest_name
            if 'columns_for_validation' in request.session:
                del request.session['columns_for_validation']
        except KeyError as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Cannot find ingest name in request'})
    # try:
        uid = request.session['user_id']
        user_name = request.session['username']
        data_manager_id = request.session['data_manager_id']
        # length = 12
        # chars = string.ascii_letters + string.digits + '!@#$%^&*()'
        # random.seed = (os.urandom(1024))
        # value = ''.join(random.choice(chars) for _ in range(length))
        # if ingestion_name:
        # _ingest_name = ''.join(random.choice(chars) for _ in range(length))
        # request.session['ingest_id'] = value
        # else:
        # value = value + request.session.session_key
        # request.session['ingest_id'] = value
        # entity_name = 'investigator'

        logger.error(str(_ingest_name))
        try:
            cursor = connection.cursor()
            cursor.execute("INSERT INTO ingestion(uid, username, ingest_name, data_manager_id, entity) VALUES "
                           "('{}', '{}', '{}', '{}', '{}')".format(uid, user_name, _ingest_name, data_manager_id, entity_name))
            connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Ingestion name already exists.'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_id FROM ingestion WHERE uid='{}' AND username='{}' AND ingest_name='{}' AND "
                           "data_manager_id='{}' "
                           "and delete_flag != '1' and entity = '{}'".format(uid, user_name, _ingest_name,
                                                                             data_manager_id, entity_name))
            value = cursor.fetchall()[0][0]
            if value:
                request.session['ingest_id'] = value
                request.session['ingest_name'] = _ingest_name
                request.session['ingest_id'] = value
                flow_flags(value, uid, '1')
                return JsonResponse({'ok': 'Ingestion id created'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Ingestion ID not created.'})
    else:
        return JsonResponse({'failure': 'Error in creating Ingestion.'})

        # request.session['ingest_id'] = value
    # except Exception as e:
    #     logger.error(str(e))
    #     k = dict()
    #     k['Error'] = str(e).replace("'", '"')
    #     # k = json.dumps(k)
    #     cursor = connection.cursor()
    #     logger.error(
    #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #     cursor.execute(
    #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #             request.session.get('ingest_id', -1),
    #             request.session.get('user_id', -1), json.dumps(k)))
    #     connection.commit()
    #     return JsonResponse({'failure': 'Ingest name already exists'})



class SystemStorage(FileSystemStorage):
    """

    """

    def __init__(self, location=None, base_url=None, file_permissions_mode=None,
                 directory_permissions_mode=None):
        """

        :param location:
        :param base_url:
        :param file_permissions_mode:
        :param directory_permissions_mode:
        """
        super().__init__(location, base_url, file_permissions_mode,
                         directory_permissions_mode)
        self._location = location
        self._base_url = base_url
        self._file_permissions_mode = file_permissions_mode
        self._directory_permissions_mode = directory_permissions_mode

    @override(FileSystemStorage)
    def get_available_name(self, name, max_length=None):
        """
        Returns a filename that's free on the target storage system, and
        available for new content to be written to.
        
        :param name:
        :param max_length:
        :return:
        """

        dir_name, file_name = os.path.split(name)
        file_root, file_ext = os.path.splitext(file_name)
        # If the filename already exists, add an underscore and a random 7
        # character alphanumeric string (before the file extension, if one
        # exists) to the filename until the generated filename doesn't exist.
        # Truncate original name if required, so the new filename does not
        # exceed the max_length.
        # while self.exists(name) or (max_length and len(name) > max_length):
        name = os.path.join(dir_name, "%s_%s%s" % (file_root, int(time.time()), file_ext))
        while self.exists(name) or (max_length and len(name) > max_length):
            # file_ext includes the dot.
            name = os.path.join(dir_name, "%s_%s%s" % (file_root, int(time.time()), file_ext))
            if max_length is None:
                continue
            # Truncate file_root if max_length exceeded.
            truncation = len(name) - max_length
            if truncation > 0:
                file_root = file_root[:-truncation]
                # Entire file_root was truncated in attempt to find an available filename.
                if not file_root:
                    raise SuspiciousFileOperation(
                        'Storage can not find an available filename for "%s". '
                        'Please make sure that the corresponding file field '
                        'allows sufficient "max_length".' % name
                    )
                name = os.path.join(dir_name, "%s_%s%s" % (file_root, int(time.time()), file_ext))
        return name


class AutoMapping(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            # logger.error(str(data))
            # data = {'key1':['one', 'two', 'three'], 'key2':['pen','ink','paper']}
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found.'})
        try:

            matrix = list()
            for source in data['source']:
                for target in data['target']:
                    score = fuzz.ratio(str(source).lower(), str(target).lower())
                    matrix.append((source, target, score))

            matrix = sorted(matrix, key=lambda x: x[2], reverse=True)
            matrix = list(filter(lambda x: x[2] >= 75, matrix))
            # logger.error(str(matrix))

            ret = list()
            used = set()
            for source, target, score in matrix:
                if source not in used and target not in used:
                    d = dict()
                    d['source'] = source
                    d['target'] = target
                    ret.append(d)
                    used.add(source)
                    used.add(target)
            logger.error(str(ret))

            #########################################
            # Previous code                         #
            #########################################

            # target_col = list()
            # ui_information = dict()
            # for s in data['target']:
            #     target_col.append(s)
            #
            # logger.error(str(data['source']))
            # logger.error(str(data['target']))
            # logger.error(str(len(data['source'])))
            # logger.error(str(len(data['target'])))
            #
            # for source in data['source']:
            #     for target in data['target']:
            #         if target in target_col:
            #
            #             score = fuzz.ratio(str(source).lower(), str(target).lower())
            #             if source in ui_information and score > ui_information[source][1]:
            #                 ui_information[source] = [target, score]
            #             elif source not in ui_information:
            #                 ui_information[source] = [target, score]
            #     target_col.remove(ui_information[source][0])
            #     if len(target_col) == 0:
            #         break
            #
            # logger.error(str(ui_information))
            #
            # ret = list()
            # for k, v in ui_information.items():
            #     if v[1] > 75:
            #         d = dict()
            #         d['source'] = k
            #         d['target'] = v[0]
            #         ret.append(d)
            # logger.error(str(ret))

            return JsonResponse(ret, safe=False)

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Not able to auto-map'})


class SourceFileReader(APIView):

    @staticmethod
    def post(request):
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error(str(entity_name))
            data = json.loads(request.read().decode('utf-8'))
            if data['conn_method'] == 'db_connection':
                dbname = data['database_name']
                port = data['port']
                host = data['host_name']
                user = data['username']
                password = data['password']
                db_table = data['table_name']
                custom_source_name = data['custom_source_name']
                source_priority = data['source_priority']
                try:
                    conn = psycopg2.connect(dbname=dbname, user=user, host=host,
                                            password=password, port=port)
                    cursor = conn.cursor()
                    cursor.execute(
                        "SELECT column_name, data_type FROM information_schema.columns where table_name  = '{}' ORDER  BY ordinal_position ".format(
                            db_table))
                except Exception as e:
                    logger.error("Table not found in database")
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                    return JsonResponse({'error': 'Error in establishing connection '})
                else:
                    conn_string = '{'
                    for k, v in data.items():
                        if not k == 'custom_source_name':
                            conn_string = conn_string + '"' + str(k) + '":"' + str(v) + '", '
                    conn_string = conn_string[:-2]
                    conn_string += '}'
                    try:
                        cursor = connection.cursor()
                        cursor.execute("INSERT INTO admin_sources (source_root_name, conn_method, conn_string, "
                                       "source_priority) values('{}', '{}', '{}', '{}') ".format(custom_source_name, 'db_connection'
                                        ,conn_string, source_priority))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    return JsonResponse({"success": 'Connection Successful'})
            # else:

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'Failure': 'No data Found '})


class CsvFileReader(APIView):
    """

    """

    @staticmethod
    def post(request):
        """ 
        :param entity: 
        :param request:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error(str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        if request.FILES['file']:
            misfile = request.FILES['file']
            fs = SystemStorage()
            filename = fs.save(misfile.name, misfile)
            logger.error("fiilename: "+ str(filename))
            # if entity_name == 'study':
            #     logger.error("Inside study")
            #     path = getattr(settings, "STUDY_MEDIA_ROOT", settings.BASE_DIR + "/study_media/")
            # elif entity_name == 'site':
            #     path = getattr(settings, "SITE_MEDIA_ROOT", settings.BASE_DIR + "/site_media/")
            # elif entity_name == 'sponsor':
            #     path = getattr(settings, "SPONSOR_MEDIA_ROOT", settings.BASE_DIR + "/sponsor_media/")
            # else:
            path_static = getattr(settings, "MEDIA_ROOT", settings.BASE_DIR + "/media/")
            path_static += str(filename)
            # Backup original file into orig.csv and original file path into orig_path
            # logger.error("path: "+ str(path_static))
            os.system("cp " + path_static + " orig.csv")
            # orig_path = path_static
            # logger.error("path: "+ str(path_static))
            # logger.error("orig path: "+ str(orig_path))
            # Create a detector which will try to detect the encoding of the file
            try:
                path = ''
                if entity_name == 'study':
                    # logger.error("Inside study")
                    path = getattr(settings, "STUDY_MEDIA_ROOT", settings.BASE_DIR + "/study_media/")
                elif entity_name == 'investigator':
                    path = getattr(settings, "MEDIA_ROOT", settings.BASE_DIR + "/media/")
                else:
                    path = getattr(settings, "ORG_MEDIA_ROOT", settings.BASE_DIR + "/org_media/")
                # path += filename
                detector = UniversalDetector()
                # logger.error("path_static :" + str(path_static))
                # tmp = "/home/arnav/Vitrana-Product/Mdm/src/Postgres_Django/media/S3_XYZ_1493022179.csv"
                for line in open(path_static, 'rb').readlines():
                    detector.feed(line)
                    if detector.done:
                        break
                detector.close()
                # get the encoding of the file and then run iconv -f command to change encoding into utf-8
                # and save the output into temp_foobar.csv file.
                # After that rename that file into original file name
                encoding = detector.result['encoding']
                os.system('iconv -f ' + encoding + ' -t utf-8 ' + path_static + ' > temp_foobar.csv')
                os.system('mv temp_foobar.csv ' + path_static)
                os.system('mv ' + path_static + ' ' + path)
            except Exception as e:
                # If an exception occur recover the original file from backup
                logger.error("Exception while trying to change the encoding")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
                # os.system("mv orig.csv " + orig_path)

            # Set the execute permission.
            if entity_name == 'study':
                os.system("chmod a+rX " + settings.STUDY_MEDIA_ROOT + " " + path)
            elif entity_name == 'investigator':
                os.system("chmod a+rX " + settings.MEDIA_ROOT + " " + path)
            else:
                os.system("chmod a+rX " + settings.ORG_MEDIA_ROOT + " " + path)
            uid = request.session['user_id']
            connection_type = 'file_browser'

            try:
                # path += str("temp_foobar.csv")
                path += filename
                header = headerCSV(path, request)
                if header:
                    pass
                else:
                    raise TypeError("Cannot find header")
                length = 12
                chars = string.ascii_letters + string.digits + '!@#$%^&*()'
                random.seed = (os.urandom(1024))
                source_id = ''.join(random.choice(chars) for _ in range(length))
                sourcename = path.split("/")[-1]
                logger.error(str(sourcename))
                new_source = sourcename.split('_')  # new_source = ['S1','Epsilon','<timestamp>.csv']
                new_list = new_source[:-1]  # ['S1','Epsilon']
                try:
                    cursor = connection.cursor()
                    logger.error("source_site_name: " + str(new_list[-1]))
                    cursor.execute("SELECT func_fetch_source_priority('{}')".format(new_list[-1]))
                    logger.error(str("source priority is working fine"))
                    s_priority = str(cursor.fetchall()[0][0])
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                print("s_priority: ")
                print(s_priority)
                try:
                    cursor = connection.cursor()
                    cursor.execute("INSERT INTO ingestion_sources(source_id, ingest_id, uid, conn_method, conn_string, "
                                   "source_name, header, source_priority) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', "
                                   "'{}','{}')".format(source_id, request.session['ingest_id'], uid, connection_type, path,
                                                       sourcename, header, s_priority))
                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                logger.error(str(" insert query work well!!!"))
                request.session['source_id'] = source_id
                logging.debug("Values inserted into ingestion table")

            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

            logger.error("Path of file: " + str(path))
            request.session['file'] = str(path)
            flow_flags(request.session['ingest_id'], uid, '2')

        return JsonResponse({'ok': 'success'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


class CsvMapping(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity name: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            data_mapping = data['data_mapping']
            logger.error("data_mapping: " + str(data_mapping))
            concate_key = data['concate']
            # logger.error("concat key: "+ str(concate_key))
            concate_key_copy = concate_key
            substring = data['substring']
            decode = data['decode']
            upper_case = data['uppercase']
            lower_case = data['lowercase']
            conn_type = data['connection_type']
            # storing conn type in session variable
            request.session['conn_type'] = conn_type
            source_id = data['source_id']
            try:
                cursor = connection.cursor()
                source_root_name = request.session['custom_source_name']
                logger.error("source_root_name: " + str(source_root_name))
                #TODO fetch custom source name, conn_string from ingestion_sources where source_id = '{}'
                logger.error("SELECT source_root_id, conn_string, last_load_date from admin_sources"
                               " where source_root_name = '{}'".format(source_root_name))
                cursor.execute("SELECT source_root_id, conn_string, last_load_date from admin_sources"
                               " where source_root_name = '{}'".format(source_root_name))
                data = cursor.fetchall()
                logger.error("data: " + str(data))
                # cursor.execute("SELECT source_root_name, conn_string FROM admin_sources WHERE source_id='{}'".format(source_id))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            root_source_id = ''
            conn_string = ''
            last_load_date = ''
            for i in data:
                root_source_id = i[0]
                conn_string = i[1]
                last_load_date = i[2]
            logger.error("source_root_name : " + str(source_root_name))
            logger.error("conn string  : " + str(conn_string))
            logger.error("last load date  : " + str(last_load_date))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found in the body.'})
        try:
            if 'columns_for_validation' not in request.session:
                request.session['columns_for_validation'] = list()
            mapping = dict()
            col_datatype = dict()
            org_column_form_port = list()
            for d in data_mapping:
                mapping[str(d['fromPort'])] = str(d['toPort'])
                if d['toPort'] == 'ORG TYPE' and entity_name in ['org', 'site', 'sponsor']:
                    org_column_form_port.append(d['fromPort'].lower())
                if d['toPort'] not in request.session['columns_for_validation']:
                    request.session['columns_for_validation'].append(d['toPort'])
            logger.error("mapping : " + str(mapping))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        try:
            if conn_type == 'Amazon_S3_bucket':
                try:
                    cursor = connection.cursor()
                    stage_table = ''
                    if entity_name == 'study':
                        table_name = getattr(settings, "STAGE_STUDY", "stage_study")
                        landing_table_name = 'landing_study'
                        temp_landing_table = "temp_landing_study"
                    elif entity_name == 'investigator':
                        logger.error("Inside investigator!!!")
                        table_name = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                        temp_landing_table = "temp_landing_investigator"
                        landing_table_name = 'landing_investigator'
                    else:
                        table_name = getattr(settings, "STAGE_ORG", "stage_org")
                        temp_landing_table = "temp_landing_org"
                        landing_table_name = 'landing_org'
                    user_id = request.session['user_id']
                    ingest_id = request.session['ingest_id']
                    try:
                        cursor = connection.cursor()
                        logger.error("Before query!!")
                        #TODO need to put if else here
                        cursor.execute("DELETE FROM \"{}\" WHERE ingest_id='{}' AND uid='{}' AND "
                                       "ingest_source_id='{}'".format(landing_table_name, ingest_id, user_id, source_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        logger.error("after query !!!")
                        cursor.execute("UPDATE ingestion_sources SET status_flag=NULL WHERE "
                                       "source_id='{}' AND ingest_id = '{}' AND delete_flag='0'".format(source_id, ingest_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("after update query!!")

                    # TODO REMOVE static path of csv file and write this "request.session['file']"
                    to_columns = ''
                    # if entity_name == 'org':
                    #     for key, value in mapping
                    for name in mapping.values():
                        # logger.error("inside mapping.values,name: "+ str(name))
                        if entity_name == 'study':
                            to_columns = to_columns + settings.STUDY_COLUMN_DICT[name.upper()] + ', '
                        elif entity_name == 'investigator':
                            to_columns = to_columns + settings.COLUMN_DICT[name.upper()] + ', '
                        else:
                            to_columns = to_columns + settings.ORG_COLUMN_DICT[name.upper()] + ', '
                    # logger.error("to_column before -2 : " + str(to_columns))
                    to_columns = to_columns[:-2]
                    # logger.error("to_column: " + str(to_columns))
                    # from_columns = ', '.join(mapping.keys())
                    from_columns = ''
                    for k in mapping.keys():
                        from_columns = from_columns + '"' + str(k) + '", '
                    from_columns = from_columns[:-2]

                    # logger.error("from_column: " + str(from_columns))
                    try:
                        cursor = connection.cursor()
                        logger.error("Select query !!!!")
                        cursor.execute("SELECT source_root_id from admin_sources where "
                                       "source_root_name = '{}'".format(source_root_name))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("after select query !!!!!")

                    if len(concate_key) == 0:
                         logger.error("no data for concat comes!!!")
                    else:
                        try:
                            target_column_key = concate_key.keys()
                            target_column_key = list(target_column_key)
                            target_column_key_temp = list()
                            for h in target_column_key:
                                # logger.error("h is: " + str(h))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                else:
                                    name = settings.ORG_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))

                            target_column_key = target_column_key_temp
                            # logger.error("target column key : " + str(target_column_key))
                            source_column_values = concate_key.values()
                            source_column_values = list(source_column_values)
                            source_column_values_copy = copy.deepcopy(source_column_values)

                            for k, v in enumerate(concate_key_copy):
                                source_column_values_copy[k].append(v)

                            # logger.error("HERE source value" + str(source_column_values))
                            cate_string = 'concat'
                            list_of_target_column = []
                            for i in source_column_values:
                                cate_string = cate_string + '(' + ", ' ' , ".join(['"' + foo + '"' for foo in i]) + ')'
                                list_of_target_column.append(cate_string)
                                cate_string = 'concat'

                            # uncomment below 5 lines and comment above 6 lines
                            # list_of_target_column_seperator = list()
                            # assert(len(seperator) == len(source_column_values))
                            # for names, sep in zip(source_column_values, seperator):
                            #     stri = 'concat(' + names[0] + ', ' + sep + ', ' + names[1] + ')'
                            #     list_of_target_column_seperator.append(stri)

                            # logger.error("list of target column for concat: " + str(list_of_target_column))
                            # logger.error("list of target column list : " + str(list_of_target_column_seperator))
                            my_string = ", ".join(list_of_target_column)
                            #remove above line of code and uncomment below line
                            # my_string = ", ".join(list_of_target_column_seperator)
                            logger.error("MY STRING   :  "  + str(my_string))
                            from_columns += ', ' + my_string
                            # logger.error("from_column after concat: " + str(from_columns))
                            add_to_target_string = ", ".join(target_column_key)
                            to_columns += ', ' + add_to_target_string
                            logger.error("done!!!!! concat work")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in concat!!!!!!!!!!")

                    if len(substring) == 0:
                        logger.error("No data for substring!!!")
                    else:
                        try:

                            f_string_for_substring_target = ''
                            substring_column_list, substring_target_list = list(), list()
                            logger.error("SUBSTRING  =  " + str(substring))
                            for i in substring:
                                final_string_for_substring = 'substring'
                                s_name = i['source_name']
                                pos = i['position']
                                len_sub = i['length']
                                targ = i['target_name']
                                final_string_for_substring += '("' + s_name + '", ' + str(pos) + ', ' + \
                                                              str(len_sub) + ')'
                                logger.error("final_string_for_substring: " + final_string_for_substring)
                                substring_column_list.append(final_string_for_substring)
                                # logger.error("substring column list: " + str(substring_column_list))
                                # final_string_for_substring = 'substring'
                                f_string_for_substring_target += targ.lower()
                                # logger.error("f_string_for_substring_target: " + f_string_for_substring_target)
                                substring_target_list.append(f_string_for_substring_target)
                                # logger.error("substring_target_list: " + str(substring_target_list))
                                f_string_for_substring_target = ''

                            logger.error("substring_column_list after loop: " + str(substring_column_list))
                            # ['substring(s_name, 15, 70)', 'substring(s_name_1, 16, 98)']
                            # logger.error("substring_target_list after loop: " + str(substring_target_list))
                            # ['t_name', 't_name_1']
                            new_string = ', '.join(substring_column_list)
                            from_columns += ', ' + new_string
                            # logger.error("from_column after substring: " + from_columns)

                            substring_target_list_temp = list()
                            for h in substring_target_list:
                                # logger.error("h is in substring: " + str(h))
                                # logger.error(str(mapping))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for study: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for study: " + str(substring_target_list_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for inv: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for inv: " + str(substring_target_list_temp))

                                else:
                                    name = settings.ORG_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for org: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for org:" + str(substring_target_list_temp))

                            substring_target_list = substring_target_list_temp
                            # logger.error("substring target list after loop: " + str(substring_target_list))
                            new_string_target = ', '.join(substring_target_list)
                            to_columns += ', ' + new_string_target
                            # logger.error("to_column after substring: " + to_columns)
                            # logger.error("Substring done!!!!!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in substring!!!!")
                    if len(upper_case) == 0:
                        logger.error("Upper case length is zero.")
                    else:
                        logger.error("uppercase :  "+ str(upper_case))
                        final_string = ''
                        target_column_list = list()
                        for key, value in upper_case.items():
                            final_string += 'UPPER("' + str(key) + '")' + " , "
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            else:
                                name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                        logger.error(str(final_string))
                        logger.error(str(target_column_list))
                        from_columns += ", " + final_string[:-2]
                        if len(target_column_list) == 1:
                            to_columns += ", " + target_column_list[0]
                        else:
                            to_columns += ", " + ", ".join(target_column_list)
                    if len(lower_case) == 0:
                        logger.error("Lower case length is zero.")
                    else:
                        logger.error("lowercase :  "+ str(lower_case))

                        final_string = ''
                        target_column_list = list()
                        for key, value in lower_case.items():
                            final_string += 'LOWER("' + str(key) + '")' + " , "
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            else:
                                name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                        logger.error(str(final_string))
                        logger.error(str(target_column_list))
                        from_columns += ", " + final_string[:-2]
                        if len(target_column_list) == 1:
                            to_columns += ", " + target_column_list[0]
                        else:
                            to_columns += ", " + ", ".join(target_column_list)
                    if len(decode) == 0:
                        logger.error("Decode length is zero")
                    else:
                        try:
                            final_string = 'case '
                            target_column_list = list()
                            logger.error("decode   :  " + str(decode))
                            # For each dict in decode list
                            for d in decode:
                                source_name = d['source_name']
                                final_string = final_string + 'when "' + source_name + '" = '

                                # Iterate over all the items, do nothing if this is source or target else
                                # do string manipulation
                                logger.error("Final string loop 1 : " + str(final_string))
                                for k, v in d.items():
                                    if k == 'source_name':
                                        continue
                                    elif k == 'target_name':
                                        target_column_list.append(v)
                                    else:
                                        final_string = final_string + "'" + k + "' then '" + v + "' when \"" + \
                                                       source_name + "\" = "
                                        logger.error("final string second loop  :  " + str(final_string))
                                logger.error("final string final  :  " + str(final_string))
                                final_string = final_string.split(' when ')[:-1]
                                final_string = ' when '.join(final_string)
                                final_string = final_string + ' else "' + source_name + '" end, case '
                            final_string = final_string[:-7]
                            logger.error("last final string  : " + str(final_string))
                            target_column_key_temp = list()
                            for h in target_column_list:
                                # logger.error("h is: " + str(h))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                else:
                                    name = settings.ORG_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))

                            # Join all target list
                            target_column_key_temp = ','.join(target_column_key_temp)
                            # logger.error("Final String: " + str(final_string))
                            logger.error("target column list: " + str(target_column_key_temp))
                            from_columns += ', ' + final_string
                            # logger.error("from column after decode : " + from_columns)
                            to_columns += ', ' + target_column_key_temp
                            # logger.error("to_columns after decode: " + to_columns)
                            # logger.error("Decode completed !!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in Decode")

                    staging_table = ''
                    where_string = ''
                    if entity_name == 'study':
                        staging_table = 'stage_study'
                    elif entity_name == 'investigator':
                        staging_table = 'stage_investigator'

                    else:
                        staging_table = 'stage_org'
                        if 'org_type' not in to_columns:
                            to_columns += ', org_type'
                            from_columns += " ,'" + str(entity_name) +"'"
                        else:
                            if entity_name == 'site':
                                where_string = "WHERE {} = 'site' ".format(org_column_form_port[0])
                            elif entity_name == 'sponsor':
                                where_string = "WHERE {} 'sponsor' ".format(org_column_form_port[0])
                            else:
                                where_string = """WHERE {} IN  ('site','sponsor') """.format(org_column_form_port[0])

                    # cursor.execute("""DROP TABLE "{}_{}" """.format(temp_landing_table, ingest_id))

                    logger.error("To COLUMNS  :  " + str(to_columns))
                    logger.error("from COLUMNS  :  " + str(from_columns))

                    logger.error("entity_name = " + str(entity_name))

                    mapping_ = dict()
                    for k, v in mapping.items():
                        mapping_[k] = v
                    logger.error("MAPPING UNDERSCORE  :  " + str(mapping_))

                    if concate_key:
                        # logger.error("concate : " + str(data['concate']))
                        logger.error("concate key : " + str(concate_key))
                        mapping_['concate'] = concate_key
                    if substring:
                        mapping_['substring'] = substring
                    if decode:
                        mapping_['decode'] = decode
                    if lower_case:
                        mapping_['lowercase'] = lower_case
                    if upper_case:
                        mapping_['uppercase'] = upper_case

                    logger.error("Mapping underscroe   :  " + str(mapping_))
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            "UPDATE ingestion_sources SET data_mapping ='{}', status_flag = '3' WHERE source_id='{}'".format(
                                json.dumps(mapping_), source_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO "{}" (ingest_id, uid, ingest_source_id, source_root_id, {})
                                 SELECT '{}','{}','{}','{}',{} FROM "{}_{}" """.format(landing_table_name, to_columns,
                                                                                       ingest_id, user_id, source_id,
                                                                                       root_source_id,
                                                                                       from_columns, temp_landing_table,
                                                                                       ingest_id))
                        cursor.execute(
                            """INSERT INTO "{}" (ingest_id, uid, ingest_source_id, source_root_id, {})
                                 SELECT '{}','{}','{}','{}',{} FROM "{}_{}" """.format(landing_table_name,to_columns,
                                                                                       ingest_id, user_id, source_id,
                                                                                       root_source_id,
                                                                                       from_columns,
                                                                                       temp_landing_table,
                                                                                       ingest_id))
                        connection.commit()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("after the insert query !!!!!!")
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            "UPDATE admin_sources SET data_mapping ='{}' WHERE source_root_id='{}'".format(
                                json.dumps(mapping_), root_source_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                    return JsonResponse({'failure': 'FaILUre'})
                try:
                    cursor = connection.cursor()
                    cursor.execute("select count(*) from {} where ingest_id = '{}'"
                                   .format(landing_table_name, ingest_id))
                    count_landing = cursor.fetchall()

                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                            json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                return JsonResponse({'ok': count_landing[0][0]})
            elif conn_type == 'file_browser':
                try:
                    stage_table = ''
                    if entity_name == 'study':
                        stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
                    elif entity_name == 'investigator':
                        stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                    else:
                        stage_table = getattr(settings, "STAGE_ORG", "stage_org")
                    try:
                        cursor = connection.cursor()
                        cursor.execute("SELECT column_name, data_type FROM INFORMATION_SCHEMA.COLUMNS WHERE "
                                       "table_name = '{}'".format(stage_table))
                        schema = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("schema master:")
                    logger.error(str(schema))
                    # logging.debug(str(schema))

                    schema_string = ''
                    for col_name, col_type in schema[4:-2]:
                        schema_string = schema_string + str(col_name).lower() + ' ' + str(col_type).lower() + \
                                        ' DEFAULT NULL, '
                        col_datatype[str(col_name)] = str(col_type)
                    schema_string = schema_string[:-2]
                    # logging.error("schema_string: ")
                    # logging.error(schema_string)

                    user_id = request.session['user_id']
                    ingest_id = request.session['ingest_id']
                    # cursor.execute("SELECT create_stage('{}', '{}', '{}')".format(ingest_id, user_id, schema_string))
                    # logger.error("source table created")

                    # Delete previously migrated records
                    try:
                        cursor = connection.cursor()

                        #TODO need to put if else here
                        cursor.execute("DELETE FROM \"{}\" WHERE ingest_id='{}' AND uid='{}' AND "
                                       "ingest_source_id='{}'".format(stage_table, ingest_id, user_id, source_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        cursor.execute("UPDATE ingestion_sources SET status_flag=NULL WHERE "
                                       "source_id='{}' AND ingest_id = '{}' AND delete_flag='0'".format(source_id, ingest_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    temp_string = ''
                    header = headerCSV(conn_string, request)
                    for h in header.split(request.session['delimiter']):
                        if h.lower() in mapping:
                            logger.error("available: " + h.lower() )
                            if entity_name == 'study':
                                temp_string = temp_string + '"' + h.lower() + '" ' + \
                                              col_datatype[
                                                  settings.STUDY_COLUMN_DICT[mapping[h.lower()].upper()].lower()] + ', '
                                logger.error("temp_string: ")
                                logger.error(str(temp_string))
                            elif entity_name == 'investigator':
                                temp_string = temp_string + '"' + h.lower() + '" ' + \
                                              col_datatype[
                                                  settings.COLUMN_DICT[mapping[h.lower()].upper()].lower()] + ', '

                            else:
                                logger.error("inv for " + h.lower() + " is available")
                                temp_string = temp_string + '"' + h.lower() + '" ' + \
                                              col_datatype[
                                                  settings.ORG_COLUMN_DICT[mapping[h.lower()].upper()].lower()] \
                                              + ', '
                        else:
                            logger.error(h.lower())
                            temp_string = temp_string + '"' + h.lower() + '" VARCHAR, '
                    temp_string = temp_string[:-2]
                    # logger.error("temp string: " + str(temp_string))
                    try:
                        cursor = connection.cursor()
                        logger.error("""CREATE TABLE "temp_source_{}_{}" ({})""".format(user_id, ingest_id, temp_string))
                        cursor.execute("""CREATE TABLE "temp_source_{}_{}" ({})""".format(user_id, ingest_id, temp_string))
                        # logger.error("temporary tables is created to store temp data")
                        connection.commit()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            """COPY "temp_source_{}_{}" FROM '{}' DELIMITER '{}' CSV HEADER encoding 'utf-8' """.format(
                                user_id, ingest_id, conn_string, request.session['delimiter']))
                        connection.commit()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    # logger.error("Data is copied into temp table from CSV")
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select * from temp_source_{}_{}".format(user_id, ingest_id))
                        logger.error("temp data")
                        logger.error(str(cursor.fetchall()))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    # TODO REMOVE static path of csv file and write this "request.session['file']"
                    to_columns = ''
                    # if entity_name == 'org':
                    #     for key, value in mapping
                    for name in mapping.values():
                        # logger.error("inside mapping.values,name: "+ str(name))
                        if entity_name == 'study':
                            to_columns = to_columns + settings.STUDY_COLUMN_DICT[name.upper()] + ', '
                            # logger.error("to_columns:")
                            # logger.error(str(to_columns))
                        elif entity_name == 'investigator':
                            to_columns = to_columns + settings.COLUMN_DICT[name.upper()] + ', '
                        else:
                            to_columns = to_columns + settings.ORG_COLUMN_DICT[name.upper()] + ', '
                    # logger.error("to_column before -2 : " + str(to_columns))
                    to_columns = to_columns[:-2]
                    # logger.error("to_column: " + str(to_columns))
                    from_columns = ', '.join(mapping.keys())
                    # logger.error("from_column: " + str(from_columns))

                    if len(concate_key) == 0:
                         logger.error("no data for concat comes!!!")
                    else:
                        try:
                            target_column_key = concate_key.keys()
                            target_column_key = list(target_column_key)
                            target_column_key_temp = list()
                            for h in target_column_key:
                                # logger.error("h is: " + str(h))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                else:
                                    name = settings.ORG_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))

                            target_column_key = target_column_key_temp
                            # logger.error("target column key : " + str(target_column_key))
                            source_column_values = concate_key.values()
                            source_column_values = list(source_column_values)
                            source_column_values_copy = copy.deepcopy(source_column_values)

                            for k, v in enumerate(concate_key_copy):
                                source_column_values_copy[k].append(v)

                            # logger.error("HERE source value" + str(source_column_values))


                            cate_string = 'concat'
                            list_of_target_column = []
                            for i in source_column_values:
                                cate_string = cate_string + '(' + ", ".join([foo.lower() for foo in i]) + ')'
                                list_of_target_column.append(cate_string)
                                cate_string = 'concat'

                            # uncomment below 5 lines and comment above 6 lines
                            # list_of_target_column_seperator = list()
                            # assert(len(seperator) == len(source_column_values))
                            # for names, sep in zip(source_column_values, seperator):
                            #     stri = 'concat(' + names[0] + ', ' + sep + ', ' + names[1] + ')'
                            #     list_of_target_column_seperator.append(stri)

                            # logger.error("list of target column for concat: " + str(list_of_target_column))
                            # logger.error("list of target column list : " + str(list_of_target_column_seperator))
                            my_string = ", ".join(list_of_target_column)
                            #remove above line of code and uncomment below line
                            # my_string = ", ".join(list_of_target_column_seperator)
                            # logger.error(my_string)
                            from_columns += ', ' + my_string
                            # logger.error("from_column after concat: " + str(from_columns))
                            add_to_target_string = ", ".join(target_column_key)
                            to_columns += ', ' + add_to_target_string
                            # logger.error("done!!!!! concat work")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in concat!!!!!!!!!!")

                    if len(substring) == 0:
                        logger.error("No data for substring!!!")
                    else:
                        try:

                            f_string_for_substring_target = ''
                            substring_column_list, substring_target_list = list(), list()
                            for i in substring:
                                final_string_for_substring = 'substring'
                                s_name = i['source_name']
                                pos = i['position']
                                len_sub = i['length']
                                targ = i['target_name']
                                final_string_for_substring += '(' + s_name.lower() + ', ' + str(pos) + ', ' + \
                                                              str(len_sub) + ')'
                                # logger.error("final_string_for_substring: " + final_string_for_substring)
                                substring_column_list.append(final_string_for_substring)
                                # logger.error("substring column list: " + str(substring_column_list))
                                final_string_for_substring = 'substring'
                                f_string_for_substring_target += targ.lower()
                                # logger.error("f_string_for_substring_target: " + f_string_for_substring_target)
                                substring_target_list.append(f_string_for_substring_target)
                                # logger.error("substring_target_list: " + str(substring_target_list))
                                f_string_for_substring_target = ''

                            # logger.error("substring_column_list after loop: " + str(substring_column_list))
                            # ['substring(s_name, 15, 70)', 'substring(s_name_1, 16, 98)']
                            # logger.error("substring_target_list after loop: " + str(substring_target_list))
                            # ['t_name', 't_name_1']
                            new_string = ', '.join(substring_column_list)
                            from_columns += ', ' + new_string
                            # logger.error("from_column after substring: " + from_columns)

                            substring_target_list_temp = list()
                            for h in substring_target_list:
                                # logger.error("h is in substring: " + str(h))
                                # logger.error(str(mapping))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for study: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for study: " + str(substring_target_list_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for inv: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for inv: " + str(substring_target_list_temp))

                                else:
                                    name = settings.ORG_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for org: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for org:" + str(substring_target_list_temp))

                            substring_target_list = substring_target_list_temp
                            # logger.error("substring target list after loop: " + str(substring_target_list))
                            new_string_target = ', '.join(substring_target_list)
                            to_columns += ', ' + new_string_target
                            # logger.error("to_column after substring: " + to_columns)
                            # logger.error("Substring done!!!!!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in substring!!!!")

                    if len(decode) == 0:
                        logger.error("Decode length is zero")
                    else:
                        try:
                            final_string = 'case '
                            target_column_list = list()

                            # For each dict in decode list
                            for d in decode:
                                source_name = d['source_name']
                                final_string = final_string + 'when ' + source_name + ' = '

                                # Iterate over all the items, do nothing if this is source or target else
                                # do string manipulation
                                for k, v in d.items():
                                    if k == 'source_name':
                                        continue
                                    elif k == 'target_name':
                                        target_column_list.append(v)
                                    else:
                                        final_string = final_string + "'" + k + "' then '" + v + "' when " + \
                                                       source_name + ' = '
                                final_string = final_string.split(' when ')[:-1]
                                final_string = ' when '.join(final_string)
                                final_string = final_string + ' else ' + source_name + ' end, case '
                            final_string = final_string[:-7]

                            # Join all target list
                            target_column_list = ','.join(target_column_list)
                            # logger.error("Final String: " + str(final_string))
                            # logger.error("target column list: " + str(target_column_list))
                            from_columns += ', ' + final_string
                            # logger.error("from column after decode : " + from_columns)
                            to_columns += ', ' + target_column_list
                            # logger.error("to_columns after decode: " + to_columns)
                            # logger.error("Decode completed !!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in Decode")

                    staging_table = ''
                    where_string = ''
                    if entity_name == 'study':
                        staging_table = 'stage_study'
                    elif entity_name == 'investigator':
                        staging_table = 'stage_investigator'

                    else:
                        staging_table = 'stage_org'
                        if 'org_type' not in to_columns:
                            to_columns += ', org_type'
                            from_columns += " ,'" + str(entity_name) +"'"
                        else:
                            if entity_name == 'site':
                                where_string = "WHERE {} = 'site' ".format(org_column_form_port[0])
                            elif entity_name == 'sponsor':
                                where_string = "WHERE {} 'sponsor' ".format(org_column_form_port[0])
                            else:
                                where_string = """WHERE {} IN  ('site','sponsor') """.format(org_column_form_port[0])
                    logger.error("To COLUMNS  :  " + str(to_columns))
                    logger.error("from COLUMNS  :  " + str(from_columns))
                    logger.error("entity_name = "+ str(entity_name))
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select column_name from information_schema.columns where "
                                       "table_name = 'temp_source_{}_{}'".format(user_id, ingest_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("column temp: "+ str(cursor.fetchall()))
                    try:
                        cursor = connection.cursor()
                        logger.error("""INSERT INTO "{}" ({}, ingest_id, ingest_source_id, uid)
                                                            SELECT {}, '{}', '{}', '{}' FROM "temp_source_{}_{}" {}""".format(
                            staging_table,
                            to_columns, from_columns, ingest_id, source_id, user_id, user_id, ingest_id, where_string))
                        cursor.execute("""INSERT INTO "{}" ({}, ingest_id, ingest_source_id, uid)
                                        SELECT {}, '{}', '{}', '{}' FROM "temp_source_{}_{}" {}""".format(staging_table,
                                        to_columns, from_columns, ingest_id, source_id, user_id, user_id, ingest_id, where_string))
                        connection.commit()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("data of temp table is inserted into source stagging table along with important ids")
                    try:
                        cursor = connection.cursor()
                        cursor.execute("""DROP TABLE "temp_source_{}_{}" """.format(user_id, ingest_id))
                        connection.commit()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    logger.error("temporary table is deleted")
                    # concate_key = data['concate']
                    # # logger.error("concat key: "+ str(concate_key))
                    # concate_key_copy = concate_key
                    # substring = data['substring']
                    # # logger.error("substring: " + str(substring))
                    # decode = data['decode']
                    mapping_ = dict()
                    for k, v in mapping.items():
                        mapping_[k.upper()] = v.upper()
                    if data['concate']:
                        mapping_['concate'] = data['concate']
                    if data['substring']:
                        mapping_['substring'] = data['substring']
                    if data['decode']:
                        mapping_['decode'] = data['decode']
                    logger.error("Mapping underscroe   :  " + str(mapping_))
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            "UPDATE ingestion_sources SET data_mapping ='{}', status_flag = '3' WHERE source_id='{}'".format(
                                json.dumps(mapping_), source_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                    return JsonResponse({'failure': 'FaILUre'})
                finally:
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            """DROP TABLE IF EXISTS "temp_source_{}_{}" """.format(request.session['user_id'],
                                                                                   request.session['ingest_id']))
                        connection.commit()
                    except Exception as e:
                        logger.error("Exception while trying to delete temp source table")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()

                # flow_flags(request.session['ingest_id'], request.session['user_id'], '3', 'ingestion_sources',
                #            request.session['source_id'])
                try:
                    cursor = connection.cursor()
                    cursor.execute("select count(*) from {} where ingest_id = '{}'"
                                   .format(landing_table_name, ingest_id))
                    count_landing2 = cursor.fetchall()

                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                            json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                return JsonResponse({'ok': count_landing2[0][0]})

            elif conn_type == 'db connection':
                try:
                    # data = json.loads(request.read().decode('utf-8'))
                    # column_type = request.session['database_table']
                    conn_string = json.loads(conn_string)
                    logger.error(str(conn_string))
                    dbname = conn_string['database_name']
                    port = conn_string['port']
                    host = conn_string['host_name']
                    user = conn_string['username']
                    password = conn_string['password']
                    db_table = conn_string['table_name']
                    column_type = dict()

                    try:
                        conn = psycopg2.connect(dbname=dbname, user=user, host=host, password=password, port=port)
                        cursor = conn.cursor()
                        cursor.execute("SELECT column_name, data_type FROM information_schema.columns where "
                                       "table_name  = '{}' ORDER  BY ordinal_position ".format(db_table))
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                        return JsonResponse({'error': 'Table not found '})
                    else:
                        columns = cursor.fetchall()
                        header = list()
                        header_names = list()
                        for column in columns:
                            header.append(column)
                            header_names.append(column[0])
                        # logger.error("COLUMNS: " + str(columns))
                        logger.error(str(header_names))
                        for column in columns:
                            column_type[column[0]] = column[1]

                    if len(concate_key) == 0:
                         logger.error("no data for concat comes!!!")
                    else:
                        try:
                            target_column_key = concate_key.keys()
                            target_column_key = list(target_column_key)
                            target_column_key_temp = list()
                            for h in target_column_key:
                                # logger.error("h is: " + str(h))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                else:
                                    name = settings.ORG_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))

                            target_column_key = target_column_key_temp
                            # logger.error("target column key : " + str(target_column_key))
                            source_column_values = concate_key.values()
                            source_column_values = list(source_column_values)
                            source_column_values_copy = copy.deepcopy(source_column_values)

                            for k, v in enumerate(concate_key_copy):
                                source_column_values_copy[k].append(v)

                            # logger.error("HERE source value" + str(source_column_values))
                            cate_string = 'concat'
                            list_of_target_column = []
                            for i in source_column_values:
                                cate_string = cate_string + '(' + ", ".join(['"' + foo + '"' for foo in i]) + ')'
                                list_of_target_column.append(cate_string)
                                cate_string = 'concat'

                            # uncomment below 5 lines and comment above 6 lines
                            # list_of_target_column_seperator = list()
                            # assert(len(seperator) == len(source_column_values))
                            # for names, sep in zip(source_column_values, seperator):
                            #     stri = 'concat(' + names[0] + ', ' + sep + ', ' + names[1] + ')'
                            #     list_of_target_column_seperator.append(stri)

                            # logger.error("list of target column for concat: " + str(list_of_target_column))
                            # logger.error("list of target column list : " + str(list_of_target_column_seperator))
                            my_string = ", ".join(list_of_target_column)
                            #remove above line of code and uncomment below line
                            # my_string = ", ".join(list_of_target_column_seperator)
                            logger.error("MY STRING   :  "  + str(my_string))
                            from_columns += ', ' + my_string
                            # logger.error("from_column after concat: " + str(from_columns))
                            add_to_target_string = ", ".join(target_column_key)
                            to_columns += ', ' + add_to_target_string
                            logger.error("done!!!!! concat work")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in concat!!!!!!!!!!")

                    if len(substring) == 0:
                        logger.error("No data for substring!!!")
                    else:
                        try:

                            f_string_for_substring_target = ''
                            substring_column_list, substring_target_list = list(), list()
                            logger.error("SUBSTRING  =  " + str(substring))
                            for i in substring:
                                final_string_for_substring = 'substring'
                                s_name = i['source_name']
                                pos = i['position']
                                len_sub = i['length']
                                targ = i['target_name']
                                final_string_for_substring += '("' + s_name + '", ' + str(pos) + ', ' + \
                                                              str(len_sub) + ')'
                                logger.error("final_string_for_substring: " + final_string_for_substring)
                                substring_column_list.append(final_string_for_substring)
                                # logger.error("substring column list: " + str(substring_column_list))
                                # final_string_for_substring = 'substring'
                                f_string_for_substring_target += targ.lower()
                                # logger.error("f_string_for_substring_target: " + f_string_for_substring_target)
                                substring_target_list.append(f_string_for_substring_target)
                                # logger.error("substring_target_list: " + str(substring_target_list))
                                f_string_for_substring_target = ''

                            logger.error("substring_column_list after loop: " + str(substring_column_list))
                            # ['substring(s_name, 15, 70)', 'substring(s_name_1, 16, 98)']
                            # logger.error("substring_target_list after loop: " + str(substring_target_list))
                            # ['t_name', 't_name_1']
                            new_string = ', '.join(substring_column_list)
                            from_columns += ', ' + new_string
                            # logger.error("from_column after substring: " + from_columns)

                            substring_target_list_temp = list()
                            for h in substring_target_list:
                                # logger.error("h is in substring: " + str(h))
                                # logger.error(str(mapping))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for study: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for study: " + str(substring_target_list_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for inv: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for inv: " + str(substring_target_list_temp))

                                else:
                                    name = settings.ORG_COLUMN_DICT[h.upper()].lower()
                                    # logger.error("name in substring for org: " + str(name))
                                    substring_target_list_temp.append(name)
                                    # logger.error("hhh in substring for org:" + str(substring_target_list_temp))

                            substring_target_list = substring_target_list_temp
                            # logger.error("substring target list after loop: " + str(substring_target_list))
                            new_string_target = ', '.join(substring_target_list)
                            to_columns += ', ' + new_string_target
                            # logger.error("to_column after substring: " + to_columns)
                            # logger.error("Substring done!!!!!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in substring!!!!")
                    if len(upper_case) == 0:
                        logger.error("Upper case length is zero.")
                    else:
                        logger.error("uppercase :  "+ str(upper_case))
                        final_string = ''
                        target_column_list = list()
                        for key, value in upper_case.items():
                            final_string += 'UPPER("' + str(key) + '")' + " , "
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            else:
                                name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                        logger.error(str(final_string))
                        logger.error(str(target_column_list))
                        from_columns += ", " + final_string[:-2]
                        if len(target_column_list) == 1:
                            to_columns += ", " + target_column_list[0]
                        else:
                            to_columns += ', '.join(target_column_list)
                    if len(lower_case) == 0:
                        logger.error("Lower case length is zero.")
                    else:
                        logger.error("lowercase :  "+ str(lower_case))

                        final_string = ''
                        target_column_list = list()
                        for key, value in lower_case.items():
                            final_string += 'LOWER("' + str(key) + '")' + " , "
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                            else:
                                name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                                target_column_list.append(str(name))
                        logger.error(str(final_string))
                        logger.error(str(target_column_list))
                        from_columns += ", " + final_string[:-2]
                        if len(target_column_list) == 1:
                            to_columns += ", " + target_column_list[0]
                        else:
                            to_columns += ', '.join(target_column_list)
                    if len(decode) == 0:
                        logger.error("Decode length is zero")
                    else:
                        try:
                            final_string = 'case '
                            target_column_list = list()

                            # For each dict in decode list
                            for d in decode:
                                source_name = d['source_name']
                                final_string = final_string + 'when "' + source_name + '" = '

                                # Iterate over all the items, do nothing if this is source or target else
                                # do string manipulation
                                for k, v in d.items():
                                    if k == 'source_name':
                                        continue
                                    elif k == 'target_name':
                                        target_column_list.append(v)
                                    else:
                                        final_string = final_string + "'" + k + "' then '" + v + "' when " + \
                                                       source_name + ' = '
                                final_string = final_string.split(' when ')[:-1]
                                final_string = ' when '.join(final_string)
                                final_string = final_string + ' else "' + source_name + '" end, case '
                            final_string = final_string[:-7]
                            target_column_key_temp = list()
                            for h in target_column_list:
                                # logger.error("h is: " + str(h))
                                if entity_name == 'study':
                                    name = settings.STUDY_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                elif entity_name == 'investigator':
                                    name = settings.COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))
                                else:
                                    name = settings.ORG_COLUMN_DICT[h].lower()
                                    # logger.error("name is" + str(name))
                                    target_column_key_temp.append(name)
                                    # logger.error("hhh: " + str(target_column_key_temp))

                            # Join all target list
                            target_column_key_temp = ','.join(target_column_key_temp)
                            # logger.error("Final String: " + str(final_string))
                            logger.error("target column list: " + str(target_column_key_temp))
                            from_columns += ', ' + final_string
                            # logger.error("from column after decode : " + from_columns)
                            to_columns += ', ' + target_column_key_temp
                            # logger.error("to_columns after decode: " + to_columns)
                            # logger.error("Decode completed !!!!!!!!!")
                        except Exception as e:
                            logger.error(str(e))
                            k = dict()
                            k['Error'] = str(e).replace("'", '"')
                            # k = json.dumps(k)
                            cursor = connection.cursor()
                            logger.error(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                    json.dumps(k)))
                            cursor.execute(
                                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                    request.session.get('ingest_id', -1),
                                    request.session.get('user_id', -1), json.dumps(k)))
                            connection.commit()
                            logger.error("Failure in Decode")

                    staging_table = ''
                    where_string = ''
                    if entity_name == 'study':
                        staging_table = 'stage_study'
                    elif entity_name == 'investigator':
                        staging_table = 'stage_investigator'

                    else:
                        staging_table = 'stage_org'
                        if 'org_type' not in to_columns:
                            to_columns += ', org_type'
                            from_columns += " ,'" + str(entity_name) +"'"
                        else:
                            if entity_name == 'site':
                                where_string = "WHERE {} = 'site' ".format(org_column_form_port[0])
                            elif entity_name == 'sponsor':
                                where_string = "WHERE {} 'sponsor' ".format(org_column_form_port[0])
                            else:
                                where_string = """WHERE {} IN  ('site','sponsor') """.format(org_column_form_port[0])





                    table_name = ''

                    if entity_name == 'study':
                        rev_dict = settings.STUDY_COLUMN_DICT
                        table_name = 'stage_study'
                        landing_table_name = 'landing_study'
                    elif entity_name == 'investigator':
                        rev_dict = settings.COLUMN_DICT
                        table_name = "stage_investigator"
                        landing_table_name = 'landing_investigator'
                    else:
                        rev_dict = settings.ORG_COLUMN_DICT
                        table_name = "stage_org"
                        landing_table_name = 'landing_org'

                    string1_without_x = ''
                    string1 = ''
                    string2 = ''
                    string3 = ''
                    string4 = ''

                    # last_load_date_str = "\\'"+str(last_load_date)+"\\'"

                    logger.error(str(data_mapping))
                    for dicto in data_mapping:
                        if last_load_date != None:
                            string4 = ''
                            logger.error(str(type(last_load_date)))
                            string4 += " WHERE last_updated_date  >  cast(quote_literal(''" + str(last_load_date) + "'') as date)"
                        string1_without_x += '"' + str(dicto['fromPort']) + '", '
                        string1 += 'x.' + str(dicto['fromPort']) + ', '
                        string2 += str(rev_dict[dicto['toPort']]) + ', '
                        string3 += str(dicto['fromPort']) + " " + str(column_type[dicto['fromPort']]) + ', '
                    logger.error("string1_without_x : " + str(string1_without_x))
                    logger.error("string 1  :  " + str(string1[:-2]))
                    logger.error("string 2  :  " + str(string2[:-2]))
                    logger.error("string 3  :  " + str(string3[:-2]))
                    # logger.error("string 4  :  ")+ str(string4)
                    user_id = request.session['user_id']
                    ingest_id = request.session['ingest_id']
                    try:
                        cursor = connection.cursor()


                        logger.error("SELECT x.last_date FROM dblink('dbname = {} port = {} host = {} "
                                     "user = {} password = {}', 'select max(last_updated_date)  "
                                     "from {}.public.{} ') AS x(last_date date)".format(dbname, port, host,
                                                                                          user, password, dbname,
                                                                                          db_table))

                        cursor = connection.cursor()
                        cursor.execute("SELECT x.last_date FROM dblink('dbname = {} port = {} host = {} "
                                       "user = {} password = {}', 'select max(last_updated_date)  "
                                       "from {}.public.{} ') AS x(last_date date)".format(dbname, port, host,
                                                                                            user, password, dbname, db_table))
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    max_update_date_from_source = cursor.fetchall()[0][0]
                    logger.error(str(max_update_date_from_source))
                    # logger.error("max_update_date_from_source: ", str(max_update_date_from_source))
                    try:
                        cursor = connection.cursor()
                        logger.error("INSERT INTO \"{}\" ({}) SELECT {} FROM dblink(\'dbname ={} port = {} host = {} "
                                       "user = {} password = {}\', \'select {} from {}.public.{} {}\') "
                                       "AS x({})".format(landing_table_name,
                                                         string2[:-2] + ", ingest_source_id , ingest_id, uid ",
                                                         string1[:-2] + ", '{}','{}','{}' ".format(source_id,
                                                                                                   request.session[
                                                                                                       'ingest_id'],
                                                                                                   request.session[
                                                                                                       'user_id']),
                                                         dbname, port, host, user, password, string1_without_x[:-2], dbname,
                                                         db_table, string4, string3[:-2]))
                        cursor.execute("INSERT INTO \"{}\" ({}) SELECT {} FROM dblink(\'dbname ={} port = {} host = {} "
                                       "user = {} password = {}\', \'select {} from {}.public.{} {}\') "
                                       "AS x({})".format(landing_table_name, string2[:-2] + ", ingest_source_id , ingest_id, uid ",
                                                         string1[:-2] + ", '{}','{}','{}' ".format(source_id,
                                                                                                   request.session[
                                                                                                       'ingest_id'],
                                                                                                   request.session[
                                                                                                       'user_id']),
                                                         dbname, port, host, user, password, string1_without_x[:-2], dbname,
                                                         db_table, string4, string3[:-2]))
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    # logger.error("SUCCESS: " + str(table_name))

                    # This is to be removed and a function is to be made.
                    try:
                        cursor = connection.cursor()
                        cursor.execute("UPDATE admin_sources SET last_load_date = '{}' WHERE "
                                       "source_root_id = '{}'".format(str(max_update_date_from_source), str(root_source_id)))
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    # if len(concate_key) == 0:
                    #     logger.error("no data for concat comes!!!")
                    # else:
                    #     try:
                    #         target_column_key = concate_key.keys()
                    #         target_column_key = list(target_column_key)
                    #         target_column_key_temp = list()
                    #         for h in target_column_key:
                    #             # logger.error("h is: " + str(h))
                    #             if entity_name == 'study':
                    #                 name = settings.STUDY_COLUMN_DICT[h].lower()
                    #                 # logger.error("name is" + str(name))
                    #                 target_column_key_temp.append(name)
                    #                 # logger.error("hhh: " + str(target_column_key_temp))
                    #             elif entity_name == 'investigator':
                    #                 name = settings.COLUMN_DICT[h].lower()
                    #                 # logger.error("name is" + str(name))
                    #                 target_column_key_temp.append(name)
                    #                 # logger.error("hhh: " + str(target_column_key_temp))
                    #
                    #             else:
                    #                 name = settings.ORG_COLUMN_DICT[h].lower()
                    #                 # logger.error("name is" + str(name))
                    #                 target_column_key_temp.append(name)
                    #                 # logger.error("hhh: " + str(target_column_key_temp))
                    #
                    #         target_column_key = target_column_key_temp
                    #         # logger.error("target column key : " + str(target_column_key))
                    #         source_column_values = concate_key.values()
                    #         source_column_values = list(source_column_values)
                    #         source_column_values_copy = copy.deepcopy(source_column_values)
                    #
                    #         for k, v in enumerate(concate_key_copy):
                    #             source_column_values_copy[k].append(v)
                    #         # logger.error("HERE source value" + str(source_column_values))
                    #         cate_string = 'concat'
                    #         list_of_target_column = []
                    #         for i in source_column_values:
                    #             cate_string = cate_string + '(' + ", ".join([foo.lower() for foo in i]) + ')'
                    #             list_of_target_column.append(cate_string)
                    #             cate_string = 'concat'
                    #
                    #         # uncomment below 5 lines and comment above 6 lines
                    #         # list_of_target_column_seperator = list()
                    #         # assert(len(seperator) == len(source_column_values))
                    #         # for names, sep in zip(source_column_values, seperator):
                    #         #     stri = 'concat(' + names[0] + ', ' + sep + ', ' + names[1] + ')'
                    #         #     list_of_target_column_seperator.append(stri)
                    #
                    #         # logger.error("list of target column for concat: " + str(list_of_target_column))
                    #         # logger.error("list of target column list : " + str(list_of_target_column_seperator))
                    #         my_string = ", ".join(list_of_target_column)
                    #         #remove above line of code and uncomment below line
                    #         my_string = ", ".join(list_of_target_column_seperator)
                    #         # logger.error(my_string)
                    #         from_columns += ', ' + my_string
                    #         # logger.error("from_column after concat: " + str(from_columns))
                    #         add_to_target_string = ", ".join(target_column_key)
                    #         to_columns += ', ' + add_to_target_string
                    #         # logger.error("done!!!!! concat work")
                    #     except Exception as e:
                    #         logger.error("Table not found in database")
                    #         logger.error(str(e))
                    #         k = dict()
                    #         k['Error'] = str(e).replace("'", '"')
                    #         # k = json.dumps(k)
                    #         cursor = connection.cursor()
                    #         logger.error(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    #                 json.dumps(k)))
                    #         cursor.execute(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1),
                    #                 request.session.get('user_id', -1), json.dumps(k)))
                    #         connection.commit()
                    #         logger.error("Failure in concat!!!!!!!!!!")
                    #
                    # if len(substring) == 0:
                    #     logger.error("No data for substring!!!")
                    # else:
                    #     try:
                    #         final_string_for_substring = 'substring'
                    #         f_string_for_substring_target = ''
                    #         substring_column_list, substring_target_list = list(), list()
                    #         for i in substring:
                    #             s_name = i['source_name']
                    #             pos = i['position']
                    #             len_sub = i['length']
                    #             targ = i['target_name']
                    #             final_string_for_substring += '(' + s_name.lower() + ', ' + str(pos) + ', ' + \
                    #                                           str(len_sub) + ')'
                    #             # logger.error("final_string_for_substring: " + final_string_for_substring)
                    #             substring_column_list.append(final_string_for_substring)
                    #             # logger.error("substring column list: " + str(substring_column_list))
                    #             final_string_for_substring = 'substring'
                    #             f_string_for_substring_target += targ.lower()
                    #             # logger.error("f_string_for_substring_target: " + f_string_for_substring_target)
                    #             substring_target_list.append(f_string_for_substring_target)
                    #             # logger.error("substring_target_list: " + str(substring_target_list))
                    #             f_string_for_substring_target = ''
                    #
                    #         # logger.error("substring_column_list after loop: " + str(substring_column_list))
                    #         # ['substring(s_name, 15, 70)', 'substring(s_name_1, 16, 98)']
                    #         # logger.error("substring_target_list after loop: " + str(substring_target_list))
                    #         # ['t_name', 't_name_1']
                    #         new_string = ', '.join(substring_column_list)
                    #         from_columns += ', ' + new_string
                    #         # logger.error("from_column after substring: " + from_columns)
                    #
                    #         substring_target_list_temp = list()
                    #         for h in substring_target_list:
                    #             logger.error("h is in substring: " + str(h))
                    #             # logger.error(str(mapping))
                    #             if entity_name == 'study':
                    #                 name = settings.STUDY_COLUMN_DICT[h.upper()].lower()
                    #                 # logger.error("name in substring for study: " + str(name))
                    #                 substring_target_list_temp.append(name)
                    #                 # logger.error("hhh in substring for study: " + str(substring_target_list_temp))
                    #             elif entity_name == 'investigator':
                    #                 name = settings.COLUMN_DICT[h.upper()].lower()
                    #                 # logger.error("name in substring for site: " + str(name))
                    #                 substring_target_list_temp.append(name)
                    #                 # logger.error("hhh in substring for site: " + str(substring_target_list_temp))
                    #
                    #             else:
                    #                 name = settings.ORG_COLUMN_DICT[h.upper()].lower()
                    #                 # logger.error("name in substring for investigator: " + str(name))
                    #                 substring_target_list_temp.append(name)
                    #                 # logger.error("hhh in substring for investigator:" + str(substring_target_list_temp))
                    #
                    #         substring_target_list = substring_target_list_temp
                    #         # logger.error("substring target list after loop: " + str(substring_target_list))
                    #         new_string_target = ', '.join(substring_target_list)
                    #         to_columns += ', ' + new_string_target
                    #         # logger.error("to_column after substring: " + to_columns)
                    #         # logger.error("Substring done!!!!!!!!!!!!")
                    #     except Exception as e:
                    #         logger.error("Table not found in database")
                    #         logger.error(str(e))
                    #         k = dict()
                    #         k['Error'] = str(e).replace("'", '"')
                    #         # k = json.dumps(k)
                    #         cursor = connection.cursor()
                    #         logger.error(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    #                 json.dumps(k)))
                    #         cursor.execute(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1),
                    #                 request.session.get('user_id', -1), json.dumps(k)))
                    #         connection.commit()
                    #         logger.error("Failure in substring!!!!")
                    # if len(upper_case) == 0:
                    #     logger.error("Upper case length is zero.")
                    # else:
                    #     final_string = ''
                    #     target_column_list = list()
                    #     for key, value in upper_case.items():
                    #         final_string += str(key) + " "
                    #         if entity_name == 'study':
                    #             name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("UPPER('" + str(name) + "')")
                    #         elif entity_name == 'investigator':
                    #             name = settings.COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("UPPER('" + str(name) + "')")
                    #         else:
                    #             name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("UPPER('" + str(name) + "')")
                    #     from_columns += ', ' + final_string
                    #     to_columns += ', ' + target_column_list
                    # if len(lower_case) == 0:
                    #     logger.error("Lower case length is zero.")
                    # else:
                    #     final_string = ''
                    #     target_column_list = list()
                    #     for key, value in lower_case.items():
                    #         final_string += str(key) + " "
                    #         if entity_name == 'study':
                    #             name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("LOWER('" + str(name) + "')")
                    #         elif entity_name == 'investigator':
                    #             name = settings.COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("LOWER('" + str(name) + "')")
                    #         else:
                    #             name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                    #             target_column_list.append("LOWER('" + str(name) + "')")
                    #     from_columns += ', ' + final_string
                    #     to_columns += ', ' + target_column_list
                    # if len(decode) == 0:
                    #     logger.error("Decode length is zero")
                    # else:
                    #     try:
                    #         final_string = 'case '
                    #         target_column_list = list()
                    #
                    #         # For each dict in decode list
                    #         for d in decode:
                    #             source_name = d['source_name']
                    #             final_string = final_string + 'when ' + source_name + ' = '
                    #
                    #             # Iterate over all the items, do nothing if this is source or target else
                    #             # do string manipulation
                    #             for k, v in d.items():
                    #                 if k == 'source_name':
                    #                     continue
                    #                 elif k == 'target_name':
                    #                     target_column_list.append(v)
                    #                 else:
                    #                     final_string = final_string + "'" + k + "' then '" + v + "' when " + \
                    #                                    source_name + ' = '
                    #             final_string = final_string.split(' when ')[:-1]
                    #             final_string = ' when '.join(final_string)
                    #             final_string = final_string + ' else ' + source_name + ' end, case '
                    #         final_string = final_string[:-7]
                    #
                    #         # Join all target list
                    #         target_column_list = ','.join(target_column_list)
                    #         # logger.error("Final String: " + str(final_string))
                    #         # logger.error("target column list: " + str(target_column_list))
                    #         from_columns += ', ' + final_string
                    #         # logger.error("from column after decode : " + from_columns)
                    #         to_columns += ', ' + target_column_list
                    #         # logger.error("to_columns after decode: " + to_columns)
                    #         # logger.error("Decode completed !!!!!!!!!")
                    #     except Exception as e:
                    #         logger.error("Table not found in database")
                    #         logger.error(str(e))
                    #         k = dict()
                    #         k['Error'] = str(e).replace("'", '"')
                    #         # k = json.dumps(k)
                    #         cursor = connection.cursor()
                    #         logger.error(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    #                 json.dumps(k)))
                    #         cursor.execute(
                    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #                 request.session.get('ingest_id', -1),
                    #                 request.session.get('user_id', -1), json.dumps(k)))
                    #         connection.commit()
                    #         logger.error("Failure in Decode")
                    logger.error(str(data_mapping))
                    data_mapping_db = dict()
                    logger.error(str(data_mapping))
                    for d in data_mapping:
                        str1 = str(d['fromPort'])
                        str2 = str(d['toPort'])
                        logger.error(d['toPort'])
                        logger.error(d['fromPort'])
                        data_mapping_db[str1] = str2

                    logger.error(str(data_mapping_db))
                    # for d in data_mapping:
                    #     logger.error(d['toPort'])
                    #     d['fromPort'] = d['toPort']
                    #     for t in d:
                    #         data_mapping_db.append(t)
                    # data_mapping_dbb = dict()

                    # if data['concate']:
                    #     data_mapping_db['concate'] = data['concate']
                    # if data['substring']:
                    #     data_mapping_db['substring'] = data['substring']
                    # if data['decode']:
                    #     data_mapping_db['decode'] = data['decode']

                    logger.error(str(header_names))

                    data_mapping_string_str = str(data_mapping_db).replace("'", '"')
                    try:
                        cursor = connection.cursor()
                        # logger.error("UPDATE admin_sources SET data_mapping = '{}', header ="
                        #                " '{}' ".format(str(data_mapping_db), ", ".join(header)))
                        cursor.execute("UPDATE admin_sources SET data_mapping = '{}', header ="
                                       " '{}' where source_root_id = '{}'".format(data_mapping_string_str,
                                                                    ", ".join(header_names), root_source_id))
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        cursor.execute("UPDATE ingestion_sources SET data_mapping = '{}', status_flag = '3'  WHERE "
                                       "source_id = '{}'".format(data_mapping_string_str, source_id))
                        # flow_flags(request.session['ingest_id'], request.session['user_id'], '3', 'ingestion_sources',
                        #            source_id)
                    except Exception as e:
                        logger.error("Table not found in database")
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(*) from {} where ingest_id = '{}'"
                                       .format(landing_table_name, ingest_id))
                        count_landing3 = cursor.fetchall()

                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    return JsonResponse({'ok': count_landing3[0][0]})
                except Exception as e:
                    logger.error(str(e))
                    return JsonResponse({'failure': 'Failure'})
            else:
                return JsonResponse({'failure': 'File type not found in request.'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'FAILURE'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


def database_conn(data, request):
    """

    :param data:
    :param request:
    :return:
    """
    if len(data):
        # if dbname.lower() == 'postgressql':
        custom_source_name = data['source_root_name']
        cursor = connection.cursor()
        cursor.execute("select conn_string, source_root_id, source_priority from admin_sources where "
                       "source_root_name = '{}'".format(custom_source_name))
        data = cursor.fetchall()
        for i in data:
            conn_string = i[0]
            root_source_id = i[1]
            source_priority = i[2]
        conn_string = json.loads(conn_string)
        logger.error(str(conn_string))
        request.session['source_root_id'] = root_source_id
        dbname = conn_string['database_name']
        port = conn_string['port']
        host = conn_string['host_name']
        user = conn_string['username']
        password = conn_string['password']
        db_table = conn_string['table_name']
         #todo parse the conn_string for remote db details
        conn = psycopg2.connect(dbname=dbname, user=user, host=host,
                                password=password, port=port)
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT column_name, data_type FROM information_schema.columns where table_name  = '{}' "
                "ORDER  BY ordinal_position ".format(db_table))
        except Exception as e:
            logger.error("Table not found in database")
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'error': 'Table not found '})
        else:
            columns = cursor.fetchall()
            logger.error("COLUMNS: " + str(columns))
            column_and_type = dict()
            for column in columns:
                column_and_type[column[0]] = column[1]
            header = list()
            try:
                for column in column_and_type.keys():
                    header.append(column)
                logger.error("Database HEADER is : " + str(header))
            except Exception as e:
                logger.error("Error in finding header of database table")
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error(" adadadad " + str(request.session.keys()))
            length = 12
            chars = string.ascii_letters + string.digits + '!@#$%^&*()'
            random.seed = (os.urandom(1024))
            source_id = ''.join(random.choice(chars) for _ in range(length))
            ingest_id = request.session['ingest_id']
            logger.error("ingest id   : " + str(ingest_id))
            user_id = request.session['user_id']
            t = time.localtime()
            times = time.strftime('%b-%d-%Y-%H%M', t)
            try:
                cursor = connection.cursor()
                logger.error("INSERT INTO ingestion_sources (source_priority, source_id, ingest_id, uid, source_root_id, "
                    " conn_method, conn_string,"
                    " source_name, header) VALUES ('{}', '{}', '{}', '{}', '{}', {}, '{}', '{}',"
                    "'{}')".format(source_priority, source_id, ingest_id, user_id, root_source_id, 'db connection', conn_string,
                                   str(dbname + "_" + times) + ":" + str(db_table) , ",".join(header)))
                cursor.execute(
                    "INSERT INTO ingestion_sources (source_priority, source_id, ingest_id, uid, source_root_id, "
                    " conn_method, conn_string,"
                    " source_name, header) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}',"
                    "'{}')".format(source_priority, source_id, ingest_id, user_id, root_source_id, 'db connection', json.dumps(conn_string),
                                   str(dbname + "_" + times) + ":" + str(db_table) , ",".join(header)))
                connection.commit()
            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # request.session['database_table'] = [column[0] for column in columns]
            request.session['custom_source_name'] = custom_source_name
            request.session['conn_type'] = 'database'
            return {'ok': 'Success'}
    else:
        return {'failure': 'FAILURE ARNAV'}


class DatabaseConnectionCheck(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            logger.error("DB Info is  :  " + str(data))
            conn = psycopg2.connect(dbname=data['database_name'], user=data['username'], host=data['host_name'],
                                    password=data['password'], port=data['port'])
            try:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT column_name, data_type FROM information_schema.columns where table_name  = '{}' "
                    "ORDER  BY ordinal_position ".format(
                        data['table_name']))
            except Exception as e:
                logger.error("Table not found in database")
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
                return JsonResponse({'error': 'Table not found '})
            else:
                columns = cursor.fetchall()
                if columns:
                    return JsonResponse({'success': 'Connection established.'})
            return JsonResponse({'ok': 'success'})
        except Exception as e:
            logger.error("Failure in database connection " + str(e))
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


class DatabaseConnection(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            dbinfo = json.loads(request.read().decode('utf-8'))
            result = database_conn(dbinfo, request)
            flow_flags(request.session['ingest_id'], request.session['user_id'], '2')
            return JsonResponse({'ok': 'success'})
        except Exception as e:
            logger.error("Failure in database connection " + str(e))
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


class DatabaseMapping(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        pass

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        pass


class ShowMapping(APIView):
    """

    """

    @staticmethod
    def post(request):
        """
        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_name = data['ingest_name']
            source_uid = data['source_uid']
            request.session['source_user_id'] = source_uid
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT data_mapping, source_name FROM ingestion_sources WHERE ingest_id IN "
                           "(SELECT ingest_id FROM ingestion WHERE ingest_name='{}' AND uid='{}')".format(ingest_name,
                                                                                                          source_uid))
            data = cursor.fetchall()
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            logger.error("data:" + str(data))
            d = dict()
            listo = list()
            for tup in data:
                d['mapping'] = tup[0]
                d['source_name'] = tup[1]
                listo.append(d)
            logger.error("aaaaaaaaaa:" + str(listo))
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_id FROM ingestion WHERE ingest_name='{}' "
                           "AND uid='{}' and delete_flag != '1'".format(ingest_name, source_uid))
            request.session['ingest_id'] = cursor.fetchall()[0][0]
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            return JsonResponse({'data': listo})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No source found.'})

    @staticmethod
    def get(request):
        """
        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported'})


class CurrentIngestion(APIView):
    """

    """

    @staticmethod
    def get(request, ingest_name):
        """

        :param request:
        :param ingest_name:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_id FROM ingestion WHERE ingest_name='{}' "
                               "AND uid='{}' and delete_flag != '1' and entity = '{}' ".format(ingest_name,
                                                                        request.session['user_id'], entity_name))
            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            request.session['ingest_id'] = cursor.fetchall()[0][0]
            request.session['ingest_name'] = ingest_name
            # logger.error("ingest id: " + str(ingest_name))
            # logger.error("nnnnnnnnnnnnnnnnnnn")
            return JsonResponse({'ok': 'success'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})


class DeleteIngestion(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingestion_name = data['ingest_name']
            uid = request.session['user_id']
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT status_flag FROM ingestion WHERE ingest_name='{}' AND "
                           "uid='{}'".format(ingestion_name, uid))
            flag = cursor.fetchall()[0][0]
            if flag >= 4:
                return JsonResponse({'failure': 'Cannot delete this ingestion.'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT func_delete_ingestion('{}', '{}')".format(ingestion_name, uid))
            return JsonResponse({'ok': 'Ingestion deleted successfully.'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB failure.'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


class DeleteFlow(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            print(data)
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            flow_name = data['flow_name']
            username = data['username']
            logger.error(str(flow_name))
            logger.error(str(username))
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found.'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT func_delete_flow('{}', '{}')".format(flow_name, username))
            logger.error(str("function run successfully"))
            return JsonResponse({'Ok': 'Success'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})


class SourceFinish(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        try:
            migration_flag = 1
            entity_name = request.META['HTTP_ENTITY']
            conn_type = request.session['conn_type']

            if entity_name == 'study':
                temp_landing_table = "temp_landing_study"
            elif entity_name == 'investigator':
                temp_landing_table = "temp_landing_investigator"
            else:
                temp_landing_table = "temp_landing_org"

            if conn_type != 'db connection':
                try:
                    cursor = connection.cursor()
                    cursor.execute("""DROP TABLE IF EXISTS "{}_{}" """.format(temp_landing_table, request.session['ingest_id']))
                    connection.commit()
                except Exception as e:
                    logger.error("Table not found in database")
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                            json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("DELETE FROM ingestion_sources WHERE ingest_id = '{}' AND data_mapping is null".format(
                    request.session['ingest_id']))
                connection.commit()
                cursor = connection.cursor()
                cursor.execute("select status_flag from ingestion_sources where "
                               "ingest_id = '{}' ".format(request.session['ingest_id']))
                data = cursor.fetchall()[0][0]
                logger.error("data for ingestion sources status: "+ str(data))
                if str(data) == '3':
                    migration_flag = 1
                else:
                    migration_flag = 0

                # migration_status = cursor.fetchall()[0][0]
                logger.error("migration_flag: "+ str(migration_flag))
                if migration_flag:
                    logger.error("migration_flag: "+ str(migration_flag))
                else:
                    cursor = connection.cursor()
                    cursor.execute("""update ingestion set status_flag = '2'
                                    where ingest_id = '{}' and delete_flag != '1'""".format(request.session['ingest_id']))
                    connection.commit()

            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            if migration_flag:
                logger.error("inside last")
                flow_flags(request.session['ingest_id'], request.session['user_id'], '4')
            return JsonResponse({'ok': 'Success'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB error.'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'API not supported.'})


class DeleteSourceFromIngestion(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'get method not in use'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            if entity_name == 'study':
                stage_table = 'stage_study';
            elif entity_name == 'investigator':
                stage_table = 'stage_investigator';
            else:
                stage_table = 'stage_org';
            ingest_name = data['ingest_name']
            source_name_list = data['sources']
            # print(data.get('sources'))
            source_name_list = str(source_name_list).strip('[]')
            source_uid = data['source_uid']
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found.'})
        try:
            cursor = connection.cursor()
            cursor.execute("DELETE FROM \"{}\" where ingest_source_id "
                           "IN (SELECT source_id FROM ingestion_sources WHERE "
                           "source_name IN ({}) AND ingest_id  = (SELECT ingest_id from "
                           "ingestion WHERE ingest_name = '{}' and delete_flag = '0') )".format(stage_table,
                                                                                                source_name_list,
                                                                                                ingest_name))
            logger.error("OK1")
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            cursor = connection.cursor()
            cursor.execute("DELETE FROM ingestion_sources WHERE   source_id "
                           "IN (SELECT source_id FROM ingestion_sources WHERE "
                           "source_name IN ({}) AND ingest_id  = (SELECT ingest_id from "
                           "ingestion WHERE ingest_name = '{}' and delete_flag = '0') ) ".format(source_name_list,
                                                                                                 ingest_name))
            logger.error('ok2')
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        return JsonResponse({'Success': 'OK'})


class ResumeFlow(APIView):
    """
    In the ingestion list there is a option 'resume flow'.

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'Failure': 'API not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            # logger.error(data)
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        # try:
        #     entity_name = request.META['HTTP_ENTITY']
        #     logger.error(str(entity_name))
        # except Exception as e:
        #     logger.error("error in entity name in ResumeFlow class!!!")
        #     return JsonResponse({'failure': 'Entity name not found'})
        try:
            ingest_name = data['ingest_name']
            source_uid = data['source_uid']
            edit_flag = False
            # logger.error(str(ingest_name))
            # logger.error(str(source_uid))
            dm_name = request.session['username']
            dm_uid = request.session['user_id']
            # logger.error(str(dm_name))
            # logger.error(str(dm_uid))
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_id, flow_id, steward_id FROM ingestion WHERE ingest_name = '{}' "
                               "AND uid = '{}' AND delete_flag = '0'".format(ingest_name, source_uid))
                logger.error(str('query successful'))
                data = cursor.fetchall()
                logger.error('sadsad' + str(data))
            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            request.session['ingest_id'] = data[0][0]
            request.session['flow_id'] = data[0][1]
            request.session['steward_id'] = data[0][2]
            logger.error(str("variable fetch is done"))
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT flow_name, access_type from flow WHERE flow_id = '{}' AND delete_flag = '0' AND "
                               "updated_date is NULL".format(request.session['flow_id']))
                data1 = cursor.fetchall()
            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error(str(data1))
            flow_name = data1[0][0]
            access_type = data1[0][1]
            # logger.error(str(flow_name))
            logger.error(str("done!!"))
            # TODO need to pay attention here we lost ourself here!!!
            rules = get_rules_and_validation_from_string(flow_name, dm_name, request, flag=0)
            print(type(rules))
            logger.error('rules:  ' + str(rules))
            request.session['rules'] = rules
            request.session['rules']['matcher_rules'] = rules['matcher_rules']
            request.session['rules']['validation_rules'] = rules['validation_rules']
            return JsonResponse({'Ok': 'Success'})
        except Exception as e:
            logger.error("Table not found in database")
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'Failure': 'code error'})


class SearchIngestList(APIView):
    """


    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'Failure': 'API not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_name = data['ingest_name']
            page_number = data['page_number']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        # try:
        #     entity_name = request.META['HTTP_ENTITY']
        #     logger.error(str(entity_name))
        # except Exception as e:
        #     logger.error("error in entity name in ResumeFlow class!!!")
        #     return JsonResponse({'failure': 'Entity name not found'})
        try:
            if ingest_name:
                ingest_search = "AND ingest_name ilike '%" + str(ingest_name) + "%'"
                data = ingest_list(request, page_number=page_number, ingest_search=ingest_search)
                logger.error("data in ing search: " + str(data))
                return data
            else:
                return JsonResponse({'failure': 'No ingest name found.'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse({'success': 'ok'})
