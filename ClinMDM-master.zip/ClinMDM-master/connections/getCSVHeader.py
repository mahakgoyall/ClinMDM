import csv
import logging
import re

logger = logging.getLogger("mdm_logging")


def headerCSV(csvf, request):
    try:
        logger.info("csvf: "+ str(csvf))
        with open(csvf, 'r') as myCsvFile:
            dial = None
            string = re.split(r"[~\r\n]+", myCsvFile.read())
            if not len(string):
                logger.info("CSV file is empty")
                raise TypeError("CSV file is empty")
            header = string[0]
            if header[:-1] == '\n':
                header = header[:-1]
            if header[:-1] == '\r':
                header = header[:-1]

            if header.find(";") != -1:
                dial = ";"
            if header.find(",") != -1:
                dial = ","
            if header.find("|") != -1:
                dial = "|"
            if header.find(";") != -1:
                dial = ";"

            if dial is None:
                logger.info("Cannot find delimiter")
                raise Exception("Cannot find delimiter")

            logger.debug("Delimiter is: " + str(dial))
            request.session['delimiter'] = dial
            request.session['header'] = header
            reader = csv.reader(myCsvFile, delimiter=dial)
            # header = next(reader)
            logger.debug("Header is found: " + str(header))
            return header
    except Exception as e:
        logger.error("Error is: " + str(e))
        return ''
