from django.http import JsonResponse
from django.db import connection
from rest_framework.views import APIView
import pandas as pd
from fuzzywuzzy import fuzz
import time
import logging

logger = logging.getLogger("mdm_logging")

start = 0
ingest_id = '1000'
uid = '1'
steward_id = '123'
TABLE_NAME = 'mdm_golden_temp'

mdm_column_list = """'mdm_id', 'source_id', 'source_id', 'contact_type', 'fst_name', 'full_name', 'mid_name',
                   'last_name', 'fax_ph_num1', 'fax_ph_num2', 'fax_ph_num3', 'primary_mobile_num',
                   'secondary_mobile_num', 'work_phone1', 'work_phone2', 'work_phone3', 'home_phone', 'ethnicity_name',
                   'marital_status', 'birth_dt', 'birth_place', 'citizenship', 'education_bckgnd', 'education_years',
                   'grad_yr', 'email_address', 'addr_eff_date', 'decease_flg', 'per_title', 'per_title_suffix',
                   'job_title', 'comments', 'primary_specialty', 'degree', 'certification', 'gender', 'manager_id',
                   'created_by_id', 'changed_by_id', 'created_on_dt', 'changed_on_dt', 'country', 'state', 'site_id',
                   'protocol_num', 'ts_current'"""

source = """'record_id', 'mdm_id', 'source_id', 'source_id', 'contact_type', 'fst_name', 'full_name',
          'mid_name', 'last_name ', 'fax_ph_num1', 'fax_ph_num2', 'fax_ph_num3', 'primary_mobile_num',
          'secondary_mobile_num', 'work_phone1', 'work_phone2', 'work_phone3', 'home_phone',
          'ethnicity_name', 'marital_status', 'birth_dt', 'birth_place', 'citizenship',
          'education_bckgnd', 'education_years', 'grad_yr', 'email_address', 'addr_eff_date',
          'decease_flg', 'per_title', 'per_title_suffix', 'job_title', 'comments', 'primary_specialty',
          'degree', 'certification', 'gender', 'manager_id', 'created_by_id', 'changed_by_id', 'created_on_dt',
          'changed_on_dt', 'country', 'state', 'site_id', 'protocol_num', 'ts_current', 'ingest_id',
          'ingest_source_id', 'uid'"""


def convert_into_string(values_list):
    string = ''
    for lst in values_list:
        string += '('
        for val in lst:
            string = string + "'" + str(val) + "', "
        string = string[:-2]
        string += '), '
    string = string[:-2]
    return string


def insert_into_no_match_ref_table(no_match_list):
    string = convert_into_string(no_match_list)
    try:
        cursor = connection.cursor()
        logger.error("Inserting into no match table")
        cursor.execute("INSERT INTO nomatch_ref (record_id, ingest_id, uid, ingest_source_id) VALUES {}".format(string))
        connection.commit()
    except Exception as e:
        logger.error(str(e))


def insert_into_partial_ref_table(partial_match_list):
    string = convert_into_string(partial_match_list)
    try:
        cursor = connection.cursor()
        logger.error("Inserting into partial match table")
        cursor.execute("INSERT INTO partial_ref (record_id, mdm_id, ingest_id, uid, ingest_source_id, steward_id) "
                       "VALUES {}".format(string))
        connection.commit()
        cursor.close()
    except Exception as e:
        # connection.rollback()
        # cur.close()
        logger.error(str(e))


def insert_into_exact_ref_table(exact_match_list):
    string = convert_into_string(exact_match_list)
    try:
        cursor = connection.cursor()
        logger.error("Inserting into exact match table")
        cursor.execute("INSERT INTO exact_ref (record_id, mdm_id, ingest_id, uid, ingest_source_id) VALUES "
                       "{}".format(string))
        connection.commit()
        cursor.close()
    except Exception as e:
        # connection.rollback()
        # cursor.close()
        logger.error(str(e))


class Main(APIView):
    @staticmethod
    def get(request, name):
        global start, mdm_column_list, source, ingest_id, uid, steward_id

        source_column_list = source
        exact_match_list = list()
        partial_match_list = list()
        no_match_list = list()
        mdm_column_list = mdm_column_list.replace("'", "")
        source_column_list = source_column_list.replace("'", "")
        logger.error('SELECT ' + mdm_column_list + ' FROM "{}"'.format('mdm_golden'))
        mdm = pd.read_sql('SELECT ' + mdm_column_list + ' FROM "{}"'.format('mdm_golden'), connection)

        logger.error("Length of mdm is: " + str(len(mdm)))

        # Pick data that is validated
        source_data = pd.read_sql('SELECT ' + source_column_list + ' FROM "{}" '.format('source_yy'), connection)
        ratio_list = list()
        start = time.time()
        k = 0
        source_len = len(source_data)
        mdm_len = len(mdm)
        logger.error("starting")
        for i in range(source_len):
            # not_find = True
            s_fst = source_data['fst_name'][i]
            s_lst = source_data['last_name'][i]
            for j in range(mdm_len):
                # flags = list()
                # exact_match = False
                ratio_list.append(s_fst == mdm['fst_name'][j])
                k += 1
                # logger.error(str(fuzz_ratio_fst) + " " + str(fuzz_ratio_lst))

        logger.error("Total iter is " + str(k))
        logger.error("Time taken in complete rule_engine: " + str(time.time() - start))

                # for rule in [['fst_name', 'last_name']]:
                #     rule_flag = True
                #     below_flag = False
                #     for r in rule:
                #         s1 = str(source_data[r][i]).lower().strip()
                #         s2 = str(mdm[r][j]).lower().strip()
                #         if s1 == s2 and s1 != '' and s2 != '':
                #             continue
                #
                #         below_flag = True
                #         if r == 'email_address' or r == 'primary_mobile_num':
                #             flags.append(True)
                #             rule_flag = False
                #             continue
                #         fuzz_ratio = fuzz.ratio(str(source_data[r][i]).lower(), str(mdm[r][j]).lower())
                #         # Below are the cases when strings are different
                #         # Case1: Fuzz Ratio is less than 75 and is not 0 ex: Ram and Shyam (50)
                #         # Case2: Fuzz Ratio is 0 and both strings are not null ex: Ram and Mou (0)
                #         # Case3: Exactly one of the two string is empty
                #         if (fuzz_ratio < 75 and fuzz_ratio != 0) or \
                #                 (fuzz_ratio == 0 and source_data[r][i] != '' and mdm[r][j] != '') or \
                #                 ((source_data[r][i] != '' and mdm[r][j] == '') or (source_data[r][i] == '' and mdm[r][j] != '')):
                #             flags.append(True)
                #             rule_flag = False
                #             break
                #
                #     if not below_flag:
                #         exact_match = True
                #         not_find = False
                #         exact_match_list.append([source_data['record_id'][i], mdm['mdm_id'][j], ingest_id, uid,
                #                                  source_data['ingest_source_id'][i]])
                #         break
                #
                #     if rule_flag:
                #         flags.append(False)
                #
                # if False in flags and not exact_match:
                #     not_find = False
                #     partial_match_list.append([source_data['record_id'][i], mdm['mdm_id'][j], ingest_id, uid,
                #                                source_data['ingest_source_id'][i], steward_id])

            # if not_find:
            #     no_match_list.append([source_data['record_id'][i], ingest_id, uid, source_data['ingest_source_id'][i]])



        if len(exact_match_list) > 0:
            insert_into_exact_ref_table(exact_match_list)

        if len(partial_match_list) > 0:
            insert_into_partial_ref_table(partial_match_list)

        if len(no_match_list) > 0:
            insert_into_no_match_ref_table(no_match_list)

        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT DISTINCT (mdm_id) FROM partial_ref WHERE ingest_id='{}' AND uid='{}' AND partial_ref.mdm_id IS NOT NULL ".format(
                    ingest_id, uid))
            mdm_ids = cursor.fetchall()
            counter = 1
            for mdm_id in mdm_ids:
                cursor = connection.cursor()
                cursor.execute(
                    "UPDATE partial_ref SET task_id='{}' WHERE ingest_id='{}' AND uid='{}' AND partial_ref.mdm_id='{}'".format(
                        counter, ingest_id, uid, mdm_id[0]))
                connection.commit()
                counter += 1
        except Exception as e:
            logger.error(str(e))
        return JsonResponse({'ok': 'Success'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure': 'API not supported'})


def truncate(request):
    cursor = connection.cursor()
    cursor.execute("TRUNCATE TABLE partial_ref")
    cursor = connection.cursor()
    cursor.execute("TRUNCATE TABLE nomatch_ref")
    cursor = connection.cursor()
    cursor.execute("TRUNCATE TABLE excat_ref")
    return JsonResponse({'ok': 'success'})
