from django.db import connection
from rest_framework.views import APIView
from django.http import JsonResponse
import collections
import json
import logging
from connections.views import create_ingestion, UseExistingFlow
from django.conf import settings
from validator.column_mapping import business_to_column

logger = logging.getLogger("mdm_logging")


def convert_to_alias(names, entity_name):
    if entity_name == 'study':
        alias_to_columns = settings.STUDY_COLUMN_DICT
    elif entity_name == 'investigator':
        alias_to_columns = settings.COLUMN_DICT
    else:
        alias_to_columns = settings.ORG_COLUMN_DICT

    columns_to_alias = dict()
    for k, v in alias_to_columns.items():
        columns_to_alias[v] = k
    result = list()
    for name in names:
        if name in columns_to_alias:
            result.append(columns_to_alias[name].upper())
        else:
            result.append(name.upper())
    return result


class MdmBrowser(APIView):

    @staticmethod
    def post(request):
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity name: "+ str(entity_name))
            # entity_name = 'investigator'
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'No data found in body.'}
        try:
            source_uid = data['source_uid']
            request.session['source_uid'] = source_uid
            ingest_name = data['ingest_name']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Cannot find data in request'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_id FROM ingestion WHERE ingest_name='{}' "
                           "AND uid = '{}' and entity = '{}' ".format(ingest_name,source_uid, entity_name))
            ingest_id = cursor.fetchall()[0][0]
            request.session['ingest_id'] = ingest_id
            ui_information = dict()
            ui_information[0] = 'No Match records'
            ui_information[1] = 'Exact records'
            ui_information[2] = 'Partial Match records'
            ui_information[3] = 'Ingested Source records'
            ui_information[4] = 'Rejected records'
            ui_information[5] = 'Validated records'
            logger.error(str(ui_information))
            return JsonResponse(ui_information)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure in Query'})

    @staticmethod
    def get(request):
        return JsonResponse({'failure': 'API not supported.'})


class UserData(APIView):

    @staticmethod
    def get(request, page_number):
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request, page_number, reverse_dict=None, tbl_name=None, sort=None):
        try:
            if not (tbl_name or sort or reverse_dict):
                data = json.loads(request.read().decode('utf-8'))
                logger.error("data mdm: " + str(data))
                ingest_name = data['ingest_name']
                entity_name = request.META['HTTP_ENTITY']
                try:
                    cursor = connection.cursor()
                    cursor.execute("select ingest_id from ingestion where ingest_name = '{}'"
                                   .format(ingest_name))
                    request.session['ingest_id'] = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
            else:
                # ingest_id = request.session.get('ingest_id', False)
                entity_name = request.META['HTTP_ENTITY']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'No data found in body.'}
        logger.error("sort is this  :  " + str(sort))

        try:
            sort_string = ''
            count_string = ''
            string = ''
            if sort and reverse_dict:
                sort_string += sort
                table_name = tbl_name
                logger.error("reverse dict found")
                for key, value in reverse_dict.items():
                    if key == 'mdm_id' or key == 'stage_id':
                        string += ' v.' + key + " = '" + value + "' and "
                        count_string += ' i.' + key + " = '" + value + "' and "
                        logger.error("string: " + str(string))
                    else:
                        string += ' s.' + key + " ilike '%" + value + "%' and "
                        count_string += ' i.' + key + " ilike '%" + value + "%' and "
                        logger.error("string: " + str(string))

                # logger.error("string: " + str(string))
                string = string[:-4]
                count_string = count_string[:-4]
                count_string = " AND " + count_string
                logger.error("string: " + str(string))
                logger.error("Count string  : " + str(count_string))
            elif sort:
                sort_string += sort
                table_name = tbl_name
            elif reverse_dict:
                table_name = tbl_name
                logger.error("reverse dict found")
                for key, value in reverse_dict.items():
                    if key == 'mdm_id' or key == 'stage_id':
                        string += ' v.' + key + " = '" + value + "' and "
                        count_string += key + " = '" + value + "' and "
                        logger.error("string: " + str(string))
                    else:
                        string += ' s.' + key + " ilike '%" + value + "%' and "
                        count_string += ' i.' + key + " ilike '%" + value + "%' and "
                        logger.error("string: " + str(string))

                # logger.error("string: " + str(string))
                string = string[:-4]
                count_string = count_string[:-4]
                count_string = " AND " + count_string
                logger.error("string: " + str(string))
                logger.error("Count string  : " + str(count_string))

            else:
                # data = json.loads(request.read().decode('utf-8'))
                table_name = data['table_name']
                logger.error("table name in else: " + str(table_name))
            user_id = request.session['user_id']

            if entity_name == 'study':
                stage_table = 'stage_study'
                master_table = 'mdm_study'
            elif entity_name == 'investigator':
                stage_table = 'stage_investigator'
                master_table = 'mdm_golden'
                master_col_names = settings.COLUMN_LIST
            else:
                stage_table = 'stage_org'
                master_table = 'mdm_org'
                master_col_names = collections.OrderedDict(settings.ORG_COLUMN_DICT)
                # From all master tables remove last 2 columns --> current_ts and end_ts
                # From all staging tables remove
            # try:
            #     cursor = connection.cursor()
            #     cursor.execute("SELECT column_name from information_schema.columns where "
            #                    "table_name = '{}'".format(master_table))
            #     master_col_names_2 = cursor.fetchall()
            #
            # except Exception as e:
            #     logger.error(str(e))
            #     k = dict()
            #     k['Error'] = str(e).replace("'", '"')
            #     # k = json.dumps(k)
            #     cursor = connection.cursor()
            #     logger.error(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            #     cursor.execute(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1),
            #             request.session.get('user_id', -1), json.dumps(k)))
            #     connection.commit()
            # logger.error("master_before: " + str(master_col_names))
            # logger.error("master column dict  :  " + str(master_col_names))
            # master_col_names = [key[1] for key in master_col_names.items()]
            # for i in master_col_names_2[]
            master_col_appended_s = list()
            master_col_without_quote = list()
            master_col_quote_appended_without_s = list()
            master_col = list()
            # logger.error()
            for col in master_col_names[1:]:
                master_col.append('"' + str(col) + '"')
                master_col_without_quote.append(str(col))
                master_col_quote_appended_without_s.append('"' + str(col) + '"')
                master_col_appended_s.append('s."' + str(col) + '"')
            # logger.error("master_columns :" + str(master_col_appended_s))

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found in request'})
        try:
            ui_information = dict()
            if table_name == 'No Match records':
                ingest_id = request.session['ingest_id']
                logger.error("no match records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                logger.error("where string  :  " + str(where_string))
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT v."stage_id", v."mdm_id", {} FROM \"{}\" AS s JOIN
                                   nomatch_ref AS v ON  s."stage_id" = v."stage_id" WHERE
                                   s."ingest_id" = '{}' {} limit 10 offset {}""".format(", ".join(master_col_appended_s), stage_table,
                                                             ingest_id, where_string,
                                                            str((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT v."stage_id", v."mdm_id", {} FROM \"{}\" AS s JOIN
                                nomatch_ref AS v ON s."stage_id" = v."stage_id" WHERE
                                s."ingest_id" = '{}' {} limit 10 offset {}""".format(", ".join(master_col_appended_s),
                                                                                     stage_table,ingest_id,
                                                                          where_string, str((int(page_number) - 1) * 10)))
                    # cursor.execute("""SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY v."mdm_id" ASC) as rownumber ,
                    #                v."stage_id", v."mdm_id", {} FROM \"{}\" AS s JOIN
                    #                nomatch_ref AS v ON s."ingest_id" = v."ingest_id" AND s."stage_id" = v."stage_id" WHERE
                    #                s."ingest_id" = '{}' {} ) AS s WHERE rownumber >= {} AND
                    #                rownumber <= {} """.format(", ".join(master_col_appended_s), stage_table,
                    #                                          ingest_id, where_string, str(((int(page_number) -1) * 10)+1),
                    #                                         str(((int(page_number) - 1) * 10) + 10)));
                    data = cursor.fetchall()
                    # logger.error("data: "+ str(data))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    logger.error("count string: "+ str(count_string))
                    cursor = connection.cursor()
                    logger.error("SELECT COUNT(*) FROM \"nomatch_ref\" as n join {} as i "
                                   " on n.stage_id = i.stage_id   WHERE "
                                   "n.ingest_id='{}'  and"
                                 " n.mdm_id is not null  {} ".format(stage_table, ingest_id, count_string))
                    cursor.execute("SELECT COUNT(*) FROM \"nomatch_ref\" as n join {} as i "
                                   " on n.stage_id = i.stage_id   WHERE "
                                   "n.ingest_id='{}' "
                                   " and n.mdm_id is not null  {} ".format(stage_table,ingest_id, count_string))
                    total = cursor.fetchall()[0][0]
                    # logger.error("total: "+ str(total))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id", "mdm_id"] + master_col_without_quote
            elif table_name == 'Exact records':
                ingest_id = request.session['ingest_id']
                logger.error("exact records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT v."stage_id", v."mdm_id", {} FROM \"{}\" AS s JOIN
                                   exact_ref AS v ON  s."stage_id" = v."stage_id" WHERE
                                   s."ingest_id" = '{}' {}
                                   limit 10 offset {}""".format(", ".join(master_col_appended_s), stage_table, ingest_id,
                                                                  where_string,
                                                            int((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT v."stage_id", v."mdm_id", {} FROM \"{}\" AS s JOIN
                                                   exact_ref AS v ON  s."stage_id" = v."stage_id" WHERE
                                                   s."ingest_id" = '{}' {}
                                                   limit 10 offset {}""".format(", ".join(master_col_appended_s),
                                                                                stage_table, ingest_id,
                                                                                where_string,
                                                                                int((int(page_number) - 1) * 10)))
                    data = cursor.fetchall()
                    # logger.error("data : "+ str(data))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT COUNT(*) FROM \"exact_ref\" as e join {} as i on e.stage_id = i.stage_id"
                                   "  WHERE "
                                   "e.ingest_id='{}'  {}".format(stage_table, ingest_id, count_string))
                    logger.error("SELECT COUNT(*) FROM \"exact_ref\" as e join {} as i on e.stage_id = i.stage_id"
                                   "  WHERE "
                                   "e.ingest_id='{}'  {}".format(stage_table, ingest_id, count_string))
                    total = cursor.fetchall()[0][0]
                    # logger.error("total: "+ str(total))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id", "mdm_id"] + master_col_without_quote
            elif table_name == 'Partial Match records':
                ingest_id = request.session['ingest_id']
                logger.error("partialmatch records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT v."stage_id", v."mdm_id", {} FROM "{}" AS s JOIN
                                   partial_ref AS v ON s."stage_id" = v."stage_id" WHERE
                                   s."ingest_id" = '{}' {}
                                   limit 10 offset {} """.format(", ".join(master_col_appended_s), stage_table,
                                                                 ingest_id, where_string,
                                                            int((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT v."stage_id", v."mdm_id", {} FROM "{}" AS s JOIN
                                               partial_ref AS v ON  s."stage_id" = v."stage_id" WHERE
                                               s."ingest_id" = '{}' {}
                                               limit 10 offset {} """.format(", ".join(master_col_appended_s), stage_table,
                                                                             ingest_id, where_string,
                                                                             int((int(page_number) - 1) * 10)))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT COUNT(*) FROM \"partial_ref\" as p join {} as i "
                                   "on p.stage_id = i.stage_id WHERE "
                                   "p.ingest_id='{}'  {}".format(stage_table, ingest_id, count_string))
                    total = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id", "mdm_id"] + master_col_without_quote

            elif table_name == 'Rejected records':
                ingest_id = request.session['ingest_id']
                logger.error("rejected records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT s.stage_id, s.reason, {} FROM "{}" AS s WHERE
                                   s.ingest_id = '{}' and s.valid_flag IS NULL {}
                                    limit 10 offset {}""".format(", ".join(master_col_appended_s), stage_table,
                                                                ingest_id, where_string,
                                                            str((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT s.stage_id, s.reason, {} FROM "{}" AS s WHERE
                                                   s.ingest_id = '{}' and s.valid_flag IS NULL {}
                                                    limit 10 offset {}""".format(", ".join(master_col_appended_s),
                                                                                  stage_table,
                                                                                  ingest_id, where_string,
                                                                                  str((int(page_number) - 1) * 10)))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT COUNT(*) FROM \"{}\" as i "
                                   "WHERE i.ingest_id='{}' and i.valid_flag IS NULL {}".format(stage_table, ingest_id,
                                                                                           count_string))
                    total = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id", "reason"] + master_col_without_quote

            elif table_name == 'Validated records':
                ingest_id = request.session['ingest_id']
                logger.error("validated records records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                # logger.error("""SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY s.stage_id ASC) AS rownumber,
                #                s.stage_id, {} FROM \"{}\" AS s  WHERE
                #                s.ingest_id = '{}' and s.valid_flag = '1' {} ) AS s
                #                WHERE rownumber >= {} AND rownumber <= {} """.format(", ".join(master_col_appended_s),
                #                                                                    stage_table, ingest_id, where_string,
                #                                                                    str(((int(page_number) -1) * 10)+1),
                #                                         str(((int(page_number) - 1) * 10) + 10)))
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT s.stage_id, {} FROM \"{}\" AS s  WHERE
                                    s.ingest_id = '{}' and s.valid_flag = '1' {}
                                     limit 10 offset {} """.format(", ".join(master_col_appended_s),
                                                                                        stage_table, ingest_id, where_string,
                                                                 int((int(page_number) - 1) * 10)))

                    cursor.execute("""SELECT s.stage_id, {} FROM \"{}\" AS s  WHERE
                                                    s.ingest_id = '{}' and s.valid_flag = '1' {}
                                                     limit 10 offset {} """.format(", ".join(master_col_appended_s),
                                                                                   stage_table, ingest_id, where_string,
                                                                                   int((int(page_number) - 1) * 10)))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    cursor = connection.cursor()
                    cursor.execute("SELECT COUNT(*) FROM  \"{}\" as i  "
                                   "WHERE i.ingest_id='{}' and i.valid_flag='1' {}".format(stage_table, ingest_id, count_string))
                    total = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id"] + master_col_without_quote

            elif table_name == 'Ingested Source records':
                ingest_id = request.session['ingest_id']
                logger.error("Ingested Source records ingest id: " + str(ingest_id))
                if reverse_dict and sort:
                    where_string = 'AND ' + string + sort_string
                elif reverse_dict:
                    where_string = 'AND ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT stage_id, {}
                                    FROM \"{}\" as s where ingest_id = '{}' {}
                                    limit 10 offset {}""".format(", ".join(master_col_quote_appended_without_s),
                                                                  stage_table,ingest_id, where_string,
                                                            int((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT stage_id, {} FROM \"{}\" as s where ingest_id = '{}' {}
                                                    limit 10 offset {}""".format( ", ".join(master_col_quote_appended_without_s),
                                                                                stage_table, ingest_id, where_string,
                                                                                int((int(page_number) - 1) * 10)))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                try:
                    cursor = connection.cursor()
                    logger.error("SELECT COUNT(*) FROM \"{}\" as i where i.ingest_id = '{}' {} ".format(stage_table,
                                                                                                          ingest_id,
                                                                                                          count_string))
                    cursor.execute("SELECT COUNT(*) FROM \"{}\" as i where i.ingest_id = '{}' {} ".format(stage_table,
                                                                                                   ingest_id, count_string))
                    total = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["Stage_id"] + master_col_without_quote
            else:
                logger.error("here   :   ")
                if reverse_dict and sort:
                    where_string = 'WHERE ' + string + sort_string
                elif reverse_dict:
                    where_string = 'WHERE ' + string
                elif sort:
                    where_string = sort_string
                else:
                    where_string = ''
                try:
                    where_string = where_string.replace("v.","s.")
                    cursor = connection.cursor()
                    logger.error("""SELECT s.mdm_id, {} FROM \"{}\" as s {}
                                  limit 10 offset {}""".format(", ".join(master_col), master_table, where_string,
                                                                           int((int(page_number) - 1) * 10)))
                    cursor.execute("""SELECT s.mdm_id, {} FROM \"{}\" as s {}
                                  limit 10 offset {}""".format(", ".join(master_col), master_table, where_string,
                                                                           int((int(page_number) - 1) * 10)))

                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                logger.error("data: " + str(data))
                count_string_new = ''
                if count_string:
                    count_string_new = "WHERE " + count_string[4:]
                try:
                    cursor = connection.cursor()
                    logger.error("SELECT COUNT(*) FROM \"{}\" as i {}".format(master_table, count_string_new))
                    cursor.execute("SELECT COUNT(*) FROM \"{}\" as i {}".format(master_table, count_string_new))
                    # ui_information = dict()
                    total = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['total'] = total
                ui_information['columns'] = ["mdm_id"] + master_col_without_quote
                logger.error("columns: " + str(ui_information['columns']))
                ui_information['data'] = data
            ui_information['columns'] = convert_to_alias(ui_information['columns'], entity_name)

            if reverse_dict or sort:
                return ui_information
            else:
                return JsonResponse(ui_information)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB query failure'})


class ColumnSearch(APIView):
    """

    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'No data found in body.'}
        try:
            sort_string = ''
            string = ''
            try:
                sort_field = data['sort']
                logger.error("data[sort]  : " + str(sort_field))
                if sort_field:
                    sort_string += ' ORDER BY '
            except Exception as e:
                sort_field = None
                logger.error(str(e))
                k = str(e)
                try:
                    cursor = connection.cursor()
                    logger.error("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) 
                                                                                          values('{}','{}', json.dumps(str(e)))""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1)))
                    cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) 
                                                                                          values('{}','{}', json.dumps(str(e)))""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1)))
                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                pass
            search_dict = data['search']
            page_no = int(data['page'])
            logger.error("search dict  : " + str(search_dict))
            reverse_column_dict = dict()
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity name  : " + str(entity_name))
            if entity_name == 'investigator':
                obj2 = business_to_column(getattr(settings, "COLUMN_DICT", {}))

            elif entity_name == 'study':
                obj2 = business_to_column(getattr(settings, "STUDY_COLUMN_DICT", {}))  # CHANGE TO SPONSOR COLUMN DICT
            else:
                obj2 = business_to_column(getattr(settings, "ORG_COLUMN_DICT", {}))
            if search_dict:
                for col, value in search_dict.items():
                    reverse_column_dict[obj2.get_column_name(col)] = value
            if sort_field:
                sort_string += " s." + str(obj2.get_column_name(sort_field[0])) + " " + str(sort_field[1])
            logger.error("sort string  :  " + str(sort_string))
            logger.error("reverse column_data: " + str(reverse_column_dict))
            table_name = data['table_name']
            logger.error("table_name: "+ str(table_name))
            data = UserData.post(request=request, page_number=page_no, reverse_dict=reverse_column_dict, tbl_name=table_name, sort=sort_string)
            logger.error("column search data  : " + str(data))

            return JsonResponse(data)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found for search.'})


class ExportDataAsPDF(APIView):
    """

    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            # logger.error("reverse_dict: "+ str(reverse_dict))
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity name in pdfextractor : " + str(entity_name))
            # if not reverse_dict:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'No data found in body.'}
        # string = ''
        try:

            # if reverse_dict:
            #     logger.error("reverse dict found")
            #     for key, value in reverse_dict.items():
            #         if key == 'mdm_id' or key == 'stage_id':
            #                 string += ' v.' + key + " = '" + value + "' and "
            #                 logger.error("string: "+ str(string))
            #         else:
            #                 string += ' s. ' + key + " = '" + value + "' and "
            #                 logger.error("string: "+ str(string))
            #
            #     logger.error("string: " + str(string))
            #     string = string[:-4]
            #     logger.error("string: " + str(string))
            #
            # # ingest_name = data['ingest_name']
            # if tbl_name:
            #     table_name = tbl_name
            # else:
            table_name = data['table_name']
            # user_id = request.session['user_id']
            ingest_id = request.session['ingest_id']
            # username = request.session['username']

            if entity_name == 'study':
                stage_table = 'stage_study'
                master_table = 'mdm_study'
            elif entity_name == 'investigator':
                stage_table = 'stage_investigator'
                master_table = 'mdm_golden'
            else:
                stage_table = 'stage_org'
                master_table = 'mdm_org'

                # From all master tables remove last 2 columns --> current_ts and end_ts
                # From all staging tables remove
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT column_name from information_schema.columns where "
                               "table_name = '{}'".format(master_table))
                master_col_names = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error("master_before: " + str(master_col_names))
            master_col_appended_s = list()
            master_col_without_quote = list()
            master_col_quote_appended_without_s = list()
            for col in master_col_names[1:-2]:
                master_col_without_quote.append(str(col[0]))
                master_col_quote_appended_without_s.append('"' + str(col[0]) + '"')
                master_col_appended_s.append('s."' + str(col[0]) + '"')
            logger.error("master_columns :" + str(master_col_appended_s))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found in request'})
        try:
            ui_information = dict()
            # cursor = connection.cursor()
            if table_name == 'Golden':
                # if reverse_dict:
                #     where_string = string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT s.mdm_id, {} FROM "{}" AS s
                                  where {}""".format(", ".join(master_col_appended_s),master_table, where_string))
                    cursor.execute("""SELECT s.mdm_id, {} FROM
                                    "{}" AS s """.format(", ".join(master_col_appended_s), master_table,
                                                                     where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM \"nomatch_ref\" AS v  WHERE v.ingest_id='{}' and v.uid = '{}'".format(ingest_id, user_id))
                # total = cursor.fetchall()[0][0]
                # ui_information['total'] = total
                ui_information['columns'] = ["mdm_id"] + master_col_without_quote
            elif table_name == 'No Match records':
                # if reverse_dict:
                #     where_string = 'AND ' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT v.stage_id, v.mdm_id, {} FROM "{}" AS s JOIN
                                     nomatch_ref AS v ON s.ingest_id = v.ingest_id AND s.stage_id = v.stage_id WHERE
                                    s.ingest_id = '{}' {}""".format(", ".join(master_col_appended_s),
                                                                                   stage_table, ingest_id, where_string))
                    cursor.execute("""SELECT v.stage_id, v.mdm_id, {} FROM "{}" AS s JOIN
                                   nomatch_ref AS v ON s.ingest_id = v.ingest_id AND s.stage_id = v.stage_id WHERE
                                   s.ingest_id = '{}' {}""".format(", ".join(master_col_appended_s),
                                                                   stage_table, ingest_id, where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM \"nomatch_ref\" AS v  WHERE v.ingest_id='{}' and v.uid = '{}'".format(ingest_id, user_id))
                # total = cursor.fetchall()[0][0]
                # ui_information['total'] = total
                ui_information['columns'] = ["stage_id", "mdm_id"] + master_col_without_quote

            elif table_name == 'Exact records':
                # if reverse_dict:
                #     where_string = 'AND ' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    cursor.execute("""SELECT
                                   v.stage_id, v.mdm_id, {} FROM "{}" AS s JOIN
                                   exact_ref AS v ON s.ingest_id = v.ingest_id AND s.stage_id = v.stage_id WHERE
                                   s.ingest_id = '{}' {}""".format(", ".join(master_col_appended_s),
                                                                       stage_table, ingest_id, where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM \"exact_ref\" AS v WHERE v.ingest_id='{}' and uid = '{}'".format(ingest_id, user_id))
                # total = cursor.fetchall()[0][0]
                # ui_information['total'] = total
                ui_information['columns'] = ["stage_id", "mdm_id"] + master_col_without_quote

            elif table_name == 'Partial Match records':
                # if reverse_dict:
                #     where_string = 'AND ' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    cursor.execute("""SELECT
                                   v.stage_id, v.mdm_id, {} FROM "{}" AS s JOIN
                                   partial_ref AS v ON s.ingest_id = v.ingest_id AND s.stage_id = v.stage_id WHERE
                                   s.ingest_id = '{}'""".format(", ".join(master_col_appended_s), stage_table,
                                                                ingest_id, where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM \"partial_ref\" AS v WHERE v.ingest_id='{}' and v.uid = '{}'".format(ingest_id, user_id))
                # total = cursor.fetchall()[0][0]
                ui_information['columns'] = ["stage_id", "mdm_id"] + master_col_without_quote

            elif table_name == 'Rejected records':
                # if reverse_dict:
                #     where_string = 'AND ' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    cursor.execute("""SELECT
                                   s.stage_id, s.reason, {} FROM "{}" AS s WHERE
                                   s.ingest_id = '{}'
                                   and s.valid_flag IS NULL {}""".format(", ".join(master_col_appended_s),
                                                                     stage_table, ingest_id, where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM \"stage_investigator\" AS s WHERE s.ingest_id='{}' and s.valid_flag IS NULL".format(ingest_id))
                # total = cursor.fetchall()[0][0]
                # ui_information['total'] = total
                ui_information['columns'] = ["stage_id", "reason"] + master_col_without_quote

            elif table_name == 'Validated records':
                # if reverse_dict:
                #     where_string = 'AND' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    cursor.execute("""SELECT
                                   s.stage_id, {} FROM "{}" AS s  WHERE
                                   s.ingest_id = '{}' and s.valid_flag = '1' {})""".format(", ".join(master_col_appended_s),
                                                                                       stage_table, ingest_id, where_string))
                    data = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                ui_information['data'] = data
                # cursor = connection.cursor()
                # cursor.execute("SELECT COUNT(*) FROM  \"stage_investigator\" AS s WHERE s.ingest_id='{}' and valid_flag='1'".format(ingest_id))
                # total = cursor.fetchall()[0][0]
                # ui_information['total'] = total
                ui_information['columns'] = ["stage_id"] + master_col_without_quote

            else:
                # if reverse_dict:
                #     where_string = 'where ' + string
                # else:
                where_string = ''
                try:
                    cursor = connection.cursor()
                    logger.error("""SELECT s.stage_id, {}
                                   FROM "{}" as s """.format(", ".join(master_col_appended_s), stage_table, where_string))
                    cursor.execute("""SELECT s.stage_id, {}
                                   FROM "{}" as s """.format(", ".join(master_col_appended_s), stage_table, where_string))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                # data = cursor.fetchall()
                ui_information['data'] = None
                # cursor = connection.cursor()
                ui_information['columns'] = ["stage_id"] + master_col_without_quote

            ui_information['columns'] = convert_to_alias(ui_information['columns'], entity_name)
            # if not reverse_dict:
            return JsonResponse(ui_information)
            # return ui_information
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB query failure'})

