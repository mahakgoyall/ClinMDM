from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.MdmBrowser.as_view(), name='mdm browser'),
    # url(r'^master/(?P<page_number>[0-9]+)/$', views.Master.as_view(), name='master'),
    url(r'^user_data/(?P<page_number>[0-9]+)/$', views.UserData.as_view(), name='user data'),
    url(r'^export_data_as_pdf/$', views.ExportDataAsPDF.as_view(), name='export data as pdf'),
    url(r'^column_search/$', views.ColumnSearch.as_view(), name='export data as pdf'),
]
