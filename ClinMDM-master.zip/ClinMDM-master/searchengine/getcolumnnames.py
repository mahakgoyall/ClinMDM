
class business_to_column():
    def __init__(self, dictionary):
        self.dictionary = dictionary

    def get_column_name(self, column_name):
        return self.dictionary[column_name]

    def get_column_list_as_string(self):
        return ", ".join(self.dictionary.values())

    def get_column_list_as_list(self):
        return [value for key, value in self.dictionary.items()]

    def get_key(self, value):
        for name in self.dictionary:
            if self.dictionary[name] == value:
                return name
