from datetime import datetime
from elasticsearch import Elasticsearch
from rest_framework.views import APIView
import psycopg2 as pyscopg2
import pandas as pd
from searchengine.getcolumnnames import business_to_column
from django.http import JsonResponse
import logging
from django.conf import settings
import json
import requests
import collections
from django.conf import settings
logger = logging.getLogger("mdm_logging")

IP = 'http://13.90.80.185:9200'
PORT = '5434'
HOST = '13.90.80.185'
USER = 'arnav'
PASSWORD = '123456'
DBNAME = 'mdm_data'
class CreateMapping(APIView):

    @staticmethod
    def get(request, entity_name):
        entity_name = entity_name.lower()
        try:
            if entity_name == 'investigator':
                # column_dict = getattr(settings, "COLUMN_DICT", {})
                master_table = getattr(settings, "MDM", "mdm_golden")
            elif entity_name == 'study':
                # column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            else:
                # column_dict = getattr(settings, "ORG_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_ORG", "mdm_org")
            uri = IP + '/{}/'.format(master_table)
            if entity_name == 'investigator':
                query = json.dumps({
                    "mappings": {
                        "data": {
                            "properties": {
                                "decease_flg": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "country": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mid_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "gender": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "fax_ph_num3": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "fax_ph_num2": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "fax_ph_num1": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "fst_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "per_title": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "primary_specialty": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "work_phone2": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "work_phone3": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "work_phone1": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "primary_mobile_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "created_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "contact_type": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "education_bckgnd": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "manager_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "grad_yr": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "state": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "job_title": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "home_phone": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "comments": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "per_title_suffix": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "secondary_mobile_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "citizenship": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "degree": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "birth_place": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "last_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "birth_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "certification": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }		},
                                "education_years": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "marital_status": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "email_address": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "full_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_contact_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "ethnicity_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "site_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "ts_current": {
                                    "type": "date"
                                },
                                "created_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "source_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                }
                            }
                        }
                    }
                })
                response = requests.put(uri, data=query)
                results = json.loads(response.text)
                return JsonResponse(results, safe=False)
            elif entity_name == 'study':
                query = json.dumps({
                    "mappings": {
                        "data": {
                            "properties": {
                                "decease_flg": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_org_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_code": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_full_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_purpose": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_title": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_type": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_phase_code": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_diagnosis": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "ptcl_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "therapy_area": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "sponsor": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "org_type": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_comments": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_start_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "study_end_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "created_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "created_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "country": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "state": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "ts_current": {
                                    "type": "date"
                                },
                                "created_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "source_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                }
                            }
                        }
                    }
                })
                response = requests.put(uri, data=query)
                results = json.loads(response.text)
                return JsonResponse(results, safe=False)
            else:
                query = json.dumps({
                    "mappings": {
                        "data": {
                            "properties": {
                                "decease_flg": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "mdm_org_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "org_code": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "org_name": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "org_type": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "org_main_ph_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "sec_ph_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "fax_num": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "main_email_addr": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "url": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "active_flg": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "parent_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "created_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_by_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "created_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "changed_on_dt": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "country": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "state": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "ts_current": {
                                    "type": "date"
                                },
                                "city": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                },
                                "source_id": {
                                    "type": "text",
                                    "fields": {
                                        "keyword": {
                                            "ignore_above": 256,
                                            "type": "keyword"
                                        }
                                    }
                                }
                            }
                        }
                    }
                })
                response = requests.put(uri, data=query)
                results = json.loads(response.text)
                return JsonResponse(results, safe=False)
        except Exception as e:
            logger.error(str(e))
        return JsonResponse({'Failure': 'Error in creating mapping. '})


class SyncMdm(APIView):

    @staticmethod
    def get(request, table_name, entity=None):

        try:
            conn = pyscopg2.connect(port=PORT, host=HOST, user=USER, password=PASSWORD,
                                    dbname=DBNAME)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM {}".format( table_name))
            data = cursor.fetchall()
            es = Elasticsearch(IP)
            if not data:
                logger.error("No data in {} table".format(table_name))
                try:
                    es.indices.delete(index=table_name, ignore=[400, 404])
                except Exception as e:
                    logger.error(str(e))
                    return JsonResponse({'failure': 'No data in Elasticsearch Index {}'.format(table_name)})
                if table_name == 'mdm_golden':
                    response = CreateMapping.get(request, 'investigator')
                elif table_name == 'mdm_study':
                    response = CreateMapping.get(request, 'study')
                else:
                    response = CreateMapping.get(request, 'org')
                return JsonResponse({'success': 'No data in golden table. Index deleted successfully. ',
                                     'Response from elasticsearch ': str(response)})
            # df = pd.read_sql(
            #     "select * from {} where current_ts > (select last_updated_mdm from \"Last_updated\" where \"Id\" = 1)".format(
            #         table_name), conn)
            # if table_name == 'mdm_golden':
            #     response = CreateMapping.get(request, 'investigator')
            #     logger.error("RESPONSE   :  " + str(response))
            # elif table_name == 'mdm_study':
            #     response = CreateMapping.get(request, 'study')
            # else:
            #     response = CreateMapping.get(request, 'org')
            df = pd.read_sql("select * from {}".format(table_name), conn)
            logger.error(str(df.head()))
            if len(df) == 0:
                cursor = conn.cursor()
                cursor.execute("SELECT max(current_ts) from mdm_golden")
                max_timestamp = cursor.fetchall()[0][0]
                return JsonResponse({'failure': 'No data to index. Please check the timestamp.',
                                     'max_time_stamp is :  ': str(max_timestamp)})
            else:
                data = df.T.to_dict().values()
                index_name = table_name.lower()
                cursor = conn.cursor()
                cursor.execute('update "Last_updated" set last_updated_mdm=now() where "Id"=1')
                conn.commit()
                conn.close()
                for i, d in enumerate(data):
                    try:
                        res = es.index(index=index_name, doc_type='data', id=i, body=d)
                        # if res['created'] == False :
                        #     logger.error("error in here")
                        #     document = dict()
                        #     document['doc'] = d
                        #     es.update(index=index_name, doc_type='data', id=d['mdm_id'], body=document)
                    except Exception as e:
                        logger.error(str(e))
                        continue
                return JsonResponse({'success': 'Data indexed properly in elasticsearch'})
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Failure in indexing data'})


class ColumnList(APIView):

    @staticmethod
    def get(request, entity_name):

        columns = ['ALL']
        entity_name = entity_name.lower()
        if entity_name == 'investigator':
            # column_list = settings.COLUMN_LIST
            column_dict = getattr(settings, "COLUMN_DICT", {})
            # master_table = getattr(settings, "MDM", "mdm_golden")
        elif entity_name == 'study':
            pass
            # column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
            # master_table = getattr(settings, "MDM_STUDY", "mdm_study")
        else:
            pass
            # column_dict = getattr(settings, "ORG_COLUMN_DICT", {})
            # master_table = getattr(settings, "MDM_ORG", "mdm_org")
        ordered_dict = collections.OrderedDict(sorted(column_dict.items()))
        try:
            for column in ordered_dict:
                columns.append(str(column))
            response = dict()
            response['columns'] = columns
            return JsonResponse(response)
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Error in getting keys'})


class SearchFuzzy(APIView):
    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            entity_name = data['entity_name']
            entity_name = entity_name.lower()
            logger.error("data  : " + str(data))
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Please enter search term'})
        try:
            keyword = data['keyword']
            if entity_name == 'investigator':
                column_dict = getattr(settings, "COLUMN_DICT", {})
                master_table = getattr(settings, "MDM", "mdm_golden")
            elif entity_name == 'study':
                column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            else:
                column_dict = getattr(settings, "ORG_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_ORG", "mdm_org")
            ordered_dict = collections.OrderedDict(sorted(column_dict.items()))
            if not keyword:
                return JsonResponse({'Failure': 'Please enter search term'})
            obj = business_to_column(ordered_dict)
            if data['field'] == 'ALL':
                field = obj.get_column_list_as_list()
            else:
                field = [obj.get_column_name(str(data['field']))]
            logger.error('field   : ' + str(field))
            uri = IP + '/{}/data/_search'.format(master_table)
            query = json.dumps(
                {
                    "query": {
                        "multi_match": {
                            "query": keyword,
                            "fields": field
                            , "fuzziness": 2
                        }
                    }
                }
            )
            response = requests.get(uri, data=query)
            results = json.loads(response.text)
            logger.error(str(results))
            header = list()
            for i in results['hits']['hits']:
                for j in i['_source']:
                    header.append(obj.get_key(j))
                break
            logger.error(str(header))
            return JsonResponse(results, safe=False)

        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'error in fuzzy api'})


class SearchExact(APIView):

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            entity_name = data['entity_name']
            entity_name = entity_name.lower()
            logger.error("data  : " + str(data))
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Please enter search term'})

        try:
            keyword = data['keyword']
            if not keyword:
                return JsonResponse({'Failure': 'Please enter search term'})
            if entity_name == 'investigator':
                column_dict = getattr(settings, "COLUMN_DICT", {})
                master_table = getattr(settings, "MDM", "mdm_golden")
            elif entity_name == 'study':
                column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            else:
                column_dict = getattr(settings, "ORG_COLUMN_DICT", {})
                master_table = getattr(settings, "MDM_ORG", "mdm_org")
            ordered_dict = collections.OrderedDict(sorted(column_dict.items()))
            obj = business_to_column(ordered_dict)
            if data['field'] == 'ALL':
                field = obj.get_column_list_as_list()
            else:
                field = [obj.get_column_name(str(data['field']))]
            logger.error('field   : ' + str(field))
            uri = IP + '/mdm_golden/data/_search'
            query = json.dumps(
                {
                    "query": {
                        "multi_match": {
                            "query": keyword,
                            "fields": field
                        }
                    }
                }
            )
            response = requests.get(uri, data=query)
            results = json.loads(response.text)
            header = list()
            for i in results['hits']['hits']:
                for j in collections.OrderedDict(i['_source']):
                    header.append(obj.get_key(j))
                break
            # logger.error(str(header))
            logger.error(str(header))
            return JsonResponse(results, safe=False)
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'error in exact api'})


