from django.conf.urls import url, include
# from django.contrib import admin
from . import views

urlpatterns = [ 
    url(r'^rule/check/$', views.RuleMatching.as_view(), name='rule checking'),
    url(r'^flushData/staging/$', views.TruncateStagedData.as_view(), name='flush data from staging'),
    url(r'^rule/finish/$', views.Finish.as_view(), name='update status 7 finish or rollback'),
    url(r'^delete/existingflow/$', views.DeleteExistingFlow.as_view(), name='delete existing flow'),
    url(r'^update/exact_match_to_master/$', views.UpdateExactMatchToMaster.as_view(), name='update exact match to master'),
    url(r'^update_task_list/$', views.TaskListCreation.as_view(), name='Update task list'),
    url(r'^show_task_list_admin/(?P<page_number>[0-9]+)/$', views.TaskList.as_view(), name='show task list to admin'),

]
