from fuzzywuzzy import fuzz
import pandas as pd
from django.conf import settings
from django.db import connection
import logging
import time, json
import copy
from validator.column_mapping import business_to_column

logger = logging.getLogger("mdm_logging")

start = 0


def func_process(data):
    final_string = '('
    for tup in data:
        string = tup[0]
        lst = string.split(' and ')
        for name in lst:
            final_string = final_string + "(" + name + " is  NULL or " + name + "  = '' or " \
                           + name + "  = 'NULL') OR "
    final_string = final_string[:-4]
    final_string += ')'
    logger.error("Final string is: " + str(final_string))

    return final_string


def run_engine(entity_name, stage_table, master_table, rule_dict, uid, ingest_id, column_list, steward_id, flow_name,
               scope, insert_into,
               username, flow_id, dm_uid, fc_uid, edit_flow, root_source_id):
    global start
    start = time.time()
    key = 'rule'

    func_string_2 = ''
    func_string_score_2 = ''
    logger.error("the rule list is :" + str(rule_dict))
    exact_score = int(rule_dict['score']['exact']) / 100
    partial_start = int(rule_dict['score']['partial']) / 100
    partial_end = exact_score - 0.01
    column_dict = getattr(settings, "COLUMN_DICT", {})
    study_column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
    org_column_dict = getattr(settings, "ORG_COLUMN_DICT", {})

    if entity_name == 'study':
        stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
        master_table = getattr(settings, "MDM_STUDY", "mdm_study")
        obj = business_to_column(study_column_dict)
    elif entity_name == 'investigator':
        stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
        master_table = getattr(settings, "MDM", "mdm_golden")
        obj = business_to_column(column_dict)
    else:
        stage_table = getattr(settings, "STAGE_ORG", "stage_org")
        master_table = getattr(settings, "MDM_ORG", "mdm_org")
        obj = business_to_column(org_column_dict)

    for rules, values in rule_dict['rules'].items():
        func_string = ''
        func_string_score = ''

        length_of_rule = len(values['column'])
        for index, rule in enumerate(values['column']):
            func_string = func_string + str(obj.get_column_name(rule)) + ' and '
            func_string_score = func_string_score + str(values['match_type'][index]) + ' and '
            # func_string_2 += func_string_2 + str(rule) + ' and '
        func_string_2 += func_string[:-4] + ' or '
        func_string_score_2 += func_string_score[:-4] + ' or '
        func_string = func_string[:-4]
        func_string_score = func_string_score[:-4]
        logger.error("function string: " + str(func_string))
        if insert_into:
            logger.error("inside the insert into ")
            cursor = connection.cursor()
            if not edit_flow:
                logger.error("Inside the edit flow of rule engine")
                cursor.execute("INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, "
                               "username, ingest_id, flow_engage_lock, rule_length, score, rule)"
                               " VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}','1','{}', '{}', '{}')".format(
                    dm_uid, flow_id, key,
                    func_string, flow_name,
                    scope, username,
                    ingest_id, length_of_rule, func_string_score, json.dumps(rule_dict)))
            else:
                logger.error("else part of edit flow of rule engine")
                cursor.execute("UPDATE flow SET updated_by='{}', updated_date=NOW() WHERE "
                               "flow_id='{}' AND key='{}' AND updated_date IS NULL  "
                               "AND ingest_id != '{}'".format(dm_uid, flow_id, key, ingest_id))

                connection.commit()
                cursor = connection.cursor()
                cursor.execute("INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, username,"
                               " ingest_id, flow_engage_lock, rule_length, score, rule)"
                               "VALUES ('{}','{}','{}','{}','{}','{}','{}','{}', '1','{}', '{}', '{}')"
                               .format(dm_uid, flow_id, key, func_string, flow_name, scope, username, ingest_id,
                                       length_of_rule, func_string_score, json.dumps(rule_dict)))
                logger.error("Insert query works well in rule engine ")

    func_string_2 = func_string_2[:-4]
    func_string_score_2 = func_string_score_2[:-4]

    logger.error("func string 2" + str(func_string_2))

    cursor = connection.cursor()
    # logger.error("select func_condition_temp_3('rule',0,'{}','{}', '{}')".format(flow_id, fc_uid, ingest_id))
    # cursor.execute("select func_condition_temp_3('rule',0,'{}','{}', '{}')".format(flow_id, fc_uid, ingest_id))
    # logger.error("data: "+ str(cursor.fetchall()))

    cursor = connection.cursor()
    cursor.execute("SELECT value FROM flow WHERE flow_id = '{}' AND key = 'rule'".format(flow_id))
    data = cursor.fetchall()

    res = func_process(data)

    cursor = connection.cursor()
    cursor.execute("update stage_investigator set valid_flag = NULL , reason = 'Insufficient Data'"
                   " where {} and ingest_id = '{}' and valid_flag = '1'".format(res, ingest_id))

    logger.error("update stage null completed")
    # # cursor = connection.cursor()
    # # cursor.execute("SELECT func_reject_null_rule_data('{}','{}','{}','{}','{}')".format(stage_table, flow_id, uid,
    #                                                                                     fc_uid, ingest_id))
    # connection.commit()
    # # logger.error("funct reject null rule data run hua ")
    cursor = connection.cursor()
    # This function rejects the records which have a null values in the rule matching columns
    cursor.execute("UPDATE ingestion SET flow_id = '{}', matching_rules ='{}' WHERE ingest_id = '{}'"
                   .format(flow_id, json.dumps(rule_dict), ingest_id))
    logger.error("update ingestion set")
    connection.commit()
    try:
        # cursor = connection.cursor()
        # cursor.execute("SELECT uid FROM flow WHERE flow_id='{}' AND key='validation' AND updated_date IS NULL".format(flow_id))
        # fc_uid = cursor.fetchall()[0][0]
        start = time.time()
        cursor = connection.cursor()
        logger.error("SELECT func_exact_match_temp_final({}, '{}',{},'{}','{}', '{}', '{}', '{}', '{}', '{}')".format(
            exact_score, entity_name,
            int(root_source_id),
            stage_table, master_table,
            ingest_id, uid,
            flow_id, dm_uid,
            fc_uid))
        cursor.execute("SELECT func_exact_match_temp_final({}, '{}',{},'{}','{}', '{}', '{}', '{}', '{}', '{}')".format(
            exact_score, entity_name,
            int(root_source_id),
            stage_table, master_table,
            ingest_id, uid,
            flow_id, dm_uid,
            fc_uid))
        logger.error("exact match finished")
        cursor = connection.cursor()
        logger.error("SELECT func_partial_match_temp_final({},{},'{}',{},'{}','{}', '{}', '{}', '{}', '{}', '{}', "
                     "'{}')".format(partial_start, partial_end, entity_name, int(root_source_id),
                                    stage_table, master_table, ingest_id, uid, steward_id, flow_id, dm_uid, fc_uid))
        cursor.execute("SELECT func_partial_match_temp_final({},{},'{}',{},'{}','{}', '{}', '{}', '{}', '{}', '{}', "
                       "'{}')".format(partial_start, partial_end, entity_name, int(root_source_id),
                                      stage_table, master_table, ingest_id, uid, steward_id, flow_id, dm_uid, fc_uid))
        logger.error("partial match finished")
        cursor = connection.cursor()

        logger.error("SELECT func_insert_nomatch('{}',{},'{}', '{}', '{}', '{}')".format(entity_name,
                                                                                         int(root_source_id),
                                                                                         stage_table, ingest_id, uid,
                                                                                         dm_uid))
        cursor.execute("SELECT func_insert_nomatch('{}',{},'{}', '{}', '{}', '{}')".format(entity_name,
                                                                                           int(root_source_id),
                                                                                           stage_table, ingest_id, uid,
                                                                                           dm_uid))

        logger.error("nomatch finished")
        abc = open('time.txt', 'w')
        abc.write("Time taken: " + str(time.time() - start))
        abc.close()

        #### internal partial duplicity ----> postgres recursion query ###
        logger.error("Internal Partial Matching Module")
        cursor = connection.cursor()
        logger.error("SELECT func_condition_temp_3('rule',2,'{}','{}','{}')".format(flow_id, fc_uid, ingest_id))
        cursor.execute("SELECT func_condition_temp_3('rule',2,'{}','{}','{}')".format(flow_id, fc_uid, ingest_id))
        result_cond = cursor.fetchall()[0][0]
        logger.error("result_cond: " + str(result_cond))
        cursor = connection.cursor()
        cursor.execute(""" truncate table temp_internal_match""")
        connection.commit()
        cursor = connection.cursor()
        logger.error(""" insert into temp_internal_match (s, f, score)
                                    SELECT src.stage_id as s , tgt.stage_id as f , {} from
                                    stage_investigator src, stage_investigator tgt
                                    WHERE {} > {}  and src.ingest_id = '{}' and tgt.ingest_id = '{}'
                                     and
                                    src.stage_id < tgt.stage_id and src.stage_id in
                                            (select stage_id from nomatch_ref where
                                            ingest_id  = '{}')""".format(result_cond, result_cond,
                                                                         partial_start, ingest_id,
                                                                         ingest_id, ingest_id))
        cursor.execute(""" insert into temp_internal_match (s, f, score)
                                            SELECT src.stage_id as s , tgt.stage_id as f, {} from
                                            stage_investigator src, stage_investigator tgt
                                            WHERE {} >  {} and src.ingest_id = '{}' and tgt.ingest_id = '{}'
                                            and
                                            src.stage_id < tgt.stage_id and src.stage_id in
                                            (select stage_id from nomatch_ref where
                                            ingest_id  = '{}')""".format(result_cond, result_cond,
                                                                         partial_start,
                                                                         ingest_id, ingest_id, ingest_id))

        connection.commit()

        cursor = connection.cursor()
        cursor.execute("select * from temp_internal_match")

        logger.error("data: " + str(cursor.fetchall()))

        cursor = connection.cursor()

        logger.error("""  select ok.root as root_stage, string_agg(distinct(ok.path), ',') as target_stages, ok.leven from
                        ( with recursive paths as ( select '' || score as leven, f as root, s,  '' || s as path, 1 as len
                        from temp_internal_match where not exists (select * from temp_internal_match t2
                        where t2.s = temp_internal_match.f)
                        union all select paths.leven || ',' || temp_internal_match.score , paths.root,
                         temp_internal_match.s,
                        paths.path || ',' || temp_internal_match.s, len+1 from paths
                          inner join temp_internal_match on paths.s = temp_internal_match.f )
                        select leven, root,path from paths where not exists (select * from paths x where x.len > paths.len
                        and x.root = paths.root) order by path) as ok
                        group by ok.root, ok.leven""")

        cursor.execute("""  select ok.root as root_stage, string_agg(distinct(ok.path), ',') as target_stages, ok.leven from
                            ( with recursive paths as ( select '' || score as leven, f as root, s,  '' || s as path, 1 as len
                            from temp_internal_match where not exists (select * from temp_internal_match t2
                            where t2.s = temp_internal_match.f)
                            union all select paths.leven || ',' || temp_internal_match.score , paths.root,
                             temp_internal_match.s,
                            paths.path || ',' || temp_internal_match.s, len+1 from paths
                              inner join temp_internal_match on paths.s = temp_internal_match.f )
                            select leven, root,path from paths where not exists (select * from paths x where x.len > paths.len
                            and x.root = paths.root) order by path) as ok
                            group by ok.root, ok.leven""")

        data = cursor.fetchall()

        logger.error("data is: " + str(data))

        columns_string = ''
        mdm_seq_name = ''
        if entity_name == 'study':
            mdm_seq_name = 'mdm_study_mdm_study_id_seq';
            priority_table_name = 'master_study_column_source_priority_lookup'
            lst = list(settings.STUDY_COLUMN_DICT.values())
            try:
                lst.remove('mdm_id')
                lst.remove('investigator_id')
                lst.remove('sponsor_id')
                lst.remove('site_id')
            except Exception as e:
                logger.error(str(e))

        elif entity_name == 'investigator':
            mdm_seq_name = 'mdm_test_seq';
            priority_table_name = 'master_investigator_column_source_priority_lookup'
            lst = list(settings.COLUMN_DICT.values())
            logger.error("list: " + str(lst))
            try:
                lst.remove('mdm_id')
                lst.remove('site_id')
                lst.remove('sponsor_id')
                lst.remove('study_id')
            except Exception as e:
                logger.error(str(e))
        else:
            mdm_seq_name = 'mdm_org_mdm_id_seq';
            priority_table_name = 'master_org_column_source_priority_lookup'
            lst = list(settings.ORG_COLUMN_DICT.values())
            try:
                lst.remove('mdm_id')
                lst.remove('investigator_id')
                lst.remove('study_id')
            except Exception as e:
                logger.error(str(e))

        col_string = ','.join(lst)

        delete_nomatch_data = ''

        cursor = connection.cursor()
        cursor.execute("select ings.source_id, ing.data_manager_id, ing.uid from "
                       "ingestion_sources as ings JOIN  ingestion as ing on "
                       "ing.ingest_id = ings.ingest_id where ing.ingest_id = '{}' and "
                       "ing.delete_flag != '1'".format(ingest_id))

        data_temp = cursor.fetchall()

        if data_temp:
            ing_source_id = data_temp[0][0]
            ing_dm_uid = data_temp[0][1]
            ing_uid = data_temp[0][2]

            logger.error("ing_source_id: " + str(ing_source_id))
            logger.error("ing_dm_uid: " + str(ing_dm_uid))
            logger.error("ing_uid: " + str(ing_uid))

        for tup in data:
            first = tup[0]
            rest = tup[1].split(',')
            rest_unique = list()
            scores = tup[2].split(',')
            exact_list = list()
            rest_score = list()
            exact_score = list()
            rest_list = list()
            logger.error("tuples in list: first: " + str(first) + ' rest: ' + str(rest) + " scores: " + str(scores))

            try:
                for idx in range(len(rest)):
                    if int(rest[idx]) in rest_unique or int(rest[idx]) == first:
                        scores[idx] = (scores[idx], True)
                        continue
                    rest_unique.append(int(rest[idx]))
                    scores[idx] = (scores[idx], False)
            except Exception as e:
                logger.error(str(e))

            scores = [item[0] for item in scores if item[1] == False]
            logger.error("score: " + str(scores) + "rest unique: " + str(rest_unique))
            skip_first = False
            logger.error("partial end score: " + str(partial_end))
            for score, record in zip(scores, rest_unique):
                if float(score) > partial_end:
                    skip_first = True
                    exact_list.append(record)
                    exact_score.append(score)
                    print (exact_list)
                else:
                    rest_list.append(record)
                    rest_score.append(score)
            try:
                if skip_first:
                    master_list = copy.deepcopy(exact_list)
                else:
                    master_list = copy.deepcopy(rest_list)
                logger.error("rest unique list: " + str(rest_list) + "rest score: " + str(rest_score))
                logger.error("exact list: " + str(exact_list) + "exact score: " + str(exact_score))
                master_list.insert(0, first)
                master_list = [str(i) for i in master_list]
                master_list_string = ''
                for element in master_list:
                    master_list_string += "'" + str(element) + "',"
                master_list_string = master_list_string[:-1]
                logger.error("list to be send to func to select master record: " + str(master_list_string))
                cursor = connection.cursor()
                cursor.execute(
                    "select stage_id from stage_investigator where changed_on_dt = (select max(changed_on_dt)"
                    " from stage_investigator where stage_id in ({})) "
                    " and stage_id in ({})".format(master_list_string, master_list_string))
                master_element = cursor.fetchall()
                if len(master_element) > 0:
                    master_element = master_element[0][0]
                else:
                    master_element = master_list[0]
                logger.error("master element after query: " + str(master_element))
                master_list.remove(master_element)
            except Exception as e:
                logger.error(str(e))

            try:
                # insert an element in master and take out it's master id
                cursor = connection.cursor()
                # logger.error("insert into {} ({}) select {} from {} where "
                #              "stage_id = '{}'; UPDATE nomatch_ref SET status = 'Insert from internal partial match',"
                #              "mdm_id=cast((currval('{}')) AS bigint)"
                #              " WHERE ingest_id='{}' AND stage_id='{}'".format(master_table,
                #                                                               col_string, col_string, stage_table,
                #                                                               first, mdm_seq_name,
                #                                                               ingest_id, first))
                cursor.execute("insert into {} ({}) select {} from {} where "
                               "stage_id = '{}'; UPDATE nomatch_ref SET status = 'Insert from internal partial match',"
                               "mdm_id=cast((currval('{}')) AS bigint)"
                               " WHERE ingest_id='{}' AND stage_id='{}'".format(master_table,
                                                                                col_string, col_string, stage_table,
                                                                                master_element, mdm_seq_name,
                                                                                ingest_id, master_element))
                connection.commit()
                cursor = connection.cursor()
                cursor.execute(" select currval('{}')".format(mdm_seq_name))
                master_id = cursor.fetchall()[0][0]
                cursor = connection.cursor()
                cursor.execute("select func_insert_master_priority ('{}',{},{})".format(priority_table_name,
                                                                                        int(ingest_id), int(master_id)))
                connection.commit()
                cursor = connection.cursor()
                # logger.error("insert into ref_data (source_id, mdm_id, "
                #                "source_root_id, entity, reason, ingest_id) "
                #                "select source_id, '{}','{}','{}','New Record internal match',"
                #                "'{}' from {} where stage_id = '{}' and "
                #                "ingest_id = '{}'".format(master_id,
                #                                          root_source_id, entity_name, ingest_id,
                #                                          stage_table, first, ingest_id))
                cursor.execute("insert into ref_data (source_id, mdm_id, "
                               "source_root_id, entity, reason, ingest_id) "
                               "select source_id, '{}','{}','{}','New Record internal match',"
                               "'{}' from {} where stage_id = '{}' and "
                               "ingest_id = '{}'".format(master_id,
                                                         root_source_id, entity_name, ingest_id,
                                                         stage_table, master_element, ingest_id))

                connection.commit()
                for i, k in zip(exact_list, exact_score):
                    # send exact_list elements in exact_ref table
                    cursor = CONNECTION.cursor()
                    logger.error("insert into exact_ref (stage_id, mdm_id, ingest_id, uid,"
                                 " ingest_source_id, dm_id, source_root_id, entity, source_identifier_id, matching_score)  "
                                 "select stage_id, '{}', '{}', uid, ingest_source_id, '{}', "
                                 "cast(source_root_id as bigint), '{}', source_id, '{}' from {} where "
                                 "stage_id = '{}'".format(master_id, ingest_id, uid, entity_name, k, stage_table, i))
                    cursor.execute("insert into exact_ref (stage_id, mdm_id, ingest_id, uid,"
                                   " ingest_source_id, dm_id, source_root_id, entity, source_identifier_id, matching_score)  "
                                   "select stage_id, '{}', '{}', uid, ingest_source_id, '{}', "
                                   "cast(source_root_id as bigint), '{}', source_id, '{}' from {} where "
                                   "stage_id = '{}'".format(master_id, ingest_id, uid, entity_name, k, stage_table, i))
                    connection.commit()
                    delete_nomatch_data += str(i) + ','

            except Exception as e:
                logger.error(str(e))

            # Simple way to remove a item without checking if it exists or not is to add that item and then explicitly
            # remove it.
            # rest_unique.add(first)
            # rest_unique.remove(first)
            # rest_unique = list(rest_unique)
            insert_partial_string = ''
            for item, item1 in zip(rest_list, rest_score):
                insert_partial_string += "('" + str(item) + "','" + str(master_id) + "','" + str(
                    ingest_id) + "','" + str(uid) + "','" \
                                         + str(ing_source_id) + "','" + str(ing_dm_uid) + "','" + str(
                    root_source_id) + "','" \
                                         + str(item1) + "','" + str(entity_name) + "'),"

                # #TODO matching_score needs to be saved in the internal match case

                # cursor.execute("insert into partial_ref (stage_id, mdm_id, ingest_id, uid, steward_id, "
                #                "ingest_source_id, dm_id, source_root_id, entity"
                #                " ) values ( '{}', '{}','{}','{}','{}', '{}','{}',"
                #                "'{}','{}')".form[at(item, master_id, ingest_id, uid, steward_id,
                #                                           ing_source_id, ing_dm_uid, root_source_id, entity_name ))
                delete_nomatch_data += str(item) + ','
            insert_partial_string = insert_partial_string[:-1]
            if insert_partial_string:
                cursor = connection.cursor()
                # logger.error("insert into partial_ref (stage_id, mdm_id, ingest_id, uid, "
                #              "ingest_source_id, dm_id, source_root_id, matching_score, entity) values {}".format(
                #     insert_partial_string))
                logger.error("insert into partial_ref (stage_id, mdm_id, ingest_id, uid, "
                               "ingest_source_id, dm_id, source_root_id, matching_score, entity) values {}".format(
                    insert_partial_string))
                cursor.execute("insert into partial_ref (stage_id, mdm_id, ingest_id, uid, "
                               "ingest_source_id, dm_id, source_root_id, matching_score, entity) values {}".format(
                    insert_partial_string))
                # logger.error("insert into partial_ref completed")
        delete_nomatch_data = delete_nomatch_data[:-1]
        logger.error("list to be truncated: " + str(delete_nomatch_data))
        if delete_nomatch_data:
            cursor = connection.cursor()
            logger.error("delete from nomatch_ref where ingest_id = '{}' and status is NULL and "
                         "stage_id in ({})".format(ingest_id, delete_nomatch_data))
            cursor.execute("delete from nomatch_ref where ingest_id = '{}' and status is NULL and "
                           "stage_id in ({})".format(ingest_id, delete_nomatch_data))
            connection.commit()
        cursor = connection.cursor()
        cursor.execute("""truncate  TABLE temp_internal_match""")
        connection.commit()
    except Exception as e:
        logger.error(str(e))

        # logger.error(adsd)
        ### internal partial duplicity ---> nested list imnplementation####

        # cursor = connection.cursor()
        # cursor.execute("""SELECT stage_id FROM mdm_data.public.nomatch_ref WHERE ingest_id = '{}'""".format(ingest_id))
        # stage_nomatch_list_from_db = cursor.fetchall()
        # print(type(stage_nomatch_list_from_db))  # it will be a list  [(1234,), (345,)]
        # logger.error("stage_nomatch list from db: " + str(stage_nomatch_list_from_db))
        # cursor = connection.cursor()
        # logger.error("SELECT func_condition_temp_3('rule',2,'{}','{}','{}')".format(flow_id, fc_uid, ingest_id))
        # cursor.execute("SELECT func_condition_temp_3('rule',2,'{}','{}','{}')".format(flow_id, fc_uid, ingest_id))
        # logger.error("executed ....!!!!!")
        # # logger.error("bitch: " + str(cursor.fetchall()))
        # result_cond = cursor.fetchall()[0][0]
        # logger.error("result cond: " + str(result_cond))
        #
        # stage_nomatch_list = list()
        # for i in stage_nomatch_list_from_db:
        #     stage_nomatch_list.append(i[0])
        # logger.error("stage nomatch list : " + str(stage_nomatch_list))  # [1234, 345]
        # counter = 1
        #
        # length = len(stage_nomatch_list)
        # iter = 0
        # while iter < length:
        #     logger.error("LENGTH is:" + str(length))
        #     flag = False
        #     if iter == length:
        #         break
        #     j = iter + 1
        #     while j < length:
        #         delete_flag = False
        #         try:
        #
        #             cursor = connection.cursor()
        #             logger.error("i id: " + str(stage_nomatch_list[iter]))
        #             logger.error("j id: " + str(stage_nomatch_list[j]))
        #
        #             logger.error(""" insert into internal_partial_ref (entity ,dm_id, steward_id,stage_id, ingest_id,
        #                                                     uid, ingest_source_id, source_root_id, task_id) select '{}', '{}', '{}', '{}', '{}',
        #                                                      '{}', src.ingest_source_id, '{}', '{}' FROM "stage_investigator" as src,"stage_investigator" as tgt
        #                                                 WHERE {} between '{}' and '{}' AND src.stage_id = '{}' and tgt.stage_id = '{}' """.format(
        #                 entity_name, dm_uid,
        #                 steward_id,
        #                 stage_nomatch_list[j],
        #                 ingest_id, uid,
        #                 root_source_id, counter, result_cond, partial_start, partial_end, stage_nomatch_list[iter],
        #                 stage_nomatch_list[j]))
        #             cursor.execute(""" insert into internal_partial_ref (entity ,dm_id, steward_id,stage_id, ingest_id,
        #                                 uid, ingest_source_id, source_root_id, task_id) select '{}', '{}', '{}', '{}', '{}',
        #                                  '{}', src.ingest_source_id, '{}', '{}' FROM "stage_investigator" as src,"stage_investigator" as tgt
        #                             WHERE {} between '{}' and '{}' AND src.stage_id = '{}' and tgt.stage_id = '{}' returning 1 """.format(
        #                 entity_name, dm_uid,
        #                 steward_id,
        #                 stage_nomatch_list[j],
        #                 ingest_id, uid,
        #                 root_source_id, counter, result_cond, partial_start, partial_end, stage_nomatch_list[iter],
        #                 stage_nomatch_list[j]))
        #             var = cursor.fetchall()
        #             logger.error("var: "+ str(var))
        #             logger.error("*" * 100)
        #
        #             # logger.error("result: "+ str())
        #             logger.error("j= " + str(j))
        #         except Exception as e:
        #             logger.error(str(e))
        #         if var and str(var[0][0]) == '1':
        #             counter += 1
        #             logger.error("i id: flag setting"+ str(stage_nomatch_list[iter]))
        #             delete_flag = True
        #             flag = True
        #
        #         if delete_flag:
        #             cursor = connection.cursor()
        #             cursor.execute("""DELETE FROM nomatch_ref WHERE stage_id = '{}'""".format(
        #                 stage_nomatch_list[j]))
        #             connection.commit()
        #             logger.error("delete query works well in internal partial duplicacy")
        #             stage_nomatch_list.pop(j)
        #             j -= 1
        #             length -= 1
        #         j += 1
        #         logger.error(str(j))
        #     if flag:
        #         logger.error("inside flag block")
        #         logger.error(""" insert into internal_partial_ref (entity ,dm_id, steward_id,stage_id, ingest_id,
        #                                                                 uid, ingest_source_id, source_root_id, task_id) select '{}', '{}', '{}', '{}', '{}',
        #                                                                  '{}', src.ingest_source_id, '{}', '{}' FROM "stage_investigator" as src
        #                                                             WHERE src.stage_id = '{}'  """.format(
        #             entity_name, dm_uid,
        #             steward_id,
        #             stage_nomatch_list[iter],
        #             ingest_id, uid,
        #             root_source_id, counter, stage_nomatch_list[iter]))
        #         cursor.execute(""" insert into internal_partial_ref (entity ,dm_id, steward_id,stage_id, ingest_id,
        #                                                 uid, ingest_source_id, source_root_id, task_id) select '{}', '{}', '{}', '{}', '{}',
        #                                                  '{}', src.ingest_source_id, '{}', '{}' FROM "stage_investigator" as src
        #                                             WHERE src.stage_id = '{}'  """.format(
        #             entity_name, dm_uid,
        #             steward_id,
        #             stage_nomatch_list[iter],
        #             ingest_id, uid,
        #             root_source_id, counter, stage_nomatch_list[iter]))
        #         # cursor.fetchall()
        #         logger.error("in if cond")
        #         cursor = connection.cursor()
        #         cursor.execute("""DELETE FROM nomatch_ref WHERE stage_id IN ('{}')""".format(
        #             stage_nomatch_list[iter]))
        #         connection.commit()
        #         logger.error("delete query worked...." + str(stage_nomatch_list))
        #     stage_nomatch_list = stage_nomatch_list[iter + 1:]
        #     length = len(stage_nomatch_list)
        #     logger.error("LENGTH is:" + str(length))
    try:

        columns_string = ''
        mdm_seq_name = ''
        if entity_name == 'study':
            mdm_seq_name = 'mdm_study_mdm_study_id_seq';
            priority_table_name = 'master_study_column_source_priority_lookup'
            lst = list(settings.STUDY_COLUMN_DICT.values())
            try:
                lst.remove('mdm_id')
                lst.remove('investigator_id')
                lst.remove('sponsor_id')
                lst.remove('site_id')
            except Exception as e:
                logger.error(str(e))

        elif entity_name == 'investigator':
            mdm_seq_name = 'mdm_test_seq';
            priority_table_name = 'master_investigator_column_source_priority_lookup'
            lst = list(settings.COLUMN_DICT.values())
            try:
                lst.remove('mdm_id')
                lst.remove('site_id')
                lst.remove('sponsor_id')
                lst.remove('study_id')
            except Exception as e:
                logger.error(str(e))
        else:
            mdm_seq_name = 'mdm_org_mdm_id_seq';
            priority_table_name = 'master_org_column_source_priority_lookup'
            lst = list(settings.ORG_COLUMN_DICT.values())
            try:
                lst.remove('mdm_id')
                lst.remove('investigator_id')
                lst.remove('study_id')
            except Exception as e:
                logger.error(str(e))

        # lst = list(settings.COLUMN_DICT.values())[1:-2]

        # try:
        #     lst.remove('mdm_id')
        # except Exception as e:
        #     logger.error(str(e))

        logger.error("lst: " + str(lst))
        row_schema = ','.join(lst)
        for column in lst:
            columns_string = columns_string + 's.' + str(column) + ', '
        columns_string = columns_string[:-2]

        cursor = connection.cursor()
        logger.error("SELECT stage_id FROM nomatch_ref WHERE ingest_id = '{}' AND uid = '{}' "
                     "and status is null".format(ingest_id, uid))
        cursor.execute("SELECT stage_id FROM nomatch_ref WHERE ingest_id = '{}' "
                       "AND uid = '{}' and status is null".format(ingest_id, uid))
        logger.error("no match ref ki select query fire ho gyi")
        data = cursor.fetchall()
        logger.error("data before for loop : " + str(data))
        mdm_current = ''
        for i in data:
            # logger.error("INSERT INTO {} ({}) SELECT {} FROM \"{}\" AS s JOIN nomatch_ref "
            #              "AS n ON s.stage_id=n.stage_id WHERE n.ingest_id ='{}' AND n.uid='{}' AND "
            #              "n.stage_id='{}'; UPDATE nomatch_ref SET mdm_id=cast((currval('{}')) AS bigint)"
            #              " WHERE ingest_id='{}' AND uid='{}' AND stage_id='{}'".format(master_table, row_schema,
            #                                                                            columns_string,
            #                                                                            stage_table, ingest_id,
            #                                                                            uid, i[0], mdm_seq_name,
            #                                                                            ingest_id,
            #                                                                            uid, i[0]))
            cursor.execute("INSERT INTO {} ({}) SELECT {} FROM \"{}\" AS s JOIN nomatch_ref "
                           "AS n ON s.stage_id=n.stage_id WHERE n.ingest_id ='{}' AND n.uid='{}' AND "
                           "n.stage_id='{}'; UPDATE nomatch_ref SET mdm_id=cast((currval('{}')) AS bigint)"
                           " WHERE ingest_id='{}' AND uid='{}' AND stage_id='{}'".format(master_table, row_schema,
                                                                                         columns_string,
                                                                                         stage_table, ingest_id,
                                                                                         uid, i[0], mdm_seq_name,
                                                                                         ingest_id,
                                                                                         uid, i[0]))
            cursor = connection.cursor()
            cursor.execute("insert into ref_data (mdm_id, source_id, "
                           "source_root_id, entity, reason, ingest_id) select mdm_id, source_identifier_id,source_root_id, entity, "
                           "'New Record', '{}' from nomatch_ref"
                           " where  ingest_id = '{}' and mdm_id = cast((currval('{}')) as bigint)".format(ingest_id,
                                                                                                          ingest_id,
                                                                                                          mdm_seq_name))
            cursor = connection.cursor()
            cursor.execute("SELECT currval('{}')".format(mdm_seq_name))
            mdm_current = str(cursor.fetchall()[0][0])
            cursor = connection.cursor()
            cursor.execute("SELECT func_insert_master_priority('{}',{},{})".format(priority_table_name,
                                                                                   int(ingest_id), int(mdm_current)))
            # cursor = connection.cursor()
            # cursor.execute("SELECT func_insert_into_investigator_xref({},{})".format(i[0], int(mdm_current)))

            # try:
            #     cursor = connection.cursor()
            #     cursor.execute(
            #         "SELECT DISTINCT(mdm_id) FROM partial_ref WHERE ingest_id = '{}'  AND task_id"
            #            " IS NULL".format(ingest_id))
            #     data = cursor.fetchall()
            #     # print("data:   ")
            #     # print(data)
            #
            #     cursor = connection.cursor()
            #     cursor.execute(
            #         "SELECT max(task_id) FROM internal_partial_ref WHERE ingest_id='{}' ".format(
            #             ingest_id))
            #     counter = cursor.fetchall()[0][0]
            #     # logger.error("counter: " + str(counter))
            #     if counter:
            #         counter = 1 + int(counter)
            #     else:
            #         counter = 1
            #
            #     used = set()
            #     for i in data:
            #         logger.error("keys in data: " + str(i))
            #         cursor = connection.cursor()
            #         # logger.error("counter in for loop: " + str(counter))
            #         cursor.execute(
            #             "UPDATE partial_ref SET task_id='{}' WHERE mdm_id = '{}' AND ingest_id='{}' AND uid='{}' AND "
            #             "task_id IS NULL".format(counter, i[0], ingest_id, uid))
            #         connection.commit()
            #         # logger.error("UPDATE partial_ref SET task_id='{}' WHERE mdm_id = '{}' AND ingest_id='{}' AND uid='{}' AND "
            #         #     "task_id IS NULL".format(counter, i[0], ingest_id, uid))
            #         # logger.error(str("Done!! in rulematcher.py file "))
            #         counter += 1
            # except Exception as e:
            #     logger.error(str(e))

    except Exception as e:
        logger.error(str(e))
        return {}
    return {}
