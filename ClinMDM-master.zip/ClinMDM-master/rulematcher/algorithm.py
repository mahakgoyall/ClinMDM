from rpforest import RPForest
from datasketch import MinHash
import numpy as np
from django.db import connection
import time
import logging
from fuzzywuzzy import fuzz

logger = logging.getLogger("mdm_logging")


def main(mdm, source, mdm_column_list, source_column_list):
    cursor = connection.cursor()
    cursor.execute("SELECT " + mdm_column_list + " FROM {}".format(mdm))
    data = cursor.fetchall()
    cursor.execute('SELECT ' + source_column_list + ' FROM "{}" AS x JOIN validated_data AS v ON '
                                                    'x.record_id = v.record_id AND '
                                                    'x.ingest_source_id = v.ingest_source_id AND '
                                                    'x.ingest_id = v.ingest_id AND x.uid  = v.uid'.format(source))
    source = cursor.fetchall()

    start = time.time()
    logger.error(str(mdm_column_list))
    logger.error(str(source_column_list))
    model = RPForest(leaf_size=50, no_trees=200)

    total_columns = len(data[0])

    hashes = [0] * len(data)
    for idx, tup in enumerate(data):
        m = MinHash(num_perm=64)
        # Skip first column which is mdm id
        for string in tup[:-1]:
            string = string.lower()
            m.update(string.encode('utf-8'))
        hashes[idx] = m.digest()
    model.fit(np.array(hashes))

    query_hash = list()
    for tup in source:
        m = MinHash(num_perm=64)
        # Skip first two columns which is record id and ingest_source_id
        for string in tup[:-2]:
            string = string.lower()
            m.update(string.encode('utf-8'))
        query_hash.append(m.digest())

    # res = list()
    # count = 0
    # for i, q in enumerate(query_hash):
    #     qn = q / np.linalg.norm(q)
    #     ns = model.query(qn, 200)
    #     for d in ns:
    #         # first = fuzz.ratio(source[i][0].lower() + source[i][1].lower(), data[d][0].lower() + data[d][1].lower())
    #         first = fuzz.ratio(source[i][0].lower(), data[d][0].lower())
    #         last = fuzz.ratio(source[i][1].lower(), data[d][1].lower())
    #         if first >= 75 and last >= 75:
    #             count += 1
    #             if first == 100 and last == 100:
    #                 pass
    #             else:
    #                 res.append((source[i][0], data[d][0], source[i][1], data[d][1]))

    res = dict()
    count = 0
    for i, q in enumerate(query_hash):
        qn = q / np.linalg.norm(q)
        ns = model.query(qn, 300)
        for d in ns:
            fuzzy_list = list()
            for _idx in range(total_columns - 1):
                fuzzy_list.append(fuzz.ratio(source[i][_idx].lower(), data[d][_idx].lower()))

            if all(f >= 75 for f in fuzzy_list):
                if all(f == 100 for f in fuzzy_list):
                    count += 1
                    if i in res:
                        del res[i]
                    break
                else:
                    if i in res:
                        res[i].append((source[i][0], data[d][0], source[i][1], data[d][1], source[i][2], data[d][2]))
                    else:
                        res[i] = [(source[i][0], data[d][0], source[i][1], data[d][1], source[i][2], data[d][2])]

    logger.error("Total time taken in rule matcher is: " + str(time.time() - start))
    logger.error("Total dup is: " + str(count))
    return res
