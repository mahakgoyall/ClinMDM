from django.apps import AppConfig


class SourceConfigurationConfig(AppConfig):
    name = 'source_configuration'
