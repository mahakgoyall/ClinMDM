from rulematcher.rule_matcher import run_engine
from validator.column_mapping import business_to_column
from django.conf import settings
from rest_framework.views import APIView
from django.db import connection
import requests
import json
import logging
from web_curl_service.views import flow_flags
from django.http import JsonResponse
from searchengine.views import SyncMdm
logger = logging.getLogger("mdm_logging")


def get_count(table_name, ingest_id, uid):
    try:
        if table_name == 'partial_ref':
            cursor = connection.cursor()
            cursor.execute(
                """SELECT COUNT(*) FROM "{}" WHERE ingest_id='{}' AND uid='{}'""".format(table_name, ingest_id, uid))
            partial_count = cursor.fetchall()[0][0]
            cursor = connection.cursor()
            cursor.execute("""SELECT COUNT(*) FROM "internal_partial_ref" where ingest_id ='{}' """.format(ingest_id))
            internal_partial_count = cursor.fetchall()[0][0]
            return partial_count+internal_partial_count  # To avoid the extra internal joined record added for insert purpose
        else:
            cursor = connection.cursor()
            cursor.execute("""SELECT COUNT(*) FROM "{}" WHERE ingest_id='{}' AND uid='{}'""".format(table_name, ingest_id, uid))
            return cursor.fetchall()[0][0]
    except Exception as e:
        logger.error(str(e))
    return -1


class RuleMatching(APIView):
    # TODO remove below static names. Feeling bit lazy lol. :D Will do that later.
    column_dict = getattr(settings, "COLUMN_DICT", {})
    study_column_dict = getattr(settings, "STUDY_COLUMN_DICT", {})
    org_column_dict = getattr(settings, "ORG_COLUMN_DICT", {})


    @staticmethod
    def get(request):
        entity_name = request.META['HTTP_ENTITY']
        logger.error("Entity_name: "+str(entity_name))

        if entity_name == 'study':
            master_table = getattr(settings, "MDM_STUDY", "mdm_study")
        elif entity_name == 'investigator':
            master_table = getattr(settings, "MDM", "mdm_golden")
        else:
            master_table = getattr(settings, "MDM_ORG", "mdm_org")

        count_dict = {}
        table_list = [master_table, 'validated_data', 'rejected_data', 'partial_ref', 'exact_ref', 'nomatch_ref']
        cursor = connection.cursor()
        try:
            for table in table_list:
                cursor.execute("SELECT count(*) FROM " + table)
                count_dict[table] = cursor.fetchall()[0][0]
            return JsonResponse(count_dict, safe=False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})

    def post(self, request=None, rules=None, entity_name=None, ingest_id=None, uid=None, steward_id=None, flow_name=None,
             scope=None, username=None, flow_id=None, edit_flow=None, root_source_id=None):
        if request:
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity_name: " + str(entity_name))
            uid = request.session['source_user_id']
            logger.error(str(uid))
            ingest_id = request.session['ingest_id']
            logger.error(str(ingest_id))
            steward_id = request.session['steward_id']
            logger.error(str(steward_id))
            flow_name = request.session['flow_name']
            logger.error(str(flow_name))
            scope = request.session['scope']
            logger.error(str(scope))
            username = request.session['username']
            logger.error(str(username))
            flow_id = request.session['flow_id']
            logger.error(str(flow_id))
            edit_flow = request.session['edit']
            logger.error(str(edit_flow))
            root_source_id = request.session['source_root_id']
        insert_into_flow_flag = False
        insert_into = True
        if not rules:
            rules = request.data
            logger.error(str(rules))
            print(rules)
            print(type(rules))
            request.session['rules']['matcher_rules'] = rules
        else:
            insert_into = False
            rules = rules
            logger.error(str(rules))
            print(rules)
            print(type(rules))
            insert_into_flow_flag = True

        if entity_name == 'study':
            stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
            master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            obj = business_to_column(self.study_column_dict)
        elif entity_name == 'investigator':
            stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
            master_table = getattr(settings, "MDM", "mdm_golden")
            obj = business_to_column(self.column_dict)
        else:
            stage_table = getattr(settings, "STAGE_ORG", "stage_org")
            master_table = getattr(settings, "MDM_ORG", "mdm_org")
            obj = business_to_column(self.org_column_dict)

            # obj = business_to_column(self.column_dict)
        rule_list = list()
        column_list = list()
        for k, v in rules['rules'].items():
                temp_lst = [obj.get_column_name(i) for i in v['column']]
                if len(temp_lst) > 0:
                    rule_list.append(temp_lst[:])
                column_list += temp_lst[:]

        column_list = list(set(column_list))

        # uid = request.session['user_id']

        try:
            cursor = connection.cursor()
            cursor.execute("select data_manager_id from ingestion where ingest_id =  '{}' and delete_flag != '1' "
                           " AND uid = '{}'".format(ingest_id, uid))
            dm_uid = str(cursor.fetchall()[0][0])
            logger.error("dm_uid = " + str(dm_uid))

            if request:
                cursor = connection.cursor()
                cursor.execute("SELECT distinct(uid) from flow where flow_id = '{}' and updated_date"
                               " IS NULL".format(request.session['flow_id']))
                fc_id = str(cursor.fetchall()[0][0])
                request.session['fc_id'] = fc_id

            else:
                cursor = connection.cursor()
                cursor.execute("SELECT distinct(uid) from flow where flow_id = '{}' and updated_date"
                               " IS NULL".format(flow_id))
                fc_id = str(cursor.fetchall()[0][0])
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()


        # TODO fetch the root source id from session which needs to be saved in the session when the root source is selected
        run_engine(entity_name, stage_table,  master_table, rules, uid, ingest_id, column_list,
                   steward_id, flow_name, scope, insert_into,
                   username, flow_id, dm_uid, fc_id, edit_flow, root_source_id)
        logger.error("rule engine completed")

        ui_information = dict()
        count = list()
        cursor = connection.cursor()
        cursor.execute("select count(*) from {} where ingest_id = '{}' "
                       " and reason = 'Insufficient Data' and valid_flag IS NULL".format(stage_table, ingest_id))
        insufficient_data = cursor.fetchall()
        ui_information['insufficient_data'] = insufficient_data
        for table_name in ['partial_ref', 'exact_ref', 'nomatch_ref']:
            count_ = get_count(table_name, ingest_id, uid)
            ui_information[table_name] = [count_]
            count.append(count_)

        # logger.error(str(ui_information))

        ingest_name = None
        username = None
        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT ingest_name, username FROM ingestion WHERE ingest_id='{}' AND uid='{}'".format(ingest_id,
                                                                                                       uid))
            ingest_name, username = cursor.fetchall()[0]
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()

        try:
            # Confusion if to add source_root_id column to this table or not
            cursor = connection.cursor()
            cursor.execute("INSERT INTO rule_matcher_dashboard_meta (partial_count, exact_count, nomatch_count, "
                           "uid, ingest_id, ingest_name, username) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', "
                           "'{}')".format(count[0], count[1], count[2], uid, ingest_id, ingest_name, username))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            # logger.error("Cannot insert into dashboard meta in rule matcher")

        flow_flags(ingest_id, uid, '7')
        # try:
        #     if entity_name == 'study':
        #         response = SyncMdm.get(request, table_name='mdm_golden')
        #         logger.error("Response from elasticsearch in rulematcher.views. ")
        #         logger.error("response  : " + str(response))
        #     elif entity_name == 'investigator':
        #         response = SyncMdm.get(request, table_name='mdm_study')
        #         logger.error("Response from elasticsearch in rulematcher.views. ")
        #         logger.error("response  : " + str(response))
        #     else:
        #         response = SyncMdm.get(request, table_name='mdm_org')
        #     logger.error("Response from elasticsearch in rulematcher.views. ")
        #     logger.error("response  : " + str(response))
        # except Exception as e:
        #     logger.error(str(e))
        #     k = dict()
        #     k['Error'] = str(e).replace("'", '"')
        #     # k = json.dumps(k)
        #     cursor = connection.cursor()
        #     logger.error(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        #     cursor.execute(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1),
        #             request.session.get('user_id', -1), json.dumps(k)))
        #     connection.commit()
        # response = SyncMdm.get((request, ))
        # logger.error(str(request.session['rules']))
        # logger.error("Success")
        return JsonResponse(ui_information, safe=False)


class TruncateStagedData(APIView):  # rollback in rule engine
    """
    This API is used for the rollback option after the complete rule engine completed,before click on the finish or
    continue button.
    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return: Json response with ok as key and Success as value if the data-base query works well. If there is any
        issue in between the process of data-base query then it will return the json response with failure as key and
        DB failure as value.
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity_name: " + str(entity_name))
            if entity_name == 'study':
                stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
                master_table = getattr(settings, "MDM_STUDY", "mdm_study")
                # landing_table = getattr(settings, "LANDING_STUDY", "landing_study")
            elif entity_name == 'investigator':
                stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_sponsor")
                master_table = getattr(settings, "MDM", "mdm_golden")
                # landing_table = getattr(settings, "LANDING_INVESTIGATOR", "landing_investigator" )

            else:
                stage_table = getattr(settings, "STAGE_ORG", "stage_org")
                master_table = getattr(settings, "MDM_ORG", "mdm_org")
                # landing_table = getattr(settings, "LANDING_ORG", "landing_org" )

            try:
                cursor = connection.cursor()
                cursor.execute("SELECT func_rollback_rule_engine('{}','{}','{}', '{}', '{}', "
                               "'{}')".format(stage_table, master_table, request.session['ingest_id'],
                                              request.session['source_user_id'],
                                              request.session['flow_id'], request.session['user_id']))
                # logger.error("roll back in rule engine is called here !!!!!!1")
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB failure'})
        return JsonResponse({'ok': 'Success'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return: Json response with failure as key and API not supported as value.(**Note: currently post method of API
        is not in used and kept for future use-case.)
        """
        return JsonResponse({'failure': 'API not supported.'})


class Finish(APIView):
    """
    This API is used when complete rule engine process completed and there is a graph comes and after click on the
    finish button so, we update the flow by set the flow_engage_lock to zero and delete the rules, columns for
    validation from the session variable. After click on the finish button there is no option of rollback in any
    situation as we are deleting the session variable as well as updating the flow.
    """
    @staticmethod
    def get(request):
        """
        :param request:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.error("entity_name: " + str(entity_name))
            if entity_name == 'study':
                stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
                master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            elif entity_name == 'investigator':
                stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                master_table = getattr(settings, "MDM", "mdm_golden")
            else:
                stage_table = getattr(settings, "STAGE_ORG", "stage_org")
                master_table = getattr(settings, "MDM_ORG", "mdm_org")

            flow_flags(request.session['ingest_id'], request.session['user_id'], '7')
            try:
                cursor = connection.cursor()
                cursor.execute("UPDATE FLOW SET flow_engage_lock = '0' where ingest_id  = '{}' and "
                               "flow_id = '{}' and updated_date IS NULL ".format(request.session['ingest_id'],
                                                                                 request.session['flow_id']))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                logger.error(
                    "SELECT func_update_exact_to_master('{}','{}','{}',{},'{}')".format(entity_name, stage_table,
                                                                                        master_table,
                                                                                        request.session['ingest_id'],
                                                                                        request.session['user_id']))
                cursor.execute("SELECT func_update_exact_to_master('{}','{}','{}',{},'{}')".format(entity_name, stage_table,
                                                                                master_table, request.session['ingest_id'],
                                                                                    request.session['user_id']))
                logger.error("update to exact complete")
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # logger.error('update from exact complete status:' + str(cursor.fetchall()))
            del request.session['rules']
            del request.session['columns_for_validation']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB failure'})
        return JsonResponse({'ok': 'Success'})

    @staticmethod
    def post(request):
        """

        :PARAM REQUEST:
        :RETURN:
        """
        return JsonResponse({'Failure': 'API not supported yet!!!'})


class DeleteExistingFlow(APIView):

    """    
    This is called on flow page when an user want to delete the existing flow which is
    there in the drop down option menu. This is enabled when the current existing flow
    is not under process with any ingestion. The flow_engage_lock is false then only
    user can delete the flow.
    """

    @staticmethod
    def get(request):
        """
        :param request:
        :return:
        """
        try:
            ingest_id = request.session['ingest_id']
            cursor = connection.cursor()
            cursor.execute("SELECT delete_flow('{}')".format(ingest_id))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure':'There is some error in the DB'})
        return JsonResponse({'Failure':'This is not working'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure':'API not supported currently'})


# NOTE This function is not used
class UpdateExactMatchToMaster(APIView):

    """

    """
    @staticmethod
    def post(request):
        """
        :param request:
        :return:
        """
        return JsonResponse({'Failure' : 'No working yet'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        # try:
        #     data = json.loads(request.read().decode('utf-8'))
        # except Exception as e:
        #     logger.error(str(e))
        #     return JsonResponse({'failure': 'No data found in body.'})
        try:
            # ingest_id = request.session['ingest_id']
            # uid = request.session['user_id']
            ingest_id = '222'
            uid = '190'
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'no data in the session'})
        try:
            cursor = connection.cursor()
            cursor.execute("""\
            SELECT e.stage_id, e.mdm_id, e.ingest_source_id, i.source_priority
            FROM exact_ref AS e
            JOIN ingestion_sources as i on i.source_id = e.ingest_source_id WHERE e.ingest_id = '{}' and e.uid = '{}'
            """.format(ingest_id, uid))
            data = cursor.fetchall()
            logger.error(str(data))
            logger.error('ok1')

            # cursor = connection.cursor()
            # cursor.execute(" ".format( ))
            # logger.error('ok2')

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        return JsonResponse({'Success':'OK'})

class TaskListCreation(APIView):
    """

    """

    @staticmethod
    def post(request):
        """
        :param request:
        :return:
        """
        return JsonResponse({'Failure': 'No working yet'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        try:
            entity_name = request.META['HTTP_ENTITY']
            uid = request.session.get('user_id', False)
            cursor = connection.cursor()
            cursor.execute("select role from users where user_id = '{}' AND delete_flag != '1'".format(uid))
            role = cursor.fetchall()[0][0]
            logger.error('role: ' + str(role))
            if role == '1,2,3,4':
                cursor = connection.cursor()
                cursor.execute("select distinct(mdm_id) from partial_ref where status = '9' and entity = '{}'"
                               .format(entity_name))
                mdm_ids = cursor.fetchall()
                logger.error("mdm ids are: " + str(mdm_ids))
                cursor = connection.cursor()
                cursor.execute("select max(task_id) from partial_ref")
                max_task_id = cursor.fetchall()
                if max_task_id and max_task_id[0][0]:
                    counter = max_task_id[0][0]
                else:
                    counter = 1
                for mdm_id in mdm_ids:
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select distinct(steward_id) from partial_ref where mdm_id = '{}' "
                                       "and status = '9'".format(mdm_id[0]))
                        steward_id = cursor.fetchall()
                        if steward_id and steward_id[0][0]:
                            cursor = connection.cursor()
                            cursor.execute(
                                "update partial_ref set task_id = '{}', "
                                "task_name = 'Investigator_Task_{}', steward_id = '{}' where mdm_id = '{}'"
                                .format(counter, counter, steward_id[0][0], mdm_id[0]))
                            connection.commit()
                        else:
                            cursor = connection.cursor()
                            cursor.execute(
                                "update partial_ref set task_id = '{}', task_name = 'Investigator_Task_{}' where mdm_id = '{}'"
                                .format(counter, counter, mdm_id[0]))
                            connection.commit()

                        counter += 1
                    except Exception as e:
                        logger.error(str(e))
            else:
                return JsonResponse({'failure': 'you do not have permission for this action.'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        return JsonResponse({'success': 'ok'})


class TaskList(APIView):
    """


    """

    @staticmethod
    def get(request, page_number):
        """

        :param request:
        :param page_number:
        :return:
        """
        try:
            page_number = page_number
            uid = request.session.get('user_id', False)
            entity_name = request.META['HTTP_ENTITY']
            cursor = connection.cursor()
            cursor.execute("select role from users where user_id = '{}' AND delete_flag != '1'".format(uid))
            role = cursor.fetchall()[0][0]
            logger.error('role: ' + str(role))
            context = {}
            if role == '1,2,3,4':
                cursor = connection.cursor()
                cursor.execute("select count(distinct(task_id)) from partial_ref where status = '9'"
                               " and entity = '{}' and steward_id is NULL".format(entity_name))
                total_task = cursor.fetchall()
                logger.error("count: "+ str(total_task))
                if total_task:
                    total_task = total_task[0][0]
                cursor = connection.cursor()
                cursor.execute("select DISTINCT(p.task_id), p.task_name  from partial_ref as p  "
                               " where p.status = '9' and p.entity = '{}' and p.steward_id is NULL "
                               " order by p.task_id limit 10 offset {}"
                               .format(entity_name, int(page_number) * 10 - 10))
                data = cursor.fetchall()
                dict_temp = []
                for tup in data:
                    local_dict = dict()
                    local_dict['task_name'] = tup[1]
                    local_dict['task_id'] = tup[0]
                    # local_dict['ingest_name'] = tup[1]
                    # cursor = connection.cursor()
                    # cursor.execute("select uid, data_manager_id, ingest_name from ingestion where ingest_name = '{}'"
                    #                " and delete_flag != '1'".format(tup[1]))
                    # ingest_data = cursor.fetchall()
                    # if ingest_data:
                    #     cursor = connection.cursor()
                    #     cursor.execute("select DISTINCT(username) from users where user_id = '{}' and delete_flag != '1'"
                    #                    .format(ingest_data[0][0]))
                    #     user_name = cursor.fetchall()[0][0]
                    #     local_dict['username'] = user_name
                    #     cursor = connection.cursor()
                    #     cursor.execute("select distinct(username) from users where user_id = '{}' and delete_flag != '1'"
                    #                    .format(ingest_data[0][1]))
                    #     data_manager = cursor.fetchall()[0][0]
                    #     local_dict['data_manager'] = data_manager
                    dict_temp.append(local_dict)
                context['data'] = dict_temp
                context['total_task'] = total_task
            else:
                return JsonResponse({'failure': 'you do not have permission for this action.'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure'})
        return JsonResponse(context)

    @staticmethod
    def post(request, page_number):
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data Found in body.'})
        try:
            tasks = data['task_ids']
            logger.error("tasks: "+ str(tasks))
            # st_range = data['start_range']
            # end_range = data['end_range']
            steward_id = data['steward_id']
            task_string = ''
            for i in tasks:
                task_string += "'" + str(i) + "',"
            task_string = task_string[:-1]
            logger.error("task_string: "+ str(task_string))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'At least one field is missing.'})
        try:
            entity_name = request.META['HTTP_ENTITY']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in entity.'})
        try:
            logger.error('inside post')
            cursor = connection.cursor()
            cursor.execute("update partial_ref set steward_id = '{}' where task_id in ({}) and task_id is not null "
                           "and entity = '{}'"
                           .format(steward_id, task_string, entity_name))
            connection.commit()
            logger.error('update query completed.')
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'failure'})
        return JsonResponse({'success': 'ok'})