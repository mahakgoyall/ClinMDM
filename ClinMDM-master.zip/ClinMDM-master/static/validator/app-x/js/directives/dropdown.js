angular.module('mdm').directive('dropdown', function($timeout) {
    return {
        restrict: "C",
        link: function(scope, elm, attr) {
            $timeout(function() {
                $(elm).dropdown().dropdown('setting', {
                    onChange: function(value) {
                        scope.$parent[attr.ngModel] = value
                    }
                })
            }, 0)
        }
    }
})
