angular.module('mdm', ['ngRoute','ngMaterial','ui.bootstrap','ngFileUpload','toaster','ngProgress','ngDialog','ngSanitize','chart.js','ui.bootstrap.datetimepicker','btford.socket-io']);

// angular.module('mdm')
// .factory('socket', ['$rootScope', function($rootScope) {
//   var socket = io.connect('/some/path');
//
//   return {
//     on: function(eventName, callback){
//       socket.on(eventName, callback);
//     },
//     emit: function(eventName, data) {
//       socket.emit(eventName, data);
//     }
//   };
// }]);

// angular.module('mdm')
// .factory('socket', function (socketFactory) {
//   return socketFactory({
//     prefix: 'foo~',
//     ioSocket: io.connect('/some/path')
//   });
// })
angular.module('mdm').filter('num', function() {
    return function(input) {
      return parseInt(input, 10);
    }
  })


angular.module('mdm').directive('noSpecialChar', function() {
      return {
        require: 'ngModel',
        restrict: 'A',
        link: function(scope, element, attrs, modelCtrl) {
          modelCtrl.$parsers.push(function(inputValue) {
            if (inputValue == undefined)
              return ''
            cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
            if (cleanInputValue != inputValue) {
              modelCtrl.$setViewValue(cleanInputValue);
              modelCtrl.$render();
            }
            return cleanInputValue;
          });
        }
      }
    });


    angular.module('mdm').filter('browser', function() {
      return function(input, search) {
        if (!input) return input;
        if (!search) return input;
        var expected = ('' + search).toLowerCase();
        var result = {};
        angular.forEach(input, function(value, key) {
          console.log(value + "value");
          console.log(expected + "expected");
          var actual = ('' + value).toLowerCase();
          if (actual.indexOf(expected) !== -1) {
            result[key] = value;
          }
        });
        return result;
      }
    });


    angular.module('mdm').filter('limitTocustom', function() {
       'use strict';
       return function(input, limit) {
           if (input) {
               if (limit > input.length) {
                   return input.slice(0, limit);
               } else {
                   return input.slice(0, limit) + '...';
               }
           }
       };
    });


    angular.module('mdm').filter('custom', function() {
      return function(input, search) {
        if (!input) return input;
        if (!search) return input;
        var expected = ('' + search).toLowerCase();
        var result = {};
        angular.forEach(input, function(value, key) {
          var actual = ('' + value.name).toLowerCase();
          if (actual.indexOf(expected) !== -1) {
            result[key] = value;
          }
        });
        return result;
      }
    });
