angular.module('mdm').config(['$routeProvider', '$httpProvider', function($routeProvider,$httpProvider) {
  $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
  $httpProvider.defaults.xsrfCookieName = 'csrftoken';
  // $httpProvider.defaults.headers.common['entity'] = $rootScope.entity;


    $routeProvider
    .when('/', {
      templateUrl: 'static/validator/app-x/partials/home.html' ,
      controller: 'HomeController as home',
      activeLink : 'home',
      resolve : {
        selfInfo : ['MDMService', function(MDMService) {
                 return MDMService.selfInfo()
         }]
       }
    })
    .when('/:entity/rule', {
      templateUrl: 'static/validator/app-x/partials/ruleengine.html',
      controller: 'RuleEngineController as rule',
      activeLink : 'rule',
      resolve : {
        columnList : ['MDMService', function(MDMService) {
                 return MDMService.getValidatedColumns()
         }],
        currentFlow : ['MDMService', function(MDMService) {
                  return MDMService.currentFlow()
         }]
       }
    })
    .when('/:entity/steward', {
      templateUrl: 'static/validator/app-x/partials/steward.html' ,
      controller: 'StewardController as steward',
      activeLink : 'steward',
      resolve : {
        taskList : ['MDMService', function(MDMService) {
                 return MDMService.getTasks(1,{})
         }]
       }

    })
    .when('/:entity/tasks', {
      templateUrl: 'static/validator/app-x/partials/tasks.html' ,
      controller: 'TaskController as task',
      activeLink : 'task',
      resolve : {
        stewardList: ['MDMService', function(MDMService) {
              return MDMService.showSteward();
          }],
        updateTaskList: ['MDMService', function(MDMService) {
              return MDMService.updateTaskList();
          }]
        }
    })
    .when('/:entity/validation', {
      templateUrl: 'static/validator/app-x/partials/validation.html',
      controller: 'ValidationController as validation',
      activeLink : 'validation',
      resolve : {
        columnList : ['MDMService', function(MDMService) {
                 return MDMService.getValidatedColumns()
         }],
        currentFlow : ['MDMService', function(MDMService) {
                   return MDMService.currentFlow()
         }],
         selfInfo : ['MDMService', function(MDMService) {
                  return MDMService.selfInfo()
         }],
       }
    })
    .when('/:entity/browser', {
      templateUrl: 'static/validator/app-x/partials/browser.html',
      controller: 'BrowserController as browser',
      activeLink : 'browser',
      resolve : {
        ingestions : ['MDMService', function(MDMService) {
                 return MDMService.ingestionList(1)
         }]
       }

    })
    .when('/:entity/flow', {
      templateUrl: 'static/validator/app-x/partials/flow.html',
      controller: 'FlowController as flow',
      activeLink : 'flow',
      resolve : {
        flowList : ['MDMService', function(MDMService) {
                 return MDMService.flowList(1)
         }]
       }

    })
    .when('/:entity/datamap', {
      templateUrl: 'static/validator/app-x/partials/datamap.html',
      controller: 'DataMapController as datamap',
      activeLink : 'datamap',
      resolve : {
        columnsList : ['MDMService', function(MDMService) {
                 return MDMService.getColumns()
        }],
        selfInfo : ['MDMService', function(MDMService) {
                 return MDMService.selfInfo()
        }],
        selectedIngestion : ['MDMService', function(MDMService) {
                return MDMService.selectedIngestion()
        }]


       }
    })
    .when('/:entity/connection', {
      templateUrl: 'static/validator/app-x/partials/connection.html',
      controller: 'ConnectionController as connection',
      activeLink : 'connection',
      resolve : {
        customSourceList: ['MDMService', function(MDMService) {
              return MDMService.customSourceListConn();
          }]
      }

    })
    .when('/:entity/dashboard', {
      templateUrl: 'static/validator/app-x/partials/dashboard.html',
      controller: 'DashboardController as dashboard',
      activeLink : 'dashboard',
      resolve : {
        ingestions : ['MDMService', function(MDMService) {
                 return MDMService.ingestionListReport(1)
         }]
       }
    })
    .when('/:entity/reports', {
      templateUrl: 'static/validator/app-x/partials/reports.html',
      controller: 'ReportsController as reports',
      activeLink : 'reports',
      resolve : {
        sources: ['MDMService', function(MDMService) {
              return MDMService.getReportSourcesIngestions();
          }]
        }
    })
    .when('/search-engine', {
      templateUrl: 'static/validator/app-x/partials/api.html',
      controller: 'ApiController as api',
      activeLink : 'search-engine'

    })
    .when('/existingflow/:flowID', {
      templateUrl: 'static/validator/app-x/partials/steward.html',
      controller: 'ExistingFlowController as existing',
      activeLink : 'existing',
      resolve : {
        flowData: ['MDMService', '$route', function(MDMService, $route) {
							return MDMService.getFlowDetails($route.current.params.flowID)
					}]
        }
    })
    .when('/users', {
      templateUrl: 'static/validator/app-x/partials/users.html',
      controller: 'UserController as users',
      activeLink : 'users',
      resolve : {
        userlist: ['MDMService', function(MDMService) {
							return MDMService.getusers();
					}]
        }
    })
    .when('/:entity/ingestions', {
      templateUrl: 'static/validator/app-x/partials/ingestions.html',
      controller: 'IngestionController as ingestions',
      activeLink : 'ingestions',
      resolve : {
        ingestionList: ['MDMService', function(MDMService) {
							return MDMService.ingestionList(1);
					}],
        dataManagerList: ['MDMService', function(MDMService) {
							return MDMService.showDataManager();
					}],
        stewardList: ['MDMService', function(MDMService) {
							return MDMService.showSteward();
					}],
        selfInfo : ['MDMService', function(MDMService) {
                 return MDMService.selfInfo()
         }]
        }
    })
    .when('/sources', {
      templateUrl: 'static/validator/app-x/partials/sources.html',
      controller: 'SourcesController as source',
      activeLink : 'sources',
      resolve : {
        customSourceList: ['MDMService', function(MDMService) {
              return MDMService.customSourceList();
          }]
        }
    })
    .when('/stewardanalysis', {
      templateUrl: 'static/validator/app-x/partials/stewardanalysis.html',
      controller: 'StewardAnalysisController as stewardanalysis',
      activeLink : 'stewardanalysis',
      resolve : {
        totalCount: ['MDMService', function(MDMService) {
              return MDMService.stewardAnalysisGraph();
          }]
        }
    })
    .when('/:entity/scheduler', {
      templateUrl: 'static/validator/app-x/partials/schedule.html',
      controller: 'ScheduleController as schedule',
      activeLink : 'schedule',
      resolve : {
        scheduleList : ['MDMService', function(MDMService) {
                 return MDMService.getScheduleList()
         }]
       }
    })
    .when('/:entity/scheduler/ingestion/:ingestion', {
      templateUrl: 'static/validator/app-x/partials/baseingestiondetail.html',
      controller: 'BaseIngestionController as base',
      activeLink : 'base',
      resolve : {
        scheduleDetail : ['MDMService','$route', function(MDMService,$route) {
                 return MDMService.getScheduleDetails({
                   'ingest_name' : $route.current.params.ingestion
                 })
         }]
       }
    })
    .when('/:entity/scheduler/reports/:ingestion', {
      templateUrl: 'static/validator/app-x/partials/schedulereports.html',
      controller: 'ScheduleReportController as reports',
      activeLink : 'reports',
      resolve : {
        scheduleDetail : ['MDMService','$route', function(MDMService,$route) {
                 return MDMService.getScheduleDetails({
                   'ingest_name' : $route.current.params.ingestion
                 })
         }]
       }
    })
    .when('/log', {
      templateUrl: 'static/validator/app-x/partials/log.html',
      controller: 'LogController as log',
      activeLink : 'log',
      resolve : {
        ErrorIngestions: ['MDMService', function(MDMService) {
              return MDMService.FindErrorIngest(1);
          }],
        selfInfo : ['MDMService', function(MDMService) {
                 return MDMService.selfInfo()
         }]
        }
    })
    .when('/console', {
      templateUrl: 'static/validator/app-x/partials/console.html',
      controller: 'ConsoleController as console',
      activeLink : 'console'
      // ,
      // resolve : {
      //   ErrorIngestions: ['MDMService', function(MDMService) {
      //         return MDMService.FindErrorIngest();
      //     }]
      //   }
    })
    .otherwise({
      redirectTo: '/'
    })

  }])

  angular.module('mdm').run(function($rootScope,$route,$http,MDMService) {
    $rootScope.showInBrowser = false
    $rootScope.showInReports = false
    $rootScope.isSomethingLeft = false
    // MDMService.selfInfo().then(function(response){
    //   $rootScope.selfInfo = response
    // })
    $rootScope.$on('$locationChangeSuccess', function(event, next, current) {
      if($route.current.params.entity){
        $http.defaults.headers.common['entity']  = $route.current.params.entity;
        $rootScope.entityInUse = $route.current.params.entity
      }
      else if($route.current.$$route && $route.current.$$route.activeLink == 'api'){
        delete $http.defaults.headers.common.entity
        $rootScope.entityInUse = ""
      }
      else {
        $rootScope.entityInUse = ""
      }
    });
})
