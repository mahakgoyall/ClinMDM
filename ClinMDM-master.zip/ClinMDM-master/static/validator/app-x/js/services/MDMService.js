angular.module('mdm').factory('MDMService', ['$q', '$http','Upload', function($q, $http,Upload) {
    return {
        postRules: function(payload) {
            var defer = $q.defer()
            $http.post("/rulematcher/rule/check/",payload).success(function(result) {
                defer.resolve(result)
            })
            .error(function(error) {
              console.log(error);
              defer.reject("Failure");
            });
            return defer.promise
        },
        getsession: function(){
          return sessiondata;
        },
        setsession: function(value){
          sessiondata = value;
        },
        postValidations: function(payload) {
            var defer = $q.defer()
            $http.post("/validator/getColumns/",payload,{
              ignoreLoadingBar: true
            }).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        standardizeData: function(payload) {
            var defer = $q.defer()
            $http.get("/standardization/data_standardization/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        dbConnect: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/dbConnection/",payload,{
              ignoreLoadingBar: true
            }).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        s3Connect: function(payload) {
            var defer = $q.defer()
            $http.post("/download_S3_bucket/",payload,{
              ignoreLoadingBar: true
            }).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        dbConnectCheck: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/dbConnectionCheck/",payload,{
              ignoreLoadingBar: true
            }).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ingestionDetails: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/show_ingestion_details/",payload,{
            }).success(function(result) {
                defer.resolve(result)
            })
            .error(function() {
                     defer.reject("Failure");
            });
            return defer.promise
        },
        getValidatedColumns: function() {
            var defer = $q.defer()
            $http.get("/validator/getValidatedColumns/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getColumns: function() {
            var defer = $q.defer()
            $http.get("/validator/getColumns/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        rollbackValidations: function() {
            var defer = $q.defer()
            $http.get("/validator/flushData/source/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        rollbackRules: function() {
            var defer = $q.defer()
            $http.get("/rulematcher/flushData/staging/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTableData: function(table,page) {
            var defer = $q.defer()
            $http.get("/dashboard/showTable/" + table + "/" + page ).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getIngestionsSteward: function(page) {
            var defer = $q.defer()
            $http.get("/steward/get_ingestions/" + page + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTasks: function(page,payload) {
            var defer = $q.defer()
            $http.post("/steward/get_ingestions/" + page + "/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        FindErrorIngest: function(payload) {
            var defer = $q.defer()
            $http.get("/standardization/error_logging/" + payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getErrorLogs: function(payload) {
            var defer = $q.defer()
            $http.post("/standardization/error_logging/", payload,{
              ignoreLoadingBar: true
            }).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getProgress: function(payload) {
            var defer = $q.defer()
            $http.post("/web/flow_status/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTaskDetail: function(formdata) {
            var defer = $q.defer()
            $http.post("/steward/task_detail/", formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        updateGolden: function(payload,taskId) {
            var defer = $q.defer()
            $http.post("/steward/update_mdm/" + taskId +"/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        uploadCSV: function(doc) {
           var defer = $q.defer()
           Upload.upload({
               headers: {
                   'Content-Type': 'application/byte'
               },
               url: '/connections/csvFile/',
               data: doc,
           }).success(function(result) {
               defer.resolve(result)
           })
           .error(function() {
                    defer.reject("Failed while uploading csv");
                });
           return defer.promise
        },
        getCSVColumns: function(payload) {
            var defer = $q.defer()
            $http.get("/connections/csvFile/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getmappings: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/show_mapping/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getGraphData: function(payload) {
            var defer = $q.defer()
            $http.get("/rulematcher/rule/check/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        finishRuleMatch: function(payload) {
            var defer = $q.defer()
            $http.get("/rulematcher/rule/finish/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getUserInfo: function(payload) {
            var defer = $q.defer()
            $http.get("/rulematcher/rule/check/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getRejectedDetails: function(payload) {
            var defer = $q.defer()
            $http.get("/validator/getReasonRejected/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sessioninit: function() {
            var defer = $q.defer()
            $http.get("/init").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sendmapping: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/mapping/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getusers: function() {
            var defer = $q.defer()
            $http.get("/connections/user_list/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getUserInfo: function(uid) {
            var defer = $q.defer()
            $http.get("/connections/user_info/" + uid).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        createuser : function(formdata) {
            var defer = $q.defer()
            $http.post("/admin/create_user", formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        modifyUserDetails : function(formdata) {
            var defer = $q.defer()
            $http.post("/admin/modify_user", formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        changePassword : function(formdata) {
            var defer = $q.defer()
            $http.post("/admin/change_password", formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        deleteUser : function(formdata) {
            var defer = $q.defer()
            $http.post("/admin/delete_user", formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        createingestion : function(payload) {
            var defer = $q.defer()
            $http.post("/connections/create_ingestion/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        deleteIngestion : function(payload) {
            var defer = $q.defer()
            $http.post("/connections/delete/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ingestionList : function(data) {
            var defer = $q.defer()
            $http.get("/connections/ingest_list/" + data).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ingestionListReport : function(data) {
            var defer = $q.defer()
            $http.get("/connections/ingest_list_report/" + data).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        selectedIngestion : function() {
            var defer = $q.defer()
            $http.get("/connections/ingest_name/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        useThisIngestion : function(payload) {
            var defer = $q.defer()
            $http.post("/connections/use_this_ingestion/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ingestionSourceDetail : function(payload) {
            var defer = $q.defer()
            $http.post("/connections/ingest_source_detail/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        validateRegex: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/validate_regex/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        showSteward: function() {
            var defer = $q.defer()
            $http.get("/connections/show_stewards/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sendSteward: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/show_stewards/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        discardTask: function(payload) {
            var defer = $q.defer()
            $http.post("/steward/discard_task/"+payload+"/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        insertMDM: function(id,payload) {
            var defer = $q.defer()
            $http.post("/steward/insert_mdm/"+id+"/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        flowList: function(payload) {
            var defer = $q.defer()
            console.log(payload);
            $http.get("/connections/use_flow/" + payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getFlowValidations: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/show_flow/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        useFlow: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/use_flow/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        deleteFlow: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/flow/delete/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        createFlow: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/create_flow/",payload).success(function(result) {
                defer.resolve(result)
            })
            .error(function(error) {
              console.log(error);
              defer.reject("Error while creating new flow.");
            });
            return defer.promise
        },
        selfInfo: function() {
            var defer = $q.defer()
            $http.get("/connections/user_info/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ruleMatcherGraph: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/info_rule_matcher_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getDashData: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/dashboard_circles/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        validationGraph: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/info_data_validation_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        rejectionGraph: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/rejection_analysis_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        ruleMatcherGraphSource: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/source_rule_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        validationGraphSource: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/source_data_validation_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        rejectionGraphSource: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/source_rejection_graph/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sourceList: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/source_list/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        stewardAnalysisGraph: function() {
            var defer = $q.defer()
            $http.get("/dashboard/steward_cumulative_analysis_graph/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        referentialAnalysis: function(page) {
            var defer = $q.defer()
            $http.get("/dashboard/referential_analysis_data/" + page + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTablesList: function(payload) {
            var defer = $q.defer()
            $http.post("/mdm_browser/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getGoldenData: function(page) {
            var defer = $q.defer()
            $http.get("/mdm_browser/master/" + page +  "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTablesData: function(payload,page) {
            var defer = $q.defer()
            $http.post("/mdm_browser/user_data/" + page +"/" ,payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTableCompleteData: function(payload) {
            var defer = $q.defer()
            $http.post("/mdm_browser/export_data_as_pdf/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        suggestMappings: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/automapping/",payload).success(function(result) {
                defer.resolve(result)
            })
            .error(function(error) {
              // console.log(error);
                     defer.reject("error in automap");
            });
            return defer.promise
        },
        setCurrentIngestion: function(payload) {
            var defer = $q.defer()
            $http.get("/connections/current_ingestion/" + payload + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        finishMapping: function(payload) {
            var defer = $q.defer()
            $http.get("/connections/source_finish/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        showDataManager: function() {
            var defer = $q.defer()
            $http.get("/connections/show_data_manager/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sendDataManager: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/show_data_manager/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        editFlow: function(payload) {
            var defer = $q.defer()
            $http.get("/connections/edit_flow/" + payload + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        resumeFlow: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/resume_flow/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        currentFlow: function(payload) {
            var defer = $q.defer()
            $http.get("/validator/currentFlow/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        connectS3: function(payload) {
            var defer = $q.defer()
            $http.post("/download_from_s3",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        deleteSources: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/delete_selected_source/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getElasticSearchFields: function(payload) {
            var defer = $q.defer()
            $http.get("/searchengine/getColumns/" + payload + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        elasticSearchFuzzy: function(payload) {
            var defer = $q.defer()
            $http.post("/searchengine/searchFuzzy/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        elasticSearchExact: function(payload) {
            var defer = $q.defer()
            $http.post("/searchengine/searchExact/" , payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        syncMDM: function(table) {
            var defer = $q.defer()
            $http.get("/searchengine/sync_mdm/" + table + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        columnSearch: function(payload) {
            var defer = $q.defer()
            $http.post("/mdm_browser/column_search/" , payload).success(function(result) {
                defer.resolve(result)
            })
            .error(function(error) {
              // console.log(error);
                     defer.reject("Internal Server Error");
                 });
            return defer.promise
        },
        getprioritylist: function() {
            var defer = $q.defer()
            $http.get("/source_configuration/get_priority_list/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        customSourceList: function() {
            var defer = $q.defer()
            $http.get("/source_configuration/show_source_details_to_admin/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        json: function() {
            var defer = $q.defer()
            $http.get("/static/validator/app-x/data.json").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        customSourceListConn: function() {
            var defer = $q.defer()
            $http.get("/source_configuration/show_root_source_details/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getReportSourcesIngestions: function() {
            var defer = $q.defer()
            $http.get("/dashboard/ingestion_list/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        checkSource: function(payload) {
            var defer = $q.defer()
            $http.post("/source_configuration/custom_source_name/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        connectToS3: function(payload) {
            var defer = $q.defer()
            $http.post("/source_configuration/save_admin_connection/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        connToS3Buck: function(payload) {
            var defer = $q.defer()
            $http.post("/source_configuration/admin_amazon_s3/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        landingData: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/landing_report_data/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        stagingData: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/staging_analysis/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        mdmHubData: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/mdm_hub_analysis/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        crossMatching: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/cross_matching_analysis/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        autoMergedRecords: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/auto_merge_report/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        manuallyMergedRecords: function(payload) {
            var defer = $q.defer()
            $http.post("/dashboard/manually_merge_report/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        sourceConfiguration: function(payload) {
            var defer = $q.defer()
            $http.post("/source_configuration/show_source_details_to_admin/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        dbConnectSource: function(payload) {
            var defer = $q.defer()
            $http.post("/source_configuration/save_admin_connection/", payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getTaskList: function(page) {
            var defer = $q.defer()
            $http.get("/rulematcher/show_task_list_admin/" + page + "/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        updateTaskList: function(payload) {
            var defer = $q.defer()
            $http.get("/rulematcher/update_task_list/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        assignTaskList: function(payload) {
            var defer = $q.defer()
            $http.post("/rulematcher/show_task_list_admin/1/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        scheduleNow: function(payload) {
            var defer = $q.defer()
            $http.post("/scheduler/schedule/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getScheduleList: function() {
            var defer = $q.defer()
            $http.get("/scheduler/getScheduleList/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        getScheduleDetails: function(payload) {
            var defer = $q.defer()
            $http.post("/scheduler/getScheduleList/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        searchIngestion: function(payload) {
            var defer = $q.defer()
            $http.post("/connections/search_ingest_list/",payload).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        logout: function() {
            var defer = $q.defer()
            $http.post("/logout").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        }
    }
}])
