angular.module('mdm').config(['$routeProvider', '$httpProvider', function($routeProvider,$httpProvider) {
  // $httpProvider.defaults.headers.common['X-CSRFToken'] = '{{ csrf_token|escapejs }}';
  $httpProvider.defaults.xsrfCookieName = 'csrftoken';
  $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
  // cfpLoadingBarProvider.includeSpinner = false
  // cfpLoadingBarProvider.latencyThreshold = 0

    $routeProvider
    .when('/', {
      templateUrl: 'static/validator/app/partials/login.html' ,
      controller: 'loginController as login',
      activeLink : 'login'
    })
    .when('/update', {
      templateUrl: 'static/validator/app/partials/updatepassword.html' ,
      controller: 'UpdateController as update',
      activeLink : 'update'
    })
    .when('/forgot', {
      templateUrl: 'static/validator/app/partials/forgotpassword.html' ,
      controller: 'ForgotPasswordController as forgot',
      activeLink : 'forgot'
    })
    .otherwise({
      redirectTo: '/'
    })
  }])
