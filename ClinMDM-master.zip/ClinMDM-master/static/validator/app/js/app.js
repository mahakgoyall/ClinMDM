angular.module('mdm', ['ngRoute','ngAnimate','ngMaterial','ui.bootstrap','toaster']);
