angular.module('mdm').factory('MDMService', ['$q', '$http', function($q, $http) {
    return {
        sublogin: function(formdata) {
            var defer = $q.defer()
            $http.post("/login_check/",formdata).success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        selfInfo: function() {
            var defer = $q.defer()
            $http.get("/connections/user_info/").success(function(result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        resetPassword: function (formdata) {
            var defer = $q.defer()
            $http.post("/admin/password_reset/", formdata).success(function (result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        changePassword: function (formdata) {
            var defer = $q.defer()
            $http.post("/admin/change_password/", formdata).success(function (result) {
                defer.resolve(result)
            })
            return defer.promise
        },
        forgotPassword: function (formdata) {
            var defer = $q.defer()
            $http.post("/admin/forget_password/", formdata).success(function (result) {
                defer.resolve(result)
            })
            return defer.promise
        }
    }
}])
