from django.db import connection
import re
import json
import logging
from dashboard.views import AllRejectionAnalysisGraph
from django.conf import settings


logger = logging.getLogger("mdm_logging")

# This function takes as input the validation scheme and source list from user and
# filters the data according to rules specified by the user

# #### MySQL specific type-codes
# CONSTANTS = {0: 'DECIMAL', 1: 'TINY', 2: 'SHORT', 3: 'LONG', 4: 'FLOAT', 5: 'DOUBLE',
#              6: 'NULL', 7: 'TIMESTAMP', 8: 'LONGLONG', 9: 'INT24', 10: 'DATE', 11: 'TIME',
#              12: 'DATETIME', 13: 'YEAR', 14: 'NEWDATE', 15: 'VARCHAR', 16: 'BIT', 246: 'NEWDECIMAL',
#              247: 'INTERVAL', 248: 'SET', 249: 'TINY_BLOB', 250: 'MEDIUM_BLOB', 251: 'LONG_BLOB',
#              252: 'BLOB', 253: 'VAR_STRING', 254: 'STRING', 255: 'GEOMETRY'}
# VARCHAR = [15, 253, 254, 252]
# INTEGER = [0, 1, 2, 3, 4, 5, 8, 9, 246]


# POSTGRES 
VARCHAR = [1043]
INTEGER = [20]
EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")
PRIMARY_MOBILE_NUM = re.compile(r"^[+][0-9]{10}$")
SITE_ID = re.compile(r"^[0-9]{4}$")


class ValidationError(Exception):
    pass

def convert_to_alias(names, entity_name):
    if entity_name == 'study':
        alias_to_columns = settings.STUDY_COLUMN_DICT
    elif entity_name == 'investigator':
        alias_to_columns = settings.COLUMN_DICT
    else:
        alias_to_columns = settings.ORG_COLUMN_DICT

    columns_to_alias = dict()
    for k, v in alias_to_columns.items():
        columns_to_alias[v] = k
    result = list()
    for name in names:
        if name in columns_to_alias:
            result.append(columns_to_alias[name].upper())
        else:
            result.append(name.upper())
    return result

def data_validation(input_validation_schema, _object, uid, ingest_id, flow_name, user, ingestion_name,
                    scope, insert_into, flow_id, dm_uid, edit_flow, entity_name, root_source_id, schedule_flag=False):
    # We need these 4 columns of any record
    ing_name = ingestion_name
    logger.error("ingest_name: " + str(ingestion_name))
    columns = ['record_id', 'ingest_id', 'ingest_source_id', 'uid']
    # for column in input_validation_schema.keys():
    #     if len(input_validation_schema[column]) > 0:
    #         columns.append(_object.get_column_name(column))
    # counter = len(input_validation_schema) - 1
    # count = 0
    for i in range(len(input_validation_schema)):
        i = str(i)
        columns.append(_object.get_column_name(input_validation_schema[i][1]))
        # count += 1

    logger.error("columns: " + str(columns))

    func_string = ''
    temp_list = list()
    try:
        for i in range(len(input_validation_schema)):
            i = str(i)
            if i == str(len(input_validation_schema)-1):
                input_validation_schema[i][5] = ""
            column = str(_object.get_column_name(input_validation_schema[i][1]))
            if str(input_validation_schema[i][2]).lower() == "not null":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " +  column \
                              + " is " + str(input_validation_schema[i][2]).strip() + " " + \
                              str(input_validation_schema[i][3]).strip() + " " + str(input_validation_schema[i][4]) +\
                              " " + str(input_validation_schema[i][5])
            elif str(input_validation_schema[i][2]).lower() == ">":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                              + " " + str(input_validation_schema[i][2]) + " $$" + str(input_validation_schema[i][3]).strip() +\
                              "$$ " + str(input_validation_schema[i][4]) + " " + str(input_validation_schema[i][5])
                temp_list.append(column)
            elif str(input_validation_schema[i][2]).lower() == "<":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                              + " " + str(input_validation_schema[i][2]) + " $$" + str(input_validation_schema[i][3]).strip() +\
                              "$$ " + str(input_validation_schema[i][4]) + " " + str(input_validation_schema[i][5])
                temp_list.append(column)
            elif str(input_validation_schema[i][2]).lower() == "equals to":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                               + " = $$" + str(input_validation_schema[i][3]).strip() + "$$ " + str(input_validation_schema[i][4]) + \
                              " " + str(input_validation_schema[i][5])
                temp_list.append(column)
            elif str(input_validation_schema[i][2]).lower() == "not equals to":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                              + " != $$" + str(input_validation_schema[i][3]).strip() + "$$ " + str(input_validation_schema[i][4]) + \
                              " " + str(input_validation_schema[i][5])
                temp_list.append(column)
            elif str(input_validation_schema[i][2]).lower() == "contains":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                              + " ILIKE  $$%" + str(input_validation_schema[i][3]).strip() + "%$$ " + str(input_validation_schema[i][4]) +\
                              " " + str(input_validation_schema[i][5])
                temp_list.append(column)
            elif str(input_validation_schema[i][2]).lower() == "regex":
                func_string = func_string + " " + str(input_validation_schema[i][0]) + " " + column \
                               + " ~ $$" + str(input_validation_schema[i][3]).strip() + "$$ " + str(input_validation_schema[i][4]) + \
                              " " + str(input_validation_schema[i][5])
                temp_list.append(column)



        logger.error("func_String: " + str(func_string ))

    except Exception as e:
        logger.error(str(e))
        return "Invalid rule"

    # func_string = ''
    # stupid_list = list()
    # logger.error("input_validation_schema: "+ str(input_validation_schema))
    # for column in columns[4:]:
    #     validation = input_validation_schema[_object.get_key(column.lower())]
    #     if str(validation[0]).lower() == "not null":
    #         func_string = func_string + column + ' is ' + validation[0] + ' and '
    #     elif str(validation[0]).lower() == ">":
    #         if '>' in validation[1]:
    #             logger.error("inside if")
    #             func_string = func_string + column + " '" + validation[1].rstrip() + "' "
    #             stupid_list.append(column)
    #         else:
    #             logger.error("in else")
    #             func_string = func_string + column + " > ''" + validation[1] + "'' and "
    #             stupid_list.append(column)
    #         # func_string = func_string + column + " > ''" + validation[1] + "'' and "
    #         # stupid_list.append(column)
    #     elif str(validation[0]).lower() == "<":
    #         if '<' in validation[1]:
    #             func_string = func_string + column + " '" + validation[1].rstrip() + "' "
    #             stupid_list.append(column)
    #         else:
    #             func_string = func_string + column + " < ''" + validation[1] + "'' and "
    #             stupid_list.append(column)
    #         # func_string = func_string + column + " < ''" + validation[1] + "'' and "
    #         # stupid_list.append(column)
    #     elif str(validation[0]).lower() == "equals to":
    #         if '=' in validation[1]:
    #             func_string = func_string + column + " '" + validation[1].rstrip() + "' "
    #             stupid_list.append(column)
    #         else:
    #             func_string = func_string + column + " = ''" + validation[1] + "'' and "
    #             stupid_list.append(column)
    #         # func_string = func_string + column + " = ''" + validation[1] + "'' and "
    #         # stupid_list.append(column)
    #     elif str(validation[0]).lower() == "contains":
    #         logger.error("validation[1]:  " + str(validation[1]))
    #         if '%' in validation[1]:
    #             func_string = func_string + column + " ilike '" + validation[1].rstrip() + "' and "
    #             stupid_list.append(column)
    #         else:
    #             func_string = func_string + column + " ilike ''%" + validation[1] + "%''" + " and "
    #             stupid_list.append(column)
    #     elif str(validation[0]).lower() == "regex":
    #         if '~' in validation[1]:
    #             func_string = func_string + column + " '" + validation[1].rstrip() + "' "
    #             stupid_list.append(column)
    #         else:
    #             func_string = func_string + column + " ~ ''" + validation[1] + "'' and "
    #             stupid_list.append(column)
    #         # func_string = func_string + column + " ~ ''" + validation[1] + "'' and "
    #         # stupid_list.append(column)
    #     elif str(validation[0]).lower() == "not equals to":
    #         if '!=' in validation[1]:
    #             func_string = func_string + column + " '" + validation[1].rstrip() + "' "
    #             stupid_list.append(column)
    #         else:
    #             func_string = func_string + column + " != ''" + validation[1] + "'' and "
    #             stupid_list.append(column)
            # func_string = func_string + column + " != ''" + validation[1] + "'' and "
            # stupid_list.append(column)

    if entity_name == 'study':
        stage_table = 'stage_study'
        landing_table = 'landing_study'
    elif entity_name == 'investigator':
        stage_table = 'stage_investigator'
        landing_table = 'landing_investigator'
    else:
        stage_table = 'stage_org'
        landing_table = 'landing_org'

    # for x in stupid_list:

    for x in temp_list:
        cursor = connection.cursor()
        cursor.execute("SELECT func_update_stage_NULL('{}', '{}', '{}', '{}')".format(uid, ingest_id, x,
                                                                                      stage_table))
        logger.error("update stage null done")

    # func_string = func_string[:-4]
    key = 'validation'
    if insert_into:
        cursor = connection.cursor()
        logger.error("UPDATE ingestion SET flow_id = e'{}', validation_rules = e'{}' WHERE "
                       "ingest_id = e'{}'".format(flow_id, func_string, ingest_id))
        cursor.execute("UPDATE ingestion SET flow_id = e'{}', validation_rules = e'{}' WHERE "
                       "ingest_id = e'{}'".format(flow_id, func_string, ingest_id))
        cursor = connection.cursor()
        if not edit_flow:
            logger.error("INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, username, ingest_id, flow_engage_lock) "
                "VALUES (e'{}', e'{}', e'{}', e'{}', e'{}',e'{}', e'{}',e'{}', '1')".format(dm_uid, flow_id, key,
                                                                                    func_string, flow_name,
                                                                                    scope, user, ingest_id))
            cursor.execute(
                "INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, username, ingest_id, flow_engage_lock) "
                "VALUES (e'{}', e'{}', e'{}', e'{}', e'{}',e'{}', e'{}',e'{}', '1')".format(dm_uid, flow_id, key,
                                                                                    func_string, flow_name,
                                                                                    scope, user, ingest_id))
        else:
            logger.error("UPDATE flow SET updated_by='{}', updated_date=NOW() WHERE "
                           "flow_id='{}' AND key='{}' AND updated_date IS NULL AND ingest_id != '{}'".format(dm_uid,
                                                                                                             flow_id,
                                                                                                             key,
                                                                                                             ingest_id))
            cursor.execute("UPDATE flow SET updated_by='{}', updated_date=NOW() WHERE "
                           "flow_id='{}' AND key='{}' AND updated_date IS NULL AND ingest_id != '{}'".format(dm_uid,
                                                                                                             flow_id,
                                                                                                             key,
                                                                                                             ingest_id))

            cursor = connection.cursor()
            logger.error("INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, username, ingest_id, flow_engage_lock)"
                "VALUES ('{}','{}','{}','{}','{}','{}','{}','{}', '1')".format(dm_uid, flow_id, key,
                                                                               func_string, flow_name, scope,
                                                                               user, ingest_id))
            cursor.execute(
                "INSERT INTO flow(uid, flow_id, key, value, flow_name, access_type, username, ingest_id, flow_engage_lock)"
                "VALUES ('{}','{}','{}','{}','{}','{}','{}','{}', '1')".format(dm_uid, flow_id, key,
                                                                               func_string, flow_name, scope,
                                                                               user, ingest_id))
    else:
        cursor = connection.cursor()
        logger.error("UPDATE ingestion SET flow_id = '{}', validation_rules ='{}' WHERE ingest_id = '{}'".format(flow_id,
                                                                                                        func_string,
                                                                                                        ingest_id))
        cursor.execute(
            "UPDATE ingestion SET flow_id = '{}', validation_rules ='{}' WHERE ingest_id = '{}'".format(flow_id,
                                                                                                        func_string,
                                                                                                        ingest_id))
    cursor = connection.cursor()
    cursor.execute("SELECT uid FROM flow WHERE flow_id='{}' AND key='validation' and updated_date IS NULL".format(
        flow_id))
    fc_uid = str(cursor.fetchall()[0][0])
    logger.error("fc_uid    " + fc_uid)
    cursor = connection.cursor()
    # logger.error("QUERY " + "SELECT func_validation('{}', '{}', '{}', '{}', '{}','{}')".format(ingest_id, uid, flow_id,
    #                                                                                            dm_uid, fc_uid,
    #                                                                                            stage_table))

    cursor.execute("SELECT column_name FROM information_schema.columns where table_name = '{}'".format(stage_table))
    data = cursor.fetchall()
    col_list = []
    for i in data:
        col_list.append(i[0])
    col_list = col_list[1:-5] # REMOVING LANDING_ID AND SITE_ID, STUDY_ID, SPONSOR_ID, VALID_FLAG, REASON
    col_string = ", ".join(col_list)
    logger.error("col_string: " + str(col_string))
    cursor = connection.cursor()
    cursor.execute("""SELECT func_condition_temp_3('validation', 0, '{}', '{}', '{}')""".format(flow_id, fc_uid, ingest_id))
    str_output = str(cursor.fetchall()[0][0])
    logger.error("str output : " + str_output)
    cursor = connection.cursor()
    logger.error("""UPDATE {} SET valid_flag='1' WHERE {} and ingest_id = '{}' and uid = '{}'
                            and reason is null""".format(stage_table,
                                                         str_output,
                                                         ingest_id,
                                                         uid))
    cursor.execute("""UPDATE {} SET valid_flag='1' WHERE {} and ingest_id = '{}' and uid = '{}'
                        and reason is null""".format(stage_table,
                                                                                                          str_output,
                                                                                                          ingest_id,
                                                                                                          uid))

    logger.error("ok")

    logger.error("SELECT func_validation('{}', '{}', '{}', '{}', '{}', '{}')".format(ingest_id, uid, flow_id, dm_uid,
                                                                                     fc_uid, stage_table))
    # cursor.execute("SELECT func_validation('{}', '{}', '{}', '{}', '{}', '{}')".format(ingest_id, uid, flow_id, dm_uid,
    #                                                                                    fc_uid, stage_table))
    logger.error("run func validation ok")
    #
    cursor = connection.cursor()
    cursor.execute("SELECT func_validation_reason('{}', '{}', '{}', '{}', '{}', '{}')".format(uid, ingest_id, flow_id,
                                                                                              dm_uid, fc_uid,
                                                                                              stage_table))

    logger.error("run func_validation reason ok")
    cursor = connection.cursor()
    logger.error("UPDATE stage_investigator "
                 "SET    valid_flag = NULL, reason = 'Duplicate Record' "
                 "where ingest_id = '{}' and (stage_id, CTID) not in  "
                 "( SELECT stage_id, CTID "
                 "FROM   stage_investigator where ingest_id = '{}' and (CTID) in "
                 "(select max(CTID) from stage_investigator where ingest_id = '{}' "
                 "GROUP  BY contact_type , "
                 "fst_name , full_name , mid_name , last_name , fax_ph_num1 , fax_ph_num2 , "
                 "fax_ph_num3 , primary_mobile_num , "
                 "secondary_mobile_num , work_phone1 , work_phone2 , work_phone3 , home_phone , "
                 "ethnicity_name , marital_status , birth_dt , birth_place , citizenship , education_bckgnd , "
                 "education_years , grad_yr , email_address , addr_eff_date , decease_flg , per_title , "
                 "per_title_suffix , job_title , comments , primary_specialty , degree , certification , "
                 "gender , manager_id , created_by_id , changed_by_id , created_on_dt , changed_on_dt , "
                 "country , state , site_id , study_id , sponsor_id))".format(ingest_id, ingest_id, ingest_id))

    cursor.execute("UPDATE stage_investigator "
                   "SET    valid_flag = NULL, reason = 'Duplicate Record' "
                   "where ingest_id = '{}' and (stage_id, CTID) not in  "
                   "( SELECT stage_id, CTID "
                   "FROM   stage_investigator where ingest_id = '{}' and (CTID) in "
                   "(select max(CTID) from stage_investigator where ingest_id = '{}' "
                   "GROUP BY  contact_type ,"
                   "fst_name , full_name , mid_name , last_name , fax_ph_num1 , fax_ph_num2 , "
                   "fax_ph_num3 , primary_mobile_num ,"
                   "secondary_mobile_num , work_phone1 , work_phone2 , work_phone3 , home_phone , "
                   "ethnicity_name , marital_status , birth_dt , birth_place , citizenship , education_bckgnd , "
                   "education_years , grad_yr , email_address , addr_eff_date , decease_flg , per_title , "
                   "per_title_suffix , job_title , comments , primary_specialty , degree , certification , "
                   "gender , manager_id , created_by_id , changed_by_id , created_on_dt , changed_on_dt , "
                   "country , state , site_id , study_id , sponsor_id))".format(ingest_id, ingest_id,
                                                                                ingest_id))

    connection.commit()
    logger.error("dedup done")
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT source_id FROM ingestion_sources WHERE ingest_id = '{}' AND uid='{}'".format(ingest_id,
                                                                                                            uid))
        data = cursor.fetchall()
        for i in data:
            cursor = connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM \"{}\" WHERE ingest_source_id = '{}' AND ingest_id = '{}' AND "
                           "uid = '{}' AND valid_flag = '1'".format(stage_table, i[0], ingest_id, uid))
            a = cursor.fetchall()[0][0]
            cursor = connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM \"{}\" WHERE ingest_source_id = '{}' AND ingest_id = '{}' AND "
                           "uid = '{}' AND valid_flag IS NULL".format(stage_table, i[0], ingest_id, uid))
            b = cursor.fetchall()[0][0]
            cursor = connection.cursor()
            cursor.execute("SELECT source_name from \"ingestion_sources\" WHERE source_id = '{}' AND "
                           "ingest_id = '{}' AND uid = '{}'".format(i[0], ingest_id, uid))
            d = cursor.fetchall()[0]
            # c = d[0]
            # if d[1] == "file_browser":
            #     c = c.split("/")[-1]
            # else:
            #     l = c.split(',')
            #     c = l[1].split(':')[1][1:-1] + ':' + l[2].split(':')[1][1:-1]
            cursor = connection.cursor()
            logger.error("""INSERT INTO data_validation_dashboard_meta(uid, ingest_id, ingest_source_id, source_root_id,
                          source_name, total_count,total_validated_count, total_rejected_count, ingest_name,
                          username ) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')""".format(uid,ingest_id,
                                                                                                     i[0],root_source_id
                                                                                                    , d[0],
                                                                                                    int(a) + int(b),
                                                                                                    int(a), int(b),
                                                                                                    ing_name,
                                                                                                    user))
            cursor.execute("""INSERT INTO data_validation_dashboard_meta(uid, ingest_id, ingest_source_id, source_root_id, 
                           source_name, total_count,total_validated_count, total_rejected_count, ingest_name,
                            username ) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')""".format(uid, ingest_id,
                                                                                                      i[0], root_source_id,
                                                                                                      d[0],
                                                                                                      int(a) + int(b),
                                                                                                      int(a), int(b),
                                                                                                      ing_name,
                                                                                                      user))
            connection.commit()
    except Exception as e:
        logger.error(str(e))

    if schedule_flag:
        return 'Validation successful for ingest_id'
    ui_information = dict()
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT source_name , total_validated_count, total_rejected_count FROM "
                       "data_validation_dashboard_meta WHERE ingest_id = '{}' and uid = '{}'".format(ingest_id, uid))
        ui_info = cursor.fetchall()
        count = 0
        ui_information['rejected_data'] = dict()
        stage_table_schema = []
        stage_table_schema_temp = []
        stage_table_schema_temp_1 = []
        cursor = connection.cursor()
        cursor.execute("select column_name from information_schema.columns "
                       "where table_name = '{}'; ".format(stage_table))
        stage_table_schema_temp_1 = cursor.fetchall()
        print(type(stage_table_schema_temp_1))
        logger.error("stage_table_schema_temp_1: " + str(stage_table_schema_temp_1))
        """
        here we want to append the last column on the second position and want to remove the second, third and fourth 
        element from the list.
        """
        logger.error("here is my code !!!!")
        for i in stage_table_schema_temp_1:
            stage_table_schema_temp.append(i[0])
        logger.error("stage table schema temp in new way: " + str(stage_table_schema_temp))
        stage_table_schema = stage_table_schema_temp[5:6] + stage_table_schema_temp[-1:] + settings.COLUMN_LIST[2:]
        logger.error("stage_table_schema: " + str(stage_table_schema))
        stage_table_schema_string = ', '.join(['"{}"'.format(value) for value in stage_table_schema])
        logger.error("stage_table_schema_string: " + str(stage_table_schema_string))
        for tup in ui_info:
            logger.error("tup: "+ str(tup))
            logger.error("ui_info:" + str(ui_info))
            cursor = connection.cursor()
            # cursor.execute("SELECT "
            #                "s.stage_id, s.reason, s.mdm_contact_id, s.contact_type, s.fst_name, s.full_name, "
            #                "s.mid_name, s.last_name, s.fax_ph_num1, s.fax_ph_num2, s.fax_ph_num3, "
            #                "s.primary_mobile_num, s.secondary_mobile_num, s.work_phone1, s.work_phone2, "
            #                "s.work_phone3, s.home_phone, s.ethnicity_name, s.marital_status, s.birth_dt, "
            #                "s.birth_place, s.citizenship, s.education_bckgnd, s.education_years, s.grad_yr, "
            #                "s.email_address, s.addr_eff_date, s.decease_flg, s.per_title, s.per_title_suffix, "
            #                "s.job_title, s.comments, s.primary_specialty, s.degree, s.certification, s.gender, "
            #                "s.manager_id, s.created_by_id, s.changed_by_id, s.created_on_dt, s.changed_on_dt, "
            #                "s.country, s.state FROM \"stage_investigator\" AS s WHERE "
            #                "s.ingest_id = '{}' and s.valid_flag IS NULL and s.ingest_source_id "
            #                "= (SELECT source_id from ingestion_sources where ingest_id = '{}'"
            #                " AND source_name = '{}') ".format(ingest_id, ingest_id, str(tup[0])))
            logger.error("""SELECT {}  FROM "{}"  WHERE ingest_id = '{}' and valid_flag IS NULL
                                                      and ingest_source_id = (SELECT source_id from ingestion_sources where ingest_id = '{}'
                                                      AND source_name = '{}') """.format(stage_table_schema_string,
                                                                                         stage_table,
                                                                                         ingest_id, ingest_id
                                                                                        , str(tup[0])))

            cursor.execute("""SELECT {}  FROM "{}"  WHERE ingest_id = '{}' and valid_flag IS NULL
                              and ingest_source_id = (SELECT source_id from ingestion_sources where ingest_id = '{}'
                              AND source_name = '{}') """.format(stage_table_schema_string, stage_table, ingest_id,
                                                                 ingest_id ,str(tup[0])))

            data = cursor.fetchall()
            # rep = {" is not null": " is null", " like ": " contains ", "%": ""}  # define desired replacements here
            # for iter in data:
            #     logger.error("rejected loop records......" + str(iter[1]))
            #     rep = dict((re.escape(k), v) for k, v in rep.items())
            #     pattern = re.compile("|".join(rep.keys()))
            #     iter = iter[0:1] + (pattern.sub(lambda m: rep[re.escape(m.group(0))], iter[1]), ) + iter[1:]
            #     logger.error("after removing unwanted things in reason: : " + str(iter[1]))

            ui_information['rejected_data'][str(tup[0])] = dict()
            ui_information['rejected_data'][str(tup[0])]['source_name'] = str(tup[0])
            ui_information['rejected_data'][str(tup[0])]['data'] = data

            ui_information['rejected_data'][str(tup[0])]['columns'] = convert_to_alias(stage_table_schema, entity_name)
            ui_information[count] = [str(tup[0]), tup[1], tup[2]]

            count += 1

        # here we did rejection analysis just after the validation rules done.
        logger.error("ingest_name: "+ str(ingestion_name))
        add_data = AllRejectionAnalysisGraph.get(entity_name, stage_table, ingest_name=ingestion_name, source_uid=uid)
        ui_information['add_data'] = add_data
        # source_name_data = 0
        # for tup in ui_info:
        #     ui_information[source_name_data] = [str(tup[0])]
        # logger.error(str(ui_information))
        return ui_information
    except Exception as e:
        logger.error(str(e))
    return dict()
