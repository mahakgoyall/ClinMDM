# from django.db import connection
# import pandas as pd
# import json
#
#
# def getxyzdata():
# 	with connection.cursor() as cursor:
# 	    	print connection.queries
# 	        cursor.execute("SELECT * FROM xyz")
# 	        row = cursor.fetchall()
# 	        print(row," /////////////////")
# 	        datat= list()
# 	        data = pd.read_sql("SELECT * FROM {}".format('xyz'),  connection)
# 	        for column in data.columns:
# 	        	datat.append(column)
# 	        print json.dumps(datat)
# 	return data
#
# def set_session(request):
# 	print "inside set_session"
# 	request.session['temp_var'] = 'temporary'
# 	print "session set"
# 	tvar = request.session['temp_var']
# 	print("tvar = ",tvar)
# 	return tvar	