from django.db import connection


def getxyzdata():
    # with connection['MDM_data'].cursor() as cursor:
    cursor = connection.cursor()
    # print connection.queries
    # cursor.execute("""insert into Session_Ref(UID, SESSION_ID) values(%s,%s)""",[24,'sdf'])
    cursor.execute("""SELECT SOURCE_ID,MDM_CONTACT_ID,CONTACT_TYPE ,FST_NAME ,FULL_NAME ,MID_NAME ,
                    LAST_NAME ,FAX_PH_NUM1 ,FAX_PH_NUM2 ,FAX_PH_NUM3 ,PRIMARY_MOBILE_NUM ,SECONDARY_MOBILE_NUM ,WORK_PHONE1 ,WORK_PHONE2,
                    WORK_PHONE3 ,HOME_PHONE ,ETHNICITY_NAME ,MARITAL_STATUS ,BIRTH_DT ,BIRTH_PLACE ,CITIZENSHIP ,EDUCATION_BCKGND 
                    ,EDUCATION_YEARS , GRAD_YR , EMAIL_ADDRESS , ADDR_EFF_DATE , DECEASE_FLG ,PER_TITLE ,PER_TITLE_SUFFIX , JOB_TITLE 
                    ,COMMENTS , PRIMARY_SPECIALTY ,DEGREE ,CERTIFICATION ,GENDER , MANAGER_ID ,CREATED_BY_ID ,CHANGED_BY_ID ,CREATED_ON_DT ,
                     CHANGED_ON_DT,PROTOCOL_NUM,SITE_ID,STATE,COUNTRY
                    FROM (SELECT ROW_NUMBER() OVER (ORDER BY SOURCE_ID ASC) 
                    AS rownumber,* FROM {}) AS foo WHERE rownumber >= {} 
                    AND rownumber <={}""".format('SOURCE1', 2, 2))

    print(cursor.fetchall())
    # cursor.execute("SELECT * FROM xyz")
    # row = cursor.fetchall()
    # print(row," /////////////////")
    # datat= list()
    # data = pd.read_sql("SELECT * FROM {}".format('xyz'),  connection)
    # for column in data.columns:
    # datat.append(column)
    # print json.dumps(datat)
    return "inserted"      
