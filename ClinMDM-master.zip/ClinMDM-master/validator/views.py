from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from rest_framework.views import APIView
from validator.data_validator import data_validation
from validator.column_mapping import business_to_column
from django.conf import settings
from django.db import connection
from django.views.decorators.csrf import ensure_csrf_cookie
from passlib.hash import pbkdf2_sha256
from rulematcher.views import RuleMatching
import random
import os
import binascii
import string
import pandas as pd
import json
import yagmail, keyring, keyrings.alt
import logging
from web_curl_service.views import flow_flags
import bcrypt

logger = logging.getLogger("mdm_logging")


class ValidationError(Exception):
    pass


def init(request):
    return JsonResponse({'user_id': request.session['user_id'], 'role': request.session['role']})


def index(request):
    return render(request, 'index.html')


def create_user(request):
    # TODO, setup yagmail with keyring. See link https://github.com/kootenpv/yagmail
    # import keyring, keyrings, yagmail
    # keyring.set_password('yagmail', 'gmailaccount', 'appgeneratorpassword')
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})

    try:
        full_name = data["full_name"]
        username = data["username"]
        email = data["email"]
        role = data["role"]
        role = ','.join([str(r) for r in role])
        # alias_username = username.()
    except KeyError as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'At least one field is missing'})

    length = 12
    chars = string.ascii_letters + string.digits + '!@#$%^&*()'
    random.seed = (os.urandom(1024))
    password = ''.join(random.choice(chars) for _ in range(length))
    # TODO save _hash instead of plaintext password
    _hash = pbkdf2_sha256.hash(password)
    password = password.encode('utf-8')
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    hashed = hashed.decode('utf-8')
    try:
        username = username.upper()
        if role == '1':
            role = '1,2,3,4'
            logger.info("role if admin selected" + str(role))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
    try:
        cursor = connection.cursor()
        cursor.execute("select user_id from users where username = '{}'".format(username))
        user_exist = cursor.fetchall()
        if user_exist:
            return JsonResponse({'failure': 'Username already exists.'})
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'Database Failure.'})
    # try:
    #     cursor = connection.cursor()
    #     cursor.execute("select user_id from users where email_address = '{}'".format(email))
    #     user_email = cursor.fetchall()
    #     if user_email:
    #         return JsonResponse({'failure': 'Email Address already exists.'})
    # except Exception as e:
    #     logger.error(str(e))
    #     # k = dict()
    #     # k['Error'] = str(e).replace("'", '"')
    #     # # k = json.dumps(k)
    #     # cursor = connection.cursor()
    #     # logger.error(
    #     #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #     #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #     # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #     #     request.session.get('ingest_id', -1),
    #     #     request.session.get('user_id', -1), json.dumps(k)))
    #     # connection.commit()
    #     return JsonResponse({'failure': 'Database Failure.'})
    try:
        cursor = connection.cursor()
        cursor.execute("INSERT INTO users (username, password, name, email_address, role) VALUES"
                       " ('{}', '{}', '{}', '{}', '{}')".format(username, hashed, full_name, email, role))
        connection.commit()
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT user_id FROM users WHERE username='{}' AND"
                       " email_address='{}' and delete_flag != '1'".format(username, email))
        uid = (cursor.fetchall())[0]
        logger.error("Newly created user's uid is: " + str(uid))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': str(e)})

    try:
        url = request.META.get('HTTP_HOST')
        logger.error('url: ' + str(url))
        # yagmail.register('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        yag = yagmail.SMTP('dheerykumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        password = password.decode('utf-8')
        username = username
        to = email
        token_string = binascii.hexlify(os.urandom(128))
        subject = 'MDM'
        body = 'Your account is created on mdm page.\n\n\n Username: ' + username + '\nPassword: ' + password
        body += '\n\n\n'
        html = "<h5>Click on this link to redirect on change password functionality </h5> " \
               "<a href = '" + str('http://') + url + "' > " + str(url) + "</a><br /><br />"
        yag.send(to=str(to), subject=subject, contents=[body, html])
        logger.error(str("done"))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'Unable to send mail.'})

    return JsonResponse({'success': 'ok', 'uid': uid})


def change_password(request):
    """
    admin/change_password
    :param request: 
    :return: 
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
        uid = data["userid"]
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'No data found in body.'})

    length = 12
    chars = string.ascii_letters + string.digits + '!@#$%^&*()'
    random.seed = (os.urandom(1024))
    password = ''.join(random.choice(chars) for _ in range(length))
    # TODO save _hash instead of plaintext password
    _hash = pbkdf2_sha256.hash(password)
    password = password.encode('utf-8')
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    hashed = hashed.decode('utf-8')

    try:
        cursor = connection.cursor()
        cursor.execute("SELECT email_address FROM users WHERE user_id='{}' and delete_flag != '1'".format(uid))
        email = cursor.fetchall()[0][0]
        print('email address: ' + str(email))
    except Exception as e:
        logger.error(str(e))
    try:
        cursor = connection.cursor()
        cursor.execute("UPDATE users SET password='{}', reset_flag='0' WHERE user_id='{}'".format(hashed, uid))
        connection.commit()
        print("password reset successfully.")
    except Exception as e:
        logger.error(str(e))
    try:
        url = request.META.get('HTTP_HOST')
        logger.error('url: ' + str(url))
        # yagmail.register('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        yag = yagmail.SMTP('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        password = password.decode('utf-8')
        to = email
        token_string = binascii.hexlify(os.urandom(128))
        subject = 'MDM'
        body = 'Your new Password is: ' + '\nPassword: ' + password
        body += '\n\n\n'
        html = "<h5>Click on this link to redirect on Login Screen. </h5> " \
               "<a href = '" + str('http://') + url + "' > " + str(url) + "</a><br /><br />"
        yag.send(to=str(to), subject=subject, contents=[body, html])
        logger.info(str("done"))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'Unable to send mail.'})
    return JsonResponse({'uid': uid})


def modify_user(request):
    """
    
    :param request: 
    :return: 
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})

    try:
        uid = data["userid"]
        full_name = data["full_name"]
        username = data["username"]
        email = data["email"]
        role = data["role"]
        role = ','.join([str(r) for r in role])
    except KeyError as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'At least one field is missing'})

    try:
        username = username.upper()
        cursor = connection.cursor()
        cursor.execute("select 1 from users where username = '{}' and user_id != '{}'".format(username, uid))
        user_name = cursor.fetchall()
        if user_name:
            return JsonResponse({'failure': 'Username already exists.'})
        url = request.META.get('HTTP_HOST')
        logger.error('url: ' + str(url))
        cursor = connection.cursor()
        cursor.execute("SELECT email_address FROM users WHERE user_id='{}' and delete_flag != '1'".format(uid))
        old_user_email = cursor.fetchall()[0][0]
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
    try:
        cursor = connection.cursor()
        cursor.execute("UPDATE users SET username='{}', name='{}', email_address='{}', "
                       "role='{}' WHERE user_id='{}'".format(username, full_name, email, role, uid))
        connection.commit()

        print("updated successfully")
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()

    try:
        cursor = connection.cursor()
        cursor.execute("SELECT email_address, username, role, name from users WHERE user_id='{}' and "
                       "delete_flag != '1'".format(uid))
        user_info = cursor.fetchall()
        print(str(user_info))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()

    try:
        # yagmail.register('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        yag = yagmail.SMTP('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        for user_info_list in user_info:
            new_email = user_info_list[0]
            roles_code = user_info_list[2]
            name = user_info_list[3]

        username = username
        if old_user_email != email:
            to = old_user_email
            token_string = binascii.hexlify(os.urandom(128))
            subject = 'MDM'
            body = 'Your details have been updated on mdm page.\n\n\n Username: ' \
                   '' + username + '\n\n Email: ' + new_email + '\n\n full name: ' + name
            body += '\n\n\n'
            html = "<h5>Click on this link to redirect on our website. </h5> " \
                   "<a href = '" + str('http://') + url + "' > " + str(url) + "</a><br /><br />"
            logger.error('html: ' + str(html))
            yag.send(to=str(to), subject=subject, contents=[body, html])
        to = email
        token_string = binascii.hexlify(os.urandom(128))
        subject = 'MDM'
        body = 'Your details have been updated on mdm page.\n\n\n Username: ' \
                   '' + username + '\n\n Email: ' + new_email + '\n\n full name: ' + name
        body += '\n\n\n'
        html = "<h5>Click on this link to redirect on our website. </h5> " \
                "<a href = '" + str('http://') + url + "' > " + str(url) + "</a><br /><br />"
        logger.error('html: ' + str(html))
        yag.send(to=str(to), subject=subject, contents=[body, html])
        logger.info(str("done"))
    except Exception as e:
        logger.error(str(e))
        # k = dict()
        # k['Error'] = str(e).replace("'", '"')
        # # k = json.dumps(k)
        # cursor = connection.cursor()
        # logger.error(
        #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        # cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #     request.session.get('ingest_id', -1),
        #     request.session.get('user_id', -1), json.dumps(k)))
        # connection.commit()
        return JsonResponse({'failure': 'Unable to send mail.'})

    return JsonResponse({'uid': uid})


def delete_user(request):
    try:
        data = json.loads(request.read().decode('utf-8'))
        uid = data['userid']
        logger.error(str(uid) + ": user id to be deleted")
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        cursor = connection.cursor()
        cursor.execute("UPDATE users SET delete_flag =  '1' where user_id = '{}'".format(uid))
        # cursor.execute("DELETE FROM users WHERE user_id='{}'".format(uid))
        connection.commit()
        cursor = connection.cursor()
        cursor.execute("select email_address from users where user_id = '{}'".format(uid))
        email = cursor.fetchall()[0][0]
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'Failure in DB query.'})
    try:
        url = request.META.get('HTTP_HOST')
        logger.error('url: ' + str(url))
        # yagmail.register('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        yag = yagmail.SMTP('dheerukumar005.12@gmail.com', 'rkiofoslcjsivbqo')
        to = email
        token_string = binascii.hexlify(os.urandom(128))
        subject = 'MDM'
        body = 'Your account has been deactivated. Please contact Admin.'
        body += '\n\n\n'
        html = "<h5>Click on this link to redirect on Login Page </h5> " \
               "<a href = '" + str('http://') + url + "' > " + str(url) + "</a><br /><br />"
        yag.send(to=str(to), subject=subject, contents=[body, html])
        logger.info(str("done"))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'Unable to send mail.'})
    return JsonResponse({'ok': 'Success'})


@ensure_csrf_cookie
def login(request):
    print('in login file')
    reset_flag = request.session.get('reset_flag', False)
    if reset_flag == '1':
        try:
            user_id = request.session['user_id']
            role = request.session['role']
            # dashboard
            return render(request, 'index-x.html', {'user_id': user_id, 'role': role})
        except KeyError as e:
            logger.error(str(e))
            pass
    # login
    print('Serving index.html')
    return render(request, 'index.html', {'reset_flag': reset_flag})


def logout(request):
    try:
        del request.session['role']
        del request.session['user_id']
        del request.session['ingest_id']
    except KeyError as e:
        logger.error(str(e))
        pass
    return render(request, 'index.html')


@ensure_csrf_cookie
def login_check(request):
    """
    
    :param request: 
    :return: 
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        username = data["Username"]
        password = data["Password"]
        reason = ''
        # pbkdf2_sha256.verify("toomanysecrets", hash)
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'All fields are mandatory.'})
    try:
        username = username.upper()
        cursor = connection.cursor()
        cursor.execute("SELECT user_id FROM users WHERE username = '{}' and delete_flag != '1'".format(username))
        # logger.info('after checking username')
        var1 = cursor.fetchall()
    except Exception as e:
        logger.error(str(e))
    try:
        if var1:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT password FROM users WHERE username = '{}' and delete_flag != '1'".format(username))
                hashed = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
            #hashed = hashed.encode('utf-8')
            #password = password.encode('utf-8')
            logger.info('username valid')
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT user_id, role, reset_flag FROM users WHERE delete_flag != '1' AND"
                               " username = '{}' AND password = '{}'".format(username, hashed)) 
                             #  bcrypt.hashpw(password, hashed).decode('utf-8') + "'")
                var = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
            logger.info("var:" + str(var))
            if var:
                # 1 is admin
                # 2 is source user
                # 3 is steward

                # TODO remove print and DO NOT USE logger
                print ("uid is: " + str(var[0][0]))
                request.session['user_id'] = var[0][0]
                request.session['role'] = var[0][1]
                request.session['username'] = username
                request.session['reset_flag'] = var[0][2]
                reset_flag = {}
                reset_flag['reset_flag'] = request.session.get('reset_flag', False)
                # Update last login time of user
                try:
                    cursor = connection.cursor()
                    cursor.execute("UPDATE users SET last_login=now() WHERE user_id='{}'".format(var[0][0]))
                except Exception as e:
                    logger.error(str(e))
            else:
                reason = 'Invalid password'
                return JsonResponse({'failure': 'Invalid Password'})
        else:
            reason = 'Invalid username'
            return JsonResponse({'failure': 'Invalid Username'})

    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': reason})

    return JsonResponse({'Success': reset_flag})
    # return render(request, 'index.html', {'username': username})


def reset_password(request):
    """
    
    :param request: 
    :return: 
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'No data found in body.'})

    try:
        username = data["username"]
        password = data["password"]
        old_password = data["old_password"]

    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'At least one field is missing.'})
    try:
        username = username.upper()
        cursor = connection.cursor()
        cursor.execute("select password from users where username='{}'".format(username))
        hashed_password = cursor.fetchall()[0][0]
        hashed_password = hashed_password.encode('utf-8')
        old_password = old_password.encode('utf-8')
        encrypt_pass = bcrypt.hashpw(old_password, hashed_password)
        if encrypt_pass == hashed_password:
            password = password.encode('utf-8')
            hashed = bcrypt.hashpw(password, bcrypt.gensalt())
            hashed = hashed.decode('utf-8')
            cursor = connection.cursor()
            cursor.execute("UPDATE users SET password='{}', reset_flag='1' WHERE username='{}'".format(hashed, username))
            connection.commit()
        else:
            logger.error('Incorrect old password.')
            return JsonResponse({'failure': 'Incorrect old password.'})
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': str(e)})
    return JsonResponse({'ok': 'Success'})


def forget_password(request):
    try:
        data = json.loads(request.read().decode('utf-8'))
        email = data["email"]
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        logger.error('email entered: ' + str(email))
        cursor = connection.cursor()
        cursor.execute("SELECT user_id FROM users WHERE email_address='{}' and delete_flag != '1'"
                       .format(email))
        uid = cursor.fetchall()
        logger.error('email address: ' + str(uid))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'Database Failure'})
    if uid:
        return JsonResponse({'userid': uid[0][0]})
    return JsonResponse({'failure': 'user does not exist.'})

class ValidatorClass(APIView, ValidationError):
    # TODO Remove static column dict from below. I can do that right now but feeling bit lazy lol. :D Will do that later
    MDM = getattr(settings, "MDM", "mdm_golden")
    STAGE_INVESTIGATOR = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
    STAGE_STUDY = getattr(settings, "STAGE_STUDY", "stage_study")
    STAGE_ORG = getattr(settings, "STAGE_ORG", "stage_org")
    # column_dict = getattr(settings, "COLUMN_DICT", {})

    # @staticmethod
    def get(self, request):
        try:
            logger.info("Request : " + str(request))
            entity_name = request.META['HTTP_ENTITY']
            logger.info("INGEST ID: " + str(request.session['ingest_id']))
        except KeyError as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Ingestion is not selected yet'})

        # obj1 = business_to_column(self.column_dict)
        # logger.info("obj1:")
        # logger.info(str(obj1))
        datat = list()
        # data = pd.read_sql("""SELECT * FROM "{}" LIMIT 1""".format(self.MDM),  connection)
        table_name = ''
        # TODO #### change entity by fetching from request header
        # entity = 'investigator'
        logger.info("Entity name : " + str(entity_name))
        if entity_name == 'investigator':
            logger.error("Continuing get of Investigator")
            table_name = self.STAGE_INVESTIGATOR
            landing_table_name = 'landing_investigator'
            obj1 = business_to_column(getattr(settings, "COLUMN_DICT", {}))
            logger.info("obj1: " + str(obj1))
            # logger.info(str(obj1))
        elif entity_name == 'study':
            table_name = self.STAGE_STUDY
            obj1 = business_to_column(getattr(settings, "STUDY_COLUMN_DICT", {})) # CHANGE TO STUDY COLUMN DICT
            logger.info("obj1:")
            logger.info(str(obj1))
            landing_table_name = 'landing_study'
        else:
            table_name = self.STAGE_ORG
            logger.info("table_name: " + str(table_name))
            obj1 = business_to_column(getattr(settings, "ORG_COLUMN_DICT", {}))
            logger.info("obj1: " + str(obj1))
            landing_table_name = 'landing_org'
        logger.info("table_name after if else: " + str(landing_table_name))
        # logger.info(str(table_name))
        data = pd.read_sql("""SELECT * FROM "{}" LIMIT 1""".format(landing_table_name), connection)
        logger.info("data: " + str(data))
        logger.info("Ingest name is: " + str(request.session['ingest_name']))
        # logger.info(str(data))
        for idx, column in enumerate(data.columns):
            if idx == 0:
                continue
            name = obj1.get_key(str(column))
            if name:
                datat.append(name)
        logger.info("datat: " + str(datat))
        return JsonResponse(datat, safe=False)

    # @staticmethod
    def post(self, request=None, rules=None, flow_id=None, entity_name=None, edit_flag=None, uid=None, ingest_id=None,
             source_root_id=None, flow_name=None, scope=None, username=None, ingest_name=None, dm_uid=None,
             steward_id=None,
             scheduler_flag=False, schedule_ingest_id=None):
        """

        :param request:
        :param rules:
        :return:
        """
        try:
            logger.error("in validation post ")
            if request:
                logger.info("onee: " + str(request.session))
                entity_name = request.META['HTTP_ENTITY']
                logger.info("entity_name in post of validation: " + entity_name)
                edit_flag = request.session['edit']
                uid = str(request.session['source_user_id'])
                ingest_id = str(request.session['ingest_id'])
                # add source root id to session during source loader connection page try
                source_root_id = str(request.session['source_root_id'])
                flow_flags(ingest_id, uid, '5')
                logger.info(str(source_root_id))
                flow_name = request.session['flow_name']
                scope = request.session['scope']
                username = request.session['username']
                ingest_name = request.session['ingest_name']
                logger.info("ingest_name: " + str(ingest_name))
                dm_uid = request.session['user_id']
                scheduler_flag = False

        except KeyError as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Error in GetColumn post --> entity name'})
        # entity = 'investigator'
        if entity_name == 'investigator':
            obj2 = business_to_column(getattr(settings, "COLUMN_DICT", {}))

        elif entity_name == 'study':
            obj2 = business_to_column(getattr(settings, "STUDY_COLUMN_DICT", {})) # CHANGE TO STUDY COLUMN DICT

        else:
            obj2 = business_to_column(getattr(settings, "ORG_COLUMN_DICT", {}))

        # obj2 = business_to_column(self.column_dict)
        rule_matcher_should_run = False
        insert_into = True

        if rules:
            insert_into = False
            validation_rules = rules['validation_rules']
            logger.error(str(validation_rules))
            # print(validation_rules)
            rule_matcher_should_run = True
            if request:
                flow_id = request.session['flow_id']
        else:
            validation_rules = request.data
            print("in else")
            print(type(validation_rules))
            print(validation_rules)
            # TODO remove below line of code after correct working of create new flow
            if 'rules' not in request.session:
                request.session['rules'] = dict()
            request.session['rules']['validation_rules'] = validation_rules
            if edit_flag:
                flow_id = request.session['flow_id']
            else:
                length = 12
                chars = string.ascii_letters + string.digits + '!@#$%^&*()'
                random.seed = (os.urandom(1024))
                flow_id = ''.join(random.choice(chars) for _ in range(length))
                request.session['flow_id'] = flow_id

        # uid = str(request.session['user_id'])

        try:
            if schedule_ingest_id:
                cursor = connection.cursor()
                cursor.execute("SELECT ingest_name from ingestion where ingest_id = '{}'".format(schedule_ingest_id))
                ingest_name = cursor.fetchall()[0][0]
                data = data_validation(validation_rules, obj2, uid, schedule_ingest_id, flow_name, username,
                                       ingest_name, scope, insert_into, flow_id, dm_uid, edit_flag, entity_name,
                                       source_root_id, schedule_flag=scheduler_flag)
                flow_flags(schedule_ingest_id, uid, '6')
            else:
                data = data_validation(validation_rules, obj2, uid, ingest_id, flow_name, username,
                                       ingest_name, scope, insert_into, flow_id, dm_uid, edit_flag, entity_name,
                                       source_root_id, schedule_flag=scheduler_flag)
                flow_flags(ingest_id, uid, '6')
            if rule_matcher_should_run:
                if schedule_ingest_id:
                    return RuleMatching().post(request, rules, entity_name=entity_name, ingest_id=schedule_ingest_id, uid=uid,
                                           steward_id=steward_id, flow_name=flow_name, scope=scope, username=username,
                                           flow_id=flow_id, edit_flow=edit_flag, root_source_id=source_root_id)
                else:
                    return RuleMatching().post(request, rules, entity_name=entity_name, ingest_id=ingest_id, uid=uid,
                                               steward_id=steward_id, flow_name=flow_name, scope=scope,
                                               username=username,
                                               flow_id=flow_id, edit_flow=edit_flag, root_source_id=source_root_id)
            else:
                return JsonResponse(data)
        except ValidationError as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    ingest_id, uid, json.dumps(k)))
            connection.commit()
        return JsonResponse({'failure': 'Failure'})


class TruncateValidatedData(APIView):  # rollback in data validation

    @staticmethod
    def get(request):
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("entity_name: " + str(entity_name))
            if entity_name == 'study':
                stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
                landing_table = getattr(settings, "LANDING_STUDY", "landing_study")
            elif entity_name == 'investigator':
                stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                landing_table = getattr(settings, "LANDING_INVESTIGATOR", "landing_investigator")
            else:
                stage_table = getattr(settings, "STAGE_ORG", "stage_org")
                landing_table = getattr(settings, "LANDING_ORG", "landing_org")
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT func_rollback_data_validation('{}', '{}', '{}', '{}', "
                               "'{}')".format(stage_table, request.session['ingest_id'],
                                              request.session['source_user_id'],
                                              request.session['flow_id'], request.session['user_id']))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("Truncated data validation is working here!!!! ")
            # cursor = connection.cursor()
            # cursor.execute("SELECT func_rollback_data_validation('{}', '{}', '{}', "
            #                "'{}')".format(request.session['ingest_id'], request.session['source_user_id'],
            #                               request.session['flow_id'], request.session['user_id']))
            # logger.info("Truncated data validation is working here!!!! ")
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB failure'})
        return JsonResponse({'ok': 'Success'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure': 'API not supported.'})


class GiveRejectedReason(APIView):
    @staticmethod
    def get(request):
        rejected_table = getattr(settings, "REJECTED_TABLES", ['REJECTED_SOURCE1', 'REJECTED_SOURCE2'])
        rejected_dict = {}
        cur = connection.cursor()
        try:
            for table in rejected_table:
                cur.execute("SELECT count(*),Reason FROM {} group by Reason".format(table))
                rejected_dict[table] = cur.fetchall()
                connection.commit()
            return JsonResponse(rejected_dict, safe = False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'DB failure'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure': 'API not supported'})


class ValidatedColumns(APIView):
    @staticmethod
    def get(request):
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT data_mapping FROM ingestion_sources WHERE "
                           "ingest_id='{}'".format(request.session['ingest_id']))
            columns = list()
            data = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            logger.info(" data mappings in validation :  " + str(data))
            for tup in data:
                mapping = tup[0]
                for key, value in mapping.items():
                    if key == 'concate':
                        for i in mapping['concate']:
                            columns.append(str(i))
                    elif key == 'decode':
                        for i in mapping['decode']:
                            columns.append(i['target_name'])
                    elif key == 'substring':
                        for i in mapping['substring']:
                            columns.append(i['target_name'])
                    elif key == 'lowercase':
                        for i, j in mapping['lowercase'].items():
                            columns.append(j)
                    elif key == 'uppercase':
                        for i, j in mapping['uppercase'].items():
                            columns.append(j)
                    else:
                        columns.append(str(value))
            column_list = set(columns)
            column_list = [i.upper() for i in column_list]
            logger.info("columns  : " + str(columns))
            return JsonResponse({'columns': list(column_list)})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Mapping not found'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure': 'Api not supported'})


class FlowRules(APIView):

    @staticmethod
    def get(request):
        try:
            logger.info("rules in session:"+ str(request.session['rules']))
            return JsonResponse(request.session['rules'])

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Data not found in session.'})

    @staticmethod
    def post(request):
        return JsonResponse({'failure': 'API not supported.'})
