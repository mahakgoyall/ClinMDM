from __future__ import unicode_literals

# from django.db import connection

# Create your models here.



# def my_custom_sql(self):
#     with connection.cursor() as cursor:
#         cursor.execute("SELECT * FROM xyz")
#         row = cursor.fetchall()
#         print(row," /////////////////")

#     return row