from django.conf.urls import url
# from django.contrib import admin
from . import views


urlpatterns = [ 
    url(r'^getReasonRejected/$', views.GiveRejectedReason.as_view()),
    url(r'^flushData/source/$', views.TruncateValidatedData.as_view()),
    url(r'^getColumns/$', views.ValidatorClass.as_view()),
    url(r'^getValidatedColumns/$', views.ValidatedColumns.as_view()),
    url(r'^currentFlow/$', views.FlowRules.as_view()),
    url(r'^$', views.login, name='login'),
]
