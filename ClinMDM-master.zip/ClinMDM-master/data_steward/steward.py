import json
from django.db import connection
import logging
from django.conf import settings
import re
import copy

logger = logging.getLogger("mdm_logging")
# data steward will display all the tasks created in the rule engine process .


def show_flow_completed_ingestion_list_to_steward(request, page_number):
    """

    :param request:
    :param page_number:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        temp_string = ''
        if entity_name == 'investigator':
            temp_string = " = 'investigator' "
        elif entity_name == 'study':
            temp_string = " = 'study' "
        else:
            temp_string = "IN ('site', 'sponsor', 'org')"
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT COUNT(i.ingest_id) FROM ingestion as i  "
                           "WHERE i.steward_id='{}' AND "
                           "i.status_flag='7' AND entity  {} ".format(request.session['user_id'], temp_string))
            total = cursor.fetchall()[0][0]
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT i.username, i.ingest_name  FROM ingestion as i"
                           " WHERE i.steward_id='{}' AND "
                           "i.status_flag='7' AND entity {} "
                           "LIMIT 10 OFFSET '{}'".format(request.session['user_id'], temp_string,
                                                         int(page_number) * 10 - 10))
            data = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        logger.error(str(data))
        ui_information = dict()
        counter = 0
        for tup in data:
            local_dict = dict()
            local_dict['username'] = tup[0]
            local_dict['ingest_name'] = tup[1]
            ui_information[counter] = local_dict
            counter += 1
        ui_information['total'] = total
        logger.error(str(ui_information))
        return ui_information
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    return dict()


def show_task_list_to_steward(request, page_number):
    """

    :param request:
    :param page_number:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error("page number: "+ str(page_number))
        temp_string = ''
        if entity_name == 'investigator':
            temp_string = " = 'investigator' "
        elif entity_name == 'study':
            temp_string = " = 'study' "
        else:
            temp_string = "IN ('site', 'sponsor', 'org')"

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'No data found in body.'}
    # total = 0
    # try:
    #     try:
    #         try:
    #             cursor = connection.cursor()
    #             logger.error("SELECT COUNT(distinct(task_id)) FROM partial_ref WHERE  ingest_id"
    #                            "=(SELECT ingest_id FROM "
    #                            "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                            "status != '12' AND entity {}".format(username, ingest_name, temp_string))
    #             cursor.execute("SELECT COUNT(distinct(task_id)) FROM partial_ref WHERE  ingest_id"
    #                            "=(SELECT ingest_id FROM "
    #                            "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                            "status != '12' AND entity {}".format(username, ingest_name, temp_string))
    #             total1 = cursor.fetchall()[0][0]
    #             logger.error("Total 1 is: " + str(total1))
    #             cursor = connection.cursor()
    #             cursor.execute("SELECT COUNT(distinct(task_id)) FROM internal_partial_ref where ingest_id = (select ingest_id "
    #                            "from ingestion where ingest_name = '{}') and status != '12' and "
    #                            "entity {} ".format(ingest_name, temp_string))
    #             total2 = cursor.fetchall()[0][0]
    #             logger.error("Total 2 is: " + str(total2))
    #             total = total1 + total2
    #         except Exception as e:
    #             logger.error(str(e))
    #             k = dict()
    #             k['Error'] = str(e).replace("'", '"')
    #             # k = json.dumps(k)
    #             cursor = connection.cursor()
    #             logger.error(
    #                 """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                     request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #             cursor.execute(
    #                 """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                     request.session.get('ingest_id', -1),
    #                     request.session.get('user_id', -1), json.dumps(k)))
    #             connection.commit()
    #         logger.error("total count: " + str(total))
    #         try:
    #             cursor = connection.cursor()
    #             logger.error(
    #                 "SELECT * FROM (SELECT DISTINCT (p.task_id), m.lookup_name, 'np' FROM partial_ref as p join mdm_lookup as m "
    #                 "ON p.status = m.lookup_value "
    #                 "WHERE  p.ingest_id=(SELECT ingest_id FROM "
    #                 "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                 "P.status != '12'  "
    #                 "UNION  SELECT DISTINCT (q.task_id), r.lookup_name, 'ip' FROM internal_partial_ref as q "
    #                 "join mdm_lookup as r "
    #                 "ON q.status = r.lookup_value "
    #                 "WHERE  q.ingest_id=(SELECT ingest_id FROM "
    #                 "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                 "q.status != '12') AS FOO  "
    #                 "LIMIT 10 OFFSET '{}'".format(username, ingest_name, username, ingest_name,
    #                                       int(page_number) * 10 - 10))
    #             cursor.execute(
    #                 "SELECT * FROM (SELECT DISTINCT (p.task_id), m.lookup_name, 'np' FROM partial_ref as p join mdm_lookup as m "
    #                 "ON p.status = m.lookup_value "
    #                 "WHERE  p.ingest_id=(SELECT ingest_id FROM "
    #                 "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                 "P.status != '12'  "
    #                 "UNION  SELECT DISTINCT (q.task_id), r.lookup_name, 'ip' FROM internal_partial_ref as q "
    #                 "join mdm_lookup as r "
    #                 "ON q.status = r.lookup_value "
    #                 "WHERE  q.ingest_id=(SELECT ingest_id FROM "
    #                 "ingestion WHERE username='{}' AND ingest_name='{}') AND "
    #                 "q.status != '12') AS FOO  "
    #                 "LIMIT 10 OFFSET '{}'".format(username, ingest_name, username, ingest_name,
    #                                               int(page_number) * 10 - 10))
    #             data = cursor.fetchall()
    #         except Exception as e:
    #             logger.error(str(e))
    #     except Exception as e:
    #         logger.error(str(e))
    #         k = dict()
    #         k['Error'] = str(e).replace("'", '"')
    #         # k = json.dumps(k)
    #         cursor = connection.cursor()
    #         logger.error(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #         cursor.execute(
    #             """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #                 request.session.get('ingest_id', -1),
    #                 request.session.get('user_id', -1), json.dumps(k)))
    #         connection.commit()
    #     ui_information = dict()
    #     counter = 0
    #     d = dict()
    #     for tup in data:
    #         local_dict = dict()
    #         local_dict['task_id'] = tup[0]
    #         local_dict['status'] = tup[1]
    #         local_dict['type'] = tup[2]
    #         d[counter] = local_dict
    #         counter += 1
    #     logger.error("total count after: " + str(total))
    #     ui_information['total'] = total
    #     ui_information['list'] = d
    #     print("ui_information:  ")
    #     print(ui_information)
    #     return ui_information
    # except Exception as e:
    #     logger.error(str(e))
    #     k = dict()
    #     k['Error'] = str(e).replace("'", '"')
    #     # k = json.dumps(k)
    #     cursor = connection.cursor()
    #     logger.error(
    #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
    #     cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
    #         request.session.get('ingest_id', -1),
    #         request.session.get('user_id', -1), json.dumps(k)))
    #     connection.commit()

    try:
        uid = request.session.get('user_id', False)
        entity_name = request.META['HTTP_ENTITY']
        cursor = connection.cursor()
        cursor.execute("select role from users where user_id = '{}' AND delete_flag != '1'".format(uid))
        role = cursor.fetchall()[0][0]
        logger.error('role: ' + str(role))
        context = {}
        if '3' in role:
            cursor = connection.cursor()
            logger.error("select count(distinct(task_id)) from partial_ref where steward_id = '{}'"
                           " and entity = '{}' and task_id is not null and status != '12' ".format(uid, entity_name))
            cursor.execute("select count(distinct(task_id)) from partial_ref where steward_id = '{}'"
                           " and entity = '{}' and task_id is not null and status != '12'".format(uid, entity_name))
            total_task = cursor.fetchall()
            logger.error("count: " + str(total_task))
            if total_task:
                total_task = total_task[0][0]
            cursor = connection.cursor()
            logger.error("select DISTINCT(p.task_id),  p.status, p.task_name from partial_ref as p  "
                           "where p.steward_id = '{}' and p.entity = '{}' and p.task_id is not null and status != '12'  "
                         "order by p.task_id limit 10 offset {}"
                           .format(uid, entity_name, int(page_number) * 10 - 10))
            cursor.execute("select DISTINCT(p.task_id),  p.status, p.task_name from partial_ref as p  "
                           "where p.steward_id = '{}' and p.entity = '{}' and p.task_id is not null and status != '12' "
                           " order by p.task_id limit 10 offset {}"
                           .format(uid, entity_name, int(page_number) * 10 - 10))
            data = cursor.fetchall()
            logger.error("data: "+ str(data))
            dict_temp = []
            for tup in data:
                local_dict = dict()
                local_dict['task_id'] = tup[0]
                local_dict['task_name'] = tup[2]
                local_dict['ingest_name'] = tup[1]
                status_val = tup[1]
                # cursor = connection.cursor()
                # cursor.execute("select uid, data_manager_id  from partial_ref where ingest_name = '{}'"
                #                " and delete_flag != '1'".format(tup[1]))
                # ingest_data = cursor.fetchall()
                if data:
                    # cursor = connection.cursor()
                    # cursor.execute("select DISTINCT(username) from users where user_id = '{}' and delete_flag != '1'"
                    #                .format(ingest_data[0][0]))
                    # user_name = cursor.fetchall()[0][0]
                    # # local_dict['username'] = user_name
                    cursor = connection.cursor()
                    cursor.execute("select lookup_name from mdm_lookup where "
                                   "lookup_value = '{}' ".format(status_val))
                    local_dict['status'] = cursor.fetchall()[0][0]
                    # cursor = connection.cursor()
                    # cursor.execute("select distinct(username) from users where user_id = '{}' and delete_flag != '1'"
                    #                .format(ingest_data[0][1]))
                    # data_manager = cursor.fetchall()[0][0]
                    # # local_dict['data_manager'] = data_manager
                dict_temp.append(local_dict)
            context['data'] = dict_temp
            context['total_task'] = total_task
        else:
            return {'failure': 'you do not have permission for this action.'}
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'Failure'}
    return context


def show_task_detail(request):
    """

    :param request:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error("entity_name: " + str(entity_name))
        temp_string = ''

        if entity_name == 'study':
            stage_table = getattr(settings, "STAGE_STUDY", "stage_study")
            master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            priority_table = 'master_study_column_source_priority_lookup'
            column_dict_local = copy.deepcopy(settings.STUDY_COLUMN_DICT)
            temp_string = " = 'study' "

        elif entity_name == 'investigator':
            stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
            master_table = getattr(settings, "MDM", "mdm_golden")
            priority_table = 'master_investigator_column_source_priority_lookup'
            column_dict_local = copy.deepcopy(settings.COLUMN_DICT)
            temp_string = " = 'investigator' "

        else:
            stage_table = getattr(settings, "STAGE_ORG", "stage_org")
            master_table = getattr(settings, "MDM_ORG", "mdm_org")
            priority_table = 'master_org_column_source_priority_lookup'
            column_dict_local = copy.deepcopy(settings.ORG_COLUMN_DICT)
            temp_string = "IN ('site', 'sponsor', 'org')"

        data = json.loads(request.read().decode('utf-8'))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'No data found in body.'}
    try:
        # username = data['username']
        # ingest_name = data['ingest_name']
        task_id = data['task_id']
        logger.error("task_id: "+ str(task_id))
        # type_detail = data['type']
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'Failure'}
    try:
        try:
            cursor = connection.cursor()
            cursor.execute("select distinct(steward_id) from partial_ref where task_id = '{}' and status = '10' "
                           " and steward_id is not null".format(task_id))
            st_id = cursor.fetchall()
            logger.error("st_id: " + str(st_id))
            if st_id:
                steward_string = "steward_id is not null and status = '10'"
            else:
                cursor = connection.cursor()
                cursor.execute("select distinct(steward_id) from partial_ref  where task_id = '{}' "
                               "and status in ('9','11')".format(task_id))
                steward_id  = cursor.fetchall()
                logger.error(" STEWARD id  : " + str(steward_id))
                if steward_id[0][0] :
                    steward_string = "steward_id is not null and status in ('9','11')"
                else:
                    steward_string = "steward_id is NULL and status in ('9','11')"
            cursor = connection.cursor()
            logger.error("SELECT stage_id, mdm_id, ingest_id, uid, ingest_source_id, "
                           "partial_ref_id FROM partial_ref "
                           "WHERE task_id='{}' AND  {}".format(task_id, steward_string))
            cursor.execute("SELECT stage_id, mdm_id, ingest_id, uid, ingest_source_id, "
                           "partial_ref_id FROM partial_ref "
                           "WHERE task_id='{}' AND  {} ".format(task_id, steward_string))
            data = cursor.fetchall()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        logger.error(str(data))
        mdm_data = None
        mdm_data_priority = None
        if data and data[0][1]:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT * FROM \"{}\" "
                               "WHERE mdm_id='{}'".format(priority_table, data[0][1]))
                data3 = cursor.fetchall()
                if data3:
                    mdm_data_priority = data3[0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT * FROM \"{}\" WHERE mdm_id='{}'".format(master_table, data[0][1]))
                data2 = cursor.fetchall()
                if data2:
                    mdm_data = data2[0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        if mdm_data_priority:
            mdm_data_priority = mdm_data_priority[:-1]
        if mdm_data:
            mdm_data = mdm_data[:-2]
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '{}'".format(master_table))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        column_list = [str(tup[0]).lower() for tup in cursor.fetchall()]
        alias_column_list = list()


        # Remove ts_current
        for col in column_list[:-2]:
            alias_column_list.append(list(column_dict_local.keys())[list(column_dict_local.values()).index(col)])
            # alias_column_list.append(list(settings.COLUMN_DICT.keys())[list(settings.COLUMN_DICT.values()).index(col)])

        steward_data = []
        # Created a dictionary in session for record ids and other data
        record_ids_dict = dict()
        s_priority = ''
        source_names = list()
        source_priorities = list()

        for record in data:
            stage_id = record[0]
            master_id = record[1]
            ingest_id = record[2]
            uid = record[3]
            ingest_source_id = record[4]
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT distinct(value) FROM flow WHERE key='rule' AND  "
                               "updated_date IS NULL and flow_id in (select flow_id from "
                               "ingestion where ingest_id = '{}' and delete_flag != '1' "
                               "and updated_date is null) ".format(ingest_id))
                matching_col = cursor.fetchall()
                # for k, v in settings.COLUMN_DICT.items():
                #     logger.error("rev DICT and matching col: " + str(settings.COLUMN_DICT[k] + str(matching_col[0][0])))
                #     if str(settings.COLUMN_DICT[k]) == str(matching_col[0][0]):
                #         logger.error("matching col values....: " + str(matching_col))
                #         matching_col = v

                cursor = connection.cursor()
                cursor.execute("select distinct(matching_score) from partial_ref where "
                               "ingest_id = '{}' and stage_id = '{}' "
                               "and mdm_id = '{}' and {}".format(ingest_id, stage_id, master_id, steward_string))
                matching_score = cursor.fetchall()
                cursor = connection.cursor()
                cursor.execute("SELECT source_priority FROM ingestion_sources WHERE source_id = '{}'".format(ingest_source_id))
                s_priority = str(cursor.fetchall()[0][0])
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT * FROM \"{}\" WHERE stage_id='{}'".format(stage_table, stage_id))
                # Remove ts_current, ingest_id, ingest_source_id, uid
                # Append None because mdm is not available for this source.
                stage_data = cursor.fetchall()[0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # removing first 4 columns - stage_id, ingest_id, ingest_source_id, uid
            #removing last 5 columns - site_id, sponsor_id, investigator_id, valid_flag, reason
            steward_data.append([stage_data[0]] + list(stage_data[5:-5]) + matching_score + matching_col)
            source_priorities.append(s_priority)
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT source_name FROM ingestion_sources WHERE source_id='{}'".format(ingest_source_id))
                var = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

            # Remove all the leading backslashes from file name
            # var = ((str(var)).split('/')).pop()
            # Remove last `'.)`
            # var = ((str(var)).split("'")).pop(0)
            record_ids_dict[str(int(stage_id))] = [ingest_id, uid, ingest_source_id, var, master_id ]
            source_names.append(var)

        record_ids_dict[str(int(stage_id))] = [ingest_id, uid, ingest_source_id, var, master_id]
        source_names.append(var)

        # logger.error('putting record ids in session...' + str(record_ids_dict))
        request.session['record_ids'] = record_ids_dict
        ui_information = dict()

        if mdm_data:
            # Remove last ts_current
            ui_information['mdm'] = [i for i in mdm_data]
            ui_information['mdm_priority'] = [i for i in mdm_data_priority]

        # logger.error(str(alias_column_list) + str(column_list))
        ui_information['column_list'] = alias_column_list[:]
        ui_information['keys'] = column_list[:-2]
        if data:
            try:
                for idx, lst in enumerate(steward_data):
                    logger.error(str(source_names) + str(source_priorities) + str(lst) + str(idx))
                    ui_information[idx] = lst + [source_names[0], source_priorities[0]]
            except Exception as e:
                logger.error(str(e))
        else:
            try:
                for idx, lst in enumerate(steward_data):
                    logger.error(str(source_names) + str(source_priorities) + str(lst) + str(idx))
                    ui_information[idx] = lst + [source_names[idx], source_priorities[idx]]
            except Exception as e:
                logger.error(str(e))
        # try:
            # cursor = connection.cursor()
            # cursor.execute("SELECT value FROM flow WHERE key='rule' AND flow_id='{}' and updated_date IS NULL".format(flow_id))
        # except Exception as e:
        #     logger.error(str(e))
        #     k = dict()
        #     k['Error'] = str(e).replace("'", '"')
        #     # k = json.dumps(k)
        #     cursor = connection.cursor()
        #     logger.error(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        #     cursor.execute(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1),
        #             request.session.get('user_id', -1), json.dumps(k)))
        #     connection.commit()
        rev_dict = dict()
        # for k, v in settings.COLUMN_DICT.items():
        # for k, v in column_dict_local.items():
        #     rev_dict[v] = k
        #
        # data_ = cursor.fetchall()
        # logger.error("value of flow query: " + str(data_))
        # val = set()
        # for idx, tup in enumerate(data_):
        #     lst = tup[0].split(' and ')
        #     lst = [rev_dict[i.strip()] for i in lst]
        #     for e in lst:
        #         val.add(e)
        #
        # a = list()
        # for idx, item in enumerate(val):
        #     lst.append(alias_column_list.index(item))

        ui_information['index'] = lst

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return dict()

    return ui_information


def update_mdm(request, task_id):
    """

    :param request:
    :param task_id:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error("entity_name: " + str(entity_name))
        if entity_name == 'study':
            master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            priority_table = 'master_study_column_source_priority_lookup'
            master_seq_name = 'mdm_study_mdm_study_id_seq'

        elif entity_name == 'investigator':
            master_table = getattr(settings, "MDM", "mdm_golden")
            priority_table = 'master_investigator_column_source_priority_lookup'
            master_seq_name = 'mdm_test_seq'

        else:
            master_table = getattr(settings, "MDM_ORG", "mdm_org")
            priority_table = 'master_org_column_source_priority_lookup'
            master_seq_name = 'mdm_org_mdm_id_seq'

        data = json.loads(request.read().decode('utf-8'))
        source_name = data['source_name']

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'No data found in body.'}
    try:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '{}'".format(master_table))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        column_list = [str(tup[0]) for tup in cursor.fetchall()]
        # Remove mdm_id (first column) and ts_current (last column)
        column_list = column_list[:-2]

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'Cannot find column name from schema'}

    # TODO Sawant: provide -1 if mdm_id is null
    if str(data['mdm_id']) != '-1':
        logger.error("mdm_id: "+ str(data['mdm_id']))
        try:
            logger.error(str(column_list))
            mdm_id = None
            string = ''
            string2 = ''
            source_id_dict = []
            stage_id_dict = []
            for k, v in data.items():
                # logger.error(v['value'] + ':' + v['priority'] )
                if k == 'mdm_id':
                    mdm_id = v['value']
                    logger.error("mdm_id: " + str(mdm_id))
                    continue
                elif k == 'stage_id':
                    for i in v['value']:
                        stage_id_dict.append(i)
                    continue
                elif k == 'source_name':
                    continue
                elif k == 'source_id':
                    for i in v['value']:
                        source_id_dict.append(i)
                else:
                    # if "'" in v['value']:
                    #     logger.error("re implementation!!!")
                    #     v['value'] = re.sub("'", "''", v['value'])
                    # logger.error("replacement done!!!")
                    logger.error("else 325")
                    if v['value'] and v['priority']:
                        string = string + k + "='" + str(v['value']) + "', "
                        string2 = string2 + k + "='" + str(v['priority']) + "', "
                        logger.error("string in loop: " + str(string))
                        logger.error("string2 in loop: " + str(string2))
                    else:
                        string = string + k + "= NULL, "
                        logger.error("else if else 325")
                        logger.error("string in else: " + str(string))
            # for k, v in data.items():
            #     if k == 'mdm_id':
            #         mdm_id = v
            #         continue
            #     elif k == 'stage_id':
            #         continue
            #     else:
            #         if v:
            #             string = string + k + "='" + v + "', "
            #         else:
            #             string = string + k + "=NULL, "
            string2 = string2[:-2]
            string = string[:-2]
            logger.error("String is: " + str(string))
            logger.error("String2 is : " + str(string2))
            try:
                cursor = connection.cursor()
                logger.error("UPDATE "+master_table+" SET " + string + " WHERE mdm_id='{}'".format(mdm_id))
                cursor.execute("UPDATE "+master_table+" SET " + string + " WHERE mdm_id='{}'".format(mdm_id))
                connection.commit()
                cursor = connection.cursor()
                cursor.execute("update "+master_table+" SET changed_on_dt = now() where mdm_id = '{}'".format(mdm_id))
                connection.commit()
                #TODO: Sawant: send dict if values are updating from multiple sources.
                logger.error("stage_ids: "+ str(stage_id_dict))
                ids_dict = request.session['record_ids']
                logger.error("ids dict: "+ str(ids_dict))
                for source_id_dicto, stage_id_dicto in zip(source_id_dict, stage_id_dict):
                    # ids_dict = request.session['record_ids']
                    for st_id, lst in ids_dict.items():
                        logger.error("st_id: stage_id_dicto:"+ str(st_id)+ " "+ str(stage_id_dicto))
                        logger.error("lst: " + str(lst))

                        if int(st_id) == int(stage_id_dicto):
                            ingest_id, uid, ingest_source_id, source_name, match_mdm_id = lst
                            logger.error("lst: "+ str(lst))
                    cursor = connection.cursor()
                    cursor.execute("select source_root_id from ingestion_sources"
                                   " where source_name = '{}'".format(source_name))
                    source_root_id = cursor.fetchall()[0][0]
                    cursor = connection.cursor()
                    cursor.execute("insert into ref_data (stage_id, reason, ingest_id, source_id, mdm_id, "
                                   "source_root_id, entity, source_name) select '{}', '{}','{}','{}', mdm_id,'{}', entity, '{}' from partial_ref"
                                   " where  mdm_id = '{}'".format(stage_id_dicto, "Update by steward", ingest_id,
                                                                  source_id_dicto, source_root_id, source_name, mdm_id))
                connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error("MDM update finished Steward")
            try:
                cursor = connection.cursor()
                cursor.execute("UPDATE "+priority_table+" "
                               "SET " + string2 + " WHERE mdm_id='{}'".format(mdm_id))
                connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error("MDM priority update Steward")

            ids_dict = request.session.get('record_ids', False)
            logger.error('ids_dict: ' + str(ids_dict))

            for stage_id, lst in ids_dict.items():
                ingest_id, uid, ingest_source_id, source_name, matched_mdm_id = lst
                try:
                    cursor = connection.cursor()
                    cursor.execute("UPDATE partial_ref SET status='10' WHERE task_id='{}' and "
                                   " stage_id = '{}' and mdm_id = '{}' "
                                   "and ingest_id = '{}'".format(task_id, stage_id, matched_mdm_id,ingest_id))
                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()

            del request.session['record_ids']

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'Failure'}
    else:
        logger.error("data[mdm_id]: "+ str(data['mdm_id']))
        try:
            column_names = ''
            string = ''
            string2 = ''
            source_id_dict = []
            stage_id_dict = []
            # for k, v in data.items():
            #     if k == 'mdm_id':
            #         continue
            #     else:
            #         column_names = column_names + k + ', '
            #         if v:
            #             values = values + "'" + v + "', "
            #         else:
            #             values += 'NULL, '
            for k, v in data.items():
                if k == 'mdm_id':
                    continue
                elif k == 'stage_id':
                    for p in v['value']:
                        stage_id_dict.append(p)
                elif k == 'undefined':
                    continue
                elif k == 'source_name':
                    continue
                elif k == 'source_id':
                    for i in v['value']:
                        source_id_dict.append(i)
                else:
                    # if "'" in v['value']:
                    #     logger.error("re implementation!!!")
                    #     v['value'] = re.sub("'", "''", v['value'])
                    # logger.error("replacement done!!!")
                    column_names = column_names + k + ', '
                    if v['value']:
                        string = string + "'" + v['value'] + "', "
                    else:
                        string += "NULL, "
                    if v['priority']:
                        logger.error('v priority: '+ str(v['priority']))
                        string2 = string2 + "'" + v['priority'] + "', "
                    else:
                        string2 += "NULL, "
            column_names = column_names[:-2]
            # values = values[:-2]
            string = string[:-2]
            string2 = string2[:-2]
            logger.error("column_names is: " + str(column_names))
            logger.error("string below: " + str(string))
            logger.error("string2 below: " + str(string2))
            try:

                cursor = connection.cursor()
                logger.error("INSERT INTO "+master_table+" (" + column_names + ") VALUES (" + string + "); "
                               "SELECT currval('{}')".format(master_seq_name))

                cursor.execute("INSERT INTO "+master_table+" (" + column_names + ") VALUES (" + string + "); "
                               "SELECT currval('{}');".format(master_seq_name))

                mdm_id = str(cursor.fetchall()[0][0])
                logger.error("new mdm_id: "+ str(mdm_id))
                for source_id_dicto, stage_id_dicto in zip(source_id_dict, stage_id_dict):
                    ids_dict = request.session['record_ids']
                    for st_id, lst in ids_dict.items():
                        if st_id == stage_id_dicto:
                            ingest_id, uid, ingest_source_id, source_name, match_mdm_id = lst
                    cursor = connection.cursor()
                    cursor.execute("select source_root_id from ingestion_sources"
                                   " where source_name = '{}'".format(source_name))
                    source_root_id = cursor.fetchall()[0][0]
                    cursor = connection.cursor()
                    cursor.execute("insert into ref_data (stage_id, reason, ingest_id, source_id, mdm_id, "
                                   "source_root_id, entity, source_name) select '{}', '{}','{}','{}', mdm_id,'{}', entity, '{}' from partial_ref"
                                   " where  mdm_id = '{}'".format(stage_id_dicto, "Update by steward", ingest_id,
                                                                  source_id_dicto, source_root_id, source_name, mdm_id))

                    logger.error("ref data insert ok")
                # connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                # connection.commit()
            # master_id = str(cursor.fetchall()[0][0])
            master_id = mdm_id
            logger.error("MDM insert finished steward")
            try:
                logger.error("master priority update")
                logger.error("column names: "+ column_names)
                logger.error("string2: "+ string2)
                cursor = connection.cursor()
                logger.error("INSERT INTO "+priority_table+" (mdm_id," + column_names + ") "
                                "VALUES ('"+master_id+"'," + string2 + ") ")

                cursor.execute("INSERT INTO "+priority_table+" (mdm_id," + column_names + ") "
                                "VALUES ('"+master_id+"'," + string2 + ") ")
                logger.error("Master priority update finish!!!!")
                connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            ids_dict = request.session['record_ids']

            for lst in ids_dict.values():
                ingest_id, uid, ingest_source_id, source_name = lst
                try:
                    cursor = connection.cursor()
                    cursor.execute("UPDATE internal_partial_ref SET status='10', mdm_id='{}' WHERE task_id='{}' AND "
                                   "ingest_id='{}' AND uid='{}' AND ingest_source_id='{}'".format(master_id, task_id,
                                                                                                  ingest_id, uid, ingest_source_id))
                    connection.commit()
                    logger.error('update success in mdm')
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()

            del request.session['records_ids']

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return {'failure': 'Failure'}

    return {'ok': 'Success'}


def discard_task(request, task_id):
    """

    :param request:
    :param task_id:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error("entity_name: " + str(entity_name))
        if entity_name == 'study':
            stage_table = getattr(settings, "STAGE_STUDY", "stage_study")

        elif entity_name == 'investigator':
            stage_table = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")

        else:
            stage_table = getattr(settings, "STAGE_ORG", "stage_org")

        ids_dict = request.session['record_ids']

        for stage_id, lst in ids_dict.items():
            ingest_id, uid, ingest_source_id, source_name, matched_mdm_id = lst
            try:
                try:
                    logger.error("stage_id: "+ str(stage_id))
                    cursor = connection.cursor()
                    cursor.execute("UPDATE partial_ref SET status='11' WHERE task_id='{}' AND steward_id is not null "
                                   "  AND "
                                   "steward_id='{}' ".format(task_id, uid))
                    cursor = connection.cursor()
                    cursor.execute("delete from partial_ref where task_id = '{}' and stage_id = '{}'"
                                   " and mdm_id = '{}'".format(task_id, stage_id, matched_mdm_id))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                logger.error('discard update complete')
                try:
                    cursor = connection.cursor()
                    cursor.execute("UPDATE {} SET valid_flag = NULL, reason = 'Discarded' WHERE stage_id='{}' "
                                   "AND ingest_id='{}' AND uid='{}' AND ingest_source_id='{}'".format(stage_table,
                                                                                                      stage_id, ingest_id,
                                                                                                      uid,
                                                                                                      ingest_source_id))

                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()

        # Issue discarded so we don't need any record ids
        del request.session['record_ids']
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'Failure'}
    return {'ok': 'Success'}


def insert_into_mdm(request, task_id):
    """

    :param request:
    :param task_id:
    :return:
    """
    try:
        entity_name = request.META['HTTP_ENTITY']
        logger.error("entity_name: " + str(entity_name))
        if entity_name == 'study':
            master_table = getattr(settings, "MDM_STUDY", "mdm_study")
            priority_table = 'master_study_column_source_priority_lookup'
            master_seq_name = 'mdm_study_mdm_study_id_seq'

        elif entity_name == 'investigator':
            master_table = getattr(settings, "MDM", "mdm_golden")
            priority_table = 'master_investigator_column_source_priority_lookup'
            master_seq_name = 'mdm_test_seq'

        else:
            master_table = getattr(settings, "MDM_ORG", "mdm_org")
            priority_table = 'master_org_column_source_priority_lookup'
            master_seq_name = 'mdm_org_mdm_id_seq'

        data = json.loads(request.read().decode('utf-8'))
        logger.error('1....................' + str(data))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'No data found in body.'}
    try:
        column_names = ''
        string = ''
        string2 = ''
        record_id = None
        source_name = data['source_name']
        source_id = None
        for k, v in data.items():
            if k == 'mdm_id':
                record_id = v['value']
                # column_names = column_names + k + ', '
                continue
            elif k == 'stage_id':
                continue
            elif k == 'undefined':
                continue
            elif k == 'source_name':
                continue
            elif k == 'source_id':
                source_id = v['value']
            else:
                # if "'" in v['value']:
                #     logger.error("re implementation!!!")
                #     v['value'] = re.sub("'", "''", v['value'])
                # logger.error("replacement done!!!")
                column_names = column_names + k + ', '
                if v['value']:
                    string = string + "'" + v['value'] + "', "
                else:
                    string += "NULL, "
                if v['priority']:
                    string2 = string2 + "'" + v['priority'] + "', "
                else:
                    string2 += "NULL, "
            # else:
            #     column_names = column_names + k + ', '
            #     if v:
            #         values = values + "'" + v + "', "
            #     else:
            #         values += "NULL, "

        column_names = column_names[:-2]
        # values = values[:-2]
        string = string[:-2]
        string2 = string2[:-2]

        record_id = str(record_id)
        ids_dict = request.session['record_ids']
        try:
            cursor = connection.cursor()
            # cursor.execute("INSERT INTO mdm_golden (" + column_names + ") VALUES (" + string + "); UPDATE partial_ref SET "
            #                 "mdm_id = cast(( currval('mdm_test_seq')) AS bigint), status='12' WHERE ingest_id = '{}' "
            #                 "AND uid = '{}' AND stage_id = '{}'; ".format(ingest_id, uid, record_id))
            # connection.commit()
            logger.error("INSERT INTO "+master_table+" (" + column_names + ") VALUES (" + string + "); "
                            "SELECT currval('{}');".format(master_seq_name))

            cursor.execute("INSERT INTO "+master_table+" (" + column_names + ") VALUES (" + string + "); "
                            "SELECT currval('{}');".format(master_seq_name))
            cursor = connection.cursor()
            cursor.execute("select source_root_id from ingestion_sources where source_name = '{}'"
                           .format(source_name))
            root_source_id = cursor.fetchall()[0][0]
            cursor = connection.cursor()
            cursor.execute("select currval('{}')".format(master_seq_name))
            master_var_id = cursor.fetchall()[0][0]
            logger.error("master_var_id:" +str(master_var_id))
            # cursor = connection.cursor()
            # logger.error("insert into ref_data (reason, ingest_id, source_id, mdm_id,source_name, source_root_id, entity)"
            #                " values ('{}', '{}', '{}', '{}', '{}', '{}','{}' )".format("Insert by steward",
            #                                                                                      request.session.get(
            #                                                                                          'ingest_id', -1),
            #                                                                                      source_id, master_var_id,
            #                                                                                 source_name,root_source_id, entity_name))
            # cursor.execute("insert into ref_data (reason, ingest_id, source_id, mdm_id,source_name, source_root_id, entity)"
            #                " values ('{}', '{}', '{}', '{}', '{}','{}', '{}' )".format("Insert by steward",
            #                                                                                      request.session.get(
            #                                                                                          'ingest_id', -1),
            #                                                                                      source_id, master_var_id,
            #                                                                                 source_name,root_source_id, entity_name))
            # connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        master_id = str(master_var_id)
        try:
            cursor = connection.cursor()
            # cursor.execute("INSERT INTO mdm_golden (" + column_names + ") VALUES (" + values + "); SELECT currval('mdm_golden_mdm_id_seq');")
            logger.error("INSERT INTO "+priority_table+" (mdm_id," + column_names + ") "
                            "VALUES ('"+master_id+"'," + string2 + ") ")
            cursor.execute("INSERT INTO "+priority_table+" (mdm_id," + column_names + ") "
                            "VALUES ('"+master_id+"'," + string2 + ") ")
            logger.error("Master priority update finish!!!!")
            connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        # ingest_id, uid, ingest_source_id, source_name = ids_dict[record_id]
        # for lst in ids_dict.values():
        #     ingest_id, uid, ingest_source_id, source_name = lst
        try:
            for item in ids_dict:
                if item == record_id:
                    for lst in ids_dict.values():
                        ingest_id, uid, ingest_source_id, source_name, matched_mdm_id = lst
                        logger.error('id_dict in steward insert...' + str(ingest_id)+str(source_name)+str(matched_mdm_id))
            cursor = connection.cursor()
            logger.error(
                "insert into ref_data (stage_id, reason, ingest_id, source_id, mdm_id,source_name, source_root_id, entity)"
                " values ('{}', '{}', '{}', '{}', '{}', '{}', '{}','{}' )".format(record_id, "Insert by steward",
                                                                            ingest_id, source_id, master_var_id,
                                                                            source_name, root_source_id,
                                                                            entity_name))
            cursor.execute(
                "insert into ref_data (stage_id, reason, ingest_id, source_id, mdm_id,source_name, source_root_id, entity)"
                " values ('{}', '{}', '{}', '{}', '{}', '{}','{}', '{}' )".format(record_id, "insert by steward",
                                                                            ingest_id, source_id, master_var_id,
                                                                            source_name, root_source_id,
                                                                            entity_name))
            connection.commit()
            cursor = connection.cursor()
            logger.error("delete from partial_ref WHERE ingest_id='{}' AND stage_id='{}' and "
                         "mdm_id = '{}' ".format(ingest_id, record_id, matched_mdm_id))
            cursor.execute("delete from partial_ref WHERE ingest_id='{}' AND stage_id='{}' and "
                           " mdm_id = '{}'".format(ingest_id, record_id, matched_mdm_id))
            connection.commit()
            logger.error('update success in partial_ref after direct record insert')
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()

        # try:
        #     del ids_dict[record_id]
        #     request.session['record_ids'] = ids_dict
        # except Exception as e:
        #     logger.error(str(e))
        #     k = dict()
        #     k['Error'] = str(e).replace("'", '"')
        #     # k = json.dumps(k)
        #     cursor = connection.cursor()
        #     logger.error(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        #     cursor.execute(
        #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
        #             request.session.get('ingest_id', -1),
        #             request.session.get('user_id', -1), json.dumps(k)))
        #     connection.commit()
        return {'ok': 'Success'}

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return {'failure': 'Failure'}

    return {'ok': 'Success'}
