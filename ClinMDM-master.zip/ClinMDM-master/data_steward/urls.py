from django.conf.urls import url, include

from . import views

urlpatterns = [ 
    url(r'^get_ingestions/(?P<page_number>[0-9]+)/$', views.FlowCompletedIngestionList.as_view(), name='get ingestion'),
    url(r'^task_detail/$', views.TaskDetail.as_view(), name='task detail'),
    url(r'^update_mdm/(?P<task_id>[0-9]+)/$', views.UpdateMdmBySteward.as_view(), name='update mdm by steward'),
    url(r'^discard_task/(?P<task_id>[0-9]+)/$', views.DiscardTask.as_view(), name='task discarded'),
    url(r'^insert_mdm/(?P<task_id>[0-9]+)/$', views.InsertMdm.as_view(), name='task discarded'),
]
