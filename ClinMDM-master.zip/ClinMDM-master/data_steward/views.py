from rest_framework.views import APIView
from django.http import JsonResponse
from data_steward.steward import show_task_list_to_steward, show_task_detail, show_flow_completed_ingestion_list_to_steward
from data_steward.steward import update_mdm, discard_task, insert_into_mdm
import logging


logger = logging.getLogger("mdm_logging")


# Create your views here.
class FlowCompletedIngestionList(APIView):
    """

    """
    @staticmethod
    def get(request, page_number):
        """

        :param request:
        :param page_number:
        :return:
        """
        return JsonResponse(show_flow_completed_ingestion_list_to_steward(request, page_number))

    @staticmethod
    def post(request, page_number):
        """

        :param request:
        :param page_number:
        :return:
        """
        return JsonResponse(show_task_list_to_steward(request, page_number))


class TaskDetail(APIView):
    """

    """
    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse(show_task_detail(request))

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})


class UpdateMdmBySteward(APIView):
    """

    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request, task_id):
        """

        :param request:
        :param task_id:
        :return:
        """
        return JsonResponse(update_mdm(request, task_id))


class DiscardTask(APIView):
    """

    """
    @staticmethod
    def get(request, task_id):
        """

        :param request:
        :param task_id:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported ' + str(task_id)})

    @staticmethod
    def post(request, task_id):
        """

        :param request:
        :param task_id:
        :return:
        """
        return JsonResponse(discard_task(request, task_id))


class InsertMdm(APIView):
    """

    """
    @staticmethod
    def get(request, task_id):
        """

        :param request:
        :param task_id:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported ' + str(task_id)})

    @staticmethod
    def post(request, task_id):
        """

        :param request:
        :param task_id:
        :return:
        """
        return JsonResponse(insert_into_mdm(request, task_id))
