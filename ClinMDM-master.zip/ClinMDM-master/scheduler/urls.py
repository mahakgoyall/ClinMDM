from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^schedule/$', views.SaveSchedulerDetails.as_view(), name='Custom source name'),
    url(r'^getScheduleList/$', views.GetSchedulerList.as_view(), name='Schedule name'),

]