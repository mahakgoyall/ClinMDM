import threading
from rest_framework.views import APIView
from django.db import connection
import requests
import json
import logging
from web_curl_service.views import flow_flags
from django.http import JsonResponse
from datetime import datetime
import time
import boto3
import os
import phonenumbers
import requests
import string
import random
import pandas as pd
from validator.column_mapping import business_to_column
from validator.data_validator import data_validation
import psycopg2
from django.conf import settings
from sqlalchemy import create_engine
from xml.etree import ElementTree
from amazons3.views import crawl, make_dict_from_tree
from connections.views import UseExistingFlow
from apscheduler.schedulers.background import BackgroundScheduler, BlockingScheduler
import copy
from pytz import timezone
# import datetime


input_string = 'postgresql://arnav:123456@13.90.80.185/mdm_data'

logger = logging.getLogger("mdm_logging")


def schedule_the_flow(ingest_id, user_id, entity_name, ingest_name):
    try:
        batch_ingest_name = ingest_name + "_" + str(int(time.time()))

        cursor = connection.cursor()
        cursor.execute("INSERT INTO ingestion (uid ,ingest_name , steward_id , username , updated_date,"
                          "data_manager_id ,flow_id ,validation_rules ,matching_rules, entity ,source_root_id, "
                          "matching_rules_score ,schedule_id, schedule_flow_id) SELECT uid ,'{}', steward_id , username "
                          ", updated_date,data_manager_id ,flow_id ,validation_rules ,matching_rules, entity ,source_root_id, "
                          "matching_rules_score ,schedule_id, schedule_flow_id FROM ingestion where ingest_id = '{}'"
                          "".format(batch_ingest_name, ingest_id))
        connection.commit()
        cursor = connection.cursor()
        cursor.execute("SELECT ingest_id FROM ingestion WHERE ingest_name = '{}'".format(batch_ingest_name))
        batch_ingest_id = cursor.fetchall()
        if batch_ingest_id:
            batch_ingest_id = batch_ingest_id[0][0]
        flow_flags(batch_ingest_id, user_id, '1')
        cursor = connection.cursor()
        cursor.execute(
            "SELECT conn_method, conn_string, data_mapping, source_root_id, source_id, header FROM ingestion_sources WHERE "
            "ingest_id = '{}'".format(ingest_id))
        data = cursor.fetchall()
        # connection_method = ''
        # connection_string = ''
        # data_mapping = ''
        # source_root_id = ''
        # source_id = ''
        logger.error(str(data))
        for conn_details in data:
            connection_method = conn_details[0]
            connection_string = conn_details[1]
            data_mapping = conn_details[2]
            source_root_id = conn_details[3]
            source_id = conn_details[4]
            header = conn_details[5]
        conn_string = json.loads(connection_string)
        mapping = data_mapping
        concate_key = mapping.get('concate', '')
        concate_key_copy = concate_key
        substring = mapping.get('substring', '')
        decode = mapping.get('decode', '')
        lower_case = mapping.get('lowercase', '')
        upper_case = mapping.get('uppercase', '')


        if connection_method == 'Amazon_S3_bucket':
            AWS_ACCESS_KEY_ID = conn_string['key_id']
            AWS_SECRET_ACCESS_KEY = conn_string['secret_id']
            conn_method = conn_string['conn_method']
            bucket = conn_string['bucket_name']
            s3_res = boto3.resource('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                    aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
            s3_client = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                     aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
            mybucket = s3_res.Bucket(bucket)
            objs = list()
            files = list()
            for file in mybucket.objects.all():
                name_of_file = file.key
                name_of_file = name_of_file.split('/')[0]
                if file.key == entity_name + '/' or '/'.join(file.key.split('/')[:2]) == entity_name + '/Processed':
                    continue
                if name_of_file == entity_name:
                    # code to download the file
                    logger.error("file name : " + str(file.key))
                    download_filename = '/'.join(file.key.split('/')[1:])
                    download_filename = '.'.join(download_filename.split('.')[:-1])
                    download_filename = download_filename + '_' + str(int(time.time())) + '.xml'
                    s3_client.download_file(bucket, file.key, download_filename)
                    objs.append(file.key)
                    files.append(download_filename)

                    conn_string = str(conn_string).replace("'", '"')
                    try:
                        cursor = connection.cursor()
                        cursor.execute(
                            "INSERT INTO file_source_meta (ingest_id, uid, conn_method, conn_string, source_name,"
                            "source_root_id) values ('{}','{}','{}','{}','{}',"
                            "'{}')".format(batch_ingest_id, user_id, conn_method,
                                           conn_string, download_filename,
                                           source_root_id))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id, user_id, json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id,
                                user_id, json.dumps(k)))
                        connection.commit()
            j = 0
            count = 0
            df = None
            path = os.getcwd()

            def get_main_item_from_nested_dict(d, _path):
                if _path == '':
                    return d
                _path = _path.split('`')
                first, rest = _path[0], '`'.join(_path[1:])
                # logger.error(str(first in d))
                d = d[first]
                return get_main_item_from_nested_dict(d, rest)

            while j < len(files):

                tree = ElementTree.parse(path + '/' + files[j])
                nodes = dict()
                nodes = crawl(tree.getroot(), memo=nodes)
                # logger.error(str(nodes))
                lst_test = [k for k, _ in nodes.items()]
                root = tree.getroot()
                value = make_dict_from_tree(root)
                del tree
                del nodes

                k = get_main_item_from_nested_dict(value, '`'.join(lst_test[0].split('`')[:-1]))

                del value
                del lst_test
                logger.error("working!!")
                time.sleep(3)

                if count == 0:
                    df = pd.DataFrame(k)
                    ls_2 = list(df.columns.values)
                    ls_3 = []
                    for i in ls_2:
                        ls_3.append(i.split('}')[-1])
                    df.columns = ls_3
                    df['source_unique_id'] = files[j]
                    count += 1
                    del ls_2
                else:
                    db = pd.DataFrame(k)
                    ls_2 = list(db.columns.values)
                    ls_3 = []
                    for i in ls_2:
                        ls_3.append(i.split('}')[-1])
                    db.columns = ls_3
                    db['source_unique_id'] = files[j]
                    df = df.append(db)

                j += 1

            if len(files) == 0 or df.empty:
                try:
                    cursor = connection.cursor()
                    cursor.execute(
                        """DELETE FROM ingestion_sources WHERE ingest_id = '{}' AND delete_flag = '0'""".format(
                            batch_ingest_id))
                    connection.commit()
                    # cursor = connection.cursor()
                    # cursor.execute(
                    #     """DELETE FROM ingestion WHERE ingest_id = '{}' """.format(
                    #         batch_ingest_id))
                    # connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            batch_ingest_id, user_id, json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            batch_ingest_id, user_id, json.dumps(k)))
                    connection.commit()
                logger.error("""Delete ingestion sources work well!!!""")
                return JsonResponse({'failure': 'No file in bucket'})

            # conn = psycopg2.connect(dbname=dbname, user=user, host=host, port='5432', password='123456')
            engine = create_engine(input_string)
            df_header = list(df.columns.values)
            # header_list = list()
            # for i in header:
            #     if i not in df_header:
            #         header_list.append(False)
            # if False in header_list:
            #     return {'failure': 'Headers did not match'}
            try:
                logger.error("Inside try")
                if entity_name == 'investigator':
                    logger.error("DF sql is starting")
                    # df.to_csv('testing1.csv', encoding='utf-8')
                    # logger.error("csv created!!")
                    df.to_sql('temp_landing_investigator_' + str(batch_ingest_id), engine, if_exists='append')
                    logger.error("done")
                elif entity_name == 'study':
                    df.to_sql('temp_landing_study_' + str(batch_ingest_id), engine, if_exists='append')
                elif entity_name == 'org':
                    df.to_sql('temp_landing_org_' + str(batch_ingest_id), engine, if_exists='append')
                else:
                    logger.error("Other entity comes so data frame is deleted")
                    del df
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        batch_ingest_id, user_id, json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        batch_ingest_id, user_id, json.dumps(k)))
                connection.commit()
                return JsonResponse({'error in data frame to sql': 'failure'})
            finally:
                del df
                logger.error("data frame is deleted!!")

            for file in objs:
                copy_source = {
                    'Bucket': bucket,
                    'Key': file
                }
                s3_client.copy(copy_source, bucket, entity_name + '/Processed/' + '/'.join(file.split('/')[1:]))
                s3_client.delete_object(Bucket=bucket, Key=file)
            logger.error("Download and move successful")
            flow_flags(batch_ingest_id, user_id, '2')

            try:
                cursor = connection.cursor()
                stage_table = ''
                if entity_name == 'study':
                    table_name = getattr(settings, "STAGE_STUDY", "stage_study")
                    landing_table_name = 'landing_study'
                    temp_landing_table = "temp_landing_study"
                elif entity_name == 'investigator':
                    logger.error("Inside investigator!!!")
                    table_name = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                    temp_landing_table = "temp_landing_investigator"
                    landing_table_name = 'landing_investigator'
                else:
                    table_name = getattr(settings, "STAGE_ORG", "stage_org")
                    temp_landing_table = "temp_landing_org"
                    landing_table_name = 'landing_org'
                # user_id = request.session['user_id']
                # ingest_id = request.session['ingest_id']
                # try:
                #     cursor = connection.cursor()
                #     logger.error("Before query!!")
                #     #TODO need to put if else here
                #     cursor.execute("DELETE FROM \"{}\" WHERE ingest_id='{}' AND uid='{}' AND "
                #                    "ingest_source_id='{}'".format(landing_table_name, ingest_id, user_id, source_id))
                # except Exception as e:
                #     logger.error(str(e))
                #     k = dict()
                #     k['Error'] = str(e).replace("'", '"')
                #     # k = json.dumps(k)
                #     cursor = connection.cursor()
                #     logger.error(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                #             json.dumps(k)))
                #     cursor.execute(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1),
                #             request.session.get('user_id', -1), json.dumps(k)))
                #     connection.commit()
                # try:
                #     cursor = connection.cursor()
                #     logger.error("after query !!!")
                #     cursor.execute("UPDATE ingestion_sources SET status_flag=NULL WHERE "
                #                    "source_id='{}' AND ingest_id = '{}' AND delete_flag='0'".format(source_id, ingest_id))
                # except Exception as e:
                #     logger.error(str(e))
                #     k = dict()
                #     k['Error'] = str(e).replace("'", '"')
                #     # k = json.dumps(k)
                #     cursor = connection.cursor()
                #     logger.error(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                #             json.dumps(k)))
                #     cursor.execute(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1),
                #             request.session.get('user_id', -1), json.dumps(k)))
                #     connection.commit()
                # logger.error("after update query!!")

                # TODO REMOVE static path of csv file and write this "request.session['file']"
                to_columns = ''
                # if entity_name == 'org':
                #     for key, value in mapping
                logger.error("mapping   :  " + str(mapping))
                for name in mapping.values():
                    # logger.error("inside mapping.values,name: "+ str(name))
                    if entity_name == 'study':
                        to_columns = to_columns + settings.STUDY_COLUMN_DICT[name.upper()] + ', '
                    elif entity_name == 'investigator':
                        to_columns = to_columns + settings.COLUMN_DICT[name.upper()] + ', '
                    else:
                        to_columns = to_columns + settings.ORG_COLUMN_DICT[name.upper()] + ', '
                # logger.error("to_column before -2 : " + str(to_columns))
                to_columns = to_columns[:-2]
                logger.error("to_column: " + str(to_columns))
                # from_columns = ', '.join(mapping.keys())
                from_columns = ''
                for k in mapping.keys():
                    from_columns = from_columns + '"' + str(k) + '", '
                from_columns = from_columns[:-2]

                # logger.error("from_column: " + str(from_columns))
                # try:
                #     cursor = connection.cursor()
                #     logger.error("Select query !!!!")
                #     cursor.execute("SELECT source_root_id from admin_sources where "
                #                    "source_root_name = '{}'".format(roo))
                # except Exception as e:
                #     logger.error(str(e))
                #     k = dict()
                #     k['Error'] = str(e).replace("'", '"')
                #     # k = json.dumps(k)
                #     cursor = connection.cursor()
                #     logger.error(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                #             json.dumps(k)))
                #     cursor.execute(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1),
                #             request.session.get('user_id', -1), json.dumps(k)))
                #     connection.commit()
                # logger.error("after select query !!!!!")

                if len(concate_key) == 0:
                     logger.error("no data for concat comes!!!")
                else:
                    try:
                        target_column_key = concate_key.keys()
                        target_column_key = list(target_column_key)
                        target_column_key_temp = list()
                        for h in target_column_key:
                            # logger.error("h is: " + str(h))
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))
                            else:
                                name = settings.ORG_COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))

                        target_column_key = target_column_key_temp
                        # logger.error("target column key : " + str(target_column_key))
                        source_column_values = concate_key.values()
                        source_column_values = list(source_column_values)
                        source_column_values_copy = copy.deepcopy(source_column_values)

                        for k, v in enumerate(concate_key_copy):
                            source_column_values_copy[k].append(v)

                        # logger.error("HERE source value" + str(source_column_values))
                        cate_string = 'concat'
                        list_of_target_column = []
                        for i in source_column_values:
                            cate_string = cate_string + '(' + ", ".join(['"' + foo + '"' for foo in i]) + ')'
                            list_of_target_column.append(cate_string)
                            cate_string = 'concat'

                        # uncomment below 5 lines and comment above 6 lines
                        # list_of_target_column_seperator = list()
                        # assert(len(seperator) == len(source_column_values))
                        # for names, sep in zip(source_column_values, seperator):
                        #     stri = 'concat(' + names[0] + ', ' + sep + ', ' + names[1] + ')'
                        #     list_of_target_column_seperator.append(stri)

                        # logger.error("list of target column for concat: " + str(list_of_target_column))
                        # logger.error("list of target column list : " + str(list_of_target_column_seperator))
                        my_string = ", ".join(list_of_target_column)
                        #remove above line of code and uncomment below line
                        # my_string = ", ".join(list_of_target_column_seperator)
                        logger.error("MY STRING   :  "  + str(my_string))
                        from_columns += ', ' + my_string
                        # logger.error("from_column after concat: " + str(from_columns))
                        add_to_target_string = ", ".join(target_column_key)
                        to_columns += ', ' + add_to_target_string
                        logger.error("done!!!!! concat work")
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id, user_id,
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id,
                                user_id, json.dumps(k)))
                        connection.commit()
                        logger.error("Failure in concat!!!!!!!!!!")

                if len(substring) == 0:
                    logger.error("No data for substring!!!")
                else:
                    try:

                        f_string_for_substring_target = ''
                        substring_column_list, substring_target_list = list(), list()
                        logger.error("SUBSTRING  =  " + str(substring))
                        for i in substring:
                            final_string_for_substring = 'substring'
                            s_name = i['source_name']
                            pos = i['position']
                            len_sub = i['length']
                            targ = i['target_name']
                            final_string_for_substring += '("' + s_name + '", ' + str(pos) + ', ' + \
                                                          str(len_sub) + ')'
                            logger.error("final_string_for_substring: " + final_string_for_substring)
                            substring_column_list.append(final_string_for_substring)
                            # logger.error("substring column list: " + str(substring_column_list))
                            # final_string_for_substring = 'substring'
                            f_string_for_substring_target += targ.lower()
                            # logger.error("f_string_for_substring_target: " + f_string_for_substring_target)
                            substring_target_list.append(f_string_for_substring_target)
                            # logger.error("substring_target_list: " + str(substring_target_list))
                            f_string_for_substring_target = ''

                        logger.error("substring_column_list after loop: " + str(substring_column_list))
                        # ['substring(s_name, 15, 70)', 'substring(s_name_1, 16, 98)']
                        # logger.error("substring_target_list after loop: " + str(substring_target_list))
                        # ['t_name', 't_name_1']
                        new_string = ', '.join(substring_column_list)
                        from_columns += ', ' + new_string
                        # logger.error("from_column after substring: " + from_columns)

                        substring_target_list_temp = list()
                        for h in substring_target_list:
                            # logger.error("h is in substring: " + str(h))
                            # logger.error(str(mapping))
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[h.upper()].lower()
                                # logger.error("name in substring for study: " + str(name))
                                substring_target_list_temp.append(name)
                                # logger.error("hhh in substring for study: " + str(substring_target_list_temp))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[h.upper()].lower()
                                # logger.error("name in substring for inv: " + str(name))
                                substring_target_list_temp.append(name)
                                # logger.error("hhh in substring for inv: " + str(substring_target_list_temp))

                            else:
                                name = settings.ORG_COLUMN_DICT[h.upper()].lower()
                                # logger.error("name in substring for org: " + str(name))
                                substring_target_list_temp.append(name)
                                # logger.error("hhh in substring for org:" + str(substring_target_list_temp))

                        substring_target_list = substring_target_list_temp
                        # logger.error("substring target list after loop: " + str(substring_target_list))
                        new_string_target = ', '.join(substring_target_list)
                        to_columns += ', ' + new_string_target
                        # logger.error("to_column after substring: " + to_columns)
                        # logger.error("Substring done!!!!!!!!!!!!")
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id, user_id,
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id,
                                user_id, json.dumps(k)))
                        connection.commit()
                        logger.error("Failure in substring!!!!")
                if len(upper_case) == 0:
                    logger.error("Upper case length is zero.")
                else:
                    logger.error("uppercase :  " + str(upper_case))
                    final_string = ''
                    target_column_list = list()
                    for key, value in upper_case.items():
                        final_string += 'UPPER("' + str(key) + '")' + " , "
                        if entity_name == 'study':
                            name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                        elif entity_name == 'investigator':
                            name = settings.COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                        else:
                            name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                    logger.error(str(final_string))
                    logger.error(str(target_column_list))
                    from_columns += ", " + final_string[:-2]
                    if len(target_column_list) == 1:
                        to_columns += ", " + target_column_list[0]
                    else:
                        to_columns += ', '.join(target_column_list)
                if len(lower_case) == 0:
                    logger.error("Lower case length is zero.")
                else:
                    logger.error("lowercase :  " + str(lower_case))

                    final_string = ''
                    target_column_list = list()
                    for key, value in lower_case.items():
                        final_string += 'LOWER("' + str(key) + '")' + " , "
                        if entity_name == 'study':
                            name = settings.STUDY_COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                        elif entity_name == 'investigator':
                            name = settings.COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                        else:
                            name = settings.ORG_COLUMN_DICT[value.upper()].lower()
                            target_column_list.append(str(name))
                    logger.error(str(final_string))
                    logger.error(str(target_column_list))
                    from_columns += ", " + final_string[:-2]
                    if len(target_column_list) == 1:
                        to_columns += ", " + target_column_list[0]
                    else:
                        to_columns += ', '.join(target_column_list)
                if len(decode) == 0:
                    logger.error("Decode length is zero")
                else:
                    try:
                        final_string = 'case '
                        target_column_list = list()

                        # For each dict in decode list
                        for d in decode:
                            source_name = d['source_name']
                            final_string = final_string + 'when "' + source_name + '" = '

                            # Iterate over all the items, do nothing if this is source or target else
                            # do string manipulation
                            for k, v in d.items():
                                if k == 'source_name':
                                    continue
                                elif k == 'target_name':
                                    target_column_list.append(v)
                                else:
                                    final_string = final_string + "'" + k + "' then '" + v + "' when " + \
                                                   source_name + ' = '
                            final_string = final_string.split(' when ')[:-1]
                            final_string = ' when '.join(final_string)
                            final_string = final_string + ' else "' + source_name + '" end, case '
                        final_string = final_string[:-7]
                        target_column_key_temp = list()
                        for h in target_column_list:
                            # logger.error("h is: " + str(h))
                            if entity_name == 'study':
                                name = settings.STUDY_COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))
                            elif entity_name == 'investigator':
                                name = settings.COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))
                            else:
                                name = settings.ORG_COLUMN_DICT[h].lower()
                                # logger.error("name is" + str(name))
                                target_column_key_temp.append(name)
                                # logger.error("hhh: " + str(target_column_key_temp))

                        # Join all target list
                        target_column_key_temp = ','.join(target_column_key_temp)
                        # logger.error("Final String: " + str(final_string))
                        logger.error("target column list: " + str(target_column_key_temp))
                        from_columns += ', ' + final_string
                        # logger.error("from column after decode : " + from_columns)
                        to_columns += ', ' + target_column_key_temp
                        # logger.error("to_columns after decode: " + to_columns)
                        # logger.error("Decode completed !!!!!!!!!")
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id, user_id,
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                batch_ingest_id,
                                user_id, json.dumps(k)))
                        connection.commit()
                        logger.error("Failure in Decode")

                # staging_table = ''
                # where_string = ''
                # if entity_name == 'study':
                #     staging_table = 'stage_study'
                # elif entity_name == 'investigator':
                #     staging_table = 'stage_investigator'
                #
                # else:
                #     staging_table = 'stage_org'
                #     if 'org_type' not in to_columns:
                #         to_columns += ', org_type'
                #         from_columns += " ,'" + str(entity_name) +"'"
                #     else:
                #         if entity_name == 'site':
                #             where_string = "WHERE {} = 'site' ".format(org_column_form_port[0])
                #         elif entity_name == 'sponsor':
                #             where_string = "WHERE {} 'sponsor' ".format(org_column_form_port[0])
                #         else:
                #             where_string = """WHERE {} IN  ('site','sponsor') """.format(org_column_form_port[0])

                # cursor.execute("""DROP TABLE "{}_{}" """.format(temp_landing_table, ingest_id))

                # logger.error("To COLUMNS  :  " + str(to_columns))
                # logger.error("from COLUMNS  :  " + str(from_columns))
                #
                # logger.error("entity_name = " + str(entity_name))
                #
                # mapping_ = dict()
                # for k, v in mapping.items():
                #     mapping_[k.upper()] = v
                # logger.error("MAPPING UNDERSCORE  :  " + str(mapping_))
                #
                # if concate_key:
                #     # logger.error("concate : " + str(data['concate']))
                #     logger.error("concate key : " + str(concate_key))
                #     mapping_['concate'] = concate_key
                # if substring:
                #     mapping_['substring'] = substring
                # if decode:
                #     mapping_['decode'] = decode
                # if lower_case:
                #     mapping_['lowercase'] = lower_case
                # if upper_case:
                #     mapping_['uppercase'] = upper_case
                #
                # logger.error("Mapping underscroe   :  " + str(mapping_))
                # try:
                #     cursor = connection.cursor()
                #     cursor.execute(
                #         "UPDATE ingestion_sources SET data_mapping ='{}', status_flag = '3' WHERE source_id='{}'".format(
                #             json.dumps(mapping_), source_id))
                # except Exception as e:
                #     logger.error(str(e))
                #     k = dict()
                #     k['Error'] = str(e).replace("'", '"')
                #     # k = json.dumps(k)
                #     cursor = connection.cursor()
                #     logger.error(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                #             json.dumps(k)))
                #     cursor.execute(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             request.session.get('ingest_id', -1),
                #             request.session.get('user_id', -1), json.dumps(k)))
                #     connection.commit()
                try:
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO "{}" (ingest_id, uid, ingest_source_id, source_root_id, {})
                             SELECT '{}','{}','{}','{}',{} FROM "{}_{}" """.format(landing_table_name, to_columns,
                                                                                   batch_ingest_id, user_id, source_id,
                                                                                   source_root_id,
                                                                                   from_columns, temp_landing_table,
                                                                                   batch_ingest_id))
                    cursor.execute(
                        """INSERT INTO "{}" (ingest_id, uid, ingest_source_id, source_root_id, {})
                             SELECT '{}','{}','{}','{}',{} FROM "{}_{}" """.format(landing_table_name,to_columns,
                                                                                   batch_ingest_id, user_id, source_id,
                                                                                   source_root_id,
                                                                                   from_columns,
                                                                                   temp_landing_table,
                                                                                   batch_ingest_id))
                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            batch_ingest_id, user_id,
                            json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            batch_ingest_id,
                            user_id, json.dumps(k)))
                    connection.commit()
                    return {'failure': 'Error in inserting from temp landing to landing table.'}
                logger.error("after the insert query !!!!!!")
                # try:
                #     cursor = connection.cursor()
                #     cursor.execute(
                #         "UPDATE admin_sources SET data_mapping ='{}' WHERE source_root_id='{}'".format(
                #             json.dumps(mapping), source_root_id))
                # except Exception as e:
                #     logger.error(str(e))
                #     k = dict()
                #     k['Error'] = str(e).replace("'", '"')
                #     # k = json.dumps(k)
                #     cursor = connection.cursor()
                #     logger.error(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             batch_ingest_id, user_id,
                #             json.dumps(k)))
                #     cursor.execute(
                #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                #             batch_ingest_id,
                #             user_id, json.dumps(k)))
                #     connection.commit()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        batch_ingest_id, user_id,
                        json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        batch_ingest_id,
                        user_id, json.dumps(k)))
                connection.commit()
                return JsonResponse({'failure': 'FaILUre'})
            # try:
            #     cursor = connection.cursor()
            #     cursor.execute("select count(*) from {} where ingest_id = '{}'"
            #                    .format(landing_table_name, ingest_id))
            #     count_landing = cursor.fetchall()
            #
            # except Exception as e:
            #     logger.error(str(e))
            #     k = dict()
            #     k['Error'] = str(e).replace("'", '"')
            #     # k = json.dumps(k)
            #     cursor = connection.cursor()
            #     logger.error(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1), request.session.get('user_id', -1),
            #             json.dumps(k)))
            #     cursor.execute(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1),
            #             request.session.get('user_id', -1), json.dumps(k)))
            #     connection.commit()
            # return JsonResponse({'ok': count_landing[0][0]})
            length = 12
            chars = string.ascii_letters + string.digits + '!@#$%^&*()'
            random.seed = (os.urandom(1024))
            source_id = ''.join(random.choice(chars) for _ in range(length))
            cursor = connection.cursor()
            cursor.execute("INSERT INTO ingestion_sources (source_id, ingest_id, uid, conn_method, conn_string, data_mapping,"
                           " status_flag, source_name, header, updated_by, updated_date, delete_flag,"
                           " source_priority, source_root_id) SELECT '{}', '{}', uid, conn_method, conn_string, data_mapping,"
                           " status_flag, source_name, header, updated_by, updated_date, delete_flag,"
                           " source_priority, source_root_id FROM ingestion_sources WHERE ingest_id = '{}'".format(source_id, batch_ingest_id, ingest_id))
            connection.commit()
            flow_flags(batch_ingest_id, user_id, '3', table_name='ingestion_sources')
            flow_flags(batch_ingest_id, user_id, '4')


        elif connection_method == 'db connection':
            dbname = conn_string['database_name']
            port = conn_string['port']
            host = conn_string['host_name']
            user = conn_string['username']
            password = conn_string['password']
            db_table = conn_string['table_name']
            # conn = psycopg2.connect(dbname=dbname, user=user, host=host,
            #                         password=password, port=port)
            column_type = dict()

            try:
                conn = psycopg2.connect(dbname=dbname, user=user, host=host, password=password, port=port)
                cursor = conn.cursor()
                cursor.execute("SELECT column_name, data_type FROM information_schema.columns where "
                               "table_name  = '{}' ORDER  BY ordinal_position ".format(db_table))
            except Exception as e:
                logger.error("Table not found in database")
                logger.error(str(e))
                return JsonResponse({'error': 'Table not found '})
            else:
                columns = cursor.fetchall()
                for column in columns:
                    column_type[column[0]] = column[1]
            cursor = connection.cursor()
            cursor.execute("SELECT last_load_date from admin_sources"
                           " where source_root_id = '{}'".format(source_root_id))
            last_load_date = cursor.fetchall()[0][0]

            if entity_name == 'study':
                rev_dict = settings.STUDY_COLUMN_DICT
                landing_table_name = 'landing_study'
            elif entity_name == 'investigator':
                rev_dict = settings.COLUMN_DICT
                landing_table_name = 'landing_investigator'
            else:
                rev_dict = settings.ORG_COLUMN_DICT
                landing_table_name = 'landing_org'

                string1_without_x = ''
                string1 = ''
                string2 = ''
                string3 = ''
                string4 = ''
            logger.error(str(data_mapping))
            for key, value in mapping.items():
                if not last_load_date:
                    string4 = ''
                    logger.error(str(type(last_load_date)))
                    string4 += " WHERE last_updated_date  >  cast(quote_literal(''" + str(
                        last_load_date) + "'') as date)"
                string1_without_x += '"' + str(key) + '", '
                string1 += 'x.' + str(key) + ', '
                string2 += str(rev_dict[value]) + ', '
                string3 += str(value) + " " + str(column_type[key]) + ', '
            logger.error("string1_without_x : " + str(string1_without_x))
            logger.error("string 1  :  " + str(string1[:-2]))
            logger.error("string 2  :  " + str(string2[:-2]))
            logger.error("string 3  :  " + str(string3[:-2]))
            logger.error("SELECT x.last_date FROM dblink('dbname = {} port = {} host = {} "
                         "user = {} password = {}', 'select max(last_updated_date)  "
                         "from {}.public.{} ') AS x(last_date date)".format(dbname, port, host,
                                                                            user, password, dbname,
                                                                            db_table))

            cursor = connection.cursor()
            cursor.execute("SELECT x.last_date FROM dblink('dbname = {} port = {} host = {} "
                           "user = {} password = {}', 'select max(last_updated_date)  "
                           "from {}.public.{} ') AS x(last_date date)".format(dbname, port, host,
                                                                              user, password, dbname, db_table))

            max_update_date_from_source = cursor.fetchall()[0][0]
            logger.error(str(max_update_date_from_source))
            # logger.error("max_update_date_from_source: ", str(max_update_date_from_source))
            cursor = connection.cursor()
            logger.error("INSERT INTO \"{}\" ({}) SELECT {} FROM dblink(\'dbname ={} port = {} host = {} "
                         "user = {} password = {}\', \'select {} from {}.public.{} {}\') "
                         "AS x({})".format(landing_table_name,
                                           string2[:-2] + ", ingest_source_id , ingest_id, uid ",
                                           string1[:-2] + ", '{}','{}','{}' ".format(source_id,
                                                                                     ingest_id,
                                                                                     user_id),
                                           dbname, port, host, user, password, string1_without_x[:-2], dbname,
                                           db_table, string4, string3[:-2]))
            cursor.execute("INSERT INTO \"{}\" ({}) SELECT {} FROM dblink(\'dbname ={} port = {} host = {} "
                           "user = {} password = {}\', \'select {} from {}.public.{} {}\') "
                           "AS x({})".format(landing_table_name, string2[:-2] + ", ingest_source_id , ingest_id, uid ",
                                             string1[:-2] + ", '{}','{}','{}' ".format(source_id,
                                                                                       ingest_id,
                                                                                       user_id),
                                             dbname, port, host, user, password, string1_without_x[:-2], dbname,
                                             db_table, string4, string3[:-2]))
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO ingestion_sources (source_id, ingest_id, uid, conn_method, conn_string, data_mapping,"
                " status_flag, source_name, header, updated_by, updated_date, delete_flag,"
                " source_priority, source_root_id) SELECT source_id, '{}', uid, conn_method, conn_string, data_mapping,"
                " status_flag, source_name, header, updated_by, updated_date, delete_flag,"
                " source_priority, source_root_id FROM ingestion_sources WHERE ingest_id = '{}'".format(batch_ingest_id,
                                                                                                        ingest_id))
            connection.commit()
            flow_flags(batch_ingest_id, user_id, '2')

        logger.error("")
        cursor = connection.cursor()
        cursor.execute(
            "SELECT value, flow_name, username, flow_id, access_type from flow where uid = '{}' and ingest_id = '{}'"
            " and key = 'validation' ".format(user_id, ingest_id))
        data = cursor.fetchall()
        validation_rules = data[0][0]
        flow_name = data[0][1]
        username = data[0][2]
        flow_id = data[0][3]
        scope = data[0][4]
        cursor = connection.cursor()
        cursor.execute(
            "SELECT ingest_name, steward_id from ingestion where ingest_id = '{}' and uid= '{}'".format(ingest_id,
                                                                                                        user_id))
        ingestion_data = cursor.fetchall()
        ingest_name = ingestion_data[0][0]
        steward_id = ingestion_data[0][1]

        UseExistingFlow.post(entity_name=entity_name, flow_id=flow_id, flow_name=flow_name, username=username,
                             ingest_id=ingest_id,
                             ingest_name=ingest_name, user_id=user_id, root_source_id=source_root_id, flow_scope=scope,
                             steward_id=steward_id, scheduler_flag=True, schedule_ingest_id=batch_ingest_id)
        return JsonResponse({'ok': 'Success'})
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'Failure'})


def schedule_param(schedule_details):
    param = dict()
    if schedule_details['frequency'] == 'Hourly':
        param['hours'] = schedule_details.get('hours', 0)
        param['minutes'] = schedule_details.get('minutes', 0)
        param['scheduler'] = 'interval'
        param['start_date'] = schedule_details.get('start_date', None)
        param['end_date'] = schedule_details.get('end_date', None)
    elif schedule_details['frequency'] == 'Daily':
        param['day'] = '1-31'
        param['hour'] = schedule_details.get('hours', None)
        param['minute'] = schedule_details.get('minutes', None)
        param['scheduler'] = 'cron'
        param['start_date'] = schedule_details.get('start_date', None)
        param['end_date'] = schedule_details.get('end_date', None)
    elif schedule_details['frequency'] == 'Weekly':
        days = schedule_details.get('time', None)
        param['day_of_week'] = "-".join(days)
        param['scheduler'] = 'cron'
        param['hour'] = schedule_details.get('hours', None)
        param['minute'] = schedule_details.get('minutes', None)
        param['start_date'] = schedule_details.get('start_date', None)
        param['end_date'] = schedule_details.get('end_date', None)
    else:
        time = schedule_details.get('time')
        if type(time) == int:
            param['month'] = '1-12'
            param['scheduler'] = 'cron'
            param['day'] = schedule_details.get('time', None)
            param['start_date'] = schedule_details.get('start_date', None)
            param['end_date'] = schedule_details.get('end_date', None)
        else:
            param['scheduler'] = 'cron'
            if time[0] == 'First':
                param['day'] = '1st ' + str(time[1]).lower()
            elif time[0] == 'Second':
                param['day'] = '2nd ' + str(time[1]).lower()
            elif time[0] == 'Third':
                param['day'] = '3rd ' + str(time[1]).lower()
            else:
                param['day'] = '4th ' + str(time[1]).lower()
    return param


class SaveSchedulerDetails(APIView):

    @staticmethod
    def post(request):
        """
        This function will check if the ingestion has run completely once, and the it will start running everyday
        as per the time decided by the user.
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            scheduler_details = {
                'name': data.get('name', ''),
                'start_date': data.get('start_date', '*'),
                'end_date': data.get('end_date', '*'),
                'frequency': data.get('frequency', None),
                'time': data.get('time', None),
                'ingestions': data.get('ingestions', None),
                'hours': data.get('hour', None),
                'minutes': data.get('minutes', None)
            }
            logger.error("Scheduler details  :  " + str(scheduler_details))
            ingestion_data = scheduler_details['ingestions']
            if not (scheduler_details['name'] or scheduler_details['start_date'] or scheduler_details['frequency']
                    or scheduler_details['ingestions']):
                return JsonResponse({'failure': 'Enter all mandatory fields.'})
            check_ingestion_completion = list()
            ingestion_status = dict()
            for i in ingestion_data:
                cursor = connection.cursor()
                cursor.execute("SELECT status_flag from ingestion where ingest_name = '{}'".format(i))
                data = cursor.fetchall()
                if data:
                    logger.error("status flag  : " + str(data))
                    if not str(data[0][0]) == '7':
                        check_ingestion_completion.append(False)
                        ingestion_status[i] = data[0][0]
                    else:
                        check_ingestion_completion.append(True)
            if False in check_ingestion_completion:
                return JsonResponse({'failure': ingestion_status})

            # parsed_schedule_dict = schedule_param(scheduler_details)
            # return JsonResponse({'scheduler_details': scheduler_details, 'parsed_scheduler_details': parsed_schedule_dict})
            length = 12
            chars = string.ascii_letters + string.digits + '!@#$%^&*()'
            random.seed = (os.urandom(1024))
            scheduler_id = ''.join(random.choice(chars) for _ in range(length))
            # t = time.localtime()
            # timestamp = time.strftime('%b-%d-%Y-%H%M', t)
            cursor = connection.cursor()
            logger.error("INSERT INTO schedule(schedule_id, schedule_details, schedule_name) VALUES ('{}', '{}', '{}')".format(
                scheduler_id, json.dumps(scheduler_details), scheduler_details.get('name')))
            cursor.execute("INSERT INTO schedule(schedule_id, schedule_details, schedule_name) VALUES ('{}', '{}', '{}')".format(
                scheduler_id, json.dumps(scheduler_details), scheduler_details.get('name')))
            connection.commit()

            for index, ingestion in enumerate(ingestion_data):
                args_dict = dict()
                length = 12
                chars = string.ascii_letters + string.digits + '!@#$%^&*()'
                random.seed = (os.urandom(1024))
                each_scheduler_id = ''.join(random.choice(chars) for _ in range(length))
                cursor = connection.cursor()
                logger.error("UPDATE ingestion SET schedule_id = '{}', schedule_flow_id = '{}', base_ingest_flag = 'base' where ingest_name ="
                               "'{}'".format(scheduler_id, each_scheduler_id, str(ingestion)))
                cursor.execute("UPDATE ingestion SET schedule_id = '{}', schedule_flow_id = '{}', base_ingest_flag = 'base' where ingest_name ="
                               " '{}'".format(scheduler_id, each_scheduler_id, str(ingestion)))
                connection.commit()
                cursor = connection.cursor()
                logger.error("SELECT ingest_id, uid, entity from ingestion where ingest_name = '{}'".format(ingestion))
                cursor.execute("SELECT ingest_id, uid, entity from ingestion where ingest_name = '{}'".format(ingestion))
                data = cursor.fetchall()
                logger.error(str(data))
                args_dict['scheduler_id'] = each_scheduler_id
                args_dict['scheduler_details'] = schedule_param(scheduler_details)
                args_dict['ingest_name'] = str(ingestion)
                args_dict['ingest_id'] = data[0][0]
                args_dict['user_id'] = data[0][1]
                args_dict['entity_name'] = data[0][2]
                create_thread(schedule, schedule_the_flow, args_dict)
            return JsonResponse({'Success': 'ok'})
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'Error in scheduling job.'})


def create_thread(factory, func, args_dict):
    t = threading.Thread(target=factory, args=(func, args_dict))
    t.start()
    return


# def schedule(func, scheduler_id, year=None, month=None, day=None, week=None, day_of_week=None, hour=None,
#               minute=None, second=None, start_date=None, end_date=None, timezone=None):
def schedule(func, args_dict):
    scheduler_id = args_dict.get('scheduler_id', None)
    scheduler_dict = args_dict.get('scheduler_details', None)
    year = scheduler_dict.get('year', None)
    month = scheduler_dict.get('month', None)
    day = scheduler_dict.get('day', None)
    scheduler_to_use = scheduler_dict.get('scheduler', None)
    day_of_week = scheduler_dict.get('day_of_week', None)
    hour = scheduler_dict.get('hours', None)
    minute = scheduler_dict.get('minutes', None)
    # second = args_dict.get('second', None)
    start_date = args_dict.get('start_date', None)
    end_date = args_dict.get('end_date', None)
    # timezone = args_dict.get('timezone', None)
    ingest_id = args_dict.get('ingest_id', None)
    user_id = args_dict.get('user_id', None)
    entity_name = args_dict.get('entity_name', None)
    ingest_name = args_dict.get('ingest_name', None)


    scheduler = BlockingScheduler()
    try:
        if scheduler_to_use == 'interval':
            scheduler.add_job(func, 'interval', id=scheduler_id,
                              hours=hour, minutes=minute, start_date=start_date,
                              end_date=end_date, args=(ingest_id, user_id, entity_name, ingest_name))
            scheduler.start()
        else:
            scheduler.add_job(func, 'cron', id=scheduler_id, year=year, month=month, day=day,
                              day_of_week=day_of_week, hour=hour, minute=minute, start_date=start_date,
                              end_date=end_date, timezone=timezone, args=(ingest_id, user_id, entity_name, ingest_name))
        # scheduler.add_job(func, 'interval', id=scheduler_id, minutes=minute, start_date=start_date,
        #                   end_date=end_date, args=(ingest_id, user_id, entity_name, ingest_name))
        # scheduler.start()
    except Exception as e:
        logger.error(str(e))
    return JsonResponse({'Failure': 'Error in scheduling job.'})

class GetSchedulerList(APIView):
    @staticmethod
    def get(request):
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT  i.ingest_name, s.schedule_details, s.schedule_name, s.created_date from schedule "
                           " as s JOIN ingestion as i on s.schedule_id = i.schedule_id WHERE i.base_ingest_flag = 'base' "
                           " AND i.delete_flag != '1'")
            # cursor.execute("SELECT ingest_name, schedule_id FROM ingestion WHERE base_ingest_flag = 'base' and delete_flag != '1'")
            data = cursor.fetchall()
            logger.error("scheduler details  :  " + str(data))
            listo = list()
            if data:
                for details in data:
                    ui_response = dict()
                    # ui_response['ingest_id'] = details[0]
                    ui_response['ingest_name'] = details[0]

                    ui_response['schedule_details'] = details[1]
                    ui_response['schedule_name'] = details[2]
                    ui_response['created_date'] = details[3]
                    listo.append(ui_response)
                return JsonResponse({'ui_info': listo})
            else:
                return JsonResponse({'failure': 'No details to show.'})

        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'No details to show.'})

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_name = data.get('ingest_name')
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'No ingestion selected.'})
        if ingest_name:
            cursor = connection.cursor()
            cursor.execute("SELECT ingest_id, ingest_name, username, status_flag from ingestion WHERE schedule_flow_id = "
                           "(SELECT schedule_flow_id FROM ingestion where ingest_name = '{}')".format(str(ingest_name)))
            data = cursor.fetchall()
            logger.error(str(data))
            if data:
                listo = list()
                for details in data:
                    ui_info = dict()
                    ui_info['ingest_id'] = details[0]
                    ui_info['ingest_name'] = details[1]
                    cursor = connection.cursor()
                    cursor.execute("SELECT source_id from ingestion_sources where ingest_id = '{}'".format(details[0]))
                    data = cursor.fetchall()
                    if data:
                        ui_info['source_id'] = data[0][0]
                    ui_info['username'] = details[2]
                    ui_info['status'] = details[3]
                    listo.append(ui_info)
                return  JsonResponse({'ui_info': listo})
            else:
                return JsonResponse({'failure': 'Error in fetching ingestion details.'})
        else:
            return JsonResponse({'failure': 'No ingestion selected.'})
