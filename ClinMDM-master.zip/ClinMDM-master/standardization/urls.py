from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^data_standardization/$', views.Standardization.as_view(), name='data standardization'),
    url(r'error_logging/(?P<page_number>[0-9]+)/$', views.ErrorLogging.as_view(), name= 'error_logging get call'),
    url(r'error_logging/$', views.ErrorLogging.as_view(), name= 'error_logging post'),
]