from django.apps import AppConfig


class StandardizationConfig(AppConfig):
    name = 'standardization'
