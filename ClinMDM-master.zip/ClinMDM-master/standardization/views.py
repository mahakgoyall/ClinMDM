from rest_framework.views import APIView
from django.http import JsonResponse
from django.db import connection
from django.conf import settings
import logging
import psycopg2.extras
import phonenumbers
import requests
import json
import re

logger = logging.getLogger("mdm_logging")


class Standardization(APIView):
    """
    
    """
    @staticmethod
    def get(request=None, ingest_id=None, entity_name=None, schedule_ingest_id=None):
        """

        :param request:
        :return:
        """
        try:
            # ingest_id = '794'
            # entity_name = 'investigator'
            if request:
                ingest_id = request.session.get('ingest_id', False)
                entity_name = request.META['HTTP_ENTITY']
                logger.error("entity name in standard: " + str(entity_name))
                logger.error("ingest_id: " + str(ingest_id))
            if schedule_ingest_id:
                ingest_id = schedule_ingest_id
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Failure in Standardization get'})
        if not ingest_id:
            return JsonResponse({'failure': 'No ingest id found.'})

        try:
            if entity_name == 'study':
                logger.error("Inside the data standardization of entity study")
                stage_table_name = getattr(settings, "STAGE_STUDY", "stage_study")
                landing_table_name = 'landing_study'
                temp_landing_table = "temp_landing_study"
            elif entity_name == 'investigator':
                logger.error("Inside the data standardization of entity investigator")
                stage_table_name = getattr(settings, "STAGE_INVESTIGATOR", "stage_investigator")
                logger.error("Stage_table_name: " + str(stage_table_name))
                temp_landing_table = "temp_landing_investigator"
                landing_table_name = 'landing_investigator'
            elif entity_name == 'org':
                logger.error("Inside the data standardization of entity Org")
                stage_table_name = getattr(settings, "STAGE_ORG", "stage_org")
                temp_landing_table = "temp_landing_org"
                landing_table_name = 'landing_org'
            else:
                logger.error("Inside the data standardization in the else part!!!")
                return JsonResponse({'In the else loop': 'No entity found!!'})
            try:
                cursor = connection.cursor()
                cursor.execute("""SELECT column_name, data_type FROM information_schema.columns WHERE TABLE_NAME = '{}'""".format(stage_table_name))
                logger.error("After the select Query in data standardization!!")
                data = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            data = data[1:-5]
            temp_data = list()
            for tup in data:
                if tup[1] == 'bigint' or tup[1] == 'date':
                    continue
                temp_data.append(tup[0])

            data, temp_data = temp_data, data
            # 'primary_mobile_num', 'country', 'gender', 'state'

            static_list = ['primary_mobile_num', 'country', 'gender', 'state']
            shuffler = list()

            # if 'primary_mobile_num' in data:
            #     data.remove('primary_mobile_num')
            #     data += ['primary_mobile_num']
            # if 'country' in data:
            #     data.remove('country')
            #     data += ['country']
            # if 'gender' in data:
            #     data.remove('gender')
            #     data += ['gender']
            # if 'state' in data:
            #     data.remove('state')
            #     data += ['state']
            # logger.error("Final data is: " + str(data))

            schema_string = ''
            schema_string_v2 = ''
            for c in temp_data:
                if c[0] in static_list:
                    shuffler.append(c[0])
                else:
                    schema_string = schema_string + '"' + str(c[0]) + '", '
                    schema_string_v2 = schema_string_v2 + 'A."' + str(c[0]) + '", '

            for item in shuffler:
                schema_string = schema_string + '"' + str(item) + '", '
                if item == 'primary_mobile_num':
                    schema_string_v2 = schema_string_v2 + 'A."' + item + '", '

            schema_string_v2 = schema_string_v2[:-2]
            del shuffler
            shuffler = list()

            schema_string = schema_string[:-2]
            logger.error("Schema string: " + str(schema_string))
            logger.error("Schema string v2: " + str(schema_string_v2))

            trim = ''
            for i in temp_data:
                if i[0] in static_list:
                    shuffler.append(i)
                    continue
                if i[1] == 'bigint' or i[1] == 'date':
                    trim += '"' + i[0] + '", '
                else:
                    trim += ' TRIM(' + '"' + i[0] + '") as ' + i[0] + ', '

            for i in shuffler:
                if i[1] == 'bigint' or i[1] == 'date':
                    trim += '"' + i[0] + '", '
                elif i[0] == 'country':
                    trim += ' SUBSTRING(TRIM(country) from 1 for 2) as substr_country, '
                    trim += ' TRIM(country) AS raw_country, '
                elif i[0] == 'gender':
                    trim += 'TRIM(gender) as gender, '
                elif i[0] == 'state':
                    trim += 'TRIM(state) as st, '
                else:
                    trim += ' TRIM(' + '"' + i[0] + '") as ' + i[0] + ', '

            logger.error("Trim: " + trim)
            trim = trim[:-2]
            static_select_string = "CASE when D.gender_output is not null then D.gender_output else A.gender end ," \
                                   "CASE WHEN B.country_output_name is not null then B.country_output_name else " \
                                   "A.raw_country end, " \
                                   "case when C.state_output is not null then C.state_output else A.st" \
                                   " end"

            static_join_string = "LEFT OUTER  JOIN (select distinct iso_code_2, country_output_name from ref_country) as B ON B.iso_code_2 = A.substr_country " \
                                 "LEFT OUTER  JOIN (select distinct ref_state , state_input, state_output from ref_state) as C ON C.state_input = A.st " \
                                 "LEFT OUTER  JOIN  ref_gender as D ON D.gender_input= A.gender ; "
            try:
                cursor = connection.cursor()
                logger.error("""INSERT INTO "{}" ({}) SELECT {},{} FROM ( SELECT {}  FROM "{}" WHERE ingest_id = '{}' ) AS A {} """.format(
                    stage_table_name, schema_string, schema_string_v2, static_select_string, trim, landing_table_name,
                    ingest_id, static_join_string))
                cursor.execute("""INSERT INTO "{}" ({}) SELECT {},{} FROM ( SELECT {}  FROM "{}" WHERE ingest_id = '{}' ) AS A
                              {} """.format(stage_table_name, schema_string, schema_string_v2, static_select_string, trim,
                                            landing_table_name, ingest_id, static_join_string))
                connection.commit()
                logger.error("After the insert query in data standardization!!!")


                #TODO make the where string dynamic for all column specific to entity

                cursor = connection.cursor()
                cursor.execute("insert into investigator_study_bridge select source_id, unnest(string_to_array(study_id, ';'))"
                                "from landing_investigator where ingest_id = '{}'".format(ingest_id))
                logger.error("insert into investigator_study_bridge select source_id, unnest(string_to_array(study_id, ';'))"
                             "from landing_investigator where ingest_id = '{}'".format(ingest_id))

                logger.error("insert into investigator study bridge complete")
                # return JsonResponse({'ok': 'Success'})

            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # cursor = connection.cursor()
            # logger.error("First query without investigator!!")

            # cursor.execute("""SELECT standardize_country_state('{}', '{}')""".format(stage_table_name, ingest_id))
            # # cursor.execute('with t as (select stage_id as r_id, country as desh, state as st, gender as g from "{}" '
            # #                'where ingest_id = "{}") update "{}" as s set country=(select distinct(country_output_name)'
            # #                'from ref_country where country_input_name = t.desh), state = (select distinct(state_output)'
            # #                'from ref_state where state_input = t.st) from t where s.stage_id = t.r_id and s.country '
            # #                'IS NOT NULL OR s.state IS NOT NULL'.format(landing_table_name, ingest_id, stage_table_name))
            # connection.commit()
            # logger.error("function ")
            # if entity_name == 'investigator':
            #     cursor = connection.cursor()
            #     cursor.execute("""SELECT standardize_gender('{}', '{}')""".format(stage_table_name, ingest_id))
            # #     cursor.execute("""with t as (select stage_id as r_id , gender as g from "{}" 
            # # where ingest_id = '{}') update "{}" as s set gender = (select distinct(gender_output) from ref_gender where 
            # # gender_input = t.st) from t where s.stage_id = t.r_id and s.gender IS NOT NULL  """.format(
            # #         landing_table_name, ingest_id, stage_table_name))
            #     logger.error("First query with investigator!!")
            #     connection.commit()

                #email standardization
            try:
                pass
                # cursor = connection.cursor()
                # cursor.execute("select stage_id , email_address from {} where ingest_id = '{}' and email_address is not null"
                #                .format(stage_table_name,ingest_id))
                # email_address = cursor.fetchall()
                # logger.error("email cleaning starts.")
                # if email_address:
                #     for email in email_address:
                #         stage_id = email[0]
                #         email_string = ''
                #         special_char = ['@', '.', '_', '-']
                #         if email[1]:
                #             emails = email[1].split(';')
                #             for address in emails:
                #                 c_email = ''
                #                 for i in address:
                #                     if i.isalnum() == 1 or i in special_char:
                #                         c_email += i
                #                     else:
                #                         c_email += ''
                #                 for v in special_char:
                #                     c_email = re.sub("[" + v + "]+", v, c_email)
                #                 email_string += str(c_email) + ';'
                #             email_string = email_string[:-1]
                #             cursor = connection.cursor()
                #             cursor.execute("update {} set email_address = '{}' where stage_id = '{}'"
                #                            .format(stage_table_name, email_string, stage_id))
                #             connection.commit()
                #             logger.error("stage_id: "+ str(stage_id))
                #         elif stage_id:
                #             cursor = connection.cursor()
                #             cursor.execute("update {} set email_address = NULL where stage_id = '{}'"
                #                            .format(stage_table_name, stage_id))
                #             connection.commit()
                #             logger.error("stage_id: "+ str(stage_id))
            except Exception as e:
                logger.error(str(e))
            try:
                pass
                # cursor = connection.cursor()
                # cursor.execute("select country from stage_investigator where ingest_id = '{}'".format(ingest_id))
                # country = cursor.fetchall()
                # if country:
                #     cursor = connection.cursor()
                #     logger.error("In the Phone number standardization!!")
                #
                #     logger.error("select i.stage_id,"
                #                 "case when i.primary_mobile_num is not null then i.primary_mobile_num END as primary_mobile_num,"
                #                 "case when i.country = r.country_input_name then r.iso_code_3 END as country "
                #                 "from stage_investigator as i join ref_country as r on i.country = r.country_input_name"
                #                 "where i.primary_mobile_num is not null "
                #                 "and i.ingest_id = '{}' ".format(ingest_id))
                #
                #     cursor.execute("select i.stage_id,"
                #                 "case when i.primary_mobile_num is not null then i.primary_mobile_num END as primary_mobile_num,"
                #                 "case when i.country = r.country_input_name then r.iso_code_3 END as country "
                #                 "from stage_investigator as i join ref_country as r on i.country = r.country_input_name "
                #                 "where i.primary_mobile_num is not null "
                #                 "and i.ingest_id = '{}' ".format(ingest_id))
                # else:
                #     cursor = connection.cursor()
                #     cursor.execute("""select stage_id, primary_mobile_num from stage_investigator
                #                     where ingest_id = '{}' and primary_mobile_num is not null""".format(ingest_id))
                #
                # phone_data = cursor.fetchall()
                # # print(type(phone_data))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            # iso_code = dict()
            # with open('/home/arnav/Vitrana-Product/Mdm/src/Postgres_Django/standardization/iso_code2.csv') as f:
            #     for line in f.readlines():
            #         data = line.split('`')
            #         country_code = data[1]
            #         country_code = country_code.replace(' ', '')
            #         country_iso = data[3][:-1]
            #         country_iso = country_iso.replace(' ', '')
            #         country_iso = country_iso.replace(',', '')
            #         iso_code[country_iso] = country_code
            # logger.error("iso code: " + str(iso_code))
            # lst = list()
            # new_dict = dict()
            # new_str = ''
            # for number in phone_data:
            #     phone_number = str(number[1])
            #     phone_number = clean_phone_number(phone_number)
            #     country_iso = str(number[2])
            #     record_id = str(number[0])
            #     cursor = connection.cursor()
            #     cursor.execute("""UPDATE stage_investigator set primary_mobile_num='{}' WHERE stage_id = '{}'""".format
            #                        (phone_number, record_id))
            #     connection.commit()
            #     if phone_number:
            #         country_code = str(iso_code[country_iso])
            #         uri = 'http://phonenumber.ones-app.com/details?number='
            #         request_url = uri + phone_number
            #         logger.error("output: " + request_url)
            #         response = requests.get(request_url)
            #         logger.error("response: " + str(response))
            #         try:
            #             response = json.loads(response.text)
            #         except Exception as e:
            #             logger.error(str(e))
            #             new_dict[record_id] = phone_number
            #             continue
            #         logger.error("Before")
            #         logger.error("response: " + str(response))
            #         logger.error("After\n")
            #         try:
            #             if response['is_validnumber']:
            #                 new_dict[record_id] = response['International-format']
            #                 international_format_num = response['International-format']
            #                 logger.error("new_dict: " + str(new_dict))
            #                 try:
            #                     logger.error("phone number standardization start after cleaning")
            #                     try:
            #                         logger.error("country iso: " + str(country_iso))
            #                         x = phonenumbers.parse(phone_number, country_iso)
            #                         logger.error("number after parsing: " + str(x))
            #                         res = phonenumbers.is_valid_number(x)
            #                     except Exception as e:
            #                         logger.error(str(e))
            #                     if res:
            #                         var = phonenumbers.format_number(x, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
            #                         new_dict[record_id] = var
            #                         lst.append(var)
            #                         # logger.error("dictionary: " +str(new_dict))
            #                     else:
            #                         new_dict[record_id] = phone_number
            #                         lst.append(str(number[1]))
            #
            #                     for cc in country_code.split(','):
            #                         if international_format_num[0] == '+':
            #                             new_str = international_format_num[1:]
            #                             logger.error("new_str: " + str(new_str))
            #                             # x = phonenumbers.parse(new_str, country_iso)
            #                             if new_str[0] == '0' and new_str[1] == '0':
            #                                 new_str = new_str[2:]
            #                                 logger.error("new str after changes : " + str(new_str))
            #                                 logger.error("+ found!!!")
            #                                 logger.error("Country iso : " + country_iso)
            #                                 # logger.error("phone number: " + str(international_format_num))
            #                                 x = phonenumbers.parse(new_str, country_iso)
            #                                 logger.error("plus found!!!!")
            #                             else:
            #                                 logger.error("now in the else: ")
            #                                 x = phonenumbers.parse(new_str, country_iso)
            #                                 logger.error("executed here!!!")
            #                         else:
            #                             international_format_num = '+' + cc + international_format_num
            #                             logger.error("+ not found!!!")
            #                             logger.error("Country iso in else: " + country_iso)
            #                             logger.error("phone number in else!!: " + str(international_format_num))
            #                             x = phonenumbers.parse(international_format_num, country_iso)
            #                             logger.error("plus not found!!!")
            #
            #                         res = phonenumbers.is_valid_number(x)
            #                         logger.error("res: " + str(res))
            #                         if res:
            #                             var = phonenumbers.format_number(x, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
            #                             logger.error("var : " + str(var))
            #                             new_dict[record_id] = var
            #                             lst.append(var)
            #                             # lst.append('+' + str(x.country_code) + '-' + str(x.national_number))
            #                             break
            #                         else:
            #                             new_dict[record_id] = phone_number
            #                             lst.append(str(number[1]))
            #                 except Exception as e:
            #                     new_dict[record_id] = phone_number
            #                     lst.append(str(number[1]))
            #                     logger.error(str(e))
            #             else:
            #                 new_dict[record_id] = phone_number
            #         except Exception as e:
            #             logger.error(str(e))
            #             new_dict[record_id] = phone_number
            #
            #         for k, v in new_dict.items():
            #             try:
            #                 cursor = connection.cursor()
            #                 cursor.execute("""UPDATE stage_investigator set primary_mobile_num='{}' WHERE stage_id = '{}'""".format
            #                                (v, k))
            #                 connection.commit()
            #             except Exception as e:
            #                 logger.error(str(e))
            #                 k = dict()
            #                 k['Error'] = str(e).replace("'", '"')
            #                 # k = json.dumps(k)
            #                 cursor = connection.cursor()
            #                 logger.error(
            #                     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #                         request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            #                 cursor.execute(
            #                     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #                         request.session.get('ingest_id', -1),
            #                         request.session.get('user_id', -1), json.dumps(k)))
            #                 connection.commit()
            logger.error("phone number standardization is done!! and data is inserted!!")
            return JsonResponse({'ok': 'Success'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'Failure': 'Some where after else part!!'})

    @staticmethod
    def post(request):
        """
        
        :param request: 
        :return: 
        """
        try:
            pass
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Failure in Standardization post'})

class ErrorLogging(APIView):
    """

    """

    @staticmethod
    def get(request, page_number):
        """

        :param request: 
        :return: 
        """
        loggers = []
        context = {}
        try:
            context['page_number'] = page_number
            try:
                uid = request.session.get('user_id', -1)
            except Exception as e:
                logger.error(str(e))
            cursor = connection.cursor()
            cursor.execute("select count(*) from clinmdm_logs_per_ingestion as a join ingestion as b on "
                          "a.ingest_id = b.ingest_id where a.uid = '{}'".format(uid))
            count = cursor.fetchall()[0][0]
            context['total_records_count'] = count
            cursor = connection.cursor()
            cursor.execute("""select distinct(a.ingest_id),b.ingest_name, b.steward_id, b.uid, b.data_manager_id,  
                          a.log_time from clinmdm_logs_per_ingestion as a join ingestion as b on 
                          a.ingest_id = b.ingest_id where a.uid = '{}' ORDER BY log_time limit 10 offset {}"""
                           .format(uid, str((int(page_number) - 1) * 10)))
            logs = cursor.fetchall()
            print ("logs: " + str(logs))
            for log in logs:
                logs = {}
                logs['ingestion_id'] = log[0]
                logs['ingestion_name'] = log[1]
                if log[2] is None:
                    logs['steward_name'] = "Not specified yet"
                else:
                    cursor = connection.cursor()
                    cursor.execute("select name from users where user_id = '{}'".format(log[2]))
                    steward_name = cursor.fetchall()[0][0]
                    logs['steward_name'] = steward_name

                if log[3]is None:
                    logs['owner_name'] = "Not specified yet"
                else:
                    cursor = connection.cursor()
                    cursor.execute("select name from users where user_id = '{}'".format(log[3]))
                    owner_name = cursor.fetchall()[0][0]
                    logs['owner_name'] = owner_name

                if log[4] is None:
                    logs['steward_name'] = "Not specified yet"
                else:
                    cursor = connection.cursor()
                    cursor.execute("select name from users where user_id = '{}'".format(log[4]))
                    data_manager_name = cursor.fetchall()[0][0]
                    logs['data_manager_name'] = data_manager_name

                loggers.append(logs)
            context['error_logging'] = loggers
        except Exception as e:
            logger.error(str(e))
            return  JsonResponse({'failure': 'Database Failure.'})
        return JsonResponse(context)

    @staticmethod
    def post(request):
        """

        :param request: 
        :return: 
        """
        context = {}
        loggers = []
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_id = data['ingest_id']
        except Exception as e:
            logger.error(str(e))
            return  JsonResponse({'failure': 'No data found in the body'})
        try:
            cursor = connection.cursor()
            cursor.execute("""select log, log_time from clinmdm_logs_per_ingestion where ingest_id = '{}'"""
                           .format(ingest_id))
            logs = cursor.fetchall()
            for log in logs:
                logs = {}
                logs['timestamp'] = log[1]
                logs['logs'] = log[0]
                loggers.append(logs)
            context['error_logging'] = loggers
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Database Failure'})
        return  JsonResponse(context)

def clean_phone_number(phone_number):
    if phone_number:
        phone_number = re.sub(r'[-/().?!#$@ ]', '', phone_number)
        if re.search(r'ext\d', phone_number):
            phone_number = phone_number.replace('ext', ' ext ')
        elif re.search(r'x\d', phone_number):
            phone_number = phone_number.replace('x', ' x ')
        else:
            phone_number = re.sub(r'[a-zA-Z]', '', phone_number)

        ph_num = ''
        for c in phone_number:
            if c == '+':
                if c not in ph_num:
                    ph_num += c
                else:
                    ph_num += ''
            else:
                ph_num += c
        logger.error("phone number cleaning worked! " + str(ph_num))
        return ph_num
    else:
        return 1