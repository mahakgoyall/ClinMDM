"""django_postgres URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from validator.views import logout, login_check, init, create_user, modify_user, delete_user, change_password
from validator.views import reset_password, forget_password
# from amazons3.views import push_picture_to_s3
from amazons3.views import download_from_s3, download_S3_bucket

# from validator.apis import set_session

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^admin/create_user', create_user, name='create user'),
    url(r'admin/modify_user', modify_user, name='modify_user'),
    url(r'admin/delete_user', delete_user, name='delete_user'),
    url(r'admin/change_password', change_password, name='change password'),
    url(r'admin/password_reset', reset_password, name='reset password'),
    url(r'admin/forget_password', forget_password, name='forget password'),
    url(r'^', include('validator.urls')),
    url(r'^init', init, name='init'),
    url(r'^login_check', login_check, name='Login check'),
    url(r'^logout', logout, name='Logout'),
    url(r'^validator/', include('validator.urls')),
    url(r'^rulematcher/', include('rulematcher.urls')),
    url(r'^steward/', include('data_steward.urls')),
    url(r'^dashboard/', include('dashboard.urls')),
    url(r'^connections/', include('connections.urls')),
    url(r'^web/', include('web_curl_service.urls')),
    url(r'^mdm_browser/', include('mdm_browser.urls')),
    # url(r'^cldstorage/',include('amazons3.urls')),
    # url(r'^push_picture_to_s3/$', push_picture_to_s3, name='push_picture_to_s3'),
    url(r'^download_from_s3', download_from_s3, name='download_from_s3'),
    url(r'^download_S3_bucket', download_S3_bucket, name='download_S3_bucket'),
    # url(r'^delete_and_move_from_amazons3', delete_and_move_from_amazons3, name= 'delete_and_move_from_amazons3'),
    # url(r'^source_configuration/', include('source_configuration.urls')),
    url(r'^source_configuration/', include('source_configuration.urls')),
    url(r'^standardization/', include('standardization.urls')),
    url(r'^scheduler/', include('scheduler.urls')),
    url(r'^searchengine/', include('searchengine.urls')),

]
