from django.apps import AppConfig


class StudyConnectionsConfig(AppConfig):
    name = 'study_connections'
