from django.shortcuts import render
from connections.views import *
from rest_framework.views import APIView
from connections.getCSVHeader import headerCSV
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.db import connection
from datetime import datetime
from django.core.exceptions import SuspiciousFileOperation
import time
import os
import random
import string
import logging
import json
import re
from chardet.universaldetector import UniversalDetector
from validator.views import ValidatorClass
from fuzzywuzzy import fuzz
from web_curl_service.views import flow_flags
import psycopg2
import heapq
from collections import OrderedDict


logger = logging.getLogger("mdm_logging")


def override(interface_class):
    def overrider(method):
        assert(method.__name__ in dir(interface_class))
        return method
    return overrider


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, datetime):
        serial = obj.isoformat()
        return serial
    raise TypeError("Type not serializable")


class StudyCsvFileReader(APIView):

    """
    This class is for using study CSV file reader and calling the CSVFileReader which is there in the connections app
    
    """
    @staticmethod
    def get(request):
        """
        
        :return: 
        """
        return JsonResponse({'failure':'API not supported yet!!'})

        # return JsonResponse(show_flow_completed_ingestion_list_to_steward(request, page_number))

    @staticmethod
    def post(request):
        """
        
        :return: 
        """
        return CsvFileReader.post(request, entity='study')


class StudyCsvMapping(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :return: 
        """
        return JsonResponse({'failure': 'API not supported yet'})

    @staticmethod
    def post(request):
        """

        :return: 
        """
        return CsvMapping.post(request, entity='study')