from rest_framework.views import APIView
from connections.getCSVHeader import headerCSV
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.db import connection
from datetime import datetime
from django.core.exceptions import SuspiciousFileOperation
import time
import os
import random
import string
import logging
import json
import re
from chardet.universaldetector import UniversalDetector
from validator.views import  ValidatorClass
from fuzzywuzzy import fuzz
from web_curl_service.views import flow_flags
import psycopg2
import copy
import boto3
from botocore.client import Config
logger = logging.getLogger("mdm_logging")


class CustomSourceNameCheck(APIView):

    """ Post method:
    Returns success if there is a match of custom source name in our admin_sources configuration table.
        Get method:
    Returns list of priorities of sources to UI."""
    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            custom_source_name = data['custom_source_name']
            logger.error("custom source name :  " + str(custom_source_name))
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'Enter Custom Source Name'})
        if custom_source_name:
            cursor = connection.cursor()
            cursor.execute("SELECT source_root_name from admin_sources WHERE source_root_name = "
                           "'{}'".format(str(custom_source_name)))
            data = cursor.fetchall()
            logger.error(str(data))
            if data:
                return JsonResponse({'Failure': 'Found'})
            else:
                return JsonResponse({'Success': 'ok'})



class GetPriorityList(APIView):
    @staticmethod
    def get(request):
        ui_info = dict()
        cursor = connection.cursor()
        cursor.execute("SELECT  source_root_name, priority from source_priority_lookup;")
        data = cursor.fetchall()
        if data:
            for d in data:
                if d[0]:
                    ui_info[d[1]] = d[0]
                else:
                    ui_info[d[1]] = "NULL"
            return JsonResponse(ui_info)
        return JsonResponse({'failure': 'No data found'})


class SourceDetailsForAdmin(APIView):

    @staticmethod
    def get(request):
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT  source_root_name, conn_method, conn_string, source_priority, "
                           "source_root_id from admin_sources where delete_flag != '1'")
            data = cursor.fetchall()
            logger.error("data is " + str(data))
            count = 0
            ui_info = dict()
            ui_info['data'] = list()
            if data:
                for details in data:
                    info = dict()
                    info['source_root_name'] = details[0]
                    info['conn_method'] = details[1]
                    info['conn_string'] = json.loads(details[2])
                    info['source_priority'] = details[3]
                    info['source_root_id'] = details[4]
                    cursor = connection.cursor()
                    cursor.execute("select status_flag from ingestion where source_root_id = '{}'"
                                   .format(details[4]))
                    status_flag = cursor.fetchall()
                    if len(status_flag) > 0 and status_flag[0][0] in [3, 4]:
                        info['edit_button'] = False
                        info['delete_button'] = False
                    else:
                        info['edit_button'] = True
                        info['delete_button'] = True
                    ui_info['data'].append(info)
                logger.error("   ui info   :   " + str(ui_info))
                return JsonResponse(ui_info)
            else:
                return JsonResponse({'Failure': 'No data found.'})
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'Error in fetching source details.'})

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            editable = data['editable']
            deletable = data['deletable']
            source_id = data['source_id']
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'At least one field is missing'})
        if deletable == 1:
            try:
                cursor = connection.cursor()
                cursor.execute("update admin_sources set delete_flag = '1', source_priority = NULL where source_root_id = '{}'"
                               .format(source_id))
                connection.commit()
                cursor = connection.cursor()
                logger.error("update source_priority_lookup set source_root_name = NULL where "
                               " source_root_name = (select source_root_name from admin_sources "
                               " where source_root_id = '{}')"
                               .format(source_id))
                cursor.execute("update source_priority_lookup set source_root_name = NULL where "
                               " source_root_name = (select source_root_name from admin_sources "
                               " where source_root_id = '{}')"
                               .format(source_id))
            except Exception as e:
                logger.error(str(e))
                return JsonResponse({'failure': 'Database Failure'})
        elif editable == 1:
            try:
                conn_name = data['conn_name']
                conn_priority = data['conn_priority']
                conn_string = data['conn_string']
            except Exception as e:
                logger.error(str(e))
                return JsonResponse({'failure': 'At least one field is missing'})
            try:
                conn_string = str(conn_string).replace("'", '"')
                cursor = connection.cursor()
                cursor.execute("update admin_sources set source_root_name = '{}', conn_string = '{}', "
                               "source_priority = '{}' where source_root_id = '{}' and delete_flag != '1'".format(conn_name, conn_string,
                                                                                           conn_priority, source_id))
                connection.commit()
                cursor = connection.cursor()
                cursor.execute("update source_priority_lookup set source_root_name = NULL where priority = "
                               " (select priority from source_priority_lookup where source_root_name = '{}')"
                               .format(conn_name))
                connection.commit()
                cursor = connection.cursor()
                cursor.execute("update source_priority_lookup set source_root_name = '{}'"
                               " where priority = '{}'".format(conn_name, conn_priority))
                connection.commit()
            except Exception as e:
                logger.error(str(e))
                return JsonResponse({'failure':'Database Failure'})

        return JsonResponse({'success': 'ok'})


class GetRootSourceDetails(APIView):

    @staticmethod
    def get(request):
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT source_root_name, conn_method, source_priority, conn_string FROM admin_sources where delete_flag != '1';")
            # cursor.execute("SELECT source_root_name, conn_method, source_priority FROM admin_sources;")
            data = cursor.fetchall()
            logger.error("data is " + str(data))
            ui_info = dict()
            if data:
                ui_info['db_connection'] = list()
                ui_info['Amazon_S3_bucket'] = list()
                ui_info['file_browser'] = list()
                for details in data:
                    dbdetail=dict()
                    if details[1] == 'db_connection':
                        dbdetail['name'] = details[0]
                        dbdetail['priority'] = details[2]
                        dbdetail['conn_string'] = json.loads(details[3])
                        ui_info['db_connection'].append(dbdetail)
                    elif details[1] == 'Amazon_S3_bucket':
                        dbdetail['name'] = details[0]
                        dbdetail['priority'] = details[2]
                        dbdetail['conn_string'] = json.loads(details[3])
                        ui_info['Amazon_S3_bucket'].append(dbdetail)
                    else:
                        dbdetail['name'] = details[0]
                        dbdetail['priority'] = details[2]
                        dbdetail['conn_string'] = json.loads(details[3])
                        ui_info['file_browser'].append(dbdetail)
                # for key in ui_info:
                #     if not ui_info[key]:
                #         del ui_info[key]
                logger.error(str(ui_info))
                return JsonResponse(ui_info)
            #
            # if data:
            #     for details in data:
            #         info = dict()
            #         info['custom_source_name'] = details[0]
            #         info['conn_method'] = details[1]
            #         info['source_priority'] = details[2]
            #         ui_info['data'].append(info)
            #     return JsonResponse(ui_info)
            else:
                return JsonResponse({'Failure': 'No data found.'})
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'Error in fetching details.'})


class AdminConnections(APIView):

    @staticmethod
    def post(request):
        try:
            # entity_name = request.META['HTTP_ENTITY']
            # logger.error(str(entity_name))
            data = json.loads(request.read().decode('utf-8'))
            logger.error(str(data))
            # data = json.loads(request.read().decode('utf-8'))
            if data['conn_method'] == 'db_connection':
                dbname = data['database_name']
                port = data['port']
                host = data['host_name']
                user = data['username']
                password = data['password']
                db_table = data['table_name']
                custom_source_name = data['custom_source_name']
                source_priority = data['source_priority']
                try:
                    conn = psycopg2.connect(dbname=dbname, user=user, host=host,
                                            password=password, port=port)
                    cursor = conn.cursor()
                    cursor.execute(
                        "SELECT column_name, data_type FROM information_schema.columns where table_name  "
                        "= '{}' ORDER  BY ordinal_position ".format(
                            db_table))
                except Exception as e:
                    logger.error("Table not found in database")
                    logger.error(str(e))
                    return JsonResponse({'error': 'Error in establishing connection '})
                else:
                    columns = cursor.fetchall()
                    # header_list = list()
                    # for column in columns:
                    #     header_list.append(column[0])
                    conn_string = '{'
                    for k, v in data.items():
                        if not k == 'custom_source_name' or k == 'source_priority':
                            conn_string = conn_string + '"' + str(k) + '":"' + str(v) + '", '
                    conn_string = conn_string[:-2]
                    conn_string += '}'
                    logger.error("conn_string  :  " + str(conn_string))
                    cursor = connection.cursor()
                    cursor.execute("select 1 from admin_sources where source_root_name = '{}' and delete_flag != '1'"
                                   .format(custom_source_name))
                    source_name = cursor.fetchall()
                    logger.error('source name error: ' + str(source_name))
                    if source_name:
                        return JsonResponse({'failure': 'Source name already exists.'})
                    cursor = connection.cursor()
                    cursor.execute("INSERT INTO admin_sources (source_root_name, conn_method, conn_string, "
                                   "source_priority) values('{}', '{}', '{}', '{}') ".
                                   format(custom_source_name, 'db_connection', conn_string, source_priority))
                    cursor = connection.cursor()
                    cursor.execute("UPDATE source_priority_lookup SET source_root_name = '{}' WHERE priority = "
                                   "'{}'".format(custom_source_name, source_priority))
                    return JsonResponse({"success": 'Connection Successful'})

            elif data['conn_method'] == 'Amazon_S3_bucket':
                custom_source_name = data['custom_source_name']
                # source_priority = data['source_priority']
                AWS_ACCESS_KEY_ID = data["key_id"]
                AWS_SECRET_ACCESS_KEY = data["secret_id"]
                # bucket = data['bucket_name']

                # conn_string = '{'
                # for k, v in data.items():
                #     if k != 'custom_source_name' or k != 'source_priority':
                #         conn_string = conn_string + '"' + str(k) + '":"' + str(v) + '", '
                # conn_string = conn_string[:-2]
                # conn_string += '}'
                # logger.error("conn_string  :  " + str(conn_string))
                # logger.error("HERE  in amazon S3 code!!!")

                try:
                    s3_res = boto3.resource('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                            aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
                    s3_client = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                             aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
                    #call s3 to list current buckets
                    response = s3_client.list_buckets()

                    #get a list of all bucket names from the response
                    buckets = [bucket['Name'] for bucket in response['Buckets']]

                    #print all the bucket list
                    print("Bucket list:  %s" % buckets)

                    return JsonResponse(buckets, safe=False)
                except Exception as e:
                    logger.error(str(e))
                    return JsonResponse({'Failure': 'Failure in credentials'})

                # added at source loader connection page;
                # cursor = connection.cursor()
                # cursor.execute("INSERT INTO admin_sources (source_root_name, conn_method, conn_string, "
                #                    "source_priority) values('{}', '{}', '{}', '{}') ".
                #                    format(custom_source_name, 'Amazon_S3_bucket', conn_string, source_priority))
                # return JsonResponse({'Success': 'ok'})
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'No data Found '})


class AdminConnectionAmazonS3(APIView):
    """
    
    """
    @staticmethod
    def post(request):
        """
        
        :return: 
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            logger.error(str(data))
            if data['conn_method'] == 'Amazon_S3_bucket':
                custom_source_name = data['custom_source_name']
                source_priority = data['source_priority']
                AWS_ACCESS_KEY_ID = data["key_id"]
                AWS_SECRET_ACCESS_KEY = data["secret_id"]
                bucket = data['bucket_name']
            logger.error("custom_source_name: " + str(custom_source_name))
            logger.error("source_priority: " + str(source_priority))
            logger.error("AWS_SECRET_ACCESS_KEY: " + str(AWS_SECRET_ACCESS_KEY))
            logger.error("AWS_ACCESS_KEY_ID: " + str(AWS_ACCESS_KEY_ID))
            logger.error("bucket: " + str(bucket))
            conn_string = '{'
            for k, v in data.items():
                if k != 'custom_source_name' or k != 'source_priority':
                    conn_string = conn_string + '"' + str(k) + '":"' + str(v) + '", '
            conn_string = conn_string[:-2]
            conn_string += '}'
            logger.error("conn_string  :  " + str(conn_string))
            logger.error("HERE  in amazon S3 code!!!")
            # Todo : Header, data mapping, status falg and file source name will be
            # added at source loader connection page;
            cursor = connection.cursor()
            cursor.execute("select 1 from admin_sources where source_root_name = '{}' and delete_flag != '1'"
                           .format(custom_source_name))
            source_name = cursor.fetchall()
            logger.error('source name error: ' + str(source_name))
            if source_name:
                return JsonResponse({'failure': 'source name already exists.'})
            cursor = connection.cursor()
            cursor.execute("INSERT INTO admin_sources (source_root_name, conn_method, conn_string, "
                           "source_priority) values('{}', '{}', '{}', '{}') ".
                           format(custom_source_name, 'Amazon_S3_bucket', conn_string, source_priority))
            logger.error("Successfull credentials are stored!!!!")
            cursor = connection.cursor()
            logger.error("UPDATE source_priority_lookup SET source_root_name = '{}' WHERE priority = "
                           "'{}'".format(custom_source_name, source_priority))
            cursor.execute("UPDATE source_priority_lookup SET source_root_name = '{}' WHERE priority = "
                           "'{}'".format(custom_source_name, source_priority))
            logger.error("update done!!!")
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'No data Found '})
        return JsonResponse({'ok': 'Success'})


class S3MultipleDownload(APIView):
    """
    
    """

    @staticmethod
    def post(request):
        s3_res = boto3.resource('s3', aws_access_key_id='AKIAI6KLHZTL7BAVG6HA',
                                aws_secret_access_key='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')
        s3_client = boto3.client('s3', aws_access_key_id='AKIAI6KLHZTL7BAVG6HA',
                                 aws_secret_access_key='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')
        bucket = 'Pooja'
        folder = 'Study'
        mybucket = s3_res.Bucket(bucket)
        objs = []
        for file in mybucket.objects.all():
            name_of_file = file.key
            name_of_file = name_of_file.split('/')[0]
            if file.key == folder + '/' or '/'.join(file.key.split('/')[:2]) == folder + '/Processed':
                continue
            if name_of_file == folder:
            # Download file
                print(file.key)
            s3_client.download_file(bucket, file.key, '/'.join((file.key).split('/')[1:]))
            objs.append(file.key)

        for file in objs:
            copy_source = {
                'Bucket': bucket,
                'Key': file
            }
            s3_client.copy(copy_source, bucket, folder + '/Processed/' + '/'.join(file.split('/')[1:]))
            s3_client.delete_object(Bucket=bucket, Key=file)
        return JsonResponse({'Success': 'ok'})


class UseThisSource(APIView):
    """
    
    """

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            custom_source_name = data['custom_source_name']
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'No data found.'})
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT conn_string, source_priority FROM admin_sources WHERE "
                           "source_root_name = '{}'".format(custom_source_name))
            data = cursor.fetchall()
            # for details in data:
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'Failure': 'No data found.'})
