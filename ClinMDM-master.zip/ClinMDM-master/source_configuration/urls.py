from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^custom_source_name/$', views.CustomSourceNameCheck.as_view(), name='Custom source name'),
    url(r'^get_priority_list/$', views.GetPriorityList.as_view(), name='Custom Source Name Check'),
    url(r'^save_admin_connection/$', views.AdminConnections.as_view(), name='Custom Source Name Check'),
    url(r'^show_source_details_to_admin/$', views.SourceDetailsForAdmin.as_view(), name='Custom Source Name Check'),
    url(r'^show_root_source_details/$', views.GetRootSourceDetails.as_view(), name='Show root sources'),
    url(r'^admin_amazon_s3/$', views.AdminConnectionAmazonS3.as_view(), name='AdminConnectionAmazonS3'),
]

