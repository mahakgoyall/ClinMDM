from django.apps import AppConfig


class Amazons3Config(AppConfig):
    name = 'amazons3'
