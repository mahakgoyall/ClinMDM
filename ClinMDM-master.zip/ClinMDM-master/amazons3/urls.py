from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^awscloud/$', views.Cloud_Storage_AWS.as_view(), name = 'amazon s3 storage'),
]