from django.shortcuts import render
from connections.getCSVHeader import headerCSV
from django.http import JsonResponse
from django.conf import settings
from django.db import connection
from datetime import datetime
import time
import os
import random
import string
import logging
import json
from web_curl_service.views import flow_flags
from chardet.universaldetector import UniversalDetector
import psycopg2
import boto3
from botocore.client import Config
import pandas as pd
from xml.etree import ElementTree
from sqlalchemy import create_engine
import time

# Create your views here.

# here is the logger
logger = logging.getLogger("mdm_logging")

# BUCKET_NAME = 'clinmdm'
# AWS_ACCESS_KEY_ID = 'AKIAIZ3S7EKVFUCYEEMQ'
# AWS_SECRET_ACCESS_KEY = 'vh5T8s+tMHbnAD5/WdLSdza4wMmXWdSQJbc/ghb+'
LOCALPATH = '/home/arnav/Vitrana-Product/Mdm/src/Postgres_Django/amazonpath/'

dbname = 'mdm_data'
user = 'arnav'
host = '13.90.80.185'
password = '123456'
port = '5434'

# input_string = 'postgresql://' + user + ':' + password + '/' + dbname
input_string = 'postgresql://arnav:123456@13.90.80.185:5434/mdm_data'


def override(interface_class):
    """
    
    :param interface_class: 
    :return: 
    """

    def overrider(method):
        assert (method.__name__ in dir(interface_class))
        return method

    return overrider


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, datetime):
        serial = obj.isoformat()
        return serial
    raise TypeError("Type not serializable")


def download_S3_bucket(request):
    """

    :param request: 
    :return: 
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
        logger.error("Data is: " + str(data))
        entity_name = data['entity_name']
        custom_source_name = data['source_root_name']
        logger.error("custom_source_name: " + str(custom_source_name))
        request.session['custom_source_name'] = custom_source_name
        # logger.error("abhi......YAHAAAAAAAA!!!!!!")
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    try:
        cursor = connection.cursor()
        logger.error("select conn_string, source_root_id, source_priority from admin_sources where "
                     "source_root_name = '{}' and delete_flag != '1'".format(custom_source_name))
        cursor.execute("select conn_string, source_root_id, source_priority from admin_sources where "
                       "source_root_name = '{}' and delete_flag != '1'".format(custom_source_name))
        data_1 = cursor.fetchall()
        logger.error("data_1: " + str(data_1))
        # logger.error("YAHAAAAAAAA!!!!!!")
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    try:
        logger.error("kal    ........YAHAAAAAAAA!!!!!!")
        for i in data_1:
            print(i[0])
            conn_string = i[0]
            print(conn_string)
            root_source_id = i[1]
            source_priority = i[2]

        conn_string = json.loads(conn_string)
        logger.error("string: " + str(conn_string))
        request.session['source_root_id'] = root_source_id
        logger.error("jaha bhi ...")
        # We storing root_source_id in the session
        ingest_id = request.session['ingest_id']
        logger.error("ingest_id: " + str(ingest_id))
        uid = request.session['user_id']
        logger.error("uid: " + str(uid))
        AWS_ACCESS_KEY_ID = conn_string['key_id']
        AWS_SECRET_ACCESS_KEY = conn_string['secret_id']
        conn_method = conn_string['conn_method']
        bucket = conn_string['bucket_name']
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()

    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        s3_res = boto3.resource('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
        s3_client = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID,
                                 aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
        mybucket = s3_res.Bucket(bucket)
        objs = list()
        files = list()
        logger.error("in the loop")
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    try:
        for file in mybucket.objects.all():
            name_of_file = file.key
            name_of_file = name_of_file.split('/')[0]
            # if file.key == entity_name + '/' or '/'.join(file.key.split('/')[:2]) == entity_name + '/Processed' or '/'.join(file.key.split('/')[:2]) == entity_name + '/Unprocessed':
            #     continue
            if file.key == entity_name + '/' or '/'.join(file.key.split('/')[:2]) == entity_name + '/Processed':
                continue
            if name_of_file == entity_name:
                # code to download the file
                logger.error("file name : " + str(file.key))
                download_filename = '/'.join(file.key.split('/')[1:])
                download_filename = '.'.join(download_filename.split('.')[:-1])
                download_filename = download_filename + '_' + str(int(time.time())) + '.xml'
                s3_client.download_file(bucket, file.key, download_filename)
                objs.append(file.key)
                files.append(download_filename)
                conn_string = str(conn_string).replace("'", '"')
                try:
                    cursor = connection.cursor()
                    logger.error(
                        "INSERT INTO file_source_meta (ingest_id, uid, conn_method, conn_string, source_name,"
                        "source_root_id) values ('{}','{}','{}','{}','{}',"
                        "'{}')".format(ingest_id, uid, conn_method,
                                       conn_string, download_filename,
                                       root_source_id))
                    cursor.execute(
                        "INSERT INTO file_source_meta (ingest_id, uid, conn_method, conn_string, source_name,"
                        "source_root_id) values ('{}','{}','{}','{}','{}',"
                        "'{}')".format(ingest_id, uid, conn_method,
                                       conn_string, download_filename,
                                       root_source_id))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
        logger.error("files : " + str(files))
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1),
                request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
    try:
        conn_string = str(conn_string).replace("'", '"')
        random.seed = (os.urandom(1024))
        length = 12
        chars = string.ascii_letters + string.digits + '!@#$%^&*()'
        ingest_source_id = ''.join(random.choice(chars) for _ in range(length))
        try:
            cursor = connection.cursor()
            custom_source_name_latest = custom_source_name + '_' + str(int(time.time()))
            logger.error("INSERT INTO ingestion_sources (ingest_id, uid, conn_method, conn_string, "
                           "source_priority, source_root_id, source_name, source_id) values ('{}', '{}', '{}', "
                           "'{}', '{}', '{}', '{}', '{}')".format(ingest_id, uid, conn_method, conn_string,
                                                                  source_priority, root_source_id,
                                                                  custom_source_name_latest, ingest_source_id))
            cursor.execute("INSERT INTO ingestion_sources (ingest_id, uid, conn_method, conn_string, "
                           "source_priority, source_root_id, source_name, source_id) values ('{}', '{}', '{}', "
                           "'{}', '{}', '{}', '{}', '{}')".format(ingest_id, uid, conn_method, conn_string,
                                                                  source_priority, root_source_id,
                                                                  custom_source_name_latest, ingest_source_id))
            cursor = connection.cursor()
            cursor.execute("UPDATE ingestion SET source_root_id = '{}' where ingest_id = '{}' ".format(root_source_id,
                                                                                                       ingest_id))
            connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        j = 0
        count = 0
        df = None
        path = os.getcwd()
        try:
            def get_main_item_from_nested_dict(d, _path):
                if _path == '':
                    return d
                _path = _path.split('`')
                first, rest = _path[0], '`'.join(_path[1:])
                # logger.error(str(first in d))
                d = d[first]
                return get_main_item_from_nested_dict(d, rest)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            while j < len(files):
                try:
                    logger.error("inside the while loop")
                    tree = ElementTree.parse(path + '/' + files[j])
                except Exception as e:
                    j = j + 1
                    logger.error("error in the file: " + str(e))
                    # logger.error("error in the file format!!!")
                    # b = files[j].split('_')
                    # logger.error("b is : " + str(b))
                    # c = b[-1].split('.')
                    # logger.error("c is : " + str(c))
                    # b[-1] = c[-1]
                    # logger.error("b now : " + str(b))
                    # stm = '_'.join(b[:-1])
                    # filename_in_s3 = stm + '.' + b[-1]
                    # logger.error("filename in s3 name is: " + str(filename_in_s3))
                    # a.append(filename_in_s3)
                    # logger.error("a list :" + str(a))
                    # for foo in a:
                    #     print(foo)
                    #     print(type(foo))
                    #     copy_source = {
                    #         'Bucket': bucket,
                    #         'Key': foo
                    #     }
                    #     print(copy_source)
                    #     logger.error("ye execute ho gya ")
                    #     logger.error("bucket :" + str(bucket))
                    #     logger.error("entity name: " + str(entity_name))
                    #     logger.error("s3 client: " + str(s3_client))
                    #     s3_client.copy(copy_source, bucket, str(entity_name) + '/Unprocessed/' + copy_source.get('Key', str(foo)))
                    #     logger.error("ye bhi ho gya hai ")
                    #     s3_client.delete_object(Bucket=bucket, Key=foo)
                    # logger.error("Download but error in file so move to unprocessed folder")
                    # qwerty = dict()
                    # qwerty['Error'] = str(e).replace("'", '"')
                    # # qwerty = json.dumps(qwerty)
                    # cursor = connection.cursor()
                    # logger.error(
                    #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #         request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                    #         json.dumps(qwerty)))
                    # cursor.execute(
                    #     """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    #         request.session.get('ingest_id', -1),
                    #         request.session.get('user_id', -1), json.dumps(qwerty)))
                    # connection.commit()
                    continue
                nodes = dict()
                nodes = crawl(tree.getroot(), memo=nodes)
                # logger.error(str(nodes))
                lst_test = [k for k, _ in nodes.items()]
                root = tree.getroot()
                value = make_dict_from_tree(root)
                del tree
                del nodes

                k = get_main_item_from_nested_dict(value, '`'.join(lst_test[0].split('`')[:-1]))

                del value
                del lst_test
                logger.error("working!!")
                time.sleep(3)

                if count == 0:
                    df = pd.DataFrame(k)
                    ls_2 = list(df.columns.values)
                    ls_3 = []
                    for i in ls_2:
                        ls_3.append(i.split('}')[-1])
                    df.columns = ls_3
                    df['source_unique_id'] = files[j]
                    count += 1
                    del ls_2
                else:
                    db = pd.DataFrame(k)
                    ls_2 = list(db.columns.values)
                    ls_3 = []
                    for i in ls_2:
                        ls_3.append(i.split('}')[-1])
                    db.columns = ls_3
                    db['source_unique_id'] = files[j]
                    df = df.append(db)

                j += 1
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            if len(files) == 0 or df.empty:
                try:
                    cursor = connection.cursor()
                    cursor.execute("""DELETE FROM ingestion_sources WHERE ingest_id = '{}' AND delete_flag = '0'""".format(
                        ingest_id))
                    connection.commit()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                logger.error("""Delete ingestion sources work well!!!""")
                return JsonResponse({'failure': 'No file in bucket'})

            # conn = psycopg2.connect(dbname=dbname, user=user, host=host, port='5432', password='123456')
            engine = create_engine(input_string)
            df_header = list(df.columns.values)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            logger.error("Inside try")
            if entity_name == 'investigator':
                logger.error("DF sql is starting")
                # df.to_csv('testing1.csv', encoding='utf-8')
                # logger.error("csv created!!")
                df.to_sql('temp_landing_investigator_' + str(ingest_id), engine, if_exists='append')
                logger.error("done")
            elif entity_name == 'study':
                df.to_sql('temp_landing_study_' + str(ingest_id), engine, if_exists='append')
            elif entity_name == 'org':
                df.to_sql('temp_landing_org_' + str(ingest_id), engine, if_exists='append')
            else:
                logger.error("Other entity comes so data frame is deleted")
                del df
            df_header = ' '.join(df_header)
            df_header = df_header.replace(' ', ',')
            logger.error("header_df: " + str(df_header))
            try:
                cursor = connection.cursor()
                cursor.execute(
                    "UPDATE ingestion_sources SET header = '{}' WHERE ingest_id = '{}'".format(str(df_header),
                                                                                               ingest_id))
                connection.commit()
                logger.error("update ingestion sources works well !!!")
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                cursor = connection.cursor()
                cursor.execute("UPDATE admin_sources SET header = '{}' WHERE source_root_id = '{}'".format(
                    str(df_header), root_source_id))
                connection.commit()
                logger.error("header updated")
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'error in data frame to sql': 'failure'})
        finally:
            del df
            logger.error("data frame is deleted!!")
        try:
            for file in objs:
                copy_source = {
                    'Bucket': bucket,
                    'Key': file
                }
                s3_client.copy(copy_source, bucket, entity_name + '/Processed/' + '/'.join(file.split('/')[1:]))
                s3_client.delete_object(Bucket=bucket, Key=file)
            logger.error("Download and move successful")
            flow_flags(ingest_id, uid, '2')
            return JsonResponse({'Success': 'ok'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e).replace("'", '"')
        # k = json.dumps(k)
        cursor = connection.cursor()
        logger.error(
            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            request.session.get('ingest_id', -1),
            request.session.get('user_id', -1), json.dumps(k)))
        connection.commit()
        return JsonResponse({'failure': 'connection or file path error'})


# def crawl(root, prefix='', memo={}):
#
#     new_prefix = root.tag
#     if len(prefix) > 0:
#         new_prefix = prefix + "`" + new_prefix
#     for child in root.getchildren():
#         crawl(child, new_prefix, memo)
#     if len(root.getchildren()) == 0:
#         memo[new_prefix] = root.text
#     return memo

def crawl(root, prefix='', memo={}):
    """
    Crawl function to crawl the xml tags.
    :param root: 
    :param prefix: 
    :param memo: 
    :return: memo [the dict of tags]
    """
    new_prefix = root.tag

    if len(prefix) > 0:
        new_prefix = prefix + "`" + new_prefix
        # logger.error(new_prefix)
    for child in root.getchildren():
        crawl(child, new_prefix, memo)
    if len(root.getchildren()) == 0:
        memo[new_prefix] = root.text
    return memo


def make_dict_from_tree(element_tree):
    """

    :param element_tree: 
    :return: 
    """

    def internal_iter(tree, accum):
        """

        :param tree: 
        :param accum: 
        :return: 
        """
        if tree is None:
            return accum
        if tree.getchildren():
            accum[tree.tag] = {}
            for each in tree.getchildren():
                result = internal_iter(each, {})
                if each.tag in accum[tree.tag]:
                    if not isinstance(accum[tree.tag][each.tag], list):
                        accum[tree.tag][each.tag] = [
                            accum[tree.tag][each.tag]
                        ]
                    accum[tree.tag][each.tag].append(result[each.tag])
                else:
                    accum[tree.tag].update(result)
        else:
            accum[tree.tag] = tree.text
        return accum

    return internal_iter(element_tree, {})


def download_from_s3(request):
    """
    :param request:
    :return:
    """
    try:
        data = json.loads(request.read().decode('utf-8'))
        AWS_ACCESS_KEY_ID = data["key_id"]
        AWS_SECRET_ACCESS_KEY = data["secret_id"]
        bucket_name = data['bucket_name']

        file_name = data['file_name']

        t = time.localtime()
        timestamp = time.strftime('%b-%d-%Y-%H%M', t)
        file_name_1 = file_name.split('.')  # file_name_1 = ['Omitvi','csv']     ['S1_Omitvi','csv']
        file_name_1.insert(-1, timestamp)  # file_name_2 = ['S1_Omitvi', 'Mar-20-2017-1302', 'csv']
        file_name_3 = '_'.join(file_name_1[:-1])  # file_name_3 = 'S1_Omitvi_Mar-20-2017-1302'
        destination_name = file_name_3 + '.csv'  # 'S1_Omitvi_Mar-20-2017-1302.csv'
        logger.error(str("Credentials part is OK!!!!"))
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'No data found in body.'})
    try:
        # connect to the bucket
        logger.error("here!!")
        logger.error(str(AWS_ACCESS_KEY_ID))
        logger.error(str(AWS_SECRET_ACCESS_KEY))
        s3 = boto3.resource('s3', aws_access_key_id=AWS_ACCESS_KEY_ID, aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
        path = getattr(settings, "MEDIA_ROOT", settings.BASE_DIR + "/media/")
        s3.meta.client.download_file(bucket_name, file_name, path + destination_name)
        # conn = boto.connect_s3(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
        # logger.error(str("   : Connection established "))
        # bucket = conn.get_bucket(bucket_name, validate=False)
        # # get the key object of the given key, in the bucket
        # k = Key(bucket, file_name)
        # logger.error(str(" : able to get the bucket name"))
        logger.error("S3 file download is successful.")
    except Exception as e:
        logger.error(str(e))
        k = dict()
        k['Error'] = str(e)
        cursor = connection.cursor()
        logger.error("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) 
                                      values('{}','{}', json.dumps(k))""".format(request.session.get('ingest_id', -1),
                                                                                 request.session.get('user_id', -1)))
        cursor.execute("""INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) 
                                      values('{}','{}', json.dumps(k))""".format(request.session.get('ingest_id', -1),
                                                                                 request.session.get('user_id', -1)))
        connection.commit()
        return JsonResponse({'Failure': 'error in bucket name connection'})

    try:
        path += str(destination_name)
        logger.error(str(" : new path"))
        os.system("cp " + path + " orig.csv")
        orig_path = path
        # Create a detector which will try to detect the encoding of the file
        try:
            detector = UniversalDetector()
            for line in open(path, 'rb').readlines():
                detector.feed(line)
                if detector.done:
                    break
            detector.close()
            # get the encoding of the file and then run iconv -f command to change encoding into utf-8
            # and save the output into temp_foobar.csv file.
            # After that rename that file into original file name
            encoding = detector.result['encoding']
            os.system('iconv -f ' + encoding + ' -t utf-8 ' + path + ' > temp_foobar.csv')
            os.system('mv temp_foobar.csv ' + path)
        except Exception as e:
            # If an exception occur recover the original file from backup
            logger.error("Exception while trying to change the encoding")
            logger.error(str(e))
            os.system("mv orig.csv " + orig_path)

        # Set the execute permission.
        os.system("chmod a+rX " + settings.MEDIA_ROOT + " " + path)
        uid = request.session['user_id']
        connection_type = 'Amazon_S3_bucket'

        try:
            header = headerCSV(path, request)
            if header:
                pass
            else:
                raise TypeError("Cannot find header")
            length = 12
            chars = string.ascii_letters + string.digits + '!@#$%^&*()'
            random.seed = (os.urandom(1024))
            source_id = ''.join(random.choice(chars) for _ in range(length))
            sourcename = path.split("/")[-1]
            logger.error(str(sourcename))
            # sourcename = 'S1_Omitvi_<timestamp>.csv'
            new_source = sourcename.split('_')  # new_source = ['S1','Epsilon','<timestamp>.csv']
            new_list = new_source[:-1]  # ['S1','Epsilon']
            cursor = connection.cursor()
            cursor.execute("SELECT func_fetch_source_priority('{}')".format(new_list[-1]))
            logger.error(str("source priority is working fine"))
            s_priority = str(cursor.fetchall()[0][0])
            print("s_priority: ")
            print(s_priority)
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO ingestion_sources(source_id, ingest_id, uid, conn_method, conn_string, source_name, header,"
                " source_priority) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}','{}')".format(source_id,
                                                                                                  request.session[
                                                                                                      'ingest_id'], uid,
                                                                                                  connection_type, path,
                                                                                                  sourcename, header,
                                                                                                  s_priority))
            connection.commit()
            logger.error(str("Success done!!!"))
            request.session['source_id'] = source_id
            logging.debug("Values inserted into ingestion table")
            # request.session['conn_type'] = 'csv'

        except Exception as e:
            logging.error(str(e))

        logger.error("Path of file: " + str(path))
        request.session['file'] = str(path)
        flow_flags(request.session['ingest_id'], uid, '2')

        return JsonResponse({'ok': 'success'})
    except Exception as e:
        logger.error(str(e))
        return JsonResponse({'failure': 'connection or file path error'})
