angular.module('mdm').filter('filterCheckNull', function() {
   'use strict';
   return function(input) {
     if (input == 'NULL') {
       return ''
     } else {
       return ':  ' + input
     }
   };
});
