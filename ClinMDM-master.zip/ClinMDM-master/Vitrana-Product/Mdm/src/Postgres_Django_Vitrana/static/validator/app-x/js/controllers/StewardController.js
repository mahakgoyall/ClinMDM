angular.module('mdm').controller('StewardController', ['$window','$mdToast','MDMService','$mdDialog','$scope','$uibModal','taskList','toaster','ngDialog', function($window,$mdToast,MDMService,$mdDialog,$scope,$uibModal,taskList,toaster,ngDialog) {
    var _self = this
    _self.requestInProgress = false
    _self.inserting = false
    _self.discarding = false
    _self.grabbingTask = false
    _self.fetchingList = false
    _self.sourceUsing = []
    _self.sourceKeysInUse = []
    _self.modalInstance = ''
    _self.pageNumber = 1
    _self.taskListPageNumber = 1
    _self.toHideList = ["column_list","mdm","keys"]
    console.log(taskList);
    if(taskList.failure){
      toaster.error('Error',taskList.failure)
    }
    _self.taskList = angular.copy(taskList)
    // if(_self.taskList.total_task != 0){
      // _self.taskList = _self.taskList.data
      _self.totalTasks = _self.taskList.total_task
      if(_self.totalTasks != 0){
        _self.totalTaskPages = Math.ceil(_self.taskList.total_task/10)
      }
      else {
        _self.totalTaskPages = 1
      }
      // _self.arrFromMyObj = Object.keys(_self.taskList).map(function(key) {
      // return _self.taskList[key];
      // });
    // }
    // MDMService.getIngestionsSteward().then(function(response){
    //   console.log(response)
    //   _self.ingestionList = response
    //   _self.requestInProgress = false
    // })
    _self.toHide = function(column){
      if (_self.toHideList.includes(column)){
        return true
      }
      else {
        return false
      }
    }
    //
    // _self.lookup = {
    //   9 : "Unresolved",
    //   10: "Resolved",
    //   11: "Discarded"
    // }
    // _self.ingestionList = ingestions
    // console.log(_self.ingestionList);
    _self.formData = {}
    _self.taskListForm  = {
      "username" : '',
      "ingest_name" : ''
    }
    _self.getPriorityMaster = function($index,value){
      if($index !=0 && value)
      return {
        'background': '-webkit-linear-gradient(left, lightgrey ' + _self.taskDetail.mdm_priority[$index] + '%, white 0%)'
      }
    }
    _self.getPriority = function(key,value,$index,x){
      var toSkip = ['column_list','index','mdm_priority','keys']
      if(!toSkip.includes(key)){
        if(key != 'mdm'){
          if($index == 0){
          }
          else if (x) {
            return {
              'background': '-webkit-linear-gradient(left, lightgrey ' + value[value.length-1] + '%, white 0%)'
            }
          }
        }
      }
    }

    _self.confirmationDialog = function(action,key){
      _self.action = action
      if(key){
        _self.toInsert = key
      }
      _self.instance = ngDialog.open(
        { template: 'confirmation.html',
          scope:$scope,
          className: 'ngdialog-theme-plain',
          closeByDocument : false,
          showClose : false,
          closeByNavigation :true
        });
    }

    _self.closeConfirmation = function(){
      _self.instance.close()

    }

    _self.performAction = function(){
      _self.instance.close()
      if(_self.action == 'Insert into MDM'){
        _self.sendToMDM(_self.toInsert)
      }
      else if(_self.action == 'Discard the task'){
        _self.discardTask()
      }
    }

    _self.getTaskList  = function(ingestion,username){
      _self.taskListForm.ingest_name = ingestion
      _self.taskListForm.username = username
      _self.fetchingList = true
      MDMService.getTasks(_self.taskListPageNumber,{}).then(function(response){
        _self.fetchingList = false
        console.log(response);
        if(response.failure){
          toaster.error("Error",response.failure)
        }
        else {
          // if(_self.ingestionList == ''){
          //
          // }
          // else{
          // _self.temp = angular.copy(_self.ingestionList)
          // _self.ingestionList = ''
          // }
          _self.taskList = angular.copy(response)
          _self.totalTasks = response.total_task
          _self.totalTaskPages = Math.ceil(response.total_task/10)
          // _self.arrFromMyObj = Object.keys(_self.taskList).map(function(key) {
          // return _self.taskList[key];
          // });
        }

      })
    }

    _self.refreshTaskList = function(){
      _self.getTaskList(_self.taskListForm.ingest_name,_self.taskListForm.username)
    }

    _self.back = function(){
      _self.taskList = ''
      _self.ingestionList = _self.temp
      _self.taskListPageNumber = 1
    }

    _self.getTaskDetail = function(task){
      _self.grabbingTask = true
      _self.TaskDetailForm = {
    	"username" : _self.taskListForm.username,
    	"ingest_name" : _self.taskListForm.ingest_name,
    	"task_id" :  task.task_id
      // "type"    : task.type
    	}
      console.log(_self.TaskDetailForm);
      _self.selected = task.task_id
      _self.formData = {}
      MDMService.getTaskDetail(_self.TaskDetailForm).then(function(response){
        _self.grabbingTask = false
        console.log(response)
        _self.taskDetail = response
        for (i=0;i<response.keys.length;i++){
          var temp = response.keys[i]
          _self.formData[temp] = {
            "value" : "",
            "priority" : ""
          }
        }
        console.log(_self.formData)
        var temp1 = "mdm_id"
        var temp2  = "mdm"
        if (_self.taskDetail[temp2]){
          _self.formData[temp1].value = _self.taskDetail[temp2][0]
        }
        _self.modalInstance = $uibModal.open({
         animation: true,
         size : 'lg',
         templateUrl: 'stewardModal.html',
         scope: $scope,
         backdrop: 'static',
         windowClass: 'steward-modal-window'
       });
      //  _self.modalInstance.opened.then(function(response){
      //    setTimeout(function(){
      //      $('#example1').progress();
      //    }, 200);
      //  })


      })
    }


    _self.viewTask = function(task){
      var TaskDetailForm = {
      // "username" : task.username,
      // "ingest_name" : task.ingest_name,
      "task_id" :  task.task_id
      // "type"    : task.type
      }
      console.log(TaskDetailForm);
      _self.grabbingTask = true
      MDMService.getTaskDetail(TaskDetailForm).then(function(response){
        _self.grabbingTask = false
        console.log(response)
        _self.taskDetail = angular.copy(response)
        _self.modalInstance = $uibModal.open({
         animation: true,
         size : 'lg',
         templateUrl: 'detail.html',
         scope: $scope,
         backdrop: 'static',
         windowClass: 'steward-modal-window'
       });

     })
    }

    _self.changeValue = function(index,value,params){
      // var key = _self.taskDetail.column_list[index]
      // _self.formData[key] = value
      // console.log(_self.formData)
      if (params == 'master'){
        console.log(index);
        var key = _self.taskDetail.keys[index]
        _self.formData[key].value = value
        _self.formData[key].priority = _self.taskDetail.mdm_priority[index]
        console.log(_self.formData)
      }
      else {
        var key = _self.taskDetail.keys[index-1]
        _self.formData[key].value = value
        _self.formData[key].priority = _self.taskDetail[params][_self.taskDetail[params].length - 1]
        _self.sourceKeysInUse[key] = params
        // if(_self.sourceUsing.includes(_self.taskDetail[params][1])){
        //
        // }
        // else {
        //   _self.sourceUsing.push(_self.taskDetail[params][1])
        //
        // }

        // console.log(_self.sourceUsing);
        // console.log(_self.taskDetail[params][1]);

      }
      // else {
      //   var temp = "mdm"
      //   if (_self.taskDetail[temp]){
      //     var key = _self.taskDetail.column_list[index-1]
      //     _self.formData[key] = value
      //     console.log(_self.formData)
      //   }
      //   else {
      //     var key = _self.taskDetail.column_list[index-2]
      //     _self.formData[key] = value
      //     console.log(_self.formData)
      //   }
      // }
    }

    _self.insertAllMaster = function(){
      angular.forEach(_self.taskDetail.mdm,function(value,key){
        var tempKey = _self.taskDetail.keys[key]
        console.log(tempKey);
        if(_self.formData[tempKey]){
            _self.formData[tempKey].value = value
        }
      })
      console.log(_self.formData);
    }

    _self.insertAll = function(key){
      console.log(key)
      var temp = angular.copy(_self.taskDetail[key])
      // temp.splice(0,1)
      temp.splice(temp.length-1,1)
      for (i=0;i<temp.length ;i++){

        var tempValue = temp[i]
        var tempKey = _self.taskDetail.keys[i]
        if (tempKey == 'mdm_id'){
          continue;
        }
        if(_self.formData[tempKey]){
          _self.sourceKeysInUse[tempKey] = key
          _self.formData[tempKey].value = tempValue
          _self.formData[tempKey].priority = _self.taskDetail[key][_self.taskDetail[key].length-1]
        }

      }
      console.log("Insert all")
      console.log(_self.formData)
    }

    _self.sendToMDM = function(key){
      _self.inserting = true
      var tempForm = {}
      var temp = angular.copy(_self.taskDetail[key])
      // tempForm['record_id'] = temp[0]
      // temp.splice(0,1)
      temp.splice(temp.length-1,1)
      for (i=0;i<temp.length ;i++){
        // var tempValue = temp[i]
        var tempValue = {
          "value" : "",
          "priority" : ""
        }
        tempValue.value = temp[i]
        var tempKey = _self.taskDetail.keys[i]
        if (tempKey == 'mdm_id'){
          tempForm[tempKey] = tempValue
          continue;
        }
        tempValue.priority = _self.taskDetail[key][_self.taskDetail[key].length-1]
        tempForm[tempKey] = tempValue
      }
      console.log("send to mdm")
      tempForm['source_name']  = _self.taskDetail[key][_self.taskDetail[key].length - 2]
      console.log(tempForm)
      MDMService.insertMDM(_self.selected,tempForm).then(function(response){
        console.log(response)
        if(response.failure){
          $mdToast.showSimple(response.failure)
          _self.inserting = false
        }
        else {
          toaster.success("Success","Successfully Inserted into MDM")
          var temp = 1
          console.log(_self.taskDetail);
          if(_self.taskDetail[temp]){
            _self.formData = {}
	          _self.taskDetail = ''
      	    _self.TaskDetailForm = {
          		"username" : _self.taskListForm.username,
          		"ingest_name" : _self.taskListForm.ingest_name,
          		"task_id" : _self.selected
                // "type"     : _self.TaskDetailForm.type
          	}
          	console.log(_self.TaskDetailForm)
            MDMService.getTaskDetail(_self.TaskDetailForm).then(function(response){
              console.log(response)
              _self.taskDetail = response
              for (i=0;i<_self.taskDetail.keys.length;i++){
                var temp = _self.taskDetail.keys[i]
                _self.formData[temp] = ''
              }
              console.log(_self.taskDetail)
              var temp1 = "mdm_id"
              var temp2  = "mdm"
              if (_self.taskDetail[temp2]){
                _self.formData[temp1] = _self.taskDetail[temp2][0]
              }
            })
          }
          else{
              _self.refreshTaskList()
              _self.closeModal()
          }
          _self.inserting = false

        }
      })
    }


    // _self.insertAllSource = function(key,index){
    //   for (i=1;i<_self.taskDetail.column_list.length;i++){
    //     var tempValue = _self.taskDetail[key][index][0][i]
    //     var tempKey = _self.taskDetail.column_list[i]
    //
    //     _self.formData[tempKey] = tempValue
    //   }

    _self.toHide = function($index){
      var temp = "mdm"
      if (_self.taskDetail[temp] && $index == 0){
        return true
      }
      else if (_self.taskDetail[temp] && $index == 1){
        return false
      }
      else if ($index == 0 || $index == 1){
        return true
      }
      else {
        return false
      }
    }

    _self.submit = function(){
      var flag = false
      angular.forEach(_self.formData,function(value,key){
        var toSkip = ['stage_id','source_id','source_name','mdm_id']
        if(toSkip.includes(key)){

        }
        else {
          if(value.value == ''){

          }
          else{
            flag = true
          }
        }
      })
      if(flag){
        _self.formData['source_name']  = _self.taskDetail[0][_self.taskDetail[0].length - 2]
        var unique = []
        console.log(_self.sourceKeysInUse);
        // angular.forEach(_self.sourceKeysInUse,function(value,key){
        //   if(unique.includes(value)){
        //
        //     console.log(value);
        //   }
        //   else {
        //     console.log(value);
        //
        //     unique.push(value)
        //   }
        // })
        var keys = Object.keys(_self.sourceKeysInUse)
        for(i=0;i<keys.length;i++){
          if(unique.includes(_self.sourceKeysInUse[keys[i]])){
          }
          else {
            unique.push(_self.sourceKeysInUse[keys[i]])
          }
        }
        _self.formData['stage_id'] = {
          'priority'    : '',
          'value'       : []
        }
        _self.formData['source_id'].value = []
        for(i=0;i<unique.length;i++){
          var temp = unique[i]
          console.log(unique);
          _self.formData['source_id'].value.push(_self.taskDetail[temp][1])
          _self.formData['stage_id'].value.push(_self.taskDetail[temp][0])
        }
        console.log(_self.formData);
        var temp = "mdm"
        if (_self.taskDetail[temp]){
          MDMService.updateGolden(_self.formData,_self.selected).then(function(response){
            console.log(response)
            MDMService.getTasks(_self.taskListPageNumber,{}).then(function(response){
              console.log(response)
              _self.taskList = angular.copy(response)
            })
            _self.closeModal()
          })
        }
        else {
          var temp = "mdm_id"
          _self.formData[temp] = -1;
          MDMService.updateGolden(_self.formData,_self.selected).then(function(response){
            console.log(response)
            MDMService.getTasks(_self.taskListPageNumber,_self.taskListForm).then(function(response){
              console.log(response)
              _self.taskList = angular.copy(response)
            })
            _self.closeModal()
          })

        }
      }
      else {
        toaster.error('Error','Select from atleast one source to update.')
        return
      }

      // MDMService.updateGolden(_self.formData,_self.selected).then(function(response){
      //   console.log(response)
      //   MDMService.getTasks().then(function(response){
      //     _self.taskList = response
      //     _self.requestInProgress = false
      //   })
      //   _self.closeModal()
      // })
    }

    _self.closeModal = function(){
      _self.modalInstance.dismiss('cancel');

    }
    _self.cancel = function () {
        _self.modalInstance.dismiss();
    };
    _self.discardTask = function() {
      console.log(_self.selected);
      _self.discarding = true
      MDMService.discardTask(_self.selected).then(function(response) {
        _self.requestInProgress = true
        _self.discarding = false
        console.log(response);
        if (response.failure){
          _self.requestInProgress = false
          $mdToast.show($mdToast.simple()
          .textContent(response.failure))
        }
        else {
          _self.closeModal()
          // _self.taskListPageNumber = 1
          _self.refreshTaskList()
          _self.requestInProgress = false
          toaster.pop('success', "Success", "Task Discarded");
        }
      })
    }

    // _self.modifyRecord= function(record){
    //   _self.selected = record
    //   console.log(record)
    //   console.log(_self.formData)
    //   _self.requestInProgress = true
    //   MDMService.getTaskDetail(record).then(function(response){
    //     _self.requestInProgress = false
    //     _self.taskDetail = response
    //     for (i=0;i<_self.taskDetail.column_list.length;i++){
    //       var temp = _self.taskDetail.column_list[i]
    //       _self.formData[temp] = ''
    //     }
    //     var temp = "MASTER RECORD"
    //     if (_self.taskDetail[temp][0][0]){
    //       _self.formData.Id = _self.taskDetail[temp][0][0][0]
    //     }
    //       console.log(response)
    //     _self.modalInstance = $uibModal.open({
    //      animation: true,
    //      size : 'lg',
    //      templateUrl: 'stewardModal.html',
    //      scope: $scope,
    //      windowClass: 'steward-modal-window'
    //    });
    //  })
    // }
    //
    //
    //
    // _self.submit = function(){
    //   console.log(_self.formData)
    //   MDMService.updateGolden(_self.formData,_self.selected).then(function(response){
    //     console.log(response)
    //     MDMService.getTasks().then(function(response){
    //       _self.taskList = response
    //       _self.requestInProgress = false
    //     })
    //     _self.closeModal()
    //   })
    // }
    //
    // _self.closeModal = function(){
    //   _self.modalInstance.dismiss('cancel');
    //
    // }
    //
    // _self.insertAll = function(key){
    //   console.log(key)
    //   for (i=1;i<_self.taskDetail.column_list.length;i++){
    //     var tempValue = _self.taskDetail[key][0][0][i]
    //     var tempKey = _self.taskDetail.column_list[i]
    //
    //     _self.formData[tempKey] = tempValue
    //   }
    // }
    //
    // _self.insertAllSource = function(key,index){
    //   for (i=1;i<_self.taskDetail.column_list.length;i++){
    //     var tempValue = _self.taskDetail[key][index][0][i]
    //     var tempKey = _self.taskDetail.column_list[i]
    //
    //     _self.formData[tempKey] = tempValue
    //   }
    // }

    _self.changePage = function() {
      // _self.requestInProgress = true
      if(!_self.taskList){
        MDMService.getIngestionsSteward(_self.pageNumber).then(function(response){
          // _self.requestInProgress = false
          console.log(response);
          _self.ingestionList = response
          // if (response.total == 0){
          //   _self.toShow = false
          // } else {
          //   _self.toShow = true
          // }
        })
      }
      else {
        _self.fetchingList = true
        MDMService.getTasks(_self.taskListPageNumber,{}).then(function(response){
          _self.fetchingList = false
          console.log(response);
            // if(_self.ingestionList == ''){
            //
            // }
            // else{
            // _self.temp = angular.copy(_self.ingestionList)
            // _self.ingestionList = ''
            // }
            _self.taskList = angular.copy(response)
            console.log(_self.taskList);
            // _self.arrFromMyObj = Object.keys(_self.taskList).map(function(key) {
            // return _self.taskList[key];
            // });
        })
      }

    }


}])
