angular.module('mdm').controller('DataMapController', ['$window', 'MDMService', '$scope', 'columnsList','toaster','$uibModal','selfInfo','selectedIngestion','ngDialog','$rootScope','$timeout', function($window, MDMService, $scope, columnsList,toaster,$uibModal,selfInfo,selectedIngestion,ngDialog,$rootScope,$timeout) {
  var _self = this

  _self.rawcolumns = columnsList
  console.log(_self.rawcolumns);
  console.log(selectedIngestion);
  if(_self.rawcolumns.failure ||  selectedIngestion.failure){
    toaster.error("Error","You have to select an ingestion first.")
    $window.location.href = "#/" + $rootScope.entityInUse + "/ingestions";
    return;
  }
  _self.ingestionInfo = selectedIngestion
  _self.sources = Object.keys(_self.ingestionInfo.sources)
  _self.advancedToSkip = ['uppercase','lowercase','concate','decode','substring']

  _self.selectedSource = _self.sources[0]
  _self.requestInProgress = false
  _self.ongoingDataMigration = false
  _self.finishMapping = false
  _self.selectedAction = ''
  _self.showOptions = false
  _self.concatData = false
  _self.uppercaseData = false
  _self.lowercaseData = false
  _self.finalList = []
  _self.SourceColList = []
  _self.TargetColList = []
  _self.SourceCol = ''
  _self.TargetCol = ''
  _self.selectedConcatSource = ""
  _self.selectedConcatTarget = ""
  _self.selectedDecodeSource = ""
  _self.selectedDecodeTarget = ""
  _self.selectedSubStringTarget = ""
  _self.selectedSubStringSource = ""
  _self.selectedSubStringLength = null
  _self.selectedSubStringPosition = null
  _self.selectedUpperSource = ""
  _self.selectedUpperTarget = ""
  _self.selectedLowerSource = ""
  _self.selectedLowerTarget = ""
  _self.isSelected = ''
  _self.toView = 'simple'
  _self.concat = {
    'concate' : {}
  }
  _self.substring = {
    'substring' : []
  }
  _self.decode = {
    'decode' : []
  }
  _self.lowercase = {
  }
  _self.uppercase = {
  }
  _self.decodeConditions = [{
    "find" : "",
    "replace" : ""
  }]

  //To copy existing mapping/Preloading
  _self.copyMappings = function(){
    angular.forEach(_self.ingestionInfo.sources[_self.selectedSource].mapping,function(value,key){
      var toSkip = ["concate","decode","substring","uppercase","lowercase"]
      if(key == 'concate'){
        _self.concat.concate = value
      } else if (key == 'decode') {
        _self.decode.decode = value
      }else if (key == 'lowercase') {
        _self.lowercase = value
      }else if (key == 'uppercase') {
        _self.uppercase = value
      }
       else if (key == 'substring') {
        _self.substring.substring = value
      } else{
        _self.SourceColList.push(key);
        _self.TargetColList.push(value);
        _self.finalList.push({
          "source" : key,
          "target" : value
        })
      }
    })
    _self.tempMappings = angular.copy(_self.finalList)
  }




  _self.change = function(){
    console.log(_self.selectedSubStringLength);
  }

  // To only show columns which aren't used
  _self.columnsToShow = function(){
    var toShow = angular.copy(_self.rawcolumns)
    if(_self.finalList.length > 0){
      angular.forEach(_self.finalList,function(value,key){
        if (toShow.includes(value.target)) {
          var tempIndex = toShow.indexOf(value.target)
          toShow.splice(tempIndex,1)
        }
      })
    }
    if(_self.decode.decode.length > 0){
      angular.forEach(_self.decode.decode,function(value,key){
        if(toShow.includes(value.target_name)){
          var tempIndex = toShow.indexOf(value.target_name)
          toShow.splice(tempIndex,1)
        }
      })
    }
    if(_self.substring.substring.length > 0){
      angular.forEach(_self.substring.substring,function(value,key){
        if(toShow.includes(value.target_name)){
          var tempIndex = toShow.indexOf(value.target_name)
          toShow.splice(tempIndex,1)
        }
      })
    }
    if( _self.concat.concate && (Object.keys(_self.concat.concate)).length > 0){
      _self.concatData = true
      angular.forEach(_self.concat.concate,function(value,key){
        if(toShow.includes(key)){
          var tempIndex = toShow.indexOf(key)
          toShow.splice(tempIndex,1)
        }
      })
    }

    if( _self.uppercase && (Object.keys(_self.uppercase)).length > 0){
      _self.uppercaseData = true
      angular.forEach(_self.uppercase,function(value,key){
        if(toShow.includes(value)){
          var tempIndex = toShow.indexOf(value)
          toShow.splice(tempIndex,1)
        }
      })
    }

    if( _self.lowercase && (Object.keys(_self.lowercase)).length > 0){
      _self.lowercaseData = true
      angular.forEach(_self.lowercase,function(value,key){
        if(toShow.includes(value)){
          var tempIndex = toShow.indexOf(value)
          toShow.splice(tempIndex,1)
        }
      })
    }

    if(_self.concat.concate && (Object.keys(_self.concat.concate)).length == 0){
      _self.concatData = false
    }
    if( _self.uppercase && (Object.keys(_self.uppercase)).length == 0){
      _self.uppercaseData = false
    }
    if( _self.lowercase && (Object.keys(_self.lowercase)).length == 0){
      _self.lowercaseData = false
    }

    _self.toShow = angular.copy(toShow)
    return toShow
  }

  _self.toShow = angular.copy(_self.columnsToShow())
  //If mapping already exists
  console.log(_self.ingestionInfo);
  console.log(_self.selectedSource);
  console.log(_self.ingestionInfo.sources[_self.selectedSource]);
  if (_self.ingestionInfo.sources) {
    if (_self.ingestionInfo.sources.length != 0) {
      if (_self.ingestionInfo.sources[_self.selectedSource].mapping) {
        _self.copyMappings()
      }
    }
  }
  // if(_self.ingestionInfo.sources[_self.selectedSource].mapping){
  // }

  _self.addDecodeCondition = function(){
    _self.decodeConditions.push({
      "find" : "",
      "replace" : ""
    })
    console.log(_self.decodeConditions);
  }
  _self.removeDecodeCondition = function(index){
    _self.decodeConditions.splice(index,1)
  }

  // setTimeout(function () {
  //   $('.selection.dropdown.column')
  //   .dropdown({
  //     forceSelection: false
  //   })
  // ;
  // }, 500);

  _self.addDecode = function(){
    var tempObj = {}
    tempObj['source_name'] = _self.selectedDecodeSource
    tempObj['target_name'] = _self.selectedDecodeTarget
    angular.forEach(_self.decodeConditions,function(value,key){
      if(value.find == '' && value.replace == ''){

      }
      else {
        tempObj[value.find] = value.replace
      }
    })
    _self.decode.decode.push(tempObj)
    _self.selectedDecodeSource = ''
    _self.selectedDecodeTarget = ''
    _self.decodeConditions = [{
      "find" : "",
      "replace" : ""
    }]
    $('.ui.search.decode.dropdown').dropdown('clear')
    // _self.columnsToShow()
  }
  _self.addConcat = function(){
    var tempKey = _self.selectedConcatTarget
    _self.concat.concate[tempKey] = _self.selectedConcatSource
    console.log(_self.concat);
    _self.selectedConcatSource = ""
    _self.selectedConcatTarget = ""
    $timeout(function() {
      // $('.ui.search.concate.dropdown').dropdown('restore defaults')
      $('.ui.concate.dropdown').dropdown('restore defaults')
    });
  }
  _self.addLower = function(){
    var tempKey = _self.selectedLowerSource
    _self.lowercase[tempKey] = _self.selectedLowerTarget
    console.log(_self.lowercase);
    _self.selectedLowerSource = ""
    _self.selectedLowerTarget = ""
    $timeout(function() {
      // $('.ui.search.concate.dropdown').dropdown('restore defaults')
      $('.ui.lowercase.dropdown').dropdown('restore defaults')

    });
  }
  _self.addUpper = function(){
    var tempKey = _self.selectedUpperSource
    _self.uppercase[tempKey] = _self.selectedUpperTarget
    console.log(_self.uppercase);
    _self.selectedUpperSource = ""
    _self.selectedUpperTarget = ""
    $timeout(function() {
      $('.ui.uppercase.dropdown').dropdown('restore defaults')
    });
  }
  _self.addSubstring = function(){
    var tempObj = {}
    tempObj['source_name'] = _self.selectedSubStringSource
    tempObj['target_name'] = _self.selectedSubStringTarget
    tempObj['position'] = _self.selectedSubStringPosition
    tempObj['length'] = _self.selectedSubStringLength
    _self.substring.substring.push(tempObj)
    console.log(_self.substring);
    _self.selectedSubStringTarget = ""
    _self.selectedSubStringSource = ""
    _self.selectedSubStringLength = ""
    _self.selectedSubStringPosition = ""
    $('.ui.search.substring.dropdown').dropdown('clear')
  }
  _self.deleteConcat = function(key){
    delete _self.concat.concate[key]
  }
  _self.deleteDecode = function(index){
    _self.decode.decode.splice(index,1)
  }
  _self.deleteSubstring = function(index){
    _self.substring.substring.splice(index,1)
  }
  _self.deleteLowercase = function(key){
    delete _self.lowercase[key]
  }
  _self.deleteUppercase = function(key){
    delete _self.uppercase[key]
  }
  _self.actions = ["Concat" , "Decode" , "Substring" , "Uppercase" , "Lowercase"]
  setTimeout(function(){
    $('.ui.small.dropdown')
    .dropdown({
      direction: 'auto',
      preserveHTML	: false
    })
  ;
  }, 200);

    if (_self.rawcolumns.failure){
      _self.migrateData = true
    }
    else {
      _self.migrateData = false
    }



  _self.viewMappings = function(){
    _self.modalInstance = $uibModal.open({
      animation: true,
      templateUrl: 'mappings.html',
      backdrop: 'static',
      size: 'lg',
      scope: $scope
    })
  }
  _self.viewDecodeConditions = function(decode){
    _self.decodeToView = decode
    _self.modalDecode = $uibModal.open({
      animation: true,
      templateUrl: 'conditions.html',
      backdrop: 'static',
      size: 'sm',
      scope: $scope
    })
  }

  _self.closeDecodeConditions = function(){
    _self.modalDecode.dismiss();
  }






  _self.changeSource = function(key){
    // If mapping already exists
    $rootScope.isSomethingLeft = false
    _self.selectedSource = key
    // _self.finalList = []
    // _self.SourceColList = []
    // _self.TargetColList = []
    // if(_self.ingestionInfo.sources[_self.selectedSource].mapping){
    //   _self.copyMappings()
    // } else {
    //   _self.finalList = []
    //   _self.SourceColList = []
    //   _self.TargetColList = []
    //   _self.tempMappings = []
    // }
  }


  _self.automap = function(){
    _self.instance = ngDialog.open({
        template: 'prompt.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }



  _self.suggestMappings = function(){
    _self.closeWarning()
    _self.concat = {
      'concate' : {}
    }
    _self.substring = {
      'substring' : []
    }
    _self.decode = {
      'decode' : []
    }
    _self.lowercase = {
    }
    _self.uppercase = {
    }
    _self.decodeConditions = [{
      "find" : "",
      "replace" : ""
    }]
    _self.formData = {
      "source" : [],
      "target" : []
    }
    _self.SourceColList = []
    _self.TargetColList = []
    for (i=0;i<_self.rawcolumns.length;i++){
      if(_self.rawcolumns[i] == null){
        continue;
      }
      // else if(!_self.columnsToShow().includes(_self.rawcolumns[i])){
      //
      // }
      else {
        _self.formData.target.push(_self.rawcolumns[i])

      }
    }
    for (i=0;i<_self.ingestionInfo.sources[_self.selectedSource].header.length;i++){
      _self.formData.source.push(_self.ingestionInfo.sources[_self.selectedSource].header[i])

    }
    console.log(_self.formData);
    _self.requestInProgress = true
    $rootScope.isSomethingLeft  = true
    MDMService.suggestMappings(_self.formData).then(function(response){
      console.log(response);
      _self.requestInProgress = false
      _self.finalList = response
      for(i=0;i<response.length;i++) {
        _self.SourceColList.push(response[i].source);
        _self.TargetColList.push(response[i].target);
      }
    },function(error){
      toaster.error('error',error)
      _self.requestInProgress = false
    })
  }




  _self.emptySuggest = function () {

    if(_self.toView == 'simple'){
      _self.SourceColList = []
      _self.TargetColList = []
      _self.finalList = []
      $rootScope.isSomethingLeft  = false
      if(_self.ingestionInfo.sources[_self.selectedSource].mapping){
        if((angular.toJson(_self.tempMappings)) != (angular.toJson(_self.finalList))){
          $rootScope.isSomethingLeft = true
        }
      }
    }
    else if(_self.toView  == 'concat'){
      _self.concat.concate = {}
      _self.concatData = false
    }
    else if (_self.toView == 'decode') {
      _self.decode.decode = []
    }
    else if( _self.toView == 'substring') {
      _self.substring.substring = []
    }
    else if(_self.toView  == 'lowercase'){
      _self.lowercase = {}

    }
    else if(_self.toView  == 'uppercase'){
      _self.uppercase = {}

    }
  }


_self.selectAction = function(action){
  _self.selectedAction = action
  if(action == 'Concat'){
    _self.currentMessage = "Select multiple source columns from left and a target column from right."
  }
  else if(action == 'Decode'){
    _self.currentMessage = "Select respective columns from left and right."
  }
  else if(action == 'Substring'){
    _self.currentMessage = "Select respective columns from left and right."
  }
}



  _self.performAction = function(action){
      _self.modalInstance = $uibModal.open({
        animation: true,
        templateUrl: action.toLowerCase() +  '.html',
        backdrop: 'static',
        size: 'lg',
        scope: $scope
      })
      _self.isSelected = action
  }


 _self.copysource = function(col) {

   if(_self.selectedAction == ''){
     _self.currentMessage = "Select Action"
     _self.showOptions = true
     _self.SourceCol = []
     _self.SourceCol.push(col)
   }
   console.log(_self.SourceCol);
   if(_self.selectedAction  == 'Concat'){
     _self.SourceCol.push(col)
   }
   else {
     _self.SourceCol = col
   }
 }

 _self.copytarget = function(col) {
   console.log(col);
   console.log(_self.SourceCol);
   if(_self.SourceCol === '' || !_self.SourceCol) {
    //  toaster.pop('warning', "Select Proper Data", "You have mapped \"" + _self.SourceCol + "\" to \"" + _self.TargetCol + "\"", 1000, 'trustedHtml');
     return;
   }
   else if(_self.TargetColList.includes(col)){
     return;
   }
  else {
     _self.TargetCol = col
     _self.pushdatatoarray()
   }
 }
 _self.checksourcecolinarray =  function(col){
   var arr = _self.SourceColList
   return arr.some(function(arrVal) {
    return col === arrVal;
  });
 }
 _self.checktargetcolinarray =  function(col){
   var arr = _self.TargetColList
   return arr.some(function(arrVal) {
    return col === arrVal;
  });
 }
 _self.checkInSourceCol = function (col) {
  //  console.log(_self.SourceCol);
   var arr = _self.SourceCol
   var x = arr.indexOf(col)
   if (col === arr) {
     return true
   } else {
     return false
   }
  //  if (x > -1) {
  //    console.log(_self.SourceCol);
  //    return true
  //  } else {
  //    return false
  //  }
 }
_self.pushdatatoarray = function() {
  _self.currentmap = {
    'source' : _self.SourceCol,
    'target' : _self.TargetCol
  }
  var x = _self.SourceColList.indexOf(_self.SourceCol);
  var y = _self.TargetColList.indexOf(_self.TargetCol);
  if(x > -1) {
   return;
  } else {
    _self.SourceColList.push(_self.SourceCol);
  }
  if(y > -1) {
   return;
  } else {
   _self.TargetColList.push(_self.TargetCol)
  }


  if(x > -1 && y > -1) {
    toaster.pop('error', "Error", "You have mapped \"" + _self.SourceCol + "\" to \"" + _self.TargetCol + "\"", 1000, 'trustedHtml');
  } else {
    _self.finalList.push(_self.currentmap)
    // toaster.pop('success', "Success", "You have mapped \"" + _self.SourceCol + "\" to \"" + _self.TargetCol + "\"", 1000, 'trustedHtml');
  }
  _self.SourceCol = ''
  _self.TargetCol = ''
  $rootScope.isSomethingLeft = true
  if((angular.toJson(_self.tempMappings)) == (angular.toJson(_self.finalList))){
    $rootScope.isSomethingLeft = false
  }
}
_self.removeitemfromarray = function(z) {
  _self.SourceCol = _self.finalList[z].source
  _self.TargetCol = _self.finalList[z].target
  var x = _self.SourceColList.indexOf(_self.SourceCol);
  var y = _self.TargetColList.indexOf(_self.TargetCol);
  if(x > -1) {
    _self.SourceColList.splice(x, 1);
  }
  if(y > -1) {
    _self.TargetColList.splice(y, 1);
  }
  if(z > -1) {
     _self.finalList.splice(z, 1);
  }
  _self.SourceCol = ''
  _self.TargetCol = ''
  $rootScope.isSomethingLeft = true
  if((angular.toJson(_self.tempMappings)) == (angular.toJson(_self.finalList))){
    $rootScope.isSomethingLeft = false
  }
}

  _self.submit = function() {
    _self.finalListData = []
    for(i=0;i<_self.finalList.length;i++) {
      _self.finalListDataObject = {
        'from' : 'Source Columns',
        'fromPort' : _self.finalList[i].source,
        'to' : 'Target Columns',
        'toPort' : _self.finalList[i].target
      }
      _self.finalListData.push(_self.finalListDataObject)
    }
    // if (_self.finalListData.length == 0){
    //   toaster.error("Error", "You have to select one column atleast.")
    //   return;
    // }

    // angular.forEach(_self.finalList,function(key,value){
    //   if(value.target == 'SOURCE_ID'){
    //
    //   }
    // })
    console.log(_self.TargetColList);
    if(_self.columnsToShow().includes('SOURCE_ID') || _self.columnsToShow().includes('STUDY ID')){
      _self.instance = ngDialog.open({
          template: 'required.html',
          scope:$scope,
          className: 'ngdialog-theme-plain',
          closeByDocument : false,
          showClose : false,
          closeByNavigation :true
        });

        return;
    }
    _self.ongoingDataMigration = true
     _self.toSend = {
       "data_mapping"    : _self.finalListData,
       "connection_type" : _self.ingestionInfo.sources[_self.selectedSource].conn_method,
       "source_id"       :  _self.ingestionInfo.sources[_self.selectedSource].source_id,
       "concate"         : _self.concat.concate,
       "decode"          : _self.decode.decode,
       "substring"       : _self.substring.substring,
       "lowercase"       : _self.lowercase,
       "uppercase"       : _self.uppercase
     }
     console.log(_self.toSend);
      MDMService.sendmapping(_self.toSend).then(function(response){
        console.log(response)
        if(response.ok) {
          _self.selectedMappings = angular.copy(response.ok)
          // toaster.success("Success", response.ok)
          _self.instance = ngDialog.open({
              template: 'success.html',
              scope:$scope,
              className: 'ngdialog-theme-plain',
              closeByDocument : false,
              showClose : false,
              closeByNavigation :true
            });
          $rootScope.isSomethingLeft = false
          MDMService.selectedIngestion().then(function(response){
            console.log(response);
            _self.ingestionInfo = response
            setTimeout(function(){
              $scope.$apply()

            }, 500);
          })
        }
        else {
          toaster.error("Error", response.failure)
        }
        _self.ongoingDataMigration = false
      })
  }

  _self.closeModal = function () {
    if (_self.modalInstance) {
      _self.modalInstance.dismiss();

      if (_self.isSelected == 'Concat') {
        _self.selectedConcatSource = ''
        _self.selectedConcatTarget = ''
        $('.ui.concate.dropdown').dropdown('restore defaults')
      } else if (_self.isSelected == 'Decode') {
        _self.selectedDecodeSource = ''
        _self.selectedDecodeTarget = ''
        _self.decodeConditions = [{
          "find" : "",
          "replace" : ""
        }]
        $('.ui.search.decode.dropdown').dropdown('clear')
      } else if(_self.isSelected == 'Substring') {
        _self.selectedSubStringTarget = ""
        _self.selectedSubStringSource = ""
        _self.selectedSubStringLength = ""
        _self.selectedSubStringPosition = ""
        $('.ui.search.substring.dropdown').dropdown('clear')
      }
      else if(_self.isSelected == 'Uppercase') {
        _self.selectedUpperSource = ""
        _self.selectedUpperTarget = ""
        $timeout(function() {
          $('.ui.uppercase.dropdown').dropdown('restore defaults')
        });
      }
      else if(_self.isSelected == 'Lowercase') {
        _self.selectedLowerSource = ""
        _self.selectedLowerTarget = ""
        $timeout(function() {
          $('.ui.lowercase.dropdown').dropdown('restore defaults')
        });
      }
    }
    else {
    }
  };

  _self.closeWarning = function(){
    _self.instance.close()

  }

  _self.finish = function(){
    // _self.modalInstance = $uibModal.open({
    //   animation: true,
    //   templateUrl: 'continue.html',
    //   backdrop: 'static',
    //   size: 'md',
    //   scope: $scope
    // })
    var flag = true
    angular.forEach(_self.ingestionInfo.sources,function(value,key){
      if(!value.mapping){
        flag = true
      }
      else {
        flag = false
      }
    })
    if(flag == false){
      _self.completed()
    }
    else {
      _self.instance = ngDialog.open({
          template: 'continue.html',
          scope:$scope,
          className: 'ngdialog-theme-plain',
          closeByDocument : false,
          showClose : false,
          closeByNavigation :true
        });
    }

    // if()

  }

  _self.completed = function(){
    _self.finishMapping = true
    MDMService.finishMapping().then(function(response){
      _self.finishMapping = false
      console.log(response);
      if(response.ok){
        if(_self.ingestionInfo.sources[_self.selectedSource].mapping != null){
          toaster.success("Success","Data sent for validation and mastering.")

        }
        $window.location.href = "#/" + $rootScope.entityInUse + "/ingestions";
      }
    })
  }
}]);
//
