angular.module('mdm').controller('loginController', ['$window','MDMService', function($window,MDMService) {
    var _self = this
    _self.showLogin = true
    _self.requestInProgress = false
    _self.username = ''
    _self.password = ''
    _self.submit = function() {
      if(_self.username == '' || _self.password == ''){
        _self.results = 'All fields are mandatory.'
      }
      else {
        _self.formdata = {
          "Username" : _self.username,
          "Password" : _self.password
        }
        _self.requestInProgress = true
        MDMService.sublogin(_self.formdata).then(function(response){
          console.log(response)
          if (response.Success) {
            if (response.Success.reset_flag == '0') {
              _self.requestInProgress = false
              window.location.href = "#/update"
            } else {
              _self.requestInProgress = false
              _self.results = "Success";
              $window.location.href='/';
            }
          } else {
            _self.requestInProgress = false
            _self.results = response.failure;
          }
        })
      }
    }
    _self.submitAgain = function() {
      if(_self.username == '' || _self.password == '' || _self.newpassword == '' || (_self.username == '' && _self.password == '' &&_self.newpassword == '') || _self.password != _self.newpassword) {
        // _self.init();
        _self.results = "Please recheck your entries.";
        return;
      } else {
        _self.formdata = {
          "username" : _self.username,
          "old_password" : _self.oldpassword,
          "password" : _self.password
        }
        _self.requestInProgress = true
        MDMService.changePassword(_self.formdata).then(function(response){
          // console.log(response)
          if (response.ok == 'Success') {
              _self.requestInProgress = false
              _self.results = "Password changed, redirecting to dashboard.";
              window.location.href='/';
          } else {
            _self.requestInProgress = false
            _self.results = "There is an error. Please try again after some time.";
          }
        })
      }
    }
    // _self.init = function() {
    //  $('.ui.form')
    // 	 .form({
    // 		 fields: {
    // 			 email: {
    // 				 identifier  : 'email',
    // 				 rules: [
    // 					 {
    // 						 type   : 'empty',
    // 						 prompt : 'Please enter your e-mail'
    // 					 },
    // 					 {
    // 						 type   : 'email',
    // 						 prompt : 'Please enter a valid e-mail'
    // 					 }
    // 				 ]
    // 			 },
    // 			 password: {
    // 				 identifier  : 'password',
    // 				 rules: [
    // 					 {
    // 						 type   : 'empty',
    // 						 prompt : 'Please enter your password'
    // 					 },
    // 					 {
    // 						 type   : 'length[6]',
    // 						 prompt : 'Your password must be at least 6 characters'
    // 					 }
    // 				 ]
    // 			 }
    // 		 }
    // 	 })
    // }
}])
