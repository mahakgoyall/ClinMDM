angular.module('mdm').controller('LoggerController', ['$window','$scope','MDMService','$uibModal', function($window,$scope,MDMService,$uibModal) {
  var _self = this

}])
