angular.module('mdm').controller('TaskController', ['$window', 'MDMService', '$scope','toaster','$uibModal','stewardList','updateTaskList', function($window, MDMService, $scope,toaster,$uibModal,stewardList,updateTaskList) {
  var _self = this
  $scope.Math = window.Math;
  _self.selectedTask = []

  _self.requestInProgress = false

  console.log(stewardList);
  _self.pageNumber = 1
  _self.stewardList = angular.copy(stewardList)
  console.log(updateTaskList);
  if(updateTaskList.success){
    MDMService.getTaskList(1).then(function(response){
      console.log(response);
      _self.taskList = angular.copy(response)
    })
  }

  _self.formData = {
    'task_ids' : [],
    'steward_id'  : null
  }

  _self.changePage = function(){
    _self.requestInProgress = true
    MDMService.getTaskList(_self.pageNumber).then(function(response){
      _self.requestInProgress = false
      console.log(response);
      _self.taskList = angular.copy(response)
    })
  }

  _self.submit = function(){
    _self.formData.task_ids = _self.selectedTask
    console.log(_self.formData);
    if( _self.formData.task_ids.length == 0 || _self.formData.steward_id == null ){
      toaster.error("Error","All fields are mandatory")
      return
    }
    _self.requestInProgress = true
    MDMService.assignTaskList(_self.formData).then(function(response){
      _self.requestInProgress = false
      console.log(response);
      if(response.success){
        toaster.success("Success", "Assigned successfully")
        _self.pageNumber = 1
        _self.changePage()
        _self.formData = {
          'task_ids' : [],
          'steward_id'  : null
        }
        _self.masterCheckbox = 'NO'
      }
      else if(response.failure){
        toaster.error("Falure", response.failure)

      }
    })
  }

  _self.getPriorityMaster = function($index,value){
    if($index !=0 && value)
    return {
      'background': '-webkit-linear-gradient(left, lightgrey ' + _self.taskDetail.mdm_priority[$index] + '%, white 0%)'
    }
  }
  _self.getPriority = function(key,value,$index,x){
    var toSkip = ['column_list','index','mdm_priority','keys']
    if(!toSkip.includes(key)){
      if(key != 'mdm'){
        if($index == 0){
        }
        else if (x) {
          return {
            'background': '-webkit-linear-gradient(left, lightgrey ' + value[value.length-1] + '%, white 0%)'
          }
        }
      }
    }
  }


  _self.getTaskDetail = function(task){
    _self.TaskDetailForm = {
    // "username" : task.username,
    // "ingest_name" : task.ingest_name,
    "task_id" :  task.task_id
    // "type"    : task.type
    }
    console.log(_self.TaskDetailForm);
    _self.requestInProgress = true
    MDMService.getTaskDetail(_self.TaskDetailForm).then(function(response){
      _self.requestInProgress = false
      console.log(response)
      _self.taskDetail = angular.copy(response)
      _self.modalInstance = $uibModal.open({
       animation: true,
       size : 'lg',
       templateUrl: 'detail.html',
       scope: $scope,
       backdrop: 'static',
       windowClass: 'steward-modal-window'
     });

   })
 }


 _self.addTask = function(x){
   if(x == 'all'){
     if(_self.masterCheckbox == 'NO'){
       _self.selectedTask = []
     }
     else {
       angular.forEach(_self.taskList.data,function(value,key){
         if(_self.selectedTask.includes(value.task_id)){
           // var tempIndex = _self.selectedIngestions.indexOf(value.ingest_name)
           // _self.selectedIngestions.splice(tempIndex,1)
         }
         else {
           _self.selectedTask.push(value.task_id)
         }
       })
     }
   }
   else {
     if(_self.selectedTask.includes(x)){
       // _self.selectedIngestions.
       var tempIndex = _self.selectedTask.indexOf(x)
       _self.selectedTask.splice(tempIndex,1)
     }
     else {
       _self.selectedTask.push(x)
     }

   }

 }


}]);
