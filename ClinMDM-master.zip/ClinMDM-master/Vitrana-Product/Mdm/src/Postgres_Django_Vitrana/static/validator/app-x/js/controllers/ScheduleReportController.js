angular.module('mdm').controller('ScheduleReportController', ['$window','MDMService','$scope','toaster','scheduleDetail','$route',function($window,MDMService,$scope,toaster,scheduleDetail,$route) {
  var _self = this
  console.log(scheduleDetail);
  _self.labels = ["Valued", "Null", "Empty"];
  _self.reportTypes = ["Landing", "Staging", "MDM Hub"];
  _self.data = [500,400,100];
  _self.graphHeight = 150
  _self.graphWidth = 150
  _self.options =  {
    responsive: false,
    maintainAspectRatio: false
  }

  $scope.Math = window.Math;

  _self.chartColors = ["#79913e","#395a85","#FD625E"]
  _self.goldenDataPageNumber = 1
  _self.rejectedDataPageNumber = 1
  _self.stagingDataPageNumber = 1
  _self.autoMergedDataPageNumber = 1
  _self.manuallyMergedDataPageNumber = 1
  _self.referentialAnalysisDataPageNumber = 1
  // _self.isCollapsed = true
  _self.clickedIndex = -1


  _self.pielabels = ["First", "Last Name"];
  _self.piedata = [5000,100];

  _self.reasonsData = []
  _self.reasonsLabel = []
  _self.noSourceAnalysisData = true
  _self.noMatchAnalysisData = true

  _self.back = function () {
    $window.history.back()

  }

  _self.getAutomerged = function(page,ingestion){
    var payload = {
      'page_no' : page,
      'ingest_id' : ingestion.ingest_id
    }
    MDMService.autoMergedRecords(payload).then(function(response){
      console.log(response);
      _self.autoMergedRecords = angular.copy(response)
    })
  }

  _self.getManuallyMerged = function(page,ingestion){
    var payload = {
      'page_no' : page,
      'ingest_id' : ingestion.ingest_id
    }
    console.log(payload);

    MDMService.manuallyMergedRecords(payload).then(function(response){
      console.log(response);
      _self.manuallyMergedRecords = angular.copy(response)

    })
  }
  _self.selectIngestion = function(x){
    var ingestion = x

    var tempForm = {
      'ingest_id' : ingestion.ingest_id
    }
    _self.selectedIngestion = ingestion
    MDMService.landingData(tempForm).then(function(response){
      console.log(response);
      _self.landingData = response.report_details[0]
      if(_self.landingData.contact_type_data.length  != 0){
        _self.createBar()
      }
      // function pageScroll() {
      //   window.scrollBy(0,100);
      //   scrolldelay = setTimeout(pageScroll,10);
      // }
      // pageScroll()
    })
    MDMService.stagingData(tempForm).then(function(response){
      console.log(response);
      _self.stagingData = response.staging_data_details
      if(_self.stagingData.contact_type_data.length  != 0){
        _self.otherBar()
      }
      for(i=0;i<_self.stagingData.reason_data.length;i++){
        _self.reasonsData.push(_self.stagingData.reason_data[i].reason_count)
        _self.reasonsLabel.push(_self.stagingData.reason_data[i].reason_data)
      }
      _self.activeReport = "Landing"

    })
    MDMService.mdmHubData(tempForm).then(function(response){
      console.log(response);
      _self.mdmHubData = response.mdm_hub_details
      if(_self.mdmHubData.contact_type_data.length  != 0){
        _self.mdmHubBar()
      }
    })

    var temp = {
      'ingest_name' :  ingestion.ingest_name ,
      'table_name' :   'Golden'
    }
    MDMService.getTablesData(temp,_self.goldenDataPageNumber).then(function(response){
      console.log(response);
      _self.goldenRecords = angular.copy(response)
    })
    MDMService.getTablesData({
      'ingest_name' :  ingestion.ingest_name ,
      'table_name' :   'Rejected records'
    },_self.rejectedDataPageNumber).then(function(response){
      console.log(response);
      _self.rejectedRecords = angular.copy(response)
    })

    MDMService.getTablesData({
      'ingest_name' :  ingestion.ingest_name ,
      'table_name' :   'Ingested Source records'
    },_self.rejectedDataPageNumber).then(function(response){
      console.log(response);
      _self.stagingRecords = angular.copy(response)
    })

    var form = {
      "ingest_name" : ingestion.ingest_name,
      "source_uid"  : ingestion.source_uid
    }
    MDMService.ruleMatcherGraph(form).then(function(response){
      console.log(response);
      _self.matchAnalysisData = angular.copy(response)
      var objLength = Object.keys(_self.matchAnalysisData)
      if(objLength == 0){
        _self.noMatchAnalysisData = true
      }
      else{
        _self.noMatchAnalysisData = false
        _self.createMatchAnalysis()

      }
    })
    MDMService.validationGraph(form).then(function(response){
      console.log(response);
      _self.sourceAnalysisData = angular.copy(response)
      var objLength = (Object.keys(_self.matchAnalysisData)).length
      if(objLength == 0){
        _self.noSourceAnalysisData = true
      }

      else {
        _self.noSourceAnalysisData = false
        _self.createSourceAnalysis((Object.keys(_self.sourceAnalysisData))[0])
      }
    })


    MDMService.referentialAnalysis(_self.referentialAnalysisDataPageNumber).then(function(response){
      console.log(response);
      _self.referentialAnalysisRecords = angular.copy(response)
    })

    _self.getAutomerged(1,ingestion)
    _self.getManuallyMerged(1,ingestion)

  }
  angular.forEach(scheduleDetail.ui_info,function(value,key){
    if(value.ingest_name == $route.current.params.ingestion){
      _self.selectIngestion(value)
    }
  })


  _self.changeDataPage = function(target){
    if(target == 'staging'){
      MDMService.getTablesData({
        'ingest_name' :  _self.selectedIngestion.ingest_name ,
        'table_name' :   'Ingested Source records'
      },_self.rejectedDataPageNumber).then(function(response){
        console.log(response);
        _self.stagingRecords = angular.copy(response)
      })
    }
    else if(target == 'rejected'){
      MDMService.getTablesData({
        'ingest_name' :  _self.selectedIngestion.ingest_name ,
        'table_name' :   'Rejected records'
      },_self.rejectedDataPageNumber).then(function(response){
        console.log(response);
        _self.rejectedRecords = angular.copy(response)
      })
    }

    else if(target == 'golden'){
      var temp = {
        'ingest_name' :  _self.selectedIngestion.ingest_name ,
        'table_name' :   'Golden'
      }
      MDMService.getTablesData(temp,_self.goldenDataPageNumber).then(function(response){
        console.log(response);
        _self.goldenRecords = angular.copy(response)
      })
    }

    else if (target == 'automerged') {
      _self.getAutomerged(_self.autoMergedDataPageNumber,_self.selectedIngestion)
    }

    else if (target == 'manuallymerged') {
      _self.getManuallyMerged(_self.manuallyMergedDataPageNumber,_self.selectedIngestion)
    }

    else if (target == 'referentialAnalysis') {
      MDMService.referentialAnalysis(_self.referentialAnalysisDataPageNumber).then(function(response){
        console.log(response);
        _self.clickedIndex = ''
        _self.referentialAnalysisRecords = angular.copy(response)
      })
    }

  }


  _self.CollapseIt = function (index) {
    if (_self.clickedIndex == index) {
      _self.clickedIndex = -1
    } else {
      _self.clickedIndex = index
    }
  }
  _self.isCollapsed = function (index) {
    if (index == _self.clickedIndex) {
      return false
    } else {
      return true
    }
  }

  _self.createMatchAnalysis = function(){
    _self.matchAnalysisGraphData = []
    var highestValue = 0
    var highestKey = ''
    angular.forEach(_self.matchAnalysisData,function(value,key){
      if(parseInt(value) > highestValue){
        highestValue = value
        highestKey = key
      }
    })
    angular.forEach(_self.matchAnalysisData,function(value,key){
      if(key == highestKey){
        _self.matchAnalysisGraphData.push({
          "percentage" : 100,
          "value"      : value,
          "name"       : highestKey
        })
      }
      else {
        _self.matchAnalysisGraphData.push({
          "percentage" : Math.round(_self.makePercentage(value,_self.matchAnalysisData[highestKey])),
          "value"      : value,
          "name"       : key
        })
      }
    })
    console.log(_self.matchAnalysisGraphData);
  }

  _self.createSourceAnalysis = function(key){
    _self.sourceAnalysisGraphData = []

    _self.sourceAnalysisGraphData.push({
      "percentage" : 100,
      "value"      : _self.sourceAnalysisData[key].total,
      "name"       : "Total"
    })
    _self.sourceAnalysisGraphData.push({
      "percentage" : Math.round(_self.makePercentage(_self.sourceAnalysisData[key].accepted,_self.sourceAnalysisData[key].total)),
      "value"      : _self.sourceAnalysisData[key].accepted,
      "name"       : "Accepted"
    })
    _self.sourceAnalysisGraphData.push({
      "percentage" : Math.round(_self.makePercentage(_self.sourceAnalysisData[key].rejected,_self.sourceAnalysisData[key].total)),
      "value"      : _self.sourceAnalysisData[key].rejected,
      "name"       : "Rejected"
    })
    console.log(_self.sourceAnalysisGraphData);
  }
  _self.makePercentage = function(what,wrt){
    return ((what/wrt) * 100)
  }

  _self.createBar = function(){
    var margin = {top: 10, right: 20, bottom: 50, left: 80},
    width = 500 - margin.left - margin.right,
    height = 175 - margin.top - margin.bottom;


    var x = d3.scaleBand()
        .rangeRound([0, width], .1)
    		.paddingInner(0.1);

    var y = d3.scaleLinear()
        .range([height, 0]);

    var xAxis = d3.axisBottom()
        .scale(x);

    var yAxis = d3.axisLeft()
        .scale(y)
        .ticks(5)
        .tickFormat(d3.format(""));
    var svg = d3.select("#bar").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    // var data = []
    // var alphabets = [ "A","B","C","D","E","F","G"]
    // angular.forEach(graphData,function(value,key){
    //   if(key!= 'add_data'){
    //     data.push({
    //         letter: "Accepted",
    //         frequency : value[1]
    //       })
    //       data.push({
    //           letter: "Rejected",
    //           frequency : value[2]
    //         })
    //   }
    // })
    // if(graphData[1] != 0){
    //   data.push({
    //       letter: "Accepted",
    //       frequency : graphData[1]
    //     })
    // }
    // if(graphData[2] != 0){
    //   data.push({
    //       letter: "Rejected",
    //       frequency : graphData[2]
    //     })
    // }
    tooltip = d3.tip().attr('class', 'd3-tip').html(function(d) {
      // console.log(d);
      return d.full + "  :  " + d.frequency
    });

    svg.call(tooltip);
    var data = []
    if(_self.landingData.contact_type_data.length != 0){
      for(i=0;i<_self.landingData.contact_type_data.length;i++){
        var string = _self.landingData.contact_type_data[i].contact_type.substring(0,5)
        string = string + ".."
        data.push({
          "letter" : string,
          "frequency" : _self.landingData.contact_type_data[i].contact_count,
          "full"  : _self.landingData.contact_type_data[i].contact_type
        })
      }

    }
    // var data = [
    // 	{
    // 		"letter" : " A",
    // 		"frequency" : 0
    // 	},
    // 	{
    // 		"letter" : "Investigator",
    // 		"frequency" : 200
    // 	},
    // 	{
    // 		"letter" : " ",
    // 		"frequency" : 0
    // 	}
    // ]



    x.domain(data.map(function(d) { return d.letter; }));
    y.domain([0, d3.max(data, function(d) { return d.frequency; })]);

    // svg.append("g")
    //     .attr("class", "x axis")
    //     .attr("transform", "translate(0," + height + ")")
    //     .call(xAxis);
    //
    // svg.append("g")
    //     .attr("class", "y axis")
    //     .call(yAxis)
    //   .append("text")
    //     .attr("transform", "rotate(-90)")
    //     .attr("y", 6)
    //     .attr("dy", ".71em")
    //     .style("text-anchor", "end")
    //     .text("Frequency");
    svg.append("g")
   .attr("class", "axis")
   .attr("transform", "translate(0," + height + ")")
   .call(d3.axisBottom(x).ticks(10))
   .selectAll("text")
     .style("text-anchor", "end")
     .attr("dx", "-.8em")
     .attr("dy", ".15em")
    //  .on('mouseover', tooltip.show)
    //  .on('mouseout', tooltip.hide)
     .attr("transform", "rotate(-65)");

   // add the y Axis
   svg.append("g")
       .call(yAxis);

    svg.selectAll(".bar")
        .data(data)
      	.enter().append("rect")
        .attr("class", "bar colored")
        .attr("x", function(d) { return x(d.letter); })
        .attr("width", x.bandwidth())
        .attr("y", function(d) { return y(d.frequency); })
        .on('mouseover', tooltip.show)
        .on('mouseout', tooltip.hide)
        .attr("height", function(d) { return height - y(d.frequency); });

    function type(d) {
      d.frequency = +d.frequency;
      return d;
    }
  }


  _self.mdmHubBar = function(){

      var margin = {top: 10, right: 20, bottom: 40, left: 50},
      width = 500 - margin.left - margin.right,
      height = 175 - margin.top - margin.bottom;

      var x = d3.scaleBand()
          .rangeRound([0, width], .1)
      		.paddingInner(0.1);

      var y = d3.scaleLinear()
          .range([height, 0]);

      var xAxis = d3.axisBottom()
          .scale(x);

      var yAxis = d3.axisLeft()
      .scale(y)
      .ticks(2)
      .tickFormat(d3.format(""));
      var svg = d3.select("#mdmHubBar").append("svg")
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
          .append("g")
          .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


      tooltip = d3.tip().attr('class', 'd3-tip').html(function(d) {
        return d.full + "  :  " + d.frequency
      });

      svg.call(tooltip);
      var data = []
      if(_self.mdmHubData.contact_type_data.length != 0){
        for(i=0;i<_self.mdmHubData.contact_type_data.length;i++){
          var string = _self.mdmHubData.contact_type_data[i].contact_type.substring(0,5)
          string = string + ".."
          data.push({
            "letter" : string,
            "frequency" : _self.mdmHubData.contact_type_data[i].contact_count,
            "full"  : _self.mdmHubData.contact_type_data[i].contact_type
          })
        }
      }




      x.domain(data.map(function(d) { return d.letter; }));
      y.domain([0, d3.max(data, function(d) { return d.frequency; })]);

      // svg.append("g")
      //     .attr("class", "x axis")
      //     .attr("transform", "translate(0," + height + ")")
      //     .call(xAxis);
      //
      // svg.append("g")
      //     .attr("class", "y axis")
      //     .call(yAxis)
      //   .append("text")
      //     .attr("transform", "rotate(-90)")
      //     .attr("y", 6)
      //     .attr("dy", ".71em")
      //     .style("text-anchor", "end")
      //     .text("Frequency");
      // svg.append("g")
      //    .attr("transform", "translate(0," + height + ")")
      //    .call(d3.axisBottom(x));


      svg.append("g")
     .attr("class", "axis")
     .attr("transform", "translate(0," + height + ")")
     .call(d3.axisBottom(x).ticks(10))
     .selectAll("text")
       .style("text-anchor", "end")
       .attr("dx", "-.8em")
       .attr("dy", ".15em")
       .attr("transform", "rotate(-65)");
     // add the y Axis
     svg.append("g")
     .call(yAxis);


      svg.selectAll(".bar")
          .data(data)
        	.enter().append("rect")
          .attr("class", "bar colored")
          .attr("x", function(d) { return x(d.letter); })
          .attr("width", x.bandwidth())
          .attr("y", function(d) { return y(d.frequency); })
          .on('mouseover', tooltip.show)
          .on('mouseout', tooltip.hide)
          .attr("height", function(d) { return height - y(d.frequency); });

      function type(d) {
        d.frequency = +d.frequency;
        return d;
      }
  }


  _self.otherBar = function(){

      var margin = {top: 10, right: 20, bottom: 50, left: 50},
      width = 500 - margin.left - margin.right,
      height = 175 - margin.top - margin.bottom;

      var x = d3.scaleBand()
          .rangeRound([0, width], .1)
          .paddingInner(0.1);

      var y = d3.scaleLinear()
          .range([height, 0]);

      var xAxis = d3.axisBottom()
          .scale(x);

      var yAxis = d3.axisLeft()
      .scale(y)
      .ticks(3)
      .tickFormat(d3.format(""));
      var svg = d3.select("#otherBar").append("svg")
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
          .append("g")
          .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


      tooltip = d3.tip().attr('class', 'd3-tip').html(function(d) {
        return d.full + "  :  " + d.frequency
      });

      svg.call(tooltip);
      var data = []
      if(_self.stagingData.contact_type_data.length != 0){
        for(i=0;i<_self.stagingData.contact_type_data.length;i++){
          var string = _self.stagingData.contact_type_data[i].contact_type.substring(0,5)
          string = string + ".."
          data.push({
            "letter" : string,
            "frequency" : _self.stagingData.contact_type_data[i].contact_count,
            "full"  : _self.stagingData.contact_type_data[i].contact_type
          })
        }

      }




      x.domain(data.map(function(d) { return d.letter; }));
      y.domain([0, d3.max(data, function(d) { return d.frequency; })]);

      // svg.append("g")
      //     .attr("class", "x axis")
      //     .attr("transform", "translate(0," + height + ")")
      //     .call(xAxis);
      //
      // svg.append("g")
      //     .attr("class", "y axis")
      //     .call(yAxis)
      //   .append("text")
      //     .attr("transform", "rotate(-90)")
      //     .attr("y", 6)
      //     .attr("dy", ".71em")
      //     .style("text-anchor", "end")
      //     .text("Frequency");
      // svg.append("g")
      //    .attr("transform", "translate(0," + height + ")")
      //    .call(d3.axisBottom(x));


      svg.append("g")
     .attr("class", "axis")
     .attr("transform", "translate(0," + height + ")")
     .call(d3.axisBottom(x).ticks(10))
     .selectAll("text")
       .style("text-anchor", "end")
       .attr("dx", "-.8em")
       .attr("dy", ".15em")
       .attr("transform", "rotate(-65)");
     // add the y Axis
     svg.append("g")
     .call(yAxis);


      svg.selectAll(".bar")
          .data(data)
          .enter().append("rect")
          .attr("class", "bar colored")
          .attr("x", function(d) { return x(d.letter); })
          .attr("width", x.bandwidth())
          .attr("y", function(d) { return y(d.frequency); })
          .on('mouseover', tooltip.show)
          .on('mouseout', tooltip.hide)
          .attr("height", function(d) { return height - y(d.frequency); });

      function type(d) {
        d.frequency = +d.frequency;
        return d;
      }
  }

// _self.createBar()
// _self.mdmHubBar()


}])
