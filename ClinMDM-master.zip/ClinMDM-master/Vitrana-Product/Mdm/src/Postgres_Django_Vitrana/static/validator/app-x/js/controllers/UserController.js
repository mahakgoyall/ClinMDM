angular.module('mdm').controller('UserController', ['$window','MDMService','$uibModal', 'userlist','toaster', '$scope','$mdToast','ngDialog',function($window,MDMService,$uibModal,userlist, toaster,$scope,$mdToast,ngDialog) {
    var _self = this
    _self.toSearch = ''
    _self.roleSelected = false
    _self.users = userlist;
    _self.RolesList = []
    _self.RolesResponseList = []
    _self.requestInProgress = false
    console.log(userlist);

    _self.role_options = [
        {role: '1', name: 'Admin'},
        {role: '2', name: 'Source Loader'},
        {role: '3', name: 'Steward User'},
        {role: '4', name: 'Data Manager'}
      ]

    _self.formdata = {
      full_name : '',
      username : '',
      email : '',
      role : []
    }
    _self.createuser = function() {
      console.log(_self.formdata);
      if(_self.formdata.full_name == '' || _self.formdata.username == '' || _self.formdata.email == '' || _self.formdata.role.length == 0){
        toaster.error("Error","All fields are mandatory")
        return;
      }
      console.log(_self.formdata);
      _self.requestInProgress = true
      MDMService.createuser(_self.formdata).then(function(response){
        _self.requestInProgress = false
        console.log(response)
        if(response.failure){
          $mdToast.showSimple(response.failure)
        }
        else {
          _self.formdata = {
            full_name : '',
            username : '',
            email : '',
            role : []
          }
          _self.RolesList = []
          $mdToast.showSimple("User was created successfully")
          MDMService.getusers().then(function(response) {
            console.log(response);
            _self.users = response;
          })

        }

      })
    }

_self.emptycreatefields = function() {
  _self.formdata = {
    full_name : '',
    username : '',
    email : '',
    role : []
  }

}
    _self.checkrolesinarray =  function(rol){
      return $.inArray(rol,   _self.formdata.role) > -1;
    }
  _self.pushdatatoarray = function(rol) {
    console.log(_self.formdata);
    var x = _self.formdata.role.indexOf(rol);
    if(x > -1) {
    _self.formdata.role.splice(x,1);
    } else {
      _self.formdata.role.push(rol);
    }
    console.log(_self.formdata.role);
  }
    _self.modifyUser = function (value) {
      _self.requestInProgress = true
      MDMService.getUserInfo(value.user_id).then(function(response) {
        _self.requestInProgress = false
        console.log(response);
        _self.update_formdata = {
          "userid" : response.user_id,
          "full_name" : response.name,
          "username" : response.username,
          "email" : response.email,
          "role" : response.role
        }
        _self.RolesResponseList = response.role
        console.log(response.role);
        _self.modalInstance = $uibModal.open({
          animation: true,
          ariaLabelledBy: 'modal-title',
          ariaDescribedBy: 'modal-body',
          templateUrl: 'modifyUser.html',
          backdrop: 'static',
          scope : $scope
        });
      })
      _self.RolesResponseList = []

  }
  _self.modifyDetails = function() {
    _self.modifyingDetails =  true
    _self.message = 'Modifying details, please wait...'
    if(_self.update_formdata.full_name == '' || _self.update_formdata.username == '' || _self.update_formdata.email == '' || _self.update_formdata.role.length == 0){
      toaster.error("Error","All fields are mandatory")
      _self.modifyingDetails =  false
      return;
    }
    MDMService.modifyUserDetails(_self.update_formdata).then(function(response) {
      _self.modifyingDetails =  false
      console.log(response);
      if(response.uid === _self.update_formdata.userid) {
        _self.cancel();
        toaster.success('Success', "User Details Changed Successfully");
      }
      MDMService.getusers().then(function(response) {
        console.log(response);
        _self.users = response;
      })
    })
  }
  _self.changePass = function() {
    _self.modifyingDetails = true
    _self.message = 'Resetting password, please wait...'
    var tempForm = {
      "userid" : _self.update_formdata.userid
    }
    console.log(tempForm);
    MDMService.changePassword(tempForm).then(function(response) {
      console.log(response);
      if(response.uid === _self.update_formdata.userid) {
        _self.modifyingDetails = false
        _self.cancel();
        toaster.success('Success', 'Check you email for a system generated password.');
      }
    })
  }
  _self.deleteConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'confirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }
  _self.closeConfirmation = function(){
    _self.instance.close()

  }
  _self.deleteUser = function() {
    var formdata = {
      "userid" : _self.update_formdata.userid
    }
    MDMService.deleteUser(formdata).then(function(response) {
      _self.instance.close()
      console.log(response);
      MDMService.getusers().then(function(response) {
        // console.log(response);
        _self.users = response;
      })
      if(response.ok === "Success") {
        _self.cancel();
        toaster.success('Success', "User deactivation successful");
      }
      else if(response.failure){
        toaster.error("Error", response.failure)
      }
      MDMService.getusers().then(function(response) {
        console.log(response);
        _self.users = response;
      })
    })
  }

  _self.checkIt = function (role) {
    // if(role == 1 ) {
    //   _self.pushdatatoarray(role)
    //   var crole = 1
    // } else {
    //   if (_self.formdata.role.includes(1)) {
    //   } else {
    //     _self.pushdatatoarray(role)
    //   }
    //   if (_self.RolesResponseList.includes(1)) {
    //   } else {
    //     _self.pushdatatoarray(role)
    //   }
    // }
    console.log(role);
    if(_self.formdata.role.includes(1) && role == 1){
      var index = _self.formdata.role.indexOf(role)
      console.log(index);
      _self.formdata.role.splice(index,1)
    }
    else if(_self.formdata.role.includes(1)){

    }
    else if((_self.formdata.role.includes(2) || _self.formdata.role.includes(3) || _self.formdata.role.includes(4) )  && role == 1){

    }
    else {
      _self.pushdatatoarray(role)
    }


  }

  _self.checkrolesinresponse =  function(rol){
    return $.inArray(rol, _self.RolesResponseList) > -1;
  }
  _self.pushdatatonewarray = function (rol) {
    var x = _self.RolesResponseList.indexOf(rol);
    if(x > -1) {
      _self.RolesResponseList.splice(x,1);
    } else {
      _self.RolesResponseList.push(rol);
    }
    console.log(_self.RolesResponseList);
  }
  _self.cancel = function () {
      _self.modalInstance.dismiss();
    };
_self.updatePassTog = function() {
  if(_self.update_formdata.password == false) {
    _self.update_formdata.password = true;
  } else {
    _self.update_formdata.password = false;
  }
}
$('#search-select').dropdown();
}])
