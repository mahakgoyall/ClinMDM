angular.module('mdm').controller('ValidationController', ['$window','MDMService','columnList','selfInfo','$scope','$mdToast','$uibModal','toaster','currentFlow','ngDialog','$rootScope',function($window,MDMService,columnList,selfInfo,$scope,$mdToast,$uibModal,toaster,currentFlow,ngDialog,$rootScope) {
  var _self = this
  console.log(selfInfo);
  _self.obj = {};
  _self.source = ''
  _self.selected = ''
  _self.toSend = {}
  _self.selectedIndex = -1
  _self.requestInProgress = false
  _self.noRejectionData  = false
  _self.lengthToSend = Object.keys(_self.toSend).length
  console.log(currentFlow);
  _self.selectedFilter = ''
  _self.flowDetails = angular.copy(currentFlow);
  if(_self.flowDetails.validation_rules){
    _self.toSend = angular.copy(_self.flowDetails.validation_rules)
  }

  // toaster.pop({type: 'success',title: 'Error',body: 'Test',timeout: 4500000});
  // setTimeout(function () {
  //   $('.selection.dropdown.column')
  //   .dropdown({
  //     forceSelection: false
  //   })
  // ;
  // }, 500);
  _self.columns = columnList.columns
  if (columnList.failure){
    toaster.pop({type: 'error',title: 'Error',body: columnList.failure,timeout: 4500});
    $window.location.href = "#/" + $rootScope.entityInUse + "/ingestions";
    return;
  }
  _self.validate = {
  "regex_string" : ''
  }





  // _self.rules = ["<",">","Contains","Not Null","Regex","Equals To"]
  _self.rules = [
    {front: "Greater Than", back: '>'},
    {front: "Smaller Than", back: '<'},
    {front: "Contains", back: 'Contains'},
    {front: "Not Null", back: 'not null'},
    {front: "Regex", back: 'regex'},
    {front: "Equals To", back: 'equals to'},
    {front: "Not Equals To", back: 'not equals to'},
  ]
  function init() {
    for (i=0;i<_self.columns.length;i++){
      _self.myKey = _self.columns[i]
      _self.obj[_self.myKey] = [];
    }
  }
  if (!columnList.failure){
    init()
  }

  if(_self.flowDetails.validation_rules){

  }

  _self.modifyKeys = function(data){
  var tempKeys = Object.keys(data.add_data[_self.selectedSource])
  _self.rejectedReasonTable = {}
  angular.forEach(data.add_data[_self.selectedSource],function(value,key){
    // var tempString = key
    // if(key.includes('ilike')){
      var temp = key
      temp = temp.replace('ilike' , 'contains')
      temp = temp.replace('ilike' , 'contains')
      temp = temp.replace('ilike' , 'contains')
      temp = temp.replace('ilike' , 'contains')
      temp = temp.replace('is not null' , 'is null')
      temp = temp.replace('is not null' , 'is null')
      temp = temp.replace('is not null' , 'is null')
      temp = temp.replace('is not null' , 'is null')
      temp = temp.replace('is not null' , 'is null')
      temp = temp.replace('%' , '')
      temp = temp.replace('%' , '')
      temp = temp.replace('%' , '')
      temp = temp.replace('%' , '')
      temp = temp.replace('%' , '')
      _self.rejectedReasonTable[temp] = value
    // }
  })
  console.log(_self.rejectedReasonTable);

}

_self.modifyData = function(data){
  angular.forEach(data.rejected_data[_self.selectedSource].data,function(value,key){
    // var tempString = key
    // if(key.includes('ilike')){
      // var temp = key
      value[1] = value[1].replace('ilike' , 'contains')
      value[1] = value[1].replace('ilike' , 'contains')
      value[1] = value[1].replace('ilike' , 'contains')
      value[1] = value[1].replace('ilike' , 'contains')
      value[1] = value[1].replace('is not null' , 'is null')
      value[1] = value[1].replace('is not null' , 'is null')
      value[1] = value[1].replace('is not null' , 'is null')
      value[1] = value[1].replace('is not null' , 'is null')
      value[1] = value[1].replace('is not null' , 'is null')
      value[1] = value[1].replace('%' , '')
      value[1] = value[1].replace('%' , '')
      value[1] = value[1].replace('%' , '')
      value[1] = value[1].replace('%' , '')
      value[1] = value[1].replace('%' , '')
      // _self.rejectedReasonTable[temp] = value
    // }
  })
}





  _self.submit = function(){
    // if(_self.selectedIndex != -1){
    //   $('.four.fields.' + _self.selectedIndex).transition('shake');
    //   return
    // }
    // console.log(_self.toSend)
    // var _temp = Object.keys(_self.toSend)
    // if (_temp.length >= 1){
      console.log(_self.newData);
      console.log($rootScope.entityInUse);
      _self.requestInProgress = true
      MDMService.standardizeData($rootScope.entityInUse).then(function (response) {
        console.log(response);
        if(response.failure){
          toaster.error("Error", response.failure)

        }
        console.log("standardization API Called");
        if (response.ok == "Success") {
            MDMService.postValidations(_self.newData).then(function(response){
              console.log("validation data POsted, API called");
              console.log(response)
              _self.requestInProgress = false
              if(response.failure){
                toaster.error("Error", response.failure)
              }
              else {
                $rootScope.isSomethingLeft = false
                _self.tableData = angular.copy(response)
                _self.graphData = angular.copy(response)
                _self.selectedSource = _self.graphData[0][0]
                _self.modifyKeys(_self.graphData)
                _self.modifyData(_self.graphData)

                if(_self.tableData.add_data[_self.selectedSource]){
                  if((Object.keys(_self.tableData.add_data[_self.selectedSource])).length == 0){
                    _self.noRejectionData = true
                  }
                }
                _self.modalInstance = $uibModal.open({
                  animation: true,
                  backdrop: 'static',
                  templateUrl: 'validationModal.html',
                  keyboard  : false,
                  scope: $scope
                });
                _self.modalInstance.opened.then(function(response){
                  setTimeout(function(){
                    _self.createBar(_self.graphData[0])
                  }, 200);
                })
              }

            })
          }
          else {
          toaster.error("Error", response.failure)
        }
      })
    // }
    //
    // else {
    //   $('.four.fields').transition('shake');
    // }

  }


  // _self.isSelected = function(){
  // if (_self.selected == index){
  //   return true
  //   }
  //   else {
  //     return false
  //   }
  // }
  _self.addToSend = function(){
    if (_self.selected == ''){
      toaster.pop('warning', "Error", "Select a column first");

      // $('.six.wide.field.column').transition('shake');
      return
    }
    else if (!_self.obj[_self.selected][0]){
      toaster.pop('warning', "Error", "Select a condition first");
      return
    }
    var temp = Object.keys(_self.toSend)
    console.log(temp)
    if (temp.includes(_self.selected)){
      toaster.pop('warning', "Error", _self.selected + '  Already Exists in Validation List.');
      return;
    }
    if (_self.obj[_self.selected][0] == "Regex") {
      _self.validate.regex_string = _self.obj[_self.selected][1]
      MDMService.validateRegex(_self.validate).then(function(response){
        console.log(response)
        if (response.ok){
          _self.toSend[_self.selected] = _self.obj[_self.selected]
          _self.selected = ''
          $('.ui.selection.dropdown.column').dropdown('clear');
          $('.ui.selection.dropdown.condition').dropdown('clear');
        }
        else {
          $mdToast.showSimple(response.failure)
        }
      })
    }
    else {
      $rootScope.isSomethingLeft = true
      _self.toSend[_self.selected] = _self.obj[_self.selected]
      _self.obj[_self.selected] = []
      _self.selected = ''
      $('.ui.selection.dropdown.column').dropdown('clear');
      $('.ui.selection.dropdown.condition').dropdown('clear');
      if((angular.toJson(_self.toSend)) == (angular.toJson(_self.flowDetails.validation_rules))){
        $rootScope.isSomethingLeft = false
      }
    }
    _self.lengthToSend = Object.keys(_self.toSend).length
    console.log(_self.toSend);
  }

  _self.delete = function(key){
    if((Object.keys(_self.toSend)).length == 1){
      $rootScope.isSomethingLeft = false
    }
    delete _self.toSend[key]
    if((angular.toJson(_self.toSend)) == (angular.toJson(_self.flowDetails.validation_rules))){
      $rootScope.isSomethingLeft = false
    }
  }

  _self.updateRecord = function(){
    _self.selectedIndex = -1
    if((angular.toJson(_self.toSend)) == (angular.toJson(_self.flowDetails.validation_rules))){
      $rootScope.isSomethingLeft = false
    }
  }

  _self.checkIfExists = function(key){
    var temp = Object.keys(_self.toSend)
    if (temp.includes(key)){
      return true
    }
    else {
      return false
    }
  }
  _self.rollbackConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'confirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }
  _self.closeConfirmation = function(){
    _self.instance.close()
  }

  _self.rollBack = function(){
    _self.instance.close()
    _self.modalInstance.dismiss('cancel');
    _self.noRejectionData = false
    MDMService.rollbackValidations().then(function(response){
      // init()
      // _self.toSend = {}

      console.log(response);
      if(response.ok){
        toaster.success("Success", "Rollback Successful.")
      }
      else {
        toaster.error("Error", "There was an error while rollback.Contact Administrator.")
      }
    })
  }
  _self.showRejectionData = function(key){
    _self.rejectionDataDisplay = _self.graphData.rejected_data[key]
    _self.rejectionReasons = Object.keys(_self.rejectedReasonTable)
    console.log(_self.rejectionReasons);
    _self.selectedFilter = ''
    _self.modalInstanceData = $uibModal.open({
     animation: true,
     backdrop: 'static',
     size : 'lg',
     templateUrl: 'rejectionDataModal.html',
     scope: $scope
   });
  }
  _self.closeModal = function(){
    _self.modalInstanceData.dismiss();
  }

  _self.updateGraph = function(key){
    d3.select("#pie").selectAll("*").remove();
    _self.createBar(_self.graphData[key])
    _self.selectedSource = _self.graphData[key][0]
    if((Object.keys(_self.tableData.add_data[_self.selectedSource])).length == 0){
      _self.noRejectionData = true
    }
  }

  _self.createBar = function(graphData){
    var margin = {top: 30, right: 20, bottom: 30, left: 40},
    width = 220 - margin.left - margin.right,
    height = 270 - margin.top - margin.bottom;

    var x = d3.scaleBand()
        .rangeRound([0, width], .1)
    		.paddingInner(0.1);

    var y = d3.scaleLinear()
        .range([height, 0]);

    var xAxis = d3.axisBottom()
        .scale(x);

    var yAxis = d3.axisLeft()
        .scale(y)
        .ticks(5)
        .tickFormat(d3.format(""));
    var svg = d3.select("#pie").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    tooltip = d3.tip().attr('class', 'd3-tip').html(function(d) {
      return d.letter + "  :  " + d.frequency
    });

    svg.call(tooltip);
    var data = []
    var alphabets = [ "A","B","C","D","E","F","G"]
    // angular.forEach(graphData,function(value,key){
    //   if(key!= 'add_data'){
    //     data.push({
    //         letter: "Accepted",
    //         frequency : value[1]
    //       })
    //       data.push({
    //           letter: "Rejected",
    //           frequency : value[2]
    //         })
    //   }
    // })
    if(graphData[1] != 0){
      data.push({
          letter: "Accepted",
          frequency : graphData[1]
        })
    }
    if(graphData[2] != 0){
      data.push({
          letter: "Rejected",
          frequency : graphData[2]
        })
    }


    // var data = [
    // 	{
    // 		"letter" : "A",
    // 		"frequency" : 5
    // 	},
    // 	{
    // 		"letter" : "B",
    // 		"frequency" : 7
    // 	},
    // 	{
    // 		"letter" : "C",
    // 		"frequency" : 8
    // 	}
    // ]


  	console.log(data)

    x.domain(data.map(function(d) { return d.letter; }));
    y.domain([0, d3.max(data, function(d) { return d.frequency; })]);

    // svg.append("g")
    //     .attr("class", "x axis")
    //     .attr("transform", "translate(0," + height + ")")
    //     .call(xAxis);
    //
    // svg.append("g")
    //     .attr("class", "y axis")
    //     .call(yAxis)
    //   .append("text")
    //     .attr("transform", "rotate(-90)")
    //     .attr("y", 6)
    //     .attr("dy", ".71em")
    //     .style("text-anchor", "end")
    //     .text("Frequency");
    svg.append("g")
       .attr("transform", "translate(0," + height + ")")
       .call(d3.axisBottom(x));

   // add the y Axis
   svg.append("g")
       .call(d3.axisLeft(y));

    svg.selectAll(".bar")
        .data(data)
      	.enter().append("rect")
        .attr("class", "bar")
        .attr("x", function(d) { return x(d.letter); })
        .attr("width", x.bandwidth())
        .on('mouseover', tooltip.show)
        .on('mouseout', tooltip.hide)
        .attr("y", function(d) { return y(d.frequency); })
        .attr("height", function(d) { return height - y(d.frequency); });

    function type(d) {
      d.frequency = +d.frequency;
      return d;
    }
  }



    _self.createChart = function(graph){
      var data = [];
      console.log(graph)
      var legendNames = []
      var length = (Object.keys(graph)).length
      for (i=0;i<length;i++){
        if (graph[i][1] == 0){
          continue;
        }
        data.push({
            letter: graph[i][0] + " Accepted",
            presses : graph[i][1]
          })
          legendNames.push(graph[i][0] + " Accepted")
      }

      for (i=0;i<length;i++){
        if (graph[i][2] == 0){
          continue;
        }
        data.push({
            letter: graph[i][0] + " Rejected",
            presses : graph[i][2]
          })
          legendNames.push(graph[i][0] + " Rejected")
      }
      console.log(data)
        tip = d3.tip().attr('class', 'd3-tip').html(function(d) {
          return d;
        });
        var width = 550,
      	height = 300,
      	radius = Math.min(width, height) / 2;
        var color = d3.scaleOrdinal()
        .range(["#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);

         var pie = d3.pie()
  	      .value(function(d) { return d.presses; })(data);

          var arc = d3.arc()
        	.outerRadius(radius - 10)
        	.innerRadius(0);

        var labelArc = d3.arc()
        	.outerRadius(radius - 70)
        	.innerRadius(radius - 40);

        var svg = d3.select("#pie")
      	.append("svg")
      	.attr("width", width)
      	.attr("height", height)
    		.append("g")
    		.attr("transform", "translate(170," + height/2 +")"); // Moving the center point. 1/2 the width and 1/2 the height

        svg.call(tip);

        var g = svg.selectAll("arc")
        	.data(pie)
        	.enter().append("g")
        	.attr("class", "arc");

        g.append("path")
      	.attr("d", arc)
      	.style("fill", function(d) { return color(d.data.letter);});

        g.append("text")
      	.attr("transform", function(d) { return "translate(" + labelArc.centroid(d) + ")"; })
      	.text(function(d) { return d.data.letter;})
        .style("fill", "#fff")
        .style("font-size", "9px")
        .style("display", "none");

        g.on('mouseover', function(data) {
          console.log(data)
          tip.show(data.data.letter + " : " + data.value + " Record")
        })
        g.on('mouseout', tip.hide)

        var ordinal = d3.scaleOrdinal()
        .domain(legendNames)
        .range(["#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);
        var svg = d3.select("#pie").selectAll("svg")

      svg.append("g")
        .attr("class", "legendOrdinal")
        .attr("transform", "translate(340,30)");

      var legendOrdinal = d3.legendColor()
        .scale(ordinal);

      svg.select(".legendOrdinal")
        .call(legendOrdinal);
    }



  // _self.addRule = function() {
  //     var length = Object.keys(_self.obj).length + 1
  //     var temp = "Rule " + length
  //     _self.obj[temp] = [];
  //     _self.obj[temp].push("")
  //     _self.length = Object.keys(_self.obj).length - 1
  //
  //     console.log(_self.length)
  //     // obj.myKey.push("k")
  // }


  _self.newData = {

  }


  _self.deleteKey = function(key){
    var tempLength = (Object.keys(_self.newData)).length
    console.log(tempLength);
    console.log(key);
    if(tempLength == 1 ){

    }
    else {
      delete _self.newData[key]
    }
  }

  _self.newData[0] = []
  _self.newData[0].push('')
  _self.newData[0].push('')
  _self.newData[0].push('')
  _self.newData[0].push('')
  _self.newData[0].push('')
  _self.newData[0].push('')

  // _self.selectedKey = 0
  console.log(_self.newData);

  _self.operators = ['AND','OR']

  _self.addNewCondition = function(){
    var keys = Object.keys(_self.newData)
    console.log(keys);
    for(i=0;i<=keys.length;i++){
      console.log(i);
      if(keys.includes((i.toString()))){
        console.log(i);
        continue;
      }
      else {
        console.log(i);
        _self.newData[i] = []
        for(j=0;j<6;j++){
          _self.newData[i].push('')
        }
        break;
      }
    }
    console.log(_self.newData);
  }


}])
