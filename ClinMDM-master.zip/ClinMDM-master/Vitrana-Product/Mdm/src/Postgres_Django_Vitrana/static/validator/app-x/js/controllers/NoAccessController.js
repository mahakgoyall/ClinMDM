angular.module('mdm').controller('NoAccessController', ['$window','MDMService','toaster','$uibModal','$scope', function($window,MDMService,toaster,$uibModal,$scope) {
    var _self = this


}])
