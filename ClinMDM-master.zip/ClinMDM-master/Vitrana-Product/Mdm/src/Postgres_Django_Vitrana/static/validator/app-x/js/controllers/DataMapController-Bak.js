 angular.module('mdm').controller('DataMapController', ['$window', 'MDMService', '$scope', '$mdToast', 'columnsList','csvColumnsList', function($window, MDMService, $scope, $mdToast, columnsList,csvColumnsList) {
   var _self = this
  //  _self.requestInProgress = false;
       // _self.requestInProgress = false
       // _self.csvrawcols = 'xyz.csv'
       // _self.csvnewcols = 'source1.csv'
   _self.rawcolumns = columnsList
   _self.csvColumnsList = csvColumnsList.header
   console.log(_self.rawcolumns);
   console.log(_self.csvColumnsList);
  //  _self.response = false;
  //  _self.response1 = true;
  //  MDMService.getCSVColumns().then(function(response){
  //    console.log(response)
  //  })

   if (_self.rawcolumns.failure){
     _self.migrateData = true
     $mdToast.showSimple(_self.rawcolumns.failure)

   }
   else if (csvColumnsList.failure){
      _self.migrateData = true
     $mdToast.showSimple(csvColumnsList.failure)

   }
   else {
     _self.migrateData = false

     _self.nodeDataArray = [{
         key: "Source Columns",
         fields: [],
         loc: "1000 0"
     }, {
         key: "Target Columns",
         fields: [],
         loc: "1500 0"
     }]
     for (i = 0; i < _self.csvColumnsList.length; i++) {
         _self.nodeDataArray[0].fields.push({
             name: _self.csvColumnsList[i]
         })

     }
     for (i = 0; i < _self.rawcolumns.length; i++) {
         _self.nodeDataArray[1].fields.push({
             name: _self.rawcolumns[i]
         })

     }
   }

   console.log(_self.nodeDataArray);
   //gojs
   _self.init = function() {
       var $ = go.GraphObject.make; // for conciseness in defining templates

       myDiagram =
           $(go.Diagram, "myDiagramDiv", {
               initialContentAlignment: go.Spot.Center,
              //  allowVerticalScroll : false,
               allowResize : true,
               scale : .71,
               allowHorizontalScroll : false,
               hasVerticalScrollbar : true,
               allowVerticalScroll : true,
               scrollMode: go.Diagram.DocumentScroll,
               allowDragOut : false,
               allowCopy : false,
               allowMove : false,
               autoScrollRegion : new go.Margin(20, 0,400, 0),
               scrollMargin : new go.Margin(1500, 0, 1200, 0),
               scrollVerticalLineChange : 3,
               validCycle: go.Diagram.CycleNotDirected, // don't allow loops
               // For this sample, automatically show the state of the diagram's model on the page
               "ModelChanged": function(e) {
                   if (e.isTransactionFinished) showModel();
               },
               "undoManager.isEnabled": true
           });



       // This template is a Panel that is used to represent each item in a Panel.itemArray.
       // The Panel is data bound to the item object.
       var fieldTemplate =
           $(go.Panel, "TableRow", // this Panel is a row in the containing Table
               new go.Binding("portId", "name"), // this Panel is a "port"
               {
                   background: "transparent", // so this port's background can be picked by the mouse
                   fromSpot: go.Spot.LeftRightSides, // links only go from the right side to the left side
                   toSpot: go.Spot.LeftRightSides,
                   // allow drawing links from or to this port:
                   fromLinkable: true,
                   toLinkable: true,
                   toLinkableDuplicates : false,
                   fromLinkableDuplicates :false
               },

               $(go.TextBlock, {
                       margin: new go.Margin(5, 7),
                       column: 2,
                       font: "13px sans-serif",
                       // and disallow drawing links from or to this text:
                       fromLinkable: false,
                       toLinkable: false,
                       toLinkableDuplicates : false,
                       fromLinkableDuplicates :false
                   },
                   new go.Binding("text", "name"))
           );

       // This template represents a whole "record".
       myDiagram.nodeTemplate =
           $(go.Node, "Auto",
               new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
               // this rectangular shape surrounds the content of the node
               $(go.Shape, {
                 figure: "Rectangle",
                 stroke : "#dedede",
                   fill: "#ffffff"
               }),
               // the content consists of a header and a list of items
               $(go.Panel, "Vertical",
                   // this is the header for the whole node
                   $(go.Panel, "Auto", {
                           stretch: go.GraphObject.Horizontal
                       }, // as wide as the whole node
                       $(go.Shape, {
                         figure: "Rectangle",
                           fill: "#2a6198",
                           stroke: 'gray',
                            strokeWidth: 2
                          //  border: "1px solid black"

                       }),
                       $(go.TextBlock, {
                               alignment: go.Spot.Center,
                               margin: 10,
                               stroke: "white",
                               textAlign: "left",
                               font: "25px sans-serif"
                                   //border: "1px solid black"
                           },
                           new go.Binding("text", "key"))),

                   // this Panel holds a Panel for each item object in the itemArray;
                   // each item Panel is defined by the itemTemplate to be a TableRow in this Table
                   $(go.Panel, "Table", {
                           name: "TABLE",
                           padding: 2,
                           defaultRowSeparatorStroke: "gray",
                           minSize: new go.Size(250, 30),
                           defaultStretch: go.GraphObject.Horizontal,
                           itemTemplate: fieldTemplate
                       },

                       new go.Binding("itemArray", "fields")
                   ) // end Table Panel of items
               ) // end Vertical Panel
           ); // end Node
       // drawn before row 1:
       $(go.RowColumnDefinition, {
               row: 1,
               separatorStrokeWidth: 0,
               separatorStroke: "black"
           }),
           myDiagram.linkTemplate =
           $(go.Link, {
                   relinkableFrom: true,
                   relinkableTo: true,

                   toShortLength: 4
               }, // let user reconnect links
               $(go.Shape, {
                   strokeWidth: 2
               }),
               $(go.Shape, {
                   toArrow: "Standard",
                   stroke: null
               })
           );

       myDiagram.model =
           $(go.GraphLinksModel, {
               linkFromPortIdProperty: "fromPort",
               linkToPortIdProperty: "toPort",
               nodeDataArray: _self.nodeDataArray,
               linkDataArray: []
           });

       // this is a bit inefficient, but should be OK for normal-sized graphs with reasonable numbers of items per node
       function findAllSelectedItems() {
           var items = [];
           for (var nit = myDiagram.nodes; nit.next();) {
               var node = nit.value;
               var table = node.findObject("TABLE");
               if (table) {
                   for (var iit = table.elements; iit.next();) {
                       var itempanel = iit.value;
                       if (itempanel.background !== "transparent") items.push(itempanel);
                   }
               }
           }
           return items;
       }

       // Override the standard CommandHandler deleteSelection behavior.
       // If there are any selected items, delete them instead of deleting any selected nodes or links.
       myDiagram.commandHandler.canDeleteSelection = function() {
           // true if there are any selected deletable nodes or links,
           // or if there are any selected items within nodes
           return go.CommandHandler.prototype.canDeleteSelection.call(myDiagram.commandHandler) ||
               findAllSelectedItems().length > 0;
       };

       myDiagram.commandHandler.deleteSelection = function() {
           var items = findAllSelectedItems();
           if (items.length > 0) { // if there are any selected items, delete them
               myDiagram.startTransaction("delete items");
               for (var i = 0; i < items.length; i++) {
                   var panel = items[i];
                   var nodedata = panel.part.data;
                   var itemarray = nodedata.fields;
                   var itemdata = panel.data;
                   var itemindex = itemarray.indexOf(itemdata);
                   myDiagram.model.removeArrayItem(itemarray, itemindex);
               }
               myDiagram.commitTransaction("delete items");
           } else { // otherwise just delete nodes and/or links, as usual
               go.CommandHandler.prototype.deleteSelection.call(myDiagram.commandHandler);
           }
       };

       showModel(); // show the diagram's initial model

       function showModel() {
           document.getElementById("mySavedModel").textContent = myDiagram.model.toJson();
           var obj = myDiagram.model.toJson();
          //  console.log(obj);
           _self.finaldata = jQuery.parseJSON(obj);
       }
   }
   _self.submit = function(){
     _self.response = false;
     _self.response1 = false;
    //  _self.requestInProgress = true;
     if (_self.finaldata.linkDataArray.length == 0){
       $mdToast.showSimple("Select atleast one mapping")
       return;
     }
     MDMService.sendmapping(_self.finaldata.linkDataArray).then(function(response){
             console.log(response)
             if(response.ok) {
               $mdToast.showSimple(response.ok)
               _self.migrateData = true
               console.log(_self.response);
             }
             else {
               $mdToast.showSimple(response.failure)
             }
            //  _self.requestInProgress = false;
            //  if(response.ok == "Success"){
              //  window.location.href = "/"
            //  }
         })
   }
// if(_self.requestInProgress == true) {
//   $('div.ui.active.dimmer').css('display','block');
// } else {
//   $('div.ui.active.dimmer').css('display','none');
// }
   setTimeout(function() {
       _self.init();
   }, 500);


 }]);
