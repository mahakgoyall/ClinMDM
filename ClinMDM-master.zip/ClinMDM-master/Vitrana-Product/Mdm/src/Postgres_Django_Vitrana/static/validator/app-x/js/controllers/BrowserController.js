angular.module('mdm').controller('BrowserController', ['$window','MDMService','$scope','ingestions','$rootScope','toaster','$uibModal', function($window,MDMService,$scope,ingestions,$rootScope,toaster,$uibModal) {
    var _self = this
    _self.response = ''
    _self.requestInProgress = false
    _self.table = ''
    _self.toSearch = ''
    _self.totalItems = 0
    _self.tables = []
    $scope.Math = window.Math;
    _self.pageNumber = 1
    _self.dataPageNumber = 1
    _self.goldenPageNumber = 1
    _self.ingestionList = ingestions
    _self.deepSearch = {}
    console.log(ingestions);
    _self.selectedSrc = ''

    _self.formData = {
      'ingest_name' : '',
      'source_uid' : ''
    }

    _self.tableDataForm = {
      'ingest_name' : '',
      'table_name' : ''
    }

    _self.searchFormData = {
      'table_name'   : '',
      'search'       : '',
      'sort'         : ["DEFAULT", "ASC"],
      'page'         : 1
    }


_self.reset = function(){
  _self.dataPageNumber = 1
  _self.deepSearch = {}
  _self.tableDataForm = {
    'ingest_name' : '',
    'table_name' : ''
  }

  _self.searchFormData = {
    'table_name'   : '',
    'search'       : '',
    'sort'         : ["DEFAULT", "ASC"],
    'page'         : 1
  }

}




    _self.changePageGolden = function(){
      _self.grabbingGolden = true
      MDMService.getTablesData(_self.tableDataForm,_self.goldenPageNumber).then(function(response) {
        _self.grabbingGolden = false
        console.log(response);
        _self.tableData = angular.copy(response)
      })
    }

    _self.openGolden = function(){
      _self.requestInProgress = true
      MDMService.getTablesData(_self.tableDataForm,_self.goldenPageNumber).then(function(response) {
        _self.requestInProgress = false
        console.log(response);
        _self.tableData = angular.copy(response)
        _self.modalInstance = $uibModal.open({
          animation: true,
          backdrop: 'static',
          size:'lg',
          templateUrl: 'goldenRecords.html',
          scope: $scope
        });
      })
    }

    _self.sort = function(column,type){
      var keys = Object.keys(_self.searchFormData.search)
      if(keys.length > 1 && _self.searchFormData.search[keys[0]].length != 0){
        // if(_self.searchFormData.sort[0] == 'DEFAULT'){
          _self.searchFormData.sort = []
        // }
        _self.searchFormData.sort.push(column)
        _self.searchFormData.sort.push(type)
        _self.searchFormData.page = _self.dataPageNumber
        _self.requestInProgress = true
        MDMService.columnSearch(_self.searchFormData).then(function(response){
          _self.requestInProgress = false
          console.log(response)
          if(response.failure){
            toaster.error(response.failure)
            return;
          }
          _self.tableData.data = response.data
          // _self.tableData.columns = response.columns
        },function(error){
          toaster.error(error)
          _self.requestInProgress = false
        })
      }

      else{
        // _self.searchFormData = {
        //   'table_name'   : '',
        //   'search'       : '',
        //   'sort'         : [],
        //   'page'         : 1
        // }
        // if(_self.searchFormData.sort[0] == 'DEFAULT'){
          _self.searchFormData.sort = []
        // }

        _self.searchFormData.table_name = _self.selectedSrc
        _self.searchFormData.sort.push(column)
        _self.searchFormData.sort.push(type)
        _self.searchFormData.page = _self.dataPageNumber
        _self.requestInProgress = true
        MDMService.columnSearch(_self.searchFormData).then(function(response){
          _self.requestInProgress = false
          console.log(response)
          if(response.failure){
            toaster.error(response.failure)
            return;
          }
          _self.tableData.data = response.data
          // _self.tableData.columns = response.columns
        },function(error){
          toaster.error(error)
          _self.requestInProgress = false
        })
      }
      console.log(_self.searchFormData);
    }

    _self.search = function(){
      angular.forEach(_self.deepSearch,function(value,key){
        if(value == ''){
          // _self.deepSearch = {}
          delete _self.deepSearch[key]
        }
      })
      console.log(_self.deepSearch);
      if((Object.keys(_self.deepSearch)).length > 0  ){
        if(_self.searchFormData.sort[0]  ==  'DEFAULT'){
          _self.searchFormData.sort = []
        }
        _self.searchFormData.table_name = _self.selectedSrc
        _self.searchFormData.search = _self.deepSearch
        // _self.searchFormData.page = 1
        _self.requestInProgress = true
        console.log(_self.searchFormData);
        MDMService.columnSearch(_self.searchFormData).then(function(response){
          // _self.searchFormData.sort = ["DEFAULT", "ASC"]
          _self.requestInProgress = false
          console.log(response)
          if(response.failure){
            toaster.error(response.failure)
            return;
          }
          _self.tableData.data = response.data
          _self.tableData.columns = response.columns
          _self.tableData.total = response.total
          console.log(_self.searchFormData);

          if( _self.searchFormData.sort.length == 0){
            _self.searchFormData.sort = ["DEFAULT", "ASC"]
          }
          console.log(_self.searchFormData);

        },function(error){
          toaster.error(error)
          _self.requestInProgress = false
        })
      }

      // else{
      //   console.log(_self.searchFormData);
      //
      //   if(_self.searchFormData.sort[0]  !=  'DEFAULT'){
      //     _self.searchFormData.sort = []
      //   }
      //
      //   else {
      //     _self.loadData(_self.selectedSrc)
      //   }
      // }
      // console.log(_self.searchFormData);
        else {
          _self.loadData(_self.selectedSrc)
        }
    }

    // Get tables list and load Golden data initially
    _self.getTablesList = function(ingest){
      _self.formData.ingest_name = ingest.ingest_name
      _self.formData.source_uid = ingest.source_uid
      // _self.selectedSrc = "Golden"
      $rootScope.showInBrowser = true
      MDMService.getTablesList(_self.formData).then(function(response){
        _self.tablesList = response
        for(i=0;i<(Object.keys(_self.tablesList).length) ; i++){
          if(_self.tablesList[i] != 'Partial Match records')
          _self.tables.push(_self.tablesList[i])
        }
        _self.getTableData(_self.tables[0])
        _self.selectedSrc = _self.tables[0]
      })
    }

    if (_self.ingestionList.total == 0){
      _self.toShow = false
    } else {
      _self.toShow = true
    }

    // Change ingestion list page
    _self.changePage = function() {
      _self.requestInProgress = true
      MDMService.ingestionList(_self.pageNumber).then(function(response){
        console.log(response);
        _self.requestInProgress = false
        _self.ingestionList = response
        if (response.total == 0){
          _self.toShow = false
        } else {
          _self.toShow = true
        }
      })
    }

    // Get data of respective by
    _self.getTableData = function(name){
      console.log(name);
      _self.deepSearch = {}
      _self.dataPageNumber = 1
      _self.tableDataForm.ingest_name = _self.formData.ingest_name
      _self.tableDataForm.table_name = name
      _self.searchFormData.search = ''
      _self.searchFormData.sort = ["DEFAULT", "ASC"]
      _self.loadData(name)

    }

    // Change data page
    _self.changePageData = function(){

      var keys = Object.keys(_self.searchFormData.search)
      if((keys.length > 0 && _self.searchFormData.search[keys[0]].length != 0 ) ||  ( _self.searchFormData.sort[0]  != 'DEFAULT') ){
        _self.searchFormData.page  =  _self.dataPageNumber
        if(_self.searchFormData.sort[0] == 'DEFAULT'){
          _self.searchFormData.sort = []
        }

        _self.requestInProgress = true
        console.log(_self.searchFormData);
        MDMService.columnSearch(_self.searchFormData).then(function(response){
          // _self.searchFormData.sort = ["DEFAULT", "ASC"]
          _self.requestInProgress = false
          console.log(response)
          if(response.failure){
            toaster.error(response.failure)
            return;
          }
          _self.tableData.data = response.data
          // _self.tableData.columns = response.columns
          // _self.tableData.total = response.total
        },function(error){
          toaster.error(error)
          _self.requestInProgress = false
        })
      }
      else {
        _self.loadData(_self.selectedSrc)

      }
      // console.log();
    }

    // Convert complete data into downloadble pdf
    _self.getPDF = function(){
      var temp = {
        'ingest_name' :_self.formData.ingest_name ,
        'table_name' : _self.selectedSrc
      }
      _self.requestInProgress = true
      console.log(temp);
      MDMService.getTableCompleteData(temp).then(function(response){
        _self.requestInProgress = false
        console.log(response);
        if(response.failure){
          toaster.error(response.failure)
          return
        }
        var doc = new jsPDF('l', 'pt','a0');
        doc.autoTable(response.columns,response.data,{
           startY: 60,
          styles: {
            overflow: 'linebreak',
            fontSize: 6,
            rowHeight: 60,
            columnWidth: 'wrap'
          },
          columnStyles: {
            1: {columnHeight:10 }
          },
          theme: 'grid'
        });
        doc.save('table.pdf');
      })
    }

    _self.getCsv = function(what){
      console.log(_self.selectedSrc);
      var temp = {
        'ingest_name' :_self.formData.ingest_name ,
        'table_name' : _self.selectedSrc
      }
      MDMService.getTableCompleteData(temp).then(function(response){
        console.log(response);
        if(what == 'data'){
          return  [{a: 1, b:2}, {a:3, b:4}]
        }
        else if(what =='headers'){
          return  ["A", "B"]
        }
      })
      console.log(what);
    }

    // To watch the changes in showInBrowser variable which controls the back button
    $rootScope.$watch('showInBrowser' ,function(){
      _self.tablesList = ''
      _self.tableData = ''
      // _self.pageNumber = 1
      _self.dataPageNumber = 1
      _self.totalItems = 0
      _self.tables = []
      _self.selectedSrc = ''
      _self.deepSearch = {}
      _self.toSearch = ''
      _self.tableDataForm = {
        'ingest_name' : '',
        'table_name' : ''
      }
      // $('.ui.small.dropdown').dropdown('restore defaults')

    },true);
    _self.back = function(){
      _self.tablesList = ''
      _self.tableData = ''
      _self.totalItems = 0
      _self.tables = ['Golden']
      _self.selectedSrc = 'Golden'

      _self.toSearch = ''
      $rootScope.showInBrowser = false
    }

    _self.loadData = function(table){
      _self.requestInProgress = true
      console.log(_self.tableDataForm);
      if (table == 'Golden'){
        MDMService.getTablesData(_self.tableDataForm,_self.dataPageNumber).then(function(response) {
          console.log(response);

            if(response.failure){
              toaster.error(response.failure)
            }
            else {
              _self.tableData = response
            }
            _self.requestInProgress = false

        })
      }
      else{
        MDMService.getTablesData(_self.tableDataForm,_self.dataPageNumber).then(function(response) {
          console.log(response);
            if(response.failure){
              toaster.error(response.failure)
            }
            // _self.result = response.Result
            _self.tableData = response
            _self.requestInProgress = false

        })
      }
    }

}])
