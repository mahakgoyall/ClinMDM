angular.module('mdm').controller('SourcesController', ['$window','MDMService','$http','$uibModal','$scope','toaster','ngDialog','customSourceList', function($window,MDMService,$http,$uibModal,$scope,toaster,ngDialog,customSourceList) {
  var _self = this
  _self.visiblecard = 'DB Connection';
  _self.type = ["DB Connection","Amazon S3"]
  _self.selectedType = "DB Connection"
  _self.bucketList = []
  _self.selectedSource = {}
  _self.connectingS3 = false
  _self.customSourceList = customSourceList.data
  _self.prioritylist = ''
  _self.disableSubmit = true;
  _self.requestInProgress = false
  _self.s3ConnectFailure = ''
  console.log(customSourceList);
  if(customSourceList.Failure){
    toaster.error("error",customSourceList.Failure)
  }

  _self.dbForm = {
    "host_name" : '',
    "port" : '',
    "username" : '',
    "password" : '',
    "database_name" : '',
    "table_name" : ''
  }

  _self.s3FormData = {
    "key_id" : '',
    "secret_id" : '',
    "bucket_name" : ''
  }
  _self.changeVisibleCard = function(card) {
    _self.visiblecard = card;
  }
  _self.addSource = function() {
    _self.s3ConnectFailure = ''
    MDMService.getprioritylist().then(function(response) {
      _self.prioritylist = response
    })
    _self.modalInstance = $uibModal.open({
     animation: true,
     templateUrl: 'addSource.html',
     backdrop: 'static',
     scope: $scope,
     keyboard : false
    })
  }
  _self.changePriority = function(key) {
    _self.newSourcePriority = key
  }
  _self.actions = function(){
      return ["Edit","Remove"]
  }
  // Perform action from dropdown , executed when an option from dropdown is selected/changed.
  _self.performAction = function(task,source){
    $('.ui.selection.small.dropdown.customdrop').dropdown('clear');
    _self.editingSource = angular.copy(source)
    if (task == 'Edit'){
      _self.disableSubmit = true
      _self.requestInProgress = true
      MDMService.getprioritylist().then(function(response) {
        _self.prioritylist = angular.copy(response)
        _self.requestInProgress = false
        console.log(_self.prioritylist);
        _self.cSourceName = angular.copy(source.source_root_name)
        _self.source_priority = angular.copy(source.source_priority)
        console.log(_self.source_priority);
        if(source.conn_method == 'Amazon_S3_bucket') {
          _self.visiblecard = "Amazon S3"
          _self.s3FormData = angular.copy(source.conn_string)
        } else if (source.conn_method == 'db_connection') {
          _self.visiblecard = "DB Connection"
          _self.dbForm = angular.copy(source.conn_string)
        } else {
          console.log("nothing");
        }
        _self.s3ConnectFailure = ''
        _self.modalInstance = $uibModal.open({
          animation: true,
          templateUrl: 'editSource.html',
          backdrop: 'static',
          scope: $scope,
          keyboard : false
        })
        $('.ui.selection.dropdown.customdrop').dropdown('refresh');
      })
      // console.log(source);
    }
    else if (task == 'Remove') {
      _self.selectedSource = source;
      _self.instance = ngDialog.open({
          template: 'continue.html',
          scope:$scope,
          className: 'ngdialog-theme-plain',
          closeByDocument : false,
          showClose : false,
          closeByNavigation :true
        });
    }
  }
  _self.checkit = function () {
    console.log(_self.editingSource.source_priority);
  }
  _self.editSource = function () {
    console.log(_self.editingSource.conn_string);
    if (_self.editingSource.conn_string) {
      console.log("truasde");
      delete _self.editingSource.conn_string.custom_source_name
      delete _self.editingSource.conn_string.source_priority
      console.log("deledsted");
    }
    var payload = {
      "editable"        : 1,
      "deletable"       : 0,
      "source_id"  : _self.editingSource.source_root_id,
      "conn_name" : _self.editingSource.source_root_name,
      "conn_priority" : _self.editingSource.source_priority,
      "conn_string" : _self.editingSource.conn_string
    }
    console.log(payload);
    MDMService.sourceConfiguration(payload).then(function(response){
      _self.modalInstance.dismiss();
      console.log(response);
      if(response.success){
        MDMService.customSourceList().then(function(response){
          console.log(response);
          toaster.success('success', 'Successfully Updated')
          _self.customSourceList = response.data
        })
      }
      else {
        console.log(response);
        toaster.error('error',response)
      }
    })
    $('.ui.selection.dropdown.customdrop').dropdown('refresh');
  }

  _self.connectToS3 = function () {
    _self.s3FormData.conn_method = 'Amazon_S3_bucket'
    _self.s3FormData.custom_source_name = _self.cSourceName;
    _self.s3FormData.source_priority = _self.selectedItem;
    console.log(_self.s3FormData);
    _self.connectingS3 = true
    MDMService.connectToS3(_self.s3FormData).then(function (response) {
      console.log(response);
      _self.connectingS3 = false
      if(response.Failure){
        _self.disableSubmit = true
        _self.s3ConnectFailure = 'Incorrect credentials'
        toaster.error('Incorrect credentials')
      } else {
        _self.bucketList = response
        _self.s3ConnectFailure = ''
        toaster.success('Connection established', 'Select the appropriate bucket.')
        _self.disableSubmit = false
      }
    })
  }
  _self.autoclear = function() {
      _self.dbForm = {
        "host_name" : '',
        "port" : '',
        "username" : '',
        "password" : '',
        "database_name" : '',
        "table_name" : ''
      }
      _self.cSourceName = ''
      _self.newSourcePriority = ''
      _self.s3FormData = {
        "key_id" : '',
        "secret_id" : '',
        "bucket_name" : ''
      }
      _self.bucketList = []
      _self.selectedItem = ''
      $('.ui.selection.priority.dropdown').dropdown('clear');
  }
  // For DB Connection & S3
_self.connectDB = function() {
  if(_self.visiblecard == "DB Connection"){
   var flag = false
   _self.dbForm.conn_method = 'db_connection'
   _self.dbForm.custom_source_name = _self.cSourceName;
   _self.dbForm.source_priority = _self.selectedItem;
  //  if(_self.cSourceName == '' || _self.selectedItem == '' || )
   angular.forEach(_self.dbForm,function(value,key){
     console.log(value);
     if(value == ''){
       flag = true
     }
   })
   if(flag){
     toaster.error("All fields are mandatory.")
     return;
   }
   console.log(_self.dbForm);
    MDMService.dbConnectSource(_self.dbForm).then(function(response) {
      console.log(response);
      if(response.success) {
        toaster.success("Success", "Database Connected Successfully");
        _self.autoclear()
      } else {
        toaster.error("Failure", "Please enter valid credentials", 5000);
      }
      MDMService.customSourceList().then(function(response1) {
        _self.customSourceList = response1.data
      })
      MDMService.getprioritylist().then(function(response) {
        _self.prioritylist = response
      })
    })
  } else {
    var flag = false
    _self.s3FormData.conn_method = 'Amazon_S3_bucket'
    _self.s3FormData.custom_source_name = _self.cSourceName;
    _self.s3FormData.source_priority = _self.selectedItem;
    angular.forEach(_self.s3FormData,function(value,key){
      if(value == ''){
        flag = true
      }
    })
    if(flag){
      toaster.error("All fields are mandatory.")
      return;
    }
    console.log(_self.s3FormData);
    MDMService.connToS3Buck(_self.s3FormData).then(function(response){
      console.log(response);
      if(response.Failure){
        toaster.error("Failure", response.Failure);
      } else if(response.failure){
        toaster.error("Failure", response.failure);
      }
      else {
        toaster.success("Success", "Connected to Amazon S3 Database");
        _self.cancel()
        _self.autoclear()
      }
      MDMService.customSourceList().then(function(response1) {
        _self.customSourceList = response1.data
      })
      MDMService.getprioritylist().then(function(response) {
        _self.prioritylist = response
      })
    })
  }
}


_self.autoClearForm = function() {
    _self.dbForm = {
      "host_name" : '',
      "port" : '',
      "username" : '',
      "password" : '',
      "database_name" : '',
      "table_name" : ''
    }
    _self.s3FormData = {
      "key_id" : '',
      "secret_id" : '',
      "bucket_name" : ''
    }
    _self.bucketList = []
}
_self.cancel = function(){
  _self.modalInstance.dismiss();
  _self.autoclear()
}
_self.closeWarning = function(){
  _self.instance.close()
}
_self.completed = function(){
  console.log(_self.selectedSource);
  var payload = {
    "editable"        : 0,
    "deletable"       : 1,
    "source_id"  : _self.selectedSource.source_root_id
  }
  console.log(payload);
  MDMService.sourceConfiguration(payload).then(function(response){
    console.log(response);
    if(response.success){
      _self.closeWarning();
      MDMService.customSourceList().then(function(response){
        console.log(response);
        toaster.success('Success', 'Source removed successfully')
        _self.customSourceList = response.data
      })
    }
    else {
      toaster.error('error',response)
    }
  })
}

}])
