angular.module('mdm').controller('FlowController', ['$window','MDMService','$scope','$uibModal','flowList','toaster','ngDialog','$rootScope',function($window,MDMService,$scope,$uibModal,flowList,toaster,ngDialog,$rootScope) {
  var _self = this
  _self.showDetails = false
  _self.requestInProgress = false
  _self.selected = []
  _self.actions = ["Edit","View","Run","Delete"]
  _self.entities = ['Investigator','Sponsor','Site','Study']
  _self.flowList = flowList
  console.log(flowList);
  if(flowList.failure){
    toaster.error(flowList.failure)
  }
  _self.noData = ''
  _self.creatingFlow = false
  _self.deleteInProgress = false

  $scope.Math = window.Math;
  // console.log(flowList);
  // if (flowList.list){
  //   _self.flowList = flowList.list
  // }
  _self.flowForm = {
    "flow_name" : "",
    "scope" : "",
  }

  _self.deleteForm  = {
    "username" : "",
    "flow_name" : ""
  }

  _self.reset = function(){
    _self.flowForm = {
      "flow_name" : "",
      "scope" : "",
    }
  }
  _self.pageNumber = 1
  // _self.pageNumber = 1

  _self.changePage = function() {
    _self.requestInProgress = true
    console.log(_self.pageNumber);
    MDMService.flowList(_self.pageNumber).then(function(response){
      _self.requestInProgress = false
      _self.flowList = angular.copy(response)
      console.log(response);
      if (response.total == 0){
        _self.toShow = false
      } else {
        _self.toShow = true
      }
    })
  }

  _self.performAction = function(action,flow){
    if (action == 'View'){
      _self.showDetails(flow)
    }
    else if (action == 'Run'){
      _self.useThisFlow(flow)
    }

    else if(action == "Edit"){
      _self.editFlow(flow)
    }
    else if(action == "Delete"){
      _self.flowSelected = flow
      _self.deleteConfirmation()
      // _self.deleteFlow(flow)
    }
  }

  _self.deleteConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'confirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }
  _self.closeConfirmation = function(){
    $('.ui.small.dropdown').dropdown('restore defaults')
    _self.instance.close()

  }

  _self.deleteFlow = function(flow){
    _self.instance.close()
    _self.deleteForm.username = flow.username
    _self.deleteForm.flow_name = flow.flow_name
    _self.deleteInProgress = true
    console.log(_self.deleteForm);
    MDMService.deleteFlow(_self.deleteForm).then(function(response){
      console.log(response);
      _self.deleteInProgress = false
      if(response.failure){
        toaster.error("Error",response.failure)
      }
      else {
        toaster.success("Success","Delete Successful")
          _self.refreshList()
      }
    })
  }

  _self.refreshList = function(){
    $('.ui.small.dropdown').dropdown('restore defaults')
    MDMService.flowList(1).then(function(response){
      console.log(response);
      _self.flowList = response
      if (response.total == 0){
        _self.toShow = false
      } else {
        _self.toShow = true
      }
    })
  }

  _self.editFlow = function(flow){
    MDMService.editFlow(flow.flow_name).then(function(response){
      console.log(response);
      if(response.failure){
        toaster.error("Error", response.failure)
        $('.ui.small.dropdown').dropdown('restore defaults')
      }
      else {
        $window.location.href = "#/" + $rootScope.entityInUse + "/validation";
      }
    })
  }

  _self.showDetails = function(flow){
    console.log(flow);
    _self.tempForm = {
      "username" : flow.username,
      "flow_name" : flow.flow_name
    }
    MDMService.getFlowValidations(_self.tempForm).then(function(response){
      console.log(response);
      _self.flowRules = angular.copy(response)
      _self.modalInstance = $uibModal.open({
       animation: true,
       backdrop: 'static',
       templateUrl: 'flowDetails.html',
       scope: $scope
     })
     $('.ui.small.dropdown').dropdown('restore defaults')
    })
  }
  _self.cancel = function () {
      _self.modalInstance.dismiss();
      if(_self.instance){
        _self.instance.close()
      }
      _self.flowForm = {
        "flow_name" : "",
        "scope" : "",
      }
  }

  _self.closeAddModal = function(){
    if (_self.flowForm.flow_name == '' && _self.flowForm.scope == '') {
      _self.cancel()
    }
    else {
      _self.openWarning()
    }
  }
  _self.openWarning = function(){
    _self.instance = ngDialog.open(
      { template: 'warning.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }


  _self.addToSelected = function(value){
    if(_self.selected.includes(value)){
      var index = _self.selected.indexOf(value)
      _self.selected.splice(index,1)
    }
    else {
      _self.selected.push(value)
    }
    console.log(_self.selected);
  }



  _self.createNew = function(){
    _self.modalInstance = $uibModal.open({
     animation: true,
     templateUrl: 'flowModal.html',
     backdrop: 'static',
     scope: $scope
   })
  }

  _self.createFlow = function(){
    _self.flowForm.flow_name = _self.flowForm.flow_name.toUpperCase()
    console.log(_self.flowForm);
    _self.creatingFlow = true
    MDMService.createFlow(_self.flowForm).then(function(response){
      console.log(response);
      if(response.ok){
        _self.closeModal()
        toaster.success("Success","Flow created, redirecting to the Data Validation page.")
        $window.location.href = "#/" + $rootScope.entityInUse + "/validation";
      }
    },function(error){
      toaster.error('error',error)
      _self.creatingFlow = false
    })
  }

  _self.useThisFlow = function(value){
    var temp = {
      "flow_name" : "",
      "username"  : "",
      "page"      : _self.pageNumber
    }
    // console.log(temp);
    temp.flow_name = value.flow_name
    temp.username = value.username
    _self.requestInProgress = true
    console.log(temp);
    MDMService.useFlow(temp).then(function(response){
      $('.ui.small.dropdown').dropdown('restore defaults')
      _self.requestInProgress = false
      console.log(response);
      if (response.failure){
        toaster.error("Error",response.falure)
      }
      else {
        toaster.pop('success', "Success", "Data mastered successfully & Partial matches sent to Steward");
        // _self.createRefGraph(response)
        _self.graphData = angular.copy(response)
        _self.modalInstance = $uibModal.open({
         animation: true,
         templateUrl: 'graph.html',
         scope: $scope
        })
        _self.modalInstance.opened.then(function(response){
          setTimeout(function(){
            _self.pieChart(_self.graphData)

          }, 200);
        })

        if(_self.graphData.exact_ref[0] == 0 && _self.graphData.partial_ref[0] == 0 && _self.graphData.nomatch_ref[0] == 0)
        {
          _self.noData = "No data to display"
        }
      }


      // if(response.ok){
      //   $window.location.href = "#/validation"
      // }
    })
  }
  // MDMService.getFlowDetails("flow_3").then(function(response){
  //   _self.flowDetail = response['_source'].flow_3
  // })


  _self.change = function() {
    if (_self.showDetails == true){
      _self.showDetails = false
    }
    else {
      _self.showDetails = true
    }
  }






  _self.closeModal = function(){
    _self.reset()
    _self.modalInstance.dismiss('cancel');
  }

  _self.pieChart = function(graph){
    var data = [];
    var legendNames = []
    if(graph.exact_ref > 0){
      data.push({
        letter: "Exact",
        presses : graph.exact_ref[0]
      })
      legendNames.push("Exact Match")
    }
    if(graph.partial_ref > 0){
      data.push({
        letter : "Partial",
        presses : graph.partial_ref[0]
      })
      legendNames.push("Partial Match  ")

    }
    if(graph.nomatch_ref > 0){
      data.push({
      letter : "NoMatch",
      presses: graph.nomatch_ref[0]
      })
      legendNames.push("No Match")

    }
      tip = d3.tip().attr('class', 'd3-tip').html(function(d) {
        console.log(d);
        return d;
      });
      var width = 500,
      height = 300,
      // Think back to 5th grade. Radius is 1/2 of the diameter. What is the limiting factor on the diameter? Width or height, whichever is smaller
      radius = Math.min(width, height) / 2;
      var color = d3.scaleOrdinal()
      .range(["#a05d56", "#d0743c", "#ff8c00"]);

       var pie = d3.pie()
        .value(function(d) { return d.presses; })(data);

        var arc = d3.arc()
        .outerRadius(radius - 10)
        .innerRadius(0);

      var labelArc = d3.arc()
        .outerRadius(radius - 70)
        .innerRadius(radius - 40);



      var svg = d3.select("#pie")
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", "translate(" + width/2 + "," + height/2 +")"); // Moving the center point. 1/2 the width and 1/2 the height

      svg.call(tip);

      var g = svg.selectAll("arc")
        .data(pie)
        .enter().append("g")
        .attr("class", "arc");

      g.append("path")
      .attr("d", arc)
      .style("fill", function(d) { return color(d.data.letter);});

      g.append("text")
      .attr("transform", function(d) { return "translate(" + labelArc.centroid(d) + ")"; })
      .text(function(d) { return d.data.letter;})
      .style("font-size", "9px")
      .style("display", "none")
      .style("fill", "#fff");

      g.on('mouseover', function(data) {
        tip.show(data.data.letter + " : " + data.value + " Record")
      })
      g.on('mouseout', tip.hide)


      var ordinal = d3.scaleOrdinal()
      .domain(legendNames)
      .range(["#a05d56", "#d0743c", "#ff8c00"]);
      var svg = d3.select("#pie").selectAll("svg")

    svg.append("g")
      .attr("class", "legendOrdinal")
      .attr("transform", "translate(400,30)");

    var legendOrdinal = d3.legendColor()
      //d3 symbol creates a path-string, for example
      //"M0,-8.059274488676564L9.306048591020996,
      //8.059274488676564 -9.306048591020996,8.059274488676564Z"
      // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
      // .shapePadding(10)
      .scale(ordinal);

    svg.select(".legendOrdinal")
      .call(legendOrdinal);



  }

  _self.rollbackConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'rollbackConfirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }
  _self.closeConfirmation = function(){
    _self.instance.close()

  }


  _self.rollBack = function(){
    _self.modalInstance.dismiss('cancel');
    _self.instance.close()
    MDMService.rollbackRules().then(function(response){
      if(!response.failure){
        MDMService.rollbackValidations().then(function(responseNew){
          console.log(responseNew);
          if(responseNew.failure){
            toaster.error("Error", responseNew.failure)
          }
          else if(response.ok) {
            toaster.success("Success","Rollback Successful")
          }
        })
      }
      else {
        toaster.error("Error", response.failure)
      }
    })
  }


}])
