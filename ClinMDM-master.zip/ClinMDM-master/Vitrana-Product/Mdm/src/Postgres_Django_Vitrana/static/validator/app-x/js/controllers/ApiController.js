angular.module('mdm').controller('ApiController', ['$window','MDMService','toaster','$uibModal','$scope', function($window,MDMService,toaster,$uibModal,$scope) {
    var _self = this
    // _self.columns = columns.columns
    // toaster.pop({type: 'success',title: 'Error',body: 'Test Test Test Test Test Test Test Test Test Test Test Test Test ',timeout: 4500000});
    _self.entities = ['Investigator','Study','Org']
    _self.formData = {
    "keyword" : "",
    "field"   : "",
    "entity_name" : ""

    }
    _self.selectedColumn = ''

    _self.changeEntity = function(){
      MDMService.getElasticSearchFields(_self.selectedEntity).then(function(response){
        console.log(response);
        _self.columns = angular.copy(response.columns)
      })
    }


    _self.getResults = function(){
      console.log(_self.selectedColumn);
      if(_self.selectedColumn == '' || _self.selectedEntity == '' || _self.searchType == '' || _self.formData.keyword == ''){
        toaster.error('Error',"All fields are mandatory")
        return;
      }
      _self.formData.field = _self.selectedColumn
      _self.formData.entity_name = _self.selectedEntity
      console.log(_self.searchType);
      console.log(_self.formData);
      _self.requestInProgress = true
      if(_self.searchType == 'Exact'){
        MDMService.elasticSearchExact(_self.formData).then(function(response){
          _self.requestInProgress = false
          console.log(response);
          if(response.failure){
            toaster.error("Error",response.failure)
          }
          else {
            _self.searchResults = response
          }
        })
      }
      else {
        MDMService.elasticSearchFuzzy(_self.formData).then(function(response){
          _self.requestInProgress = false
          console.log(response);
          if(response.failure){
            toaster.error("Error",response.failure)
          }
          else {
            _self.searchResults = response
          }
        })
      }
    }

    _self.studyDetails = function(record){
      console.log(record);
      var tempForm = {
        'investigator_mdm_id'  : record._source.mdm_id
      }
      // _self.requestInProgress = true
      MDMService.crossMatching(tempForm).then(function(response){
        // _self.requestInProgress = false
        console.log(response);
        _self.studyInfo = angular.copy(response.data)
        _self.modalInstance = $uibModal.open({
          animation: true,
          size : 'md',
          templateUrl: 'studyDetails.html',
          backdrop: 'static',
          scope: $scope
        })
      })
    }

    // var clipboard = new Clipboard('.btn');
    _self.options = ['Exact','Fuzzy']
    // clipboard.on('success', function(e) {
    //     console.info('Action:', e.action);
    //     console.info('Text:', e.text);
    //     console.info('Trigger:', e.trigger);
    //
    //     e.clearSelection();
    // });
    //
    // clipboard.on('error', function(e) {
    //     console.error('Action:', e.action);
    //     console.error('Trigger:', e.trigger);
    // });


}])
