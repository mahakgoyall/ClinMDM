angular.module('mdm').controller('ForgotPasswordController', ['$window','MDMService','toaster', function($window,MDMService,toaster) {
    var _self = this
    _self.email = ''

    _self.formdata = {
      'email' : ''
    }
    _self.requestInProgress = false
    _self.forgotPassword = function(){
      if(_self.email == ''){
        _self.results = "All fields are mandatory"
        return;
      }
      _self.formdata.email = _self.email
      _self.requestInProgress = true
      console.log(_self.formdata);
      MDMService.forgotPassword(_self.formdata).then(function(response){
        console.log(response);
        var toSend = angular.copy(response)
        console.log(toSend);
        if(response.userid){
          MDMService.changePassword(toSend).then(function(response){
            _self.requestInProgress = false
            console.log(response);
            if(response.uid){
              toaster.success("success",'Check you email for a system generated password.')
              window.location.href = "#/"
            }
          })
        }
        else {
          _self.requestInProgress = false
          toaster.error('error',response.failure)
        }
      })
    }
}])
