angular.module('mdm').controller('IndexController', ['$window', '$route', 'MDMService', '$scope', '$rootScope', 'toaster', '$interval', 'ngDialog', function($window, $route, MDMService, $scope, $rootScope, toaster, $interval, ngDialog) {

  // Variable Declaration
  var _self = this
  _self.$route = $route
  _self.entities = ['investigator', 'site', 'study', 'sponsor', 'org']
  _self.sidemenuDropdown = ['browser','ingestions','steward','dashboard']
  _self.sourceLoader = ["home", "browser", "datamap", "connection", "dashboard", "ingestions", "search-engine","reports"]
  _self.steward = ["steward", "home", "stewardanalysis","search-engine"]
  _self.dataManager = ["home", "rule", "validation", "browser", "flow", "dashboard", "ingestions", "search-engine","reports"]
  _self.tasks = {
    "ingestions"        : "Create Ingestion",
    "validation"        : "Data Validation",
    "steward"           : "Data Steward",
    "flow"              : "Create Flow",
    "datamap"           : "Data Mapping",
    "dashboard"         : "Reports",
    "connection"        : "Choose Connection",
    "browser"           : "MDM Browser",
    "rule"              : "Rule Engine",
    "source-engine"     : "Search Engine",
    "users"             : "Users",
    "sources"           : "Source Configuration",
    "stewardanalysis"   : "Steward Analysis",
    "schedule"          : "Scheduler",
    "config"            : "Score Configuration",
    "reports"           : "Reports",
    "search-engine"     : "Search Engine",
    "log"               : "Error Logging",
    "base"              : "Ingestion Details",
    "task"              : "Steward Assignment"
  }
  _self.message = "You don't have permissions to access this page."

  // Function to intialize user info.
  _self.init = function() {
    MDMService.selfInfo().then(function(response) {
      if(response.failure){
        $window.location.reload()
      }
      _self.selfInfo = angular.copy(response)
      _self.role = response.role
      console.log(_self.selfInfo);
    })
  }



      $(window).resize(function()
      {
          if ($(".popover").is(":visible"))
          {
              var popover = $(".popover");
              popover.addClass("noTransition");
              $("input:focus").popover('show');
              popover.removeClass("noTransition");
          }
      });


  // Call the init function
  _self.init()

  // Opens the confirmation dialog/prompt
  _self.confirmation = function() {
    _self.instance = ngDialog.open({
      template: 'leaveConfirmation.html',
      scope: $scope,
      className: 'ngdialog-theme-plain',
      closeByDocument: false,
      showClose: false,
      closeByNavigation: true
    });
  }

  // socket.on('notification', function(data) {
  //     $scope.$apply(function () {
  //     });
  //   });
    // socket.on('foo~bar', function () {
    //     $scope.bar = true;
    //   });

  // Closes the confirmation dialog/prompt
  _self.closeConfirmation = function() {
    _self.instance.close()
  }

  // Logout function
  _self.logout = function() {
    if ($rootScope.isSomethingLeft) {
      _self.nextPath = '/logout'
      _self.confirmation()
    } else {
      $window.location.href = "/logout"
    }
  }

  // Change route according to the option selected in the left menu, takes entity & desired route
  _self.changeRoute = function(entity, path) {
    _self.nextPath = "#/" + entity + "/" + path
    if ($rootScope.isSomethingLeft) {
      _self.confirmation()
    } else if (_self.entities.includes(entity)) {
      $window.location.href = "#/" + entity + "/" + path
    } else {
      $window.location.href = "#/" + path
    }
  }

  // _self.routeMe = function(entity) {
  //   if (_self.role.length == 1) {
  //     if (_self.role.includes(3)) {
  //       $window.location.href = "#/steward"
  //     } else {
  //       $window.location.href = "#/" + entity + "/ingestions"
  //     }
  //   } else {
  //     $window.location.href = "#/" + entity + "/ingestions"
  //   }
  //
  // }

  _self.changeConfirm = function() {
    console.log(_self.nextPath);
    if(_self.nextPath.includes('logout')){
      $window.location.href = "/logout"
    }

    else {
      $window.location.href = _self.nextPath
    }
  }

  _self.permissions = function() {
    if (_self.role) {
      if (_self.role.includes(1)) {
        return true
      } else if (_self.role.length == 1) {
        if (_self.role.includes(1)) {
          return true
        } else if (_self.role.includes(2) && _self.sourceLoader.includes(_self.nextRoute)) {
          return true
        } else if (_self.role.includes(3) && _self.steward.includes(_self.nextRoute)) {
          return true
        } else if (_self.role.includes(4) && _self.dataManager.includes(_self.nextRoute)) {
          return true
        } else {
          return false
        }
      } else if ((_self.role.includes(2) && _self.sourceLoader.includes(_self.nextRoute)) || (_self.role.includes(3) && _self.steward.includes(_self.nextRoute)) || (_self.role.includes(4) && _self.dataManager.includes(_self.nextRoute))) {
        return true
      } else {
        return false
      }
    }
  }

  $scope.$on("$routeChangeSuccess", function(event, current, previous) {
    if (current.$$route) {
      _self.activeLink = current.$$route.activeLink
      _self.currentTask = _self.tasks[_self.activeLink]
    }
    _self.preloader = false
    $rootScope.isSomethingLeft = false
  })

  $scope.$on("$routeChangeStart", function(event, next, previous) {
    $window.scrollTo(0, 0);
    if (next.$$route) {
      _self.nextRoute = next.$$route.activeLink
    }
    // _self.instance = ngDialog.open(
    //   { template: 'confirmation.html',
    //     scope:$scope,
    //     className: 'ngdialog-theme-plain',
    //     closeByDocument : false,
    //     showClose : false,
    //     closeByNavigation :true
    //   });
    _self.preloader = true
    $rootScope.previousRoute = _self.activeLink
    $rootScope.showInBrowser = false;
    $rootScope.showInReports = false;
  })

  _self.back = function() {
    if (_self.activeLink == 'rule') {
      MDMService.rollbackValidations().then(function(response) {
        console.log(response);
        if (response.ok) {
          toaster.success("Success", "Rollback Successful.")
          $window.location.href = "#/" + $rootScope.entityInUse + "/validation";
        } else {
          toaster.error("Error", "There was an error while rollback.Contact Administrator.")
        }
      })
    } else if (_self.activeLink == 'browser') {
      $rootScope.showInBrowser = false;
    } else if (_self.activeLink == 'dashboard') {
      $rootScope.showInReports = false;
    } else if (_self.activeLink == 'validation') {
      $window.location.href = "#/" + $rootScope.entityInUse + "/flow";
    } else {
      $window.history.back()
    }
  }


  _self.progressToHide = function() {
    if (_self.activeLink == 'validation' || _self.activeLink == 'rule' || _self.activeLink == 'datamap' || _self.activeLink == 'connection' || _self.activeLink == 'flow') {
      return true
    } else {
      return false
    }
  }



  // _self.time = function() {
  //   _self.d = Date.now();
  // }
  //
  // $interval(function() {
  //   _self.time();
  // }, 1000);


  // window.onbeforeunload = function(e) {
  //     return 'Please press the Logout button to logout.';
  // };

  setTimeout(function() {
    $('.ui.dropdown.item.left.bar').dropdown({
      on: 'hover'
    });
  }, 500);

  // _self.userdetails = MDMService.getsession();
  // console.log(_self.userdetails);
}])
