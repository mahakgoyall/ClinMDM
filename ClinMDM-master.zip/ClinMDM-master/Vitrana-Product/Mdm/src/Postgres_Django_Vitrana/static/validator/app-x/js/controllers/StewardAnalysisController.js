angular.module('mdm').controller('StewardAnalysisController', ['$window','MDMService','totalCount','toaster','$scope', function($window,MDMService,totalCount,toaster,$scope) {
  var _self = this
  console.log(totalCount);
  if(totalCount.failure){
    toaster.error(totalCount.failure)
  }
  _self.graphData = totalCount
  _self.pending = []
  _self.completed = []
  _self.toView = ''

  angular.forEach(_self.graphData.data,function(value,key){
    // if(value.unresolved > 0 ){
    //   _self.pending.push(value)
    // }
    //
    // else if( value.resolved == value.total){
    //   _self.completed.push(value)
    // }

    if(value.pending_count > 0){
      _self.pending.push(value)
    }
    else if(value.total_count == value.completed_count){
      _self.completed.push(value)
    }
  })

  // for(i=0;i < _self.graphData.ingestions.length ; i++){
  //   var temp = _self.graphData.ingestions[i].ingestion_name
  //   if(_self.graphData.pending_ingestions.includes(temp)){
  //     _self.pending.push(value)
  //   }
  //   else if(_self.graphData.completed_ingestions.includes(temp)){
  //
  //   }
  // }
  console.log(_self.pending);
  console.log(_self.completed);

  _self.selectCategory = {
    // content: 'Hello, World!',
    templateUrl: 'options.html',
    // title: 'Title',
    scope : $scope
  };

  _self.createBar = function(){
    var margin = {top: 30, right: 20, bottom: 30, left: 40},
    width = 275 - margin.left - margin.right,
    height = 300 - margin.top - margin.bottom;

    var x = d3.scaleBand()
        .rangeRound([0, width], .1)
        .paddingInner(0.1);

    var y = d3.scaleLinear()
        .range([height, 0]);

    var xAxis = d3.axisBottom()
        .scale(x);

    var yAxis = d3.axisLeft()
        .scale(y)
        .ticks(5)
        .tickFormat(d3.format(""));
    var svg = d3.select("#barchart").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


    var data = [
      // {
      //   "letter" : "Total",
      //   "frequency" : 10
      // },
      // {
      //   "letter" : "Pending",
      //   "frequency" : 6
      // },
      // {
      //   "letter" : "Completed",
      //   "frequency" : 4
      // }
    ]

    data.push({
      "letter" : "Total",
      "frequency" : _self.graphData.total_record_count
    })
    data.push({
      "letter" : "Pending",
      "frequency" : _self.graphData.total_pending_records
    })
    data.push({
      "letter" : "Completed",
      "frequency" : _self.graphData.completed_records
    })





    console.log(data)

    x.domain(data.map(function(d) { return d.letter; }));
    y.domain([0, d3.max(data, function(d) { return d.frequency; })]);

    svg.append("g")
       .attr("transform", "translate(0," + height + ")")
       .call(d3.axisBottom(x));

   // add the y Axis
   svg.append("g")
       .call(yAxis);


    svg.selectAll(".bar")
        .data(function(d){console.log(data); return data;})
        .enter().append("rect")
        .attr("class", "bar pointer" )
        .attr("x", function(d) { return x(d.letter); })
        .attr("width", x.bandwidth())
        .attr("y", function(d) { return y(d.frequency); })
        .on("click", function(d){
          // d3.select(this).style("fill", "red");
          _self.toView = d.letter
          $scope.$apply()
        })
        .attr("height", function(d) { return height - y(d.frequency); });

    function type(d) {
      d.frequency = +d.frequency;
      return d;
    }
  }

  _self.createBar()

  // _self.labels = ["Completed","Total","Pending"];
  // _self.data = [300, 500, 100];
  //
  // _self.options =  {
  //  responsive: false,
  //  maintainAspectRatio: false
  // }


  // if(_self.ingestions.list[0]){
  //   _self.selectedIngestion = 0
  // }
}])
