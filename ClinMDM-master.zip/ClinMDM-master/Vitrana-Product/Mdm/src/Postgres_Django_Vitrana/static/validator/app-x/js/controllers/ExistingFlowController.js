angular.module('mdm').controller('ExistingFlowController', ['$window','MDMService','flowData','$route','cfpLoadingBar','$interval','$scope', function($window,MDMService,flowData,$route,cfpLoadingBar,$interval,$scope) {
    var _self = this
    _self.validation = flowData._source[$route.current.params.flowID].validation_rules
    _self.rules = flowData._source[$route.current.params.flowID].matching_rules
    _self.requestInProgress  =false

    _self.done = ["ingestion"]
    _self.init = function(){
      _self.requestInProgress  = true
      // MDMService.postValidations(_self.validation).then(function(response){
      //  _self.done.push('validations')
      //
      //   MDMService.postRules(_self.rules).then(function(response){
      //    _self.done.push('rules')
      //    $window.location.href = ''
      //    _self.requestInProgress  = false
      //   })
      // })
      _self.status = "Applying Validations"

      setTimeout(function(){
        $('#loadingBar').progress('set percent', 10)
      },1000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 15)
      },1000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 20)
      },2000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 25)
        _self.done.push('validations')
        $scope.$apply()
      },3000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 35)
        _self.status = "Applying Rules"
        $scope.$apply()

      },3500);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 45)
      },4000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 55)
      },4500);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 60)
      },5000)
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 65)
      },5500);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 75)
      },6000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 85)
        _self.status = "Almost Done"
      },7000);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 90)
      },8000)
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 100)
        _self.status = "Completed, Wait while we redirect you to Data Steward"
        _self.done.push('rule')
        $scope.$apply()
      },9500);
      setTimeout(function(){
        $('#loadingBar').progress('set percent', 100)
        $window.location.href = "http://104.199.199.193:5000/#/steward"
      },12000);


    }

    _self.init()


}])
