angular.module('mdm').controller('ConnectionController', ['$window','MDMService','$scope','toaster','ngProgressFactory','$uibModal','ngDialog','$rootScope','customSourceList',function($window,MDMService,$scope,toaster,ngProgressFactory,$uibModal,ngDialog,$rootScope,customSourceList) {
  var _self = this
  _self.selectedOption = ''
  console.log(customSourceList);
  _self.customSourceList = customSourceList
  _self.requestInProgress = false
  _self.something = 'upward'
  _self.uploadInProgress = false
  _self.type = ["DB Connection","Amazon S3"]
  _self.selectedType = ""
  $('.ui.customdrop').dropdown();
  _self.sourceList = []
  for(var key in _self.customSourceList) {
    var c = _self.customSourceList[key]
    for (var i = 0; i < c.length; i++) {
      var z = c[i].name;
      _self.sourceList.push(z)
    }
  }
  // for (var i = 0; i < _self.customSourceList.db_connection.length; i++) {
  // }
  // for (var i = 0; i < _self.customSourceList.Amazon_S3_bucket.length; i++) {
  //   var z = _self.customSourceList.Amazon_S3_bucket[i].name;
  //   _self.sourceList.push(z)
  // }
  console.log(_self.sourceList);
  _self.selectedSource = ''
  _self.s3FormData = {
    "key_id" : "",
    "secret_id" : "",
    "bucket_name" : "",
    "sourcePriority" : ""
  }
  _self.formData = {
       'file': ''
   }


  _self.dbForm = {
    "database_name" : "",
    "username" : "",
    "host_name" : "",
    "password" : "",
    "port" : "",
    "table_name" : "",
    "sourcePriority" : ""

 }
 _self.clearForm = function () {
   _self.s3FormData = {
     "key_id" : "",
     "secret_id" : "",
     "bucket_name" : "",
     "sourcePriority" : ""
   }

   _self.dbForm = {
     "database_name" : "",
     "username" : "",
     "host_name" : "",
     "password" : "",
     "port" : "",
     "table_name" : "",
     "sourcePriority" : ""
  }
 }
 // _self.updateSourceList = function () {
 //   _self.sourceList = []
 //   if (_self.selectedType == 'DB Connection') {
 //     for (var i = 0; i < _self.customSourceList.db_connection.length; i++) {
 //       var z = _self.customSourceList.db_connection[i].name;
 //       _self.sourceList.push(z)
 //     }
 //     _self.s3FormData = {
 //       "key_id" : "",
 //       "secret_id" : "",
 //       "bucket_name" : "",
 //       "sourcePriority" : ""
 //     }
 //   } else if (_self.selectedType == 'Amazon S3') {
 //     for (var i = 0; i < _self.customSourceList.Amazon_S3_bucket.length; i++) {
 //       var z = _self.customSourceList.Amazon_S3_bucket[i].name;
 //       _self.sourceList.push(z)
 //     }
 //     _self.dbForm = {
 //       "database_name" : "",
 //       "username" : "",
 //       "host_name" : "",
 //       "password" : "",
 //       "port" : "",
 //       "table_name" : "",
 //       "sourcePriority" : ""
 //    }
 //    // _self.selectedSource = ''
 //   }
 //  //  _self.clearForm()
 // }
 // _self.updateSourceList();
 _self.updateSourceEntries = function () {
   for(var key in _self.customSourceList) {
    //  alert(options.commands[key].cmd);
    var c = _self.customSourceList[key]
    for (var i = 0; i < c.length; i++) {
      var z = c[i].conn_string;
      if (z.conn_method == 'Amazon_S3_bucket') {
        if (c[i].name == _self.selectedSource) {
          _self.selectedType = z.conn_method
          console.log("hesada");
          _self.s3FormData = {
            "key_id" : z.key_id,
            "secret_id" : z.secret_id,
            "bucket_name" : z.bucket_name,
            "sourcePriority" : c[i].priority
          }
        }
      } else if (z.conn_method == 'db_connection') {
        if (c[i].name == _self.selectedSource) {
          _self.selectedType = z.conn_method
          _self.dbForm = {
            "database_name" : z.database_name,
            "username" : z.username,
            "host_name" : z.host_name,
            "password" : z.password,
            "port" : z.port,
            "table_name" : z.table_name,
            "sourcePriority" : c[i].priority
          }
        }
      }
    }
   }
  //  _self.updateSourceList();
 }

_self.submit = function () {
  console.log(_self.s3FormData);
  console.log(_self.dbForm);
  if (_self.selectedType == 'db_connection') {
    var formdata = {
     "source_root_name" : _self.selectedSource
    }
    console.log(formdata);
    MDMService.dbConnect(formdata).then(function(response) {
     console.log(response);
     if(response.ok == 'success') {
       _self.requestInProgress = false
       toaster.success("Success", "Connected to Database");
       $window.location.href = "#/" + $rootScope.entityInUse + "/datamap";
     } else {
       _self.requestInProgress = false
       toaster.error("Failure", "Unable to Connect");
     }
    })
  } else if (_self.selectedType == 'Amazon_S3_bucket') {
    var formdata = {
     "source_root_name" : _self.selectedSource,
     "entity_name" : $rootScope.entityInUse
    }
    console.log(formdata);
    _self.connectingS3 = true
    MDMService.s3Connect(formdata).then(function(response){
      _self.connectingS3 = false
     console.log(response);
     if(response.failure){
       _self.requestInProgress = false
       toaster.error("Failure", response.failure);
     }
     else {
       _self.requestInProgress = false
       $window.location.href = "#/" + $rootScope.entityInUse + "/datamap";
     }
    })
  }
}


  _self.toggle = function(option){
    console.log(option)
    if(_self.selecteOption == option){
      _self.selectedOption = ''
    }
    else {
      _self.selectedOption = option
    }
  }

  // To upload csv
  _self.uploadCSV = function(){
    if(!_self.formData.file){
      toaster.error("Error","Select a file first.")
      return;
    }

    _self.uploadingFile = true
    MDMService.uploadCSV(_self.formData).then(function(response){
      // _self.modalInstance = $uibModal.open({
      //   animation: true,
      //   templateUrl: 'continue.html',
      //   backdrop: 'static',
      //   size: 'md',
      //   scope: $scopey
      // })
      // _self.instance = ngDialog.open({ template: 'continue.html',scope:$scope, className: 'ngdialog-theme-plain',closeByDocument : false,showClose : false,closeByNavigation :true });


      _self.uploadingFile = false
      // _self.requestInProgress = false
      $window.location.href = "#/" + $rootScope.entityInUse + "/datamap";

    },function(error){
      toaster.error(error)
      _self.uploadingFile = false
    })
  }

_self.closeModal = function () {
  console.log("k");

  $('#attachmentName').val(''); // cancel upload file.
  _self.formData = {
       'file': ''
   }
   _self.dbForm = {
     "database_name" : "",
     "username" : "",
     "host_name" : "",
     "password" : "",
     "port" : "",
     "table_name" : ""
  }
  _self.s3FormData = {
    "key_id" : "",
    "secret_id" : "",
    "bucket_name" : "",
    "file_name" : ""
  }
  _self.instance.close()
};



  /**************************************************************************/
var fileExtentionRange = '.csv';
var MAX_SIZE = 30; // MB
$(document).on('change', '.btn-file :file', function() {
    var input = $(this);
    if (navigator.appVersion.indexOf("MSIE") != -1) { // IE
        var label = input.val();
        input.trigger('fileselect', [1, label, 0])
    } else {
        var label = input.val().replace(/\\/g, '/').replace(/.*\//, '')
        var numFiles = input.get(0).files ? input.get(0).files.length : 1
        var size = input.get(0).files[0].size
        _self.formData.file = $(this).get(0).files[0]
        console.log(_self.formData)
        $scope.$apply()
        fileselect(numFiles, label, size)
    }
});
fileselect = function(numFiles, label, size) {
        $('#attachmentName').attr('name', 'attachmentName') // allow upload.
        var postfix = label.substr(label.lastIndexOf('.'))
        if (fileExtentionRange.indexOf(postfix.toLowerCase()) > -1) {
            if (size > 1024 * 1024 * MAX_SIZE) {
                alert('max size：<strong>' + MAX_SIZE + '</strong> MB.')
                $('#_attachmentName').val('')
                $('#attachmentName').removeAttr('name'); // cancel upload file.
            } else {
                $('#_attachmentName').val(label)
            }
        } else {
            toaster.error("Error", "Only" + fileExtentionRange + ' file types are allowed');
            $('#attachmentName').val(''); // cancel upload file.
            _self.formData = {
                 'file': ''
             }
            $scope.$apply()
        }
    }
    /**************************************************************************/

}])
