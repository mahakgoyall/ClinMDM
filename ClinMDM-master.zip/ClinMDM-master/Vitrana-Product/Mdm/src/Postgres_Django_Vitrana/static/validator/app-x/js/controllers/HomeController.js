angular.module('mdm').controller('HomeController', ['$window','MDMService','selfInfo', function($window,MDMService,selfInfo) {
    var _self = this
    _self.selfInfo = selfInfo
    _self.noStudyData  = false
    _self.noOrgData = false
    _self.noInvData = false

    // _self.rolesToShow = []
    var formdata = {
      "userid" : _self.selfInfo.user_id
    }
    // _self.studyColors  = ["#E5E8E8","#fff","#fff"]
    // _self.orgColors  = ["#E5E8E8","#fff","#fff"]
    MDMService.getDashData(formdata).then(function (response) {
           console.log(response)
           _self.dashData = response
           if (_self.dashData) {
            //  _self.investigatorData = [_self.dashData.investigator.data_steward, _self.dashData.investigator.source_user, _self.dashData.investigator.data_manager];
            if(_self.dashData.study.total_injections == 0){
              _self.studyData = [1,0, 0];
              _self.studyColors  = ["#E5E8E8","#fff","#fff"]
              _self.studyLabels = ["No Ingestion", " ", " "];
              _self.labels = ["Data Steward", "Source User", "Data Manager"];
              _self.noStudyData  = true

            }
            else{
               _self.studyData = [_self.dashData.study.data_steward, _self.dashData.study.source_user, _self.dashData.study.data_manager];
               _self.studyColors = ["#b8bc45","#79913e","#395a85"]
               _self.studyLabels = ["Data Steward", "Source User", "Data Manager"];
            }
            if(_self.dashData.org.total_injections == 0 ){
              _self.organizationData = [1, 0, 0];
              _self.orgColors  = ["#E5E8E8","#fff","#fff"]
              _self.orgLabels = ["No Ingestion", " ", " "];
              _self.noOrgData = true
            }
            else {
              _self.organizationData = [_self.dashData.org.data_steward, _self.dashData.org.source_user, _self.dashData.org.data_manager];
              _self.orgColors = ["#b8bc45","#79913e","#395a85"]
              _self.orgLabels = ["Data Steward", "Source User", "Data Manager"];

            }
            if(_self.dashData.investigator.data_manager == 0 && _self.dashData.investigator.data_steward == 0 && _self.dashData.investigator.source_user == 0){
              _self.investigatorData = [1, 0, 0];
              _self.investigatorColors  = ["#E5E8E8","#fff","#fff"]
              _self.investigatorLabels = ["No Ingestion", " ", " "];
              _self.noInvData = true

            }
            else {
              _self.investigatorData = [_self.dashData.investigator.data_steward, _self.dashData.investigator.source_user, _self.dashData.investigator.data_manager];
              _self.investigatorColors = ["#b8bc45","#79913e","#395a85"]
              _self.investigatorLabels = ["Data Steward", "Source User", "Data Manager"];

            }



           } else {
             _self.investigatorData = [200, 1000, 300];
             _self.studyData = [200, 1000, 300];
             _self.organizationData = [200, 1000, 300];
           }

           _self.labels = ["Data Steward", "Source User", "Data Manager"];
           _self.graphHeight = 150
           _self.graphWidth = 150
           Chart.defaults.global.tooltipFontSize = 4;
           _self.options =  {
             responsive: false,
             maintainAspectRatio: false,
             tooltipTemplate: function(label) {
               console.log(label);
                    return label.value;
                }           }
       })
      _self.init = function(){
        _self.role_options = {
          1 : 'Admin',
          2: 'Source Loader',
          3: 'Steward User',
          4: 'Data Manager'
        }


        // for(i=0;i<_self.selfInfo.role.length;i++){
        //   var temp = _self.selfInfo.role[i]
        //   _self.rolesToShow.push(_self.role_options[temp])
        // }
      }
      _self.init()

    _self.routeMe = function(){
      if (_self.selfInfo.role.includes(3)){
        $window.location.href = "#/steward"
      }
      else {
        $window.location.href = "#/ingestions"
      }
    }


  // MDMService.setsession(_self.userdetails);
    // _self.submit = function(usrname,passwd) {
    //     MDMService.sublogin(usrname,passwd).then(function(response){
    //         console.log(response)
    //         if(response == 'Success') {
    //
    //         }
    //     })
    // }
    // sessionStorage.role = JSON.stringify(_self.role);
    // _self.role = JSON.parse(sessionStorage.role);
    // console.log(_self.role);
    $('.special.card .image').dimmer({
      on: 'hover'
    });
    $('.message .close').on('click', function() {
      $(this).closest('.message').transition('fade');
    });
}])

angular.module('mdm').filter( 'camelCase', function ()
  {
      var camelCaseFilter = function ( input )
      {
          var words = input.split( ' ' );
          for ( var i = 0, len = words.length; i < len; i++ )
              words[i] = words[i].charAt( 0 ).toUpperCase() + words[i].slice( 1 );
          return words.join( ' ' );
      };
      return camelCaseFilter;
  } )
