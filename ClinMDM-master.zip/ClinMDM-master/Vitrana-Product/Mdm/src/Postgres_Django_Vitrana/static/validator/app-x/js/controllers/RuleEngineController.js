angular.module('mdm').controller('RuleEngineController', ['$window','MDMService','columnList','$scope','$uibModal','toaster','currentFlow','ngDialog','$rootScope', function($window,MDMService,columnList,$scope,$uibModal,toaster,currentFlow,ngDialog,$rootScope) {
    var _self = this
    _self.obj = {};
    _self.toSend = {

    }

    _self.score = {
      'exact'  : 95.0,
      'partial' : 75.0
    }

    _self.exactTemp = 95.0
    _self.partialTemp = 75.0


    //
    _self.isOpen = ''

    _self.isChanging = {

    }





    _self.currentRule = 'Rule 1'
    // _self.selectedIndex = 0

    // $scope.$watch('_self.selectedIndex' ,function(){
    //   _self.currentRule = 'Rule ' + (_self.selectedIndex + 1)
    //
    //   console.log(_self.selectedIndex);
    //   console.log(_self.currentRule);
    //
    // });
    // _self.selectedIndex = 0




    _self.selectMatch = function(type){
      console.log(_self.isOpen);
      console.log(_self.currentRule);
      var tempkey   =  ''
      console.log(_self.selectedIndex);
      // if(_self.isOpen[_self.currentRule]){
      //   angular.forEach(_self.isOpen[_self.currentRule],function(value,key){
      //     if(value == true){
      //       console.log(key);
      //       tempkey = key
      //     }
      //   })
      // }
      //
      // else {
      //   tempkey = _self.currentColumn
      // }

      // console.log(tempkey);
      if(_self.toSend[_self.currentRule]){
        if(_self.toSend[_self.currentRule].column.includes(_self.currentColumn)){
          return;
        }
        _self.toSend[_self.currentRule].column.push(_self.currentColumn)
        _self.toSend[_self.currentRule].match_type.push(type)
      }
      else {
        _self.toSend[_self.currentRule] = {
          'column'         : [],
          'match_type'     : []
        }

        _self.toSend[_self.currentRule].column.push(_self.currentColumn)
        _self.toSend[_self.currentRule].match_type.push(type)
      }

      console.log(_self.currentRule);
      console.log(_self.currentColumn);
      _self.isOpen[_self.currentRule][_self.currentColumn] = false
      console.log(_self.isOpen);



    }


    _self.open = function(index,x){
      console.log(_self.isOpen);
      // console.log(_self.selectedIndex);
      // console.log(_self.isOpen);
      // console.log(_self.currentRule);
      // console.log(x);
      _self.currentColumn = x
      // if(_self.isOpen  == false){
      //   _self.isOpen = true
      //
      // }
      // else {
      //
      //   console.log(_self.isOpen);
      //   _self.isOpen[_self.currentRule][x] = true
      //   $scope.$apply()
      //   console.log(_self.isOpen);
      //
      // }
      // console.log(_self.isOpen);
      // console.log(_self.isOpen);
      // setTimeout(function() {
      //   if(_self.isOpen[_self.currentRule][x] == false){
      //     _self.isOpen[_self.currentRule][x] = true
      //     $scope.$apply()
      //   }
      // }, 500);


    }




    _self.toRemove = []
    _self.columnList = columnList
    console.log(columnList);
    _self.removable = false
    _self.selectedIndex = 0
    _self.toSearch = ''
    _self.requestInProgress = false
    _self.noData = false
    _self.flowDetails = currentFlow
    // _self.isOpen = false
    console.log(currentFlow);
    // if(columnList.failure || currentFlow.failure){
    //   toaster.error(columnList.failure)
    //   $window.location.href = "#/" + $rootScope.entityInUse + "/ingestions";
    //   return
    // }


    if(_self.flowDetails.matcher_rules && _self.flowDetails.matcher_rules.rules ){
      var keys = Object.keys(_self.flowDetails.matcher_rules.rules)
      console.log(length);
      if(keys.length != 0){
        _self.toSend = angular.copy(_self.flowDetails.matcher_rules.rules)
        _self.score  = angular.copy(_self.flowDetails.matcher_rules.score)
      }
      else {
        init()
      }
    }
    else {
      init()
    }
    _self.source = ["Source 1", "Source 2"]
    function init() {
      //  _self.formData = []
        _self.myKey = "Rule 1"
        _self.toSend[_self.myKey] = {
          'column'        : [],
          'match_type'    : []
        };

        // obj.myKey.push("k")
      //  _self.formData.push(_self.obj)
        // _self.obj[_self.myKey].push(_self.columnList[3])
        // _self.obj[_self.myKey].push(_self.columnList[5])
        //
        // _self.obj[_self.myKey].push(_self.columnList[6])
        console.log(_self.toSend);
      }

    // console.log(_self.obj)
    _self.addRule = function() {
        var length = Object.keys(_self.toSend).length + 1
        var temp = "Rule " + length
        // _self.obj[temp] = [];
        _self.toSend[temp] = {
          'column'         : [],
          'match_type'     : []
        }
        // _self.obj[temp].push(_self.columnList[2])
        _self.length = Object.keys(_self.toSend).length - 1
        // obj.myKey.push("k")
        _self.selectedIndex = Object.keys(_self.toSend).length -1
        _self.currentRule = 'Rule ' + (_self.selectedIndex + 1)

    }

    _self.addField = function(index){
      var _temp = index + 1
      var rule = "Rule " + _temp
      _self.obj[rule].push("")
    }


    _self.selectCategory = {
      // content: 'Hello, World!',
      templateUrl: 'options.html',
      // title: 'Title',
      scope : $scope
    };

    _self.update = {
      // content: 'Hello, World!',
      templateUrl: 'scoreUpdate.html',
      // title: 'Title',
      scope : $scope
    };


    _self.updateMatch = function(type){
      console.log(_self.isChanging);
      console.log(_self.currentlyUpdating);
      var tempIndex = _self.toSend['Rule 1'].column.indexOf(_self.currentlyUpdating)
      _self.toSend['Rule 1'].match_type[tempIndex] = type
      _self.isChanging[_self.currentlyUpdating] = false
      // _self.toSend['Rule 1'][_self.currentlyUpdating] =

    }
//
// _self.toShow = function() {
//   var data = _self.obj
//   var siz = Object.size = function(data) {
//     size = 0, key;
//     for (key in data) {
//       if (data.hasOwnProperty(key)) size++;
//     }
//     return size;
//   };
//   // console.log(siz);
//   for(i=0;i<siz;i++) {
//     if(_self.obj['Rule '+i+''].length == 0) {
//       return true
//     } else {
//       return false
//     }
//   }
// }



    _self.removeField = function(index,key){
      // console.log(_self.obj)
      //console.log(_self.obj[key][index])
      _self.obj[key].splice(index,1)
      // console.log(_self.obj)

    }

    _self.removeLabel = function(index,key){
      _self.isChanging = {}
      // console.log(_self.obj)
      //console.log(_self.obj[key][index])




      // else if(){
      //
      // }
      _self.toSend[key].column.splice(index,1)
      _self.toSend[key].match_type.splice(index,1)
      if(_self.toSend['Rule 1'].column.length == 0){
        $rootScope.isSomethingLeft = false
      }
      if(_self.toSend[key].column.length == 0){
        // console.log(_self.obj);
      }
      // console.log(_self.obj);
      // console.log(_self.flowDetails.matcher_rules);
      // if((angular.toJson(_self.toSend)) == (angular.toJson(_self.flowDetails.matcher_rules))){
      //   $rootScope.isSomethingLeft = false
      // }
      // if(((angular.toJson(_self.toSend)) != (angular.toJson(_self.flowDetails.matcher_rules))) && ((Object.keys(_self.flowDetails.matcher_rules)).length != 0)){
      //   $rootScope.isSomethingLeft = true
      // }

      // console.log(_self.obj)
      console.log(_self.toSend);
    }

    _self.addLabel = function(index,name){
      var _temp = index + 1
      var rule = "Rule " + _temp
      if(!_self.obj[rule].includes(name)){
        _self.obj[rule].push(name)
        // console.log(_self.obj);
        // $('.ui.search.dropdown')
        // .dropdown('restore defaults')
        _self.something = ''
        _self.toSearch = ''
        if(_self.obj == _self.flowDetails.matcher_rules){
          $rootScope.isSomethingLeft = false
        }
        else{
          $rootScope.isSomethingLeft = true
        }
      }


    }



    _self.changeValue = function(index,key,field){
      _self.obj[key][index] = field
    }

    _self.submit = function(){
      // var flag = true
      // angular.forEach(_self.toSend,function(value,key){
      //   console.log(value.column.length);
      //   if(value.column.length == 0){
      //     toaster.pop('error', "Error", "Please choose atleast one column in each rule");
      //     flag = false
      //     return;
      //   }
      // })
      // if(_self.toSend['Rule 1']){
      //   if(_self.toSend['Rule 1'].column.length == 0){
      //       toaster.pop('error', "Error", "Please choose atleast one column in each rule");
      //   }
      // }
      // if(Object.keys(_self.obj).length == 0){
      //   toaster.pop('error', "Error", "Please choose atleast one column in each rule");
      //   return;
      // }
      // for(i=0;i<(Object.keys(_self.obj).length);i++){
      //   var rule = "Rule " +  (i+1)
      //   if(_self.obj[rule].length == 0){
      //     toaster.pop('error', "Error", "Please choose atleast one column in each rule");
      //     return;
      //   }
      // }
      if(_self.toSend['Rule 1'].column.length != 0){

        var tempForm = {}
        tempForm['rules'] = _self.toSend
        tempForm['score'] = _self.score
        console.log(tempForm)
        _self.requestInProgress = true
        MDMService.postRules(tempForm).then(function(response){
          $rootScope.isSomethingLeft = false
          console.log(response)
          _self.requestInProgress = false
          _self.graphData = angular.copy(response)
          // toaster.pop('success', "Success", "Data mastered successfully & Partial matches sent to Steward");
        _self.modalInstance = $uibModal.open({
             animation: true,
             backdrop: 'static',
             templateUrl: 'ruleModal.html',
             backdrop: 'static',
             scope: $scope
          })

          _self.modalInstance.opened.then(function(response){
            setTimeout(function(){
              if (_self.graphData.nomatch_ref[0] == 0 && _self.graphData.partial_ref[0] == 0 && _self.graphData.exact_ref[0] == 0){
                _self.noData = true
              }
              else {
                _self.createRefGraph(_self.graphData)
              }

            }, 200);
        })
        },function(error){
          _self.requestInProgress = false
          toaster.error('Error', error);
          return;
        })
      }
    }

    _self.ruleSettings = function(index,key){
      if (index == _self.selectedIndex){
        _self.removeRule(index,key)
        if(index == 1){
          _self.selectedIndex = 0
          _self.currentRule = 'Rule 1'

        }
      }
      else {
        _self.selectedIndex = index
        _self.currentRule = 'Rule ' + (index+1)
      }
    }

    _self.removeRule = function(index,key){
      if((Object.keys(_self.toSend)).length == 1){
        _self.toSend['Rule 1'].column = []
        _self.toSend['Rule 1'].score = []
        _self.selectedIndex = 0
        _self.currentRule = 'Rule 1'
        return;
      }
      delete _self.toSend[key]
      // if((angular.toJson(_self.toSend)) == (angular.toJson(_self.flowDetails.matcher_rules))){
      //   $rootScope.isSomethingLeft = false
      // }
      if (index !== Object.keys(_self.toSend).length){
        for (i=0;i<Object.keys(_self.toSend).length - (index);i++){
          var temp = "Rule " + (index+1+i)
          var temp_ = "Rule " + (index+2+i)
          _self.toSend[temp] = _self.toSend[temp_]
          delete _self.toSend[temp_]
        }
        _self.selectedIndex = _self.selectedIndex - 1
        _self.currentRule = 'Rule ' + (_self.selectedIndex + 1)
      }

  }

  _self.checkIfExists = function(key){
    var _temp = _self.selectedIndex + 1
    var rule = "Rule " + _temp
    if (_self.toSend[rule].column.includes(key) || key == null){
      return true
    }
    else {
      return false
    }
  }
  _self.rollbackConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'confirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }
  _self.closeConfirmation = function(){
    _self.instance.close()

  }

  _self.rollBack = function(){
    _self.modalInstance.dismiss('cancel');
    _self.instance.close()
    MDMService.rollbackRules().then(function(response){
      console.log(response);
      if(response.ok){
        toaster.success("Success", "Rollback Successful.")
      }
      else {
        toaster.error("Error", "There was an error while rolling back.Contact Administrator for more information.")
      }

    })
    // _self.obj = {};
    _self.selectedIndex = 0
    _self.toSearch = ''
    _self.noData = false
    // init()
  }
  // _self.rollBack = function(){
  //   MDMService.rollbackValidations().then(function(response){
  //   })
  // }


  // _self.setPriority = function(){
  //   $('.ui.basic.small.modal').modal('show');
  // }
  //
  _self.moveUp = function(index,name){
    var temp = _self.source[index-1]
    _self.source[index-1] = name
    _self.source[index] = temp
  }
  _self.moveDown = function(index,name){
    var temp = _self.source[index+1]
    _self.source[index+1] = name
    _self.source[index] = temp
  }


  _self.setPriority = function(){
    _self.priorityInstance = $uibModal.open({
     animation: true,
     templateUrl: '/static/partials/priority.html',
     scope: $scope
      })
  }

  _self.viewValidations = function(){
    _self.modalInstance = $uibModal.open({
     animation: true,
     backdrop: 'static',
     templateUrl: 'validationDetails.html',
     scope: $scope
   })
  }



  _self.createRefGraph = function(graph) {
    var data = [];
    var legendNames = []
    if(graph.exact_ref > 0){
      data.push({
        letter: "Exact Match",
        presses : graph.exact_ref[0]
      })
      legendNames.push("Exact Match   " + "(" + graph.exact_ref[0] + ")")
    }
    if(graph.partial_ref > 0){
      data.push({
        letter : "Partial Match",
        presses : graph.partial_ref[0]
      })
      legendNames.push("Partial Match   " + "(" + graph.partial_ref[0] + ")")

    }
    if(graph.nomatch_ref > 0){
      data.push({
      letter : "No-Match",
      presses: graph.nomatch_ref[0]
      })
      legendNames.push("No Match   " + "(" + graph.nomatch_ref[0] + ")")

    }
    if(graph.insufficient_data[0][0] > 0){
      data.push({
      letter : "Insufficient data records",
      presses: graph.insufficient_data[0][0]
      })
      legendNames.push("Insufficient data   " + "(" + graph.insufficient_data[0][0] + ")")
    }
    // console.log(data)


    tip = d3.tip().attr('class', 'd3-tip').html(function(d) {
      // console.log(d);
      return d;
    });
    var width = 550,
    height = 300,
    // Think back to 5th grade. Radius is 1/2 of the diameter. What is the limiting factor on the diameter? Width or height, whichever is smaller
    radius = Math.min(width, height) / 2;
    var color = d3.scaleOrdinal()
    .range(["#40699b", "#7f9a48", "#9e413d"]);

     var pie = d3.pie()
      .value(function(d) { return d.presses; })(data);

      var arc = d3.arc()
      .outerRadius(radius - 10)
      .innerRadius(0);

    var labelArc = d3.arc()
      .outerRadius(radius - 70)
      .innerRadius(radius - 40);

    var svg = d3.select("#pie")
    .append("svg")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("transform", "translate(170," + height/2 +")"); // Moving the center point. 1/2 the width and 1/2 the height

    svg.call(tip);

    var g = svg.selectAll("arc")
      .data(pie)
      .enter().append("g")
      .attr("class", "arc");

    g.append("path")
    .attr("d", arc)
    .style("fill", function(d) { return color(d.data.letter);});

    g.append("text")
    .attr("transform", function(d) { return "translate(" + labelArc.centroid(d) + ")"; })
    .text(function(d) { return d.data.letter;})
    .style("fill", "#fff")
    .style("display", "none");


    g.on('mouseover', function(data) {
      tip.show("Count : " + data.value)
    })
    g.on('mouseout', tip.hide)

    var ordinal = d3.scaleOrdinal()
    .domain(legendNames)
    .range(["#40699b", "#7f9a48", "#9e413d"]);
    var svg = d3.select("#pie").selectAll("svg")

  svg.append("g")
    .attr("class", "legendOrdinal")
    .attr("transform", "translate(340,30)");

  var legendOrdinal = d3.legendColor()
    //d3 symbol creates a path-string, for example
    //"M0,-8.059274488676564L9.306048591020996,
    //8.059274488676564 -9.306048591020996,8.059274488676564Z"
    // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
    // .shapePadding(10)
    .scale(ordinal);

  svg.select(".legendOrdinal")
    .call(legendOrdinal);

  }


    // $('html,body').animate({
    // scrollTop: $(".ui.center.header").offset().top
    // }, 'slow');

    _self.discardPriorities = function(){
      _self.priorityInstance.dismiss('cancel');
    }

    _self.finish = function(){
      MDMService.finishRuleMatch().then(function(response){
        console.log(response);
      })
      MDMService.syncMDM('mdm_golden').then(function(response){
        console.log(response);
      })
      _self.modalInstance.dismiss()
      toaster.pop('success', "Success", "Data mastered successfully & Partial matches sent to Steward");
      $window.location.href = "#/reports"
    }

    _self.search = function(term){
      if (_self.toSearch != ''){
        var temp = term.toLowerCase()
        if (temp.includes(_self.toSearch)){
          return "grey"
        }
        else {
          return "lightgrey"
        }
      }

    }

    _self.matchType = function(key,index){
      if(_self.toSend[key].match_type[index] == 'Exact'){
        return 'green'
      }

      else if(_self.toSend[key].match_type[index] == 'Partial'){
        return 'lightgrey'
      }

    }

    _self.configure = function(){
      _self.modalInstance = $uibModal.open({
           animation: true,
           backdrop: 'static',
           templateUrl: 'configure.html',
           backdrop: 'static',
           scope: $scope
        })
    }

    _self.closeModal = function (parameter) {
      _self.modalInstance.dismiss('cancel');
      if(parameter == 'Discard'){
        _self.exactTemp = _self.score.exact
        _self.partialTemp = _self.score.partial
      }
      else if(parameter == 'Update'){
        _self.score.exact = _self.exactTemp
        _self.score.partial = _self.partialTemp
        toaster.success('Success','Score Updated')
      }

    }

}])
