angular.module('mdm').controller('ScheduleController', ['$window','MDMService','toaster','$uibModal','$scope','scheduleList','$rootScope', function($window,MDMService,toaster,$uibModal,$scope,scheduleList,$rootScope) {
    var _self = this
    _self.noSchdeule = false
    console.log(scheduleList);
    if(scheduleList.failure){
      // toaster.error('Error', scheduleList.failure)
      _self.noSchdeule = true
    }
    else {

      _self.scheduleList = angular.copy(scheduleList.ui_info)
    }
    _self.actions =['View Ingestions','Pause','Shutdown','Delete']
    _self.frequency = ['Hourly','Daily','Weekly','Monthly']
    _self.daysFull = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
    _self.daysTrimmed = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    _self.every = ['First','Second','Third','Fourth']
    _self.dates = []
    _self.days = []
    for(i=1;i<32;i++){
      _self.dates.push(i)
    }
    for(i=1;i<8;i++){
      _self.days.push({
        'front' : _self.daysFull[i],
        'back'  : _self.daysTrimmed[i]
      })
    }
    _self.schedule = {
      'start_date'   :   new Date(),
      'end_date'     :   new Date(),
      'frequency'    :   '',
      'time'         :   new Date(),
      'days'         : []
    }


    _self.isOpen = {
      'start'    : false,
      'end'      : false,
      'daily'    : false,
      'hourly'   : false
    }
    _self.openCalendar = function(e,key) {
          e.preventDefault();
          e.stopPropagation();
          _self.isOpen[key] = true;
          console.log(_self.isOpen);
    };
    _self.performAction = function(schedule){
      if(_self.selected == 'View Ingestions'){
        $window.location.href = "#/" + $rootScope.entityInUse + "/scheduler/ingestion/" + schedule.ingest_name
      }
      // else if(_self.selected == 'View Details'){
      //   _self.schedule = schedule.schedule_details
      //   _self.modifySchedule()
      // }
    }


    _self.modifySchedule = function(){
      _self.modalInstance = $uibModal.open({
       animation: true,
       templateUrl: 'schedule.html',
       backdrop: 'static',
       scope: $scope
      })
    }


    _self.getDetails = function(schedule){
      // console.log(schedule);
      // var tempForm = {
      //   'ingest_name'   : schedule.ingest_name
      // }
      // MDMService.getScheduleDetails(tempForm).then(function(response){
      //   console.log(response);
      // })
      $window.location.href = "#/" + $rootScope.entityInUse + "/scheduler/ingestion/" + schedule.ingest_name
    }

    _self.saveSchedule = function(){
      var tempForm = {}
      if(_self.schedule.frequency == 'Hourly' ||  _self.schedule.frequency == 'Daily'){
        var tempForm   = {
          'name'         : _self.schedule.name,
          'start_date'   : _self.schedule.start_date,
          'end_date'     : _self.schedule.end_date,
          'frequency'    : _self.schedule.frequency,
          'hour'         : _self.schedule.hour,
          'minutes'      : _self.schedule.minutes,
          'ingestions'   : _self.selectedIngestions
        }
        console.log(tempForm);
      }
      else if(_self.schedule.frequency == 'Weekly'){
        var tempForm   = {
          'name'         : _self.schedule.name,
          'start_date'   : _self.schedule.start_date,
          'end_date'     : _self.schedule.end_date,
          'frequency'    : _self.schedule.frequency,
          'time'         : _self.schedule.days,
          'ingestions'   : _self.selectedIngestions
        }
        console.log(tempForm);
      }
      else if(_self.schedule.frequency == 'Monthly'){
        console.log(_self.monthlyDays);
        if(_self.monthlyDays == true){
          var tempForm   = {
            'name'         : _self.schedule.name,
            'start_date'   : _self.schedule.start_date,
            'end_date'     : _self.schedule.end_date,
            'frequency'    : _self.schedule.frequency,
            'time'          : _self.ofEveryMonth,
            'ingestions'   : _self.selectedIngestions
          }
          console.log(tempForm);
        }
        else {
            var tempForm   = {
              'name'         : _self.schedule.name,
              'start_date'   : _self.schedule.start_date,
              'end_date'     : _self.schedule.end_date,
              'frequency'    : _self.schedule.frequency,
              'time'          : [],
              'ingestions'   : _self.selectedIngestions
            }
            tempForm.time.push(_self.ofEvery)
            tempForm.time.push(_self.onDay)
            console.log(tempForm);
        }
      }
    }


}])
