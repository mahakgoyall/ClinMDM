angular.module('mdm').controller('ConnectionController', ['$window','MDMService','$scope','toaster','ngProgressFactory','$uibModal','ngDialog',function($window,MDMService,$scope,toaster,ngProgressFactory,$uibModal,ngDialog) {
  var _self = this
  _self.selectedOption = ''
  _self.requestInProgress = false
  _self.something = 'upward'
  _self.uploadInProgress = false

  var s = ngProgressFactory.createInstance()
  s.setParent(document.getElementById('progress'));
  s.setColor('#2a6198')
  _self.formData = {
       'file': ''
   }

  //  _self.instance = ngDialog.open(
  //    { template: 'continue.html',
  //      scope:$scope,
  //      className: 'ngdialog-theme-plain',
  //      closeByDocument : false,
  //      showClose : false,
  //      closeByNavigation :true
  //    });

   _self.type = ["DB Connection","Amazon S3"]

   _self.selectedType = "DB Connection"

   _self.s3FormData = {
     "key_id" : "",
     "secret_id" : "",
     "bucket_name" : "",
     "file_name" : ""
   }


   _self.dbForm = {
     "database_name" : "",
     "username" : "",
     "host_name" : "",
     "password" : "",
     "port" : "",
     "table_name" : ""
  }

  _self.toggle = function(option){
    console.log(option)
    if(_self.selecteOption == option){
      _self.selectedOption = ''
    }
    else {
      _self.selectedOption = option
    }
  }

  // To upload csv
  _self.uploadCSV = function(){
    if(!_self.formData.file){
      toaster.error("Error","Select a file first.")
      return;
    }

    s.start();
    _self.requestInProgress = true
    MDMService.uploadCSV(_self.formData).then(function(response){
      // _self.modalInstance = $uibModal.open({
      //   animation: true,
      //   templateUrl: 'continue.html',
      //   backdrop: 'static',
      //   size: 'md',
      //   scope: $scopey
      // })
      _self.instance = ngDialog.open({ template: 'continue.html',scope:$scope, className: 'ngdialog-theme-plain',closeByDocument : false,showClose : false,closeByNavigation :true });
      _self.requestInProgress = false
      s.complete()
      // toaster.success("Success","Upload Successful, Redirecting.")
      // $window.location.href = "#/datamap"
    },function(error){
      toaster.error(error)
      _self.requestInProgress = false
      s.complete()
    })
  }

  // For DB Connection & S3
_self.connectDB = function() {
  if(_self.selectedType == "DB Connection"){
   var flag = false
   angular.forEach(_self.dbForm,function(value,key){
     if(value == ''){
       flag = true
     }
   })
   if(flag){
     toaster.error("All fields are mandatory.")
     return;
   }
    MDMService.dbConnect(_self.dbForm).then(function(response) {
      console.log(response);
      if(response.ok == 'success') {
        _self.instance = ngDialog.open(
          { template: 'continue.html',
            scope:$scope,
            className: 'ngdialog-theme-plain',
            closeByDocument : false,
            showClose : false,
            closeByNavigation :true
          });
      } else {
        toaster.error("Failure", "Unable to Connect");
      }
    })
  }

  else {
    var flag = false
    angular.forEach(_self.s3FormData,function(value,key){
      if(value == ''){
        flag = true
      }
    })
    if(flag){
      toaster.error("All fields are mandatory.")
      return;
    }
    MDMService.connectS3(_self.s3FormData).then(function(response){
      console.log(response);
      if(response.failure){
        toaster.error("Failure", response.failure);
      }
      else {
        _self.instance = ngDialog.open(
          { template: 'continue.html',
            scope:$scope,
            className: 'ngdialog-theme-plain',
            closeByDocument : false,
            showClose : false,
            closeByNavigation :true
          });
      }
    })
  }

}

_self.closeModal = function () {
  console.log("k");

  $('#attachmentName').val(''); // cancel upload file.
  _self.formData = {
       'file': ''
   }
   _self.dbForm = {
     "database_name" : "",
     "username" : "",
     "host_name" : "",
     "password" : "",
     "port" : "",
     "table_name" : ""
  }
  _self.s3FormData = {
    "key_id" : "",
    "secret_id" : "",
    "bucket_name" : "",
    "file_name" : ""
  }
  // $scope.$apply()
  _self.instance.close()
    // _self.modalInstance.dismiss();
};



  /**************************************************************************/
var fileExtentionRange = '.csv';
var MAX_SIZE = 30; // MB
$(document).on('change', '.btn-file :file', function() {
    var input = $(this);
    if (navigator.appVersion.indexOf("MSIE") != -1) { // IE
        var label = input.val();
        input.trigger('fileselect', [1, label, 0])
    } else {
        var label = input.val().replace(/\\/g, '/').replace(/.*\//, '')
        var numFiles = input.get(0).files ? input.get(0).files.length : 1
        var size = input.get(0).files[0].size
        _self.formData.file = $(this).get(0).files[0]
        console.log(_self.formData)
        $scope.$apply()
        fileselect(numFiles, label, size)
    }
});
fileselect = function(numFiles, label, size) {
        $('#attachmentName').attr('name', 'attachmentName') // allow upload.
        var postfix = label.substr(label.lastIndexOf('.'))
        if (fileExtentionRange.indexOf(postfix.toLowerCase()) > -1) {
            if (size > 1024 * 1024 * MAX_SIZE) {
                alert('max size：<strong>' + MAX_SIZE + '</strong> MB.')
                $('#_attachmentName').val('')
                $('#attachmentName').removeAttr('name'); // cancel upload file.
            } else {
                $('#_attachmentName').val(label)
            }
        } else {
            // alert('Only' + fileExtentionRange + ' file types are allowed')
            toaster.error("Error", "Only" + fileExtentionRange + ' file types are allowed');
            // $('#attachmentName').removeAttr('name')
            $('#attachmentName').val(''); // cancel upload file.
            _self.formData = {
                 'file': ''
             }
            $scope.$apply()
        }
    }
    /**************************************************************************/

}])
