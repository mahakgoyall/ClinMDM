angular.module('mdm').controller('DashboardController', ['$window', '$sce','$scope','MDMService','$timeout','ingestions','$rootScope','toaster', function($window, $sce,$scope,MDMService,$timeout,ingestions,$rootScope,toaster) {
    var _self = this
    console.log(ingestions)
    if(ingestions.failure){
      toaster.error(ingestions.failure)
    }
    _self.ingestionList = ingestions
    _self.showIngestions = true
    _self.showAll = true
    _self.pageNumber = 1
    _self.showGraphs = false
    // _self.allMatchAnalysis = false
    // _self.allSourceAnalysis = false
    // _self.rejectionAnalysis = false
    // _self.sourceAnalysis = false
    // _self.svgRejectionIndividual = false
    $scope.Math = window.Math;
    _self.matchAnalysis = false
    _self.dynamicWidth = 450
    _self.sources = ["All"]
    _self.sourceList = []
    _self.selectedSrc = ''
    _self.selectedSize = 'medium'
    _self.selectedColor = 'blue'
    // _self.selectedSrc = "All"
    // _self.link = $sce.trustAsResourceUrl("https://app.powerbi.com/view?r=eyJrIjoiYWU2OWQzYmMtMGJiYS00ZGZlLThjZGYtNzViZDY5OGZkNjAyIiwidCI6IjE5YTA0MzhlLTcyZmItNDAzOC04M2RlLTJmYjQ5MzYzMGMxYiIsImMiOjR9")

    _self.formData  = {
      "ingest_name" : '',
      "source_uid"  : ''
    }

    _self.sourceForm = {
      "ingest_name" : '',
      "source_name" : ''
    }

    _self.all = function(){
      // _self.selectedSource = 'All'
      _self.showAll = true
    }

    _self.getHeight = function(){
      if (_self.selectedSize == 'small') {
        return "10em;"
      }
      else if (_self.selectedSize == 'medium') {
        return "35em;"
      }
      else if (_self.selectedSize == 'large') {
        return "50em;"
      }
    }

    _self.getColorBefore = function(index){
      if (_self.selectedColor == 'blue') {
        return "rgba(5, 62, 123, .6)"
      }
      else if (_self.selectedColor == 'green') {
        return "rgba(5, 123, 5, .3)"
      }
    }

    _self.getColorAfter = function(index){
      if (_self.selectedColor == 'blue') {
        return "rgba(47, 83, 122, .7)"
      }
      else if (_self.selectedColor == 'green') {
        return "rgba(63, 122, 47, .4)"
      }
    }

    _self.onHover = function(x){
      angular.forEach(_self.legendData,function(value,key){
        if(value == x.name){
          _self.textOnHover = key
        }
      })
    }

    $rootScope.$watch('showInReports' ,function(){
      _self.showGraphs = false
      _self.showAll = true
      // _self.sources = ["All"]
      // _self.allMatchAnalysis = false
      // _self.matchAnalysis = false
      // _self.sourceAnalysis = false
      // _self.allSourceAnalysis = false
      // _self.rejectionAnalysis = false
      // _self.selectedSrc = "All"
      _self.dynamicWidth = 450
      $('.ui.small.dropdown').dropdown('restore defaults');

    },true);

    _self.back = function(){
      $rootScope.showinReports = false;
      _self.showGraphs = false
      _self.showAll = true
      _self.sources = ["All"]
      _self.allMatchAnalysis = false
      _self.matchAnalysis = false
      _self.sourceAnalysis = false
      _self.allSourceAnalysis = false
      _self.rejectionAnalysis = false
      _self.selectedSrc = "All"
      $('.ui.small.dropdown').dropdown('restore defaults');

    }

    if (_self.ingestionList.total == 0){
      _self.toShow = false
    } else {
      _self.toShow = true
    }
    _self.changePage = function() {
      MDMService.ingestionList(_self.pageNumber).then(function(response){
        // console.log(response);
        _self.ingestionList = response
        if (response.total == 0){
          _self.toShow = false
        } else {
          _self.toShow = true
        }
      })
    }




    _self.createGraph = function(ingestion){

      // _self.allSourceAnalysis = ''

      _self.formData.ingest_name = ingestion.ingest_name
      _self.formData.source_uid = ingestion.source_uid
      _self.showGraphs = true
      console.log(_self.formData);
      $rootScope.showInReports = true;
      // MDMService.getFlowValidations(_self.formData).then(function(response){
      //   console.log(response);
      //   _self.makeToolTipData(response)
      // })
      // d3.select("#groupedSourceAnalysis").selectAll("*").remove();
      // d3.select("#pie").selectAll("*").remove();
      // d3.select("#groupedLegend").selectAll("*").remove();
      // d3.select("#svgRejection").selectAll("*").remove();
      // MDMService.sourceList(_self.formData).then(function(response){
      //   console.log(response);
      //   _self.sourceList = response.source_list.source_list
      //   for(i=0;i<response.source_list.source_list.length;i++){
      //     _self.sources.push(response.source_list.source_list[i])
      //   }
      //   if(response.source_list.source_list.length >1){
      //     _self.dynamicWidth = _self.dynamicWidth + (response.source_list.source_list.length * 80)
      //
      //   }
      // })
      MDMService.rejectionGraph(_self.formData).then(function(response){
        console.log(response);
        _self.rejectionAnalysisData = response
        _self.createRejectionAnalysis((Object.keys(_self.rejectionAnalysisData))[0])
      })
      MDMService.ruleMatcherGraph(_self.formData).then(function(response){
        console.log(response);
        _self.matchAnalysisData = response
        _self.createMatchAnalysis((Object.keys(_self.matchAnalysisData))[0])
      })
      MDMService.validationGraph(_self.formData).then(function(response){
        console.log(response);
        _self.sourceAnalysisData = response
        _self.sourcesList = Object.keys(_self.sourceAnalysisData)
        console.log(_self.sourcesList);
        _self.selectedSrc = _self.sourcesList[0]
        _self.createSourceAnalysis((Object.keys(_self.sourceAnalysisData))[0])
      })
    }

    _self.changeSource = function(x){
      _self.createMatchAnalysis(x)
      _self.createSourceAnalysis(x)
      _self.createRejectionAnalysis(x)
    }


    _self.createMatchAnalysis = function(name){
      _self.matchAnalysisGraphData = []
      var highestValue = 0
      var highestKey = ''
      angular.forEach(_self.matchAnalysisData[name],function(value,key){
        if(value > highestValue){
          highestValue = value
          highestKey = key
        }
      })
      angular.forEach(_self.matchAnalysisData[name],function(value,key){
        if(key == highestKey){
          _self.matchAnalysisGraphData.push({
            "percentage" : 100,
            "value"      : value,
            "name"       : highestKey
          })
        }
        else {
          _self.matchAnalysisGraphData.push({
            "percentage" : Math.round(_self.makePercentage(value,_self.matchAnalysisData[name][highestKey])),
            "value"      : value,
            "name"       : key
          })
        }
      })
    }

    _self.createSourceAnalysis = function(key){
      _self.sourceAnalysisGraphData = []

      _self.sourceAnalysisGraphData.push({
        "percentage" : 100,
        "value"      : _self.sourceAnalysisData[key].total,
        "name"       : "Total"
      })
      _self.sourceAnalysisGraphData.push({
        "percentage" : Math.round(_self.makePercentage(_self.sourceAnalysisData[key].accepted,_self.sourceAnalysisData[key].total)),
        "value"      : _self.sourceAnalysisData[key].accepted,
        "name"       : "Accepted"
      })
      _self.sourceAnalysisGraphData.push({
        "percentage" : Math.round(_self.makePercentage(_self.sourceAnalysisData[key].rejected,_self.sourceAnalysisData[key].total)),
        "value"      : _self.sourceAnalysisData[key].rejected,
        "name"       : "Rejected"
      })
    }

    _self.createRejectionAnalysis = function(name){
      if((Object.keys(_self.rejectionAnalysisData[name]).length == 0)){
        _self.noRejectionData = true
      }
      _self.rejectionAnalysisGraphData = []
      _self.legendData = {}
      _self.alpha = ["A","B","C","D","E","F","G","H","I","J"]
      var keys = Object.keys(_self.rejectionAnalysisData[name]);
      angular.forEach(keys,function(value,key){
        console.log(key);
        _self.legendData[keys[key]] = _self.alpha[key]
      })
      console.log(_self.legendData);
      var highestValue = 0
      var highestKey = ''
      angular.forEach(_self.rejectionAnalysisData[name],function(value,key){
        if(value > highestValue){
          highestValue = value
          highestKey = key
        }
      })
      angular.forEach(_self.rejectionAnalysisData[name],function(value,key){
        if(key == highestKey){
          _self.rejectionAnalysisGraphData.push({
            "percentage" : 100,
            "value"      : value,
            "name"       : _self.legendData[highestKey]
          })
        }
        else {
          _self.rejectionAnalysisGraphData.push({
            "percentage" : Math.round(_self.makePercentage(value,_self.rejectionAnalysisData[name][highestKey])),
            "value"      : value,
            "name"       : _self.legendData[key]
          })
        }
      })
    }

    _self.makePercentage = function(what,wrt){
      return ((what/wrt) * 100)
    }





























    /***************

    _self.createGraphIndividual = function(source){
      // console.log(source);
      if (source == "All"){
        _self.showAll = true
      }
      else{
        // _self.allMatchAnalysis = false
        _self.matchAnalysis = false
        // _self.allSourceAnalysis = false
        _self.svgRejectionIndividual = false
        _self.sourceAnalysis = false

        _self.selectedSource = source
        _self.sourceForm.ingest_name = _self.formData.ingest_name
        _self.sourceForm.source_name = source
        _self.showAll = false
        d3.select("#individualpie").selectAll("*").remove();
        d3.select("#individualChart").selectAll("*").remove();
        d3.select("#svgRejectionIndividual").selectAll("*").remove();
        MDMService.rejectionGraphSource(_self.sourceForm).then(function(response){
          console.log(response);
          _self.individualRejectionChart("/static/validator/data/" + response.csv_name + "/")

        })
        MDMService.ruleMatcherGraphSource(_self.sourceForm).then(function(response){
          console.log(response);
          _self.individualPieChart(response)

        })
        MDMService.validationGraphSource(_self.sourceForm).then(function(response){
          console.log(response);
          _self.individualChart("/static/validator/data/" + response.csv_name + "/")
        })
      }

    }

    _self.makeToolTipData = function(response){
      _self.validations = ''
      _self.rules = ''
      console.log(response.matcher_rules)
      var tempKeys = Object.keys(response.validation_rules)
      for (i = 0 ; i < tempKeys.length ; i++){
        _self.validations =  _self.validations +  tempKeys[i] + "  " +  response.validation_rules[tempKeys[i]][0] + " <br/> "
      }

      tempKeys = Object.keys(response.matcher_rules)
      for (i = 0 ; i < tempKeys.length ; i++){
        var tempString = ''
        for(j=0;j<(response.matcher_rules[tempKeys[i]].length);j++){
          tempString = tempString +  response.matcher_rules[tempKeys[i]][j] + "  "
        }
        _self.rules = _self.rules + tempKeys[i] + "  :   " +  tempString + " <br/>"
      }
      console.log(_self.validations);
      console.log(_self.rules);
    }

    _self.groupedChart = function(name){

      var svg = d3.select("#groupedSourceAnalysis")
      margin = {top: 10, right: 20, bottom: 20, left: 25},
      width = +svg.attr("width") - margin.left - margin.right,
      height = +svg.attr("height") - margin.top - margin.bottom,
      g = svg.append("g").attr("transform", "translate(" + margin.left + "," + (margin.top+0) + ")");

      var x0 = d3.scaleBand()
          .rangeRound([0, width])
          .paddingInner(0.1);

      var x = d3.scaleBand()
          .rangeRound([0, width]);
          // .paddingInner(0.1);

      var x1 = d3.scaleBand()
          .padding(0.02);

      var y = d3.scaleLinear()
          .rangeRound([height, 0]);

      var z = d3.scaleOrdinal()
      .range(["grey", "#3FAFF3", "#F84444"]);
      var legendNames = ["Total" , "Accepted" , "Rejected"]


      tipCombinedGraph = d3.tip().attr('class', 'd3-tip').html(function(d) {
        // return d.value + "  " + d.key;
        return _self.validations + d.value + "  " + d.key;
        // return
      });

      svg.call(tipCombinedGraph);
      d3.csv(name, function(d, i, columns) {
        for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
        return d;
      }, function(error, data) {
        if (error) throw error;

        var keys = data.columns.slice(1);
        var sources = []
        for(i=0;i<data.length;i++){
          sources.push(data[i].source_name)
        }
        console.log(data);
        if (!data[0]){
          _self.allSourceAnalysis = true
          $scope.$apply()
        }
        else {


          x0.domain(data.map(function(d) { return d.source_name; }));
          x1.domain(keys).rangeRound([0, x0.bandwidth()]);
          y.domain([0, d3.max(data, function(d) { return d3.max(keys, function(key) { return d[key]; }); })]).nice();
          g.append("g")
            .selectAll("g")
            .data(data)
            .enter().append("g")
              .attr("transform", function(d) {
                // if (d.source_name == sources[1]){
                //   return "translate(" + (x0(d.source_name)-120) + ",0)";
                // }
                // else {
                //   return "translate(" + x0(d.source_name) + ",0)";
                // }
                  return "translate(" + x0(d.source_name) + ",0)";

              })
            .selectAll("rect")
            .data(function(d) { return keys.map(function(key) { return {key: key, value: d[key]}; }); })
            .enter().append("rect")
              .attr("x", function(d) {
                  return x1(d.key);

              })
              .attr("y", function(d) { return y(d.value); })
              .attr("width", x1.bandwidth())
              .attr("height", function(d) { return height - y(d.value); })
              .on('mouseover', tipCombinedGraph.show)
              .on('mouseout', tipCombinedGraph.hide)
              .attr("fill", function(d) { return z(d.key); });


          g.append("g")
              .attr("class", "axis")
              .attr("transform", "translate(0," + height + ")")
              .call(d3.axisBottom(x0));

          g.append("g")
              .attr("class", "axis")
              .call(d3.axisLeft(y).ticks(null, "s"))
            .append("text")
              .attr("x", 2)
              .attr("y", y(y.ticks().pop()) + 0.5)
              .attr("dy", "0.32em")
              .attr("fill", "#000")
              .attr("font-weight", "bold")
              .attr("text-anchor", "start")
              .text("");
              var ordinal = d3.scaleOrdinal()
              .domain(legendNames)
              .range(["grey", "#3FAFF3", "#F84444"]);

            var svg1 = d3.select("#groupedLegend")
            svg1.append("g")
              .attr("class", "legendOrdinal")
              .attr("transform", "translate(280,10)");

            var legendOrdinal = d3.legendColor()
              //d3 symbol creates a path-string, for example
              //"M0,-8.059274488676564L9.306048591020996,
              //8.059274488676564 -9.306048591020996,8.059274488676564Z"
              // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
              // .shapePadding(10)
              .orient('horizontal')
              .shapeWidth(50)
              .scale(ordinal);

            svg1.select(".legendOrdinal")
              .call(legendOrdinal);
          // var legend = svg.append("g")
          //     .attr("font-family", "sans-serif")
          //     .attr("font-size", 10)
          //     .attr("text-anchor", "end")
          //   .selectAll("g")
          //   .data(keys.slice().reverse())
          //   .enter().append("g")
          //     .attr("transform", function(d, i) { return "translate(60," + i * 20 + ")"; });
          //
          // legend.append("rect")
          //     .attr("x", width - 19)
          //     .attr("width", 19)
          //     .attr("height", 19)
          //     .attr("fill", z);
          //
          // legend.append("text")
          //     .attr("x", width - 24)
          //     .attr("y", 9.5)
          //     .attr("dy", "0.32em")
          //     .text(function(d) { return d; });
        }

      });
    }

    _self.pieChart = function(graph){
      var data = [];
      var legendNames = []
      if(graph.exact_ref > 0){
        data.push({
          letter: "Exact",
          presses : graph.exact_ref
        })
        legendNames.push("Exact Match")
      }
      if(graph.partial_ref > 0){
        data.push({
          letter : "Partial",
          presses : graph.partial_ref
        })
        legendNames.push("Partial Match  ")

      }
      if(graph.nomatch_ref > 0){
        data.push({
        letter : "NoMatch",
        presses: graph.nomatch_ref
        })
        legendNames.push("No Match")

      }
      if ((graph.nomatch_ref == 0 && graph.partial_ref == 0 && graph.exact_ref == 0) || graph.failure){
        _self.allMatchAnalysis = true
      }

      else {
        tip = d3.tip().attr('class', 'd3-tip').html(function(d) {
          console.log(d);
          return _self.rules + d;
        });
        var width = 450,
        height = 300,
        // Think back to 5th grade. Radius is 1/2 of the diameter. What is the limiting factor on the diameter? Width or height, whichever is smaller
        radius = Math.min(width, height) / 2;
        var color = d3.scaleOrdinal()
        .range(["#a05d56", "#d0743c", "#ff8c00"]);

         var pie = d3.pie()
          .value(function(d) { return d.presses; })(data);

          var arc = d3.arc()
          .outerRadius(radius - 10)
          .innerRadius(0);

        var labelArc = d3.arc()
          .outerRadius(radius - 70)
          .innerRadius(radius - 40);



        var svg = d3.select("#pie")
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", "translate(" + (width/2 - 50) + "," + height/2 +")"); // Moving the center point. 1/2 the width and 1/2 the height

        svg.call(tip);

        var g = svg.selectAll("arc")
          .data(pie)
          .enter().append("g")
          .attr("class", "arc");

        g.append("path")
        .attr("d", arc)
        .style("fill", function(d) { return color(d.data.letter);});

        g.append("text")
        .attr("transform", function(d) { return "translate(" + labelArc.centroid(d) + ")"; })
        .text(function(d) { return d.data.letter;})
        .style("font-size", "9px")
        .style("display", "none")
        .style("fill", "#fff");

        g.on('mouseover', function(data) {
          tip.show(data.data.letter + " : " + data.value + " Record")
        })
        g.on('mouseout', tip.hide)


        var ordinal = d3.scaleOrdinal()
        .domain(legendNames)
        .range(["#a05d56", "#d0743c", "#ff8c00"]);
        var svg = d3.select("#pie").selectAll("svg")

      svg.append("g")
        .attr("class", "legendOrdinal")
        .attr("transform", "translate(330,10)");

      var legendOrdinal = d3.legendColor()
        //d3 symbol creates a path-string, for example
        //"M0,-8.059274488676564L9.306048591020996,
        //8.059274488676564 -9.306048591020996,8.059274488676564Z"
        // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
        // .shapePadding(10)
        .scale(ordinal);

      svg.select(".legendOrdinal")
        .call(legendOrdinal);


      }





    }



    _self.groupedRejectionChart = function(name){

      var svg = d3.select("#svgRejection"),
      margin = {top: 20, right: 100, bottom: 30, left: 40},
      width = +svg.attr("width") - margin.left - margin.right,
      height = +svg.attr("height") - margin.top - margin.bottom,
      g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      var x0 = d3.scaleBand()
          .rangeRound([0, width])
          .paddingInner(0.1);

      var x = d3.scaleBand()
          .rangeRound([0, width]);
          // .paddingInner(0.1);

      var x1 = d3.scaleBand()
          .padding(0.02);

      var y = d3.scaleLinear()
          .rangeRound([height, 0]);

      var z = d3.scaleOrdinal()
      .range(["#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);


      tipRejectedGraph = d3.tip().attr('class', 'd3-tip').html(function(d) {
        return d.key + "  " + d.value; });

      svg.call(tipRejectedGraph);
      d3.csv(name, function(d, i, columns) {
        for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
        return d;
      }, function(error, data) {
        if (error) throw error;

        var keys = data.columns.slice(1);
        // console.log(keys);
        if (!data[0]){
          _self.allRejectionAnalysis = true
        }
        else{
        var sources = []
        for(i=0;i<data.length;i++){
          sources.push(data[i].source_name)
        }
        console.log(data);
        x0.domain(data.map(function(d) { return d.source_name; }));
        x1.domain(keys).rangeRound([0, x0.bandwidth()]);
        y.domain([0, d3.max(data, function(d) { return d3.max(keys, function(key) { return d[key]; }); })]).nice();
        g.append("g")
          .selectAll("g")
          .data(data)
          .enter().append("g")
            .attr("transform", function(d) {
              // if (d.source_name == sources[1]){
              //   return "translate(" + (x0(d.source_name)-120) + ",0)";
              // }#groupedRejection
              // else {
              //   return "translate(" + x0(d.source_name) + ",0)";
              // }
                return "translate(" + x0(d.source_name) + ",0)";

            })
          .selectAll("rect")
          .data(function(d) { return keys.map(function(key) { return {key: key, value: d[key]}; }); })
          .enter().append("rect")
            .attr("x", function(d) {
              	return x1(d.key);

      			})
            .attr("y", function(d) { return y(d.value); })
            .attr("width", x1.bandwidth())
            .attr("height", function(d) { return height - y(d.value); })
            .on('mouseover', tipRejectedGraph.show)
            .on('mouseout', tipRejectedGraph.hide)
            .attr("fill", function(d) { return z(d.key); });


        g.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x0));

        g.append("g")
            .attr("class", "axis")
            .call(d3.axisLeft(y).ticks(null, "s"))
            .append("text")
            .attr("x", 2)
            .attr("y", y(y.ticks().pop()) + 0.5)
            .attr("dy", "0.32em")
            .attr("fill", "#000")
            .attr("font-weight", "bold")
            .attr("text-anchor", "start")
            .text("");

        var legend = g.append("g")
            .attr("font-family", "sans-serif")
            .attr("font-size", 10)
            .attr("text-anchor", "end")
            .selectAll("g")
            .data(keys.slice().reverse())
            .enter().append("g")
            .attr("transform", function(d, i) { return "translate(100," + i * 20 + ")"; });

        legend.append("rect")
            .attr("x", width - 19)
            .attr("width", 19)
            .attr("height", 19)
            .attr("fill", z);

        legend.append("text")
            .attr("x", width - 24)
            .attr("y", 9.5)
            .attr("dy", "0.32em")
            .text(function(d) { return d; });
        }
      });
    }





  _self.individualChart = function(name){


    var svg = d3.select("#individualChart"),
    margin = {top: 20, right: 80, bottom: 30, left: 40},
    width = +svg.attr("width") - margin.left - margin.right,
    height = +svg.attr("height") - margin.top - margin.bottom,
    g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var x0 = d3.scaleBand()
        .rangeRound([0, width])
        .paddingInner(0.1);

    var x = d3.scaleBand()
        .rangeRound([0, width]);
        // .paddingInner(0.1);

    var x1 = d3.scaleBand()
        .padding(0.02);

    var y = d3.scaleLinear()
        .rangeRound([height, 0]);

    var z = d3.scaleOrdinal()
    .range(["#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);
    var legendNames = ["Total" , "Accepted" , "Rejected"]


    individualSourceAnalysisTip = d3.tip().attr('class', 'd3-tip').html(function(d) {
      return d.value + "  " + d.key; });

    svg.call(individualSourceAnalysisTip);
    d3.csv(name, function(d, i, columns) {
      for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
      return d;
    }, function(error, data) {
      if (error) throw error;

      var keys = data.columns.slice(1);
      var sources = []
      for(i=0;i<data.length;i++){
        sources.push(data[i].source_name)
      }
      console.log(data);
      if (!data[0]){
        _self.sourceAnalysis = true
        $scope.$apply()
      }
      else {


      x0.domain(data.map(function(d) { return d.source_name; }));
      x1.domain(keys).rangeRound([0, x0.bandwidth()]);
      y.domain([0, d3.max(data, function(d) { return d3.max(keys, function(key) { return d[key]; }); })]).nice();
      g.append("g")
        .selectAll("g")
        .data(data)
        .enter().append("g")
          .attr("transform", function(d) {
            // if (d.source_name == sources[1]){
            //   return "translate(" + (x0(d.source_name)-120) + ",0)";
            // }
            // else {
            //   return "translate(" + x0(d.source_name) + ",0)";
            // }
              return "translate(" + x0(d.source_name) + ",0)";

          })
        .selectAll("rect")
        .data(function(d) { return keys.map(function(key) { return {key: key, value: d[key]}; }); })
        .enter().append("rect")
          .attr("x", function(d) {
              return x1(d.key);

          })
          .attr("y", function(d) { return y(d.value); })
          .attr("width", x1.bandwidth())
          .attr("height", function(d) { return height - y(d.value); })
          .on('mouseover', individualSourceAnalysisTip.show)
          .on('mouseout', individualSourceAnalysisTip.hide)
          .attr("fill", function(d) { return z(d.key); });


      g.append("g")
          .attr("class", "axis")
          .attr("transform", "translate(0," + height + ")")
          .call(d3.axisBottom(x0));

      g.append("g")
          .attr("class", "axis")
          .call(d3.axisLeft(y).ticks(null, "s"))
        .append("text")
          .attr("x", 2)
          .attr("y", y(y.ticks().pop()) + 0.5)
          .attr("dy", "0.32em")
          .attr("fill", "#000")
          .attr("font-weight", "bold")
          .attr("text-anchor", "start")
          .text("");

      // var legend = g.append("g")
      //     .attr("font-family", "sans-serif")
      //     .attr("font-size", 10)
      //     .attr("text-anchor", "end")
      //   .selectAll("g")
      //   .data(keys.slice().reverse())
      //   .enter().append("g")
      //     .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });
      //
      // legend.append("rect")
      //     .attr("x", width - 19)
      //     .attr("width", 19)
      //     .attr("height", 19)
      //     .attr("fill", z);
      //
      // legend.append("text")
      //     .attr("x", width - 24)
      //     .attr("y", 9.5)
      //     .attr("dy", "0.32em")
      //     .text(function(d) { return d; });
      var ordinal = d3.scaleOrdinal()
      .domain(legendNames)
      .range(["#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);
      var svg = d3.select("#individualChart")

    svg.append("g")
      .attr("class", "legendOrdinal")
      .attr("transform", "translate(330,10)");

    var legendOrdinal = d3.legendColor()
      //d3 symbol creates a path-string, for example
      //"M0,-8.059274488676564L9.306048591020996,
      //8.059274488676564 -9.306048591020996,8.059274488676564Z"
      // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
      // .shapePadding(10)
      .scale(ordinal);

    svg.select(".legendOrdinal")
      .call(legendOrdinal);

      }
    });
  }

  _self.individualPieChart = function(graph){
    var data = [];
    var legendNames = []
    if(graph.exact_ref > 0){
      data.push({
        letter: "Exact Match",
        presses : graph.exact_ref
      })
      legendNames.push("Exact Match")
    }
    if(graph.partial_ref > 0){
      data.push({
        letter : "Partial Match",
        presses : graph.partial_ref
      })
      legendNames.push("Partial Match")

    }
    if(graph.nomatch_ref > 0){
      data.push({
      letter : "No Match",
      presses: graph.nomatch_ref
      })
      legendNames.push("No Match")

    }

    if (graph.nomatch_ref == 0 && graph.partial_ref == 0 && graph.exact_ref == 0){
      _self.matchAnalysis = true
    }
    else {
      individualPietip = d3.tip().attr('class', 'd3-tip').html(function(d) {
        // console.log(d);
        return d;
      });
      var width = 450,
      height = 300,
      // Think back to 5th grade. Radius is 1/2 of the diameter. What is the limiting factor on the diameter? Width or height, whichever is smaller
      radius = Math.min(width, height) / 2;
      var color = d3.scaleOrdinal()
      .range(["#a05d56", "#d0743c", "#ff8c00"]);

       var pie = d3.pie()
        .value(function(d) { return d.presses; })(data);

        var arc = d3.arc()
        .outerRadius(radius - 10)
        .innerRadius(0);

      var labelArc = d3.arc()
        .outerRadius(radius - 70)
        .innerRadius(radius - 40);



      var svg = d3.select("#individualpie")
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", "translate(" +(width/2 - 50) + "," + height/2 +")"); // Moving the center point. 1/2 the width and 1/2 the height

      svg.call(individualPietip);

      var g = svg.selectAll("arc")
        .data(pie)
        .enter().append("g")
        .attr("class", "arc");

      g.append("path")
      .attr("d", arc)
      .style("fill", function(d) { return color(d.data.letter);});

      g.append("text")
      .attr("transform", function(d) { return "translate(" + labelArc.centroid(d) + ")"; })
      .text(function(d) { return d.data.letter;})
      .style("display", "none")
      .style("fill", "#fff");

      g.on('mouseover', function(data) {
        tip.show(data.data.letter + " : " + data.value + " Record")
      })
      g.on('mouseout', tip.hide)

      var ordinal = d3.scaleOrdinal()
      .domain(legendNames)
      .range(["#a05d56", "#d0743c", "#ff8c00"]);
      var svg = d3.select("#individualpie").selectAll("svg")

    svg.append("g")
      .attr("class", "legendOrdinal")
      .attr("transform", "translate(330,10)");

    var legendOrdinal = d3.legendColor()
      //d3 symbol creates a path-string, for example
      //"M0,-8.059274488676564L9.306048591020996,
      //8.059274488676564 -9.306048591020996,8.059274488676564Z"
      // .shape("path", d3.symbol().type(d3.symbolTriangle).size(150)())
      // .shapePadding(10)
      .scale(ordinal);

    svg.select(".legendOrdinal")
      .call(legendOrdinal);
    }




  }



  _self.individualRejectionChart = function(name){




    individualRejectionTip = d3.tip().attr('class', 'd3-tip').html(function(d) {
      return d.value + "  " + d.key; });

    d3.csv(name, function(d, i, columns) {
      for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
      return d;
    }, function(error, data) {
      if (error) throw error;

      var keys = data.columns.slice(1);
      console.log(data)
      if (!data[0]){
        _self.rejectionAnalysis = true
      }
      else {
        var svg = d3.select("#svgRejectionIndividual"),
        margin = {top: 20, right: 120, bottom: 30, left: 40},
        width = +svg.attr("width") - margin.left - margin.right,
        height = +svg.attr("height") - margin.top - margin.bottom,
        g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        svg.call(individualRejectionTip);

        var x0 = d3.scaleBand()
            .rangeRound([0, width])
            .paddingInner(0.1);

        var x = d3.scaleBand()
            .rangeRound([0, width]);
            // .paddingInner(0.1);

        var x1 = d3.scaleBand()
            .padding(0.02);

        var y = d3.scaleLinear()
            .rangeRound([height, 0]);

        var z = d3.scaleOrdinal()
        .range(["#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);
        var sources = []
        for(i=0;i<data.length;i++){
          sources.push(data[i].source_name)
        }
        console.log(data);
        x0.domain(data.map(function(d) { return d.source_name; }));
        x1.domain(keys).rangeRound([0, x0.bandwidth()]);
        y.domain([0, d3.max(data, function(d) { return d3.max(keys, function(key) { return d[key]; }); })]).nice();
        g.append("g")
          .selectAll("g")
          .data(data)
          .enter().append("g")
            .attr("transform", function(d) {
              // if (d.source_name == sources[1]){
              //   return "translate(" + (x0(d.source_name)-120) + ",0)";
              // }#groupedRejection
              // else {
              //   return "translate(" + x0(d.source_name) + ",0)";
              // }
                return "translate(" + x0(d.source_name) + ",0)";

            })
          .selectAll("rect")
          .data(function(d) { return keys.map(function(key) { return {key: key, value: d[key]}; }); })
          .enter().append("rect")
            .attr("x", function(d) {
                return x1(d.key);

            })
            .attr("y", function(d) { return y(d.value); })
            .attr("width", x1.bandwidth())
            .attr("height", function(d) { return height - y(d.value); })
            .on('mouseover', individualRejectionTip.show)
            .on('mouseout', individualRejectionTip.hide)
            .attr("fill", function(d) { return z(d.key); });


        g.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x0));

        g.append("g")
            .attr("class", "axis")
            .call(d3.axisLeft(y).ticks(null, "s"))
            .append("text")
            .attr("x", 2)
            .attr("y", y(y.ticks().pop()) + 0.5)
            .attr("dy", "0.32em")
            .attr("fill", "#000")
            .attr("font-weight", "bold")
            .attr("text-anchor", "start")
            .text("");

        var legend = g.append("g")
            .attr("font-family", "sans-serif")
            .attr("font-size", 10)
            .attr("text-anchor", "end")
            .selectAll("g")
            .data(keys.slice().reverse())
            .enter().append("g")
            .attr("transform", function(d, i) { return "translate(100," + i * 20 + ")"; });

        legend.append("rect")
            .attr("x", width - 19)
            .attr("width", 19)
            .attr("height", 19)
            .attr("fill", z);

        legend.append("text")
            .attr("x", width - 24)
            .attr("y", 9.5)
            .attr("dy", "0.32em")
            .text(function(d) { return d; });
      }

    });
  }






*******************/

}])
