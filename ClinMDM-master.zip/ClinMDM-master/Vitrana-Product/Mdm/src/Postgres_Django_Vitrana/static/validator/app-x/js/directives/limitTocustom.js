angular.module('mdm').filter('limitTocustom', function() {
   'use strict';
   return function(input, limit) {
       if (input) {
           if (limit > input.length) {
               return input.slice(0, limit);
           } else {
               return input.slice(0, limit) + '...';
           }
       }
   };
});
