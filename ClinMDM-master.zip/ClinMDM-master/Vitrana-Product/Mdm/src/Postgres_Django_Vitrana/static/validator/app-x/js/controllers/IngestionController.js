angular.module('mdm').controller('IngestionController', ['$window','MDMService','$uibModal','$scope','dataManagerList','ingestionList','toaster','$interval','selfInfo','stewardList','ngDialog','$rootScope','$http',function($window,MDMService,$uibModal,$scope,dataManagerList,ingestionList,toaster,$interval,selfInfo,stewardList,ngDialog,$rootScope,$http) {
  var _self = this
  _self.dataManagerList = angular.copy(dataManagerList)
  _self.ingestionList = angular.copy(ingestionList)
  _self.stewardList = angular.copy(stewardList)
  _self.selfInfo = angular.copy(selfInfo)
  console.log(_self.ingestionList);
  _self.showProgress = false
  _self.requestInProgress = false
  _self.pageNumber = 1
  _self.formError = false
  _self.creatingIngestion = false
  _self.selected = []
  _self.selectedIngestions = []
  _self.showProgress = false
  _self.picker = {}
  _self.allowUpload = false
  _self.advancedToSkip = ['uppercase','lowercase','concate','decode','substring']
  _self.frequency = ['Hourly','Daily','Weekly','Monthly']
  _self.daysFull = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
  _self.daysTrimmed = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
  _self.every = ['First','Second','Third','Fourth']
  _self.dates = []
  _self.days = []
  for(i=1;i<32;i++){
    _self.dates.push(i)
  }
  for(i=0;i<7;i++){
    _self.days.push({
      'front' : _self.daysFull[i],
      'back'  : _self.daysTrimmed[i]
    })
  }


  _self.selectedOrg = ''
  _self.org = [{front: "Site", back: 'site'},
      {front: "Sponsor", back: 'sponsor'},
      {front: "Site & Sponsor", back: 'org'}]
  setTimeout(function(){
    for(i=5;i<10;i++){
      $('.ui.small.dropdown.'+ i ).dropdown({direction: 'upward',preserveHTML	: true});
    }
  }, 500);

  _self.actions = function(x){
    if(x.status_flag == 5 || x.status_flag == 6){
      return ["View","Data Mapping","Resume Flow","Delete","Modify Source(s)"]
    }
    else {
      return ["View","Data Mapping","Apply Flow","Delete","Modify Source(s)"]
    }
  }
  $scope.Math = window.Math;
  _self.selectedDataManager = {
    'data_manager_id' : ''
  }
  _self.selectedDataSteward = {
    'steward_id' : ''
  }
  _self.formData = {
    "ingest_name" : ''
  }
  _self.sourceDetailForm = {
    "source_name" : '',
    "source_uid" : ""
  }

  _self.deleteSourceForm = {
    "ingest_name" : '',
    "source_uid" : "",
    "sources" : []
  }

  _self.searchForm = {
    'ingest_name'  : '',
    'page_number'  : 1
  }


  _self.schedule = {
    'start_date'   :   new Date(),
    'end_date'     :   new Date(),
    'frequency'    :   '',
    'time'         :   new Date(),
    'days'         :   [],
    'hour'         :   1,
    'minutes'      :   10,
  }

  _self.pushSources = function(source) {
    if(_self.deleteSourceForm.sources.includes(source)){
      var index = _self.deleteSourceForm.sources.indexOf(source)
      _self.deleteSourceForm.sources.splice(index,1)
    }
    else{
      _self.deleteSourceForm.sources.push(source)
    }
    console.log(_self.deleteSourceForm);
  }

    // MDMService.json().then(function(response){
    //   console.log(response);
    // })

  _self.deleteSources = function(){
    _self.instance.close()
    console.log(_self.deleteSourceForm);
    MDMService.deleteSources(_self.deleteSourceForm).then(function(response){
      console.log(response);
      if(response.failure){
        toaster.error("Error", response.failure)
      }
      else {
        toaster.success("Success","Deletion Successful")
        _self.modalInstance.dismiss();
        MDMService.ingestionList(1).then(function(response){
          _self.ingestionList = response
          if (_self.ingestionList.total == 0){
            _self.toShow = false
          } else {
            _self.toShow = true
          }
        })
      }
    })
  }

  if (_self.ingestionList.total == 0){
    _self.toShow = false
  } else {
    _self.toShow = true
  }

  // Change Page
  _self.changePage = function() {
    if(_self.searchForm.ingest_name == ''){
      _self.requestInProgress = true
      MDMService.ingestionList(_self.pageNumber).then(function(response){
        _self.requestInProgress = false
        console.log(response);
        if(response.failure){
          toaster.error("Error",response.failure)
        }
        _self.ingestionList = response
        if (response.total == 0){
          _self.toShow = false
        } else {
          _self.toShow = true
        }
      })
    }
    else{
      _self.searchForm.page_number = _self.pageNumber
      _self.searchIngestion()
    }
  }


  _self.isOpen = {
    'start'    : false,
    'end'      : false,
    'daily'    : false,
    'hourly'   : false
  }
  _self.openCalendar = function(e,key) {
        e.preventDefault();
        e.stopPropagation();
        _self.isOpen[key] = true;
        console.log(_self.isOpen);
  };

  _self.addNewSource = function(ingestion){
    _self.requestInProgress = true
    MDMService.setCurrentIngestion(ingestion.ingest_name).then(function(response){
      _self.requestInProgress = false
      $window.location.href = "#/" + $rootScope.entityInUse + "/connection";
    })
  }

  _self.searchIngestion = function(){
    if(_self.searchForm.ingest_name == ''){
      _self.requestInProgress = true
      MDMService.ingestionList(1).then(function(response){
        _self.requestInProgress = false
        if(response.failure){
          toaster.error('Error', response.failure)
        }

        else {
          _self.ingestionList = angular.copy(response)
        }
      })
      _self.searchForm.ingest_name = ''
      _self.searchForm.page_number = 1
    }
    else {
      _self.requestInProgress = true
      MDMService.searchIngestion(_self.searchForm).then(function(response){
        _self.requestInProgress = false
        console.log(response);
        if(response.failure){
          toaster.error('Error', response.failure)
        }

        else {
          _self.ingestionList = angular.copy(response)
        }
      })
    }
  }



  // Get progress of ingestion
  // _self.getProgress = function(name) {
  //   _self.dataForm = {
  //     "ingest_name" : name
  //   }
  //   _self.progressStatus = ''
  //   _self.showProgress = false
  //   MDMService.getProgress(_self.dataForm).then(function(response) {
  //     console.log(response);
  //     if(response.ingestion_flag === '0') {
  //       _self.progressStatus = 'ingestion_flag'
  //     } else if(response.ingestion_flag === '1' && response.connection_flag === '0') {
  //       _self.progressStatus = 'connection_flag'
  //     } else if(response.connection_flag === '1' && response.mapping_flag === '0' ) {
  //       _self.progressStatus = 'mapping_flag'
  //     } else if(response.mapping_flag === '1' && response.flow_flag === '0' ) {
  //       _self.progressStatus = 'flow_flag'
  //     } else if(response.flow_flag === '1' && response.validation_flag === '0' ) {
  //       _self.progressStatus = 'validation_flag'
  //     } else if(response.validation_flag === '1' && response.rules_flag === '0') {
  //       _self.progressStatus = 'rules_flag'
  //     } else if(response.rules_flag === '1') {
  //       _self.progressStatus = 'end'
  //     }
  //     _self.showProgress  = true
  //     _self.showProgress = response
  //   })
  // }

  _self.setProgress = function(ingestion){
    _self.progressStatus = ingestion.status_flag
    _self.showProgress = true
  }

  // Perform action from dropdown , executed when an option from dropdown is selected/changed.
  _self.performAction = function(task,value){
    _self.selectedIngestionDetails = value
    if (task == 'Data Mapping'){
        _self.showMappings(value)
        if(value.add_source == '1'){
          _self.allowUpload = true
        }
    }
    else if (task == 'Apply Flow'){
      // _self.useThisIngestion(value)
      // _self.modalInstance = $uibModal.open({
      //  animation: true,
      //  templateUrl: 'applyFlow.html',
      //  backdrop: 'static',
      //  scope: $scope
      // })

      _self.useThisIngestion(_self.selectedIngestionDetails)
    }
    else if (task == 'Delete'){
        // _self.deleteIngestion(value.ingest_name)
        _self.deleteConfirmation()
    }

    else if (task == 'Modify Source(s)'){
      _self.editSources(value)
    }

    else if (task == 'Resume Flow') {
      _self.resumeFlow(value)
    }
    else if(task == 'View'){
      var tempForm = {
        'ingest_name' : value.ingest_name
      }
      _self.requestInProgress = true
      MDMService.ingestionDetails(tempForm).then(function(response){
        _self.requestInProgress = false
        console.log(response);
        if(response.failure){
          toaster.error("Error",response.failure)
        }
        else {
          _self.ingestionData = angular.copy(response)
          _self.viewDetails()
        }
      },function(error){
        _self.requestInProgress = false
        toaster.error('Error',error)
      })
      _self.activeTab = 'mapping'
    }
  }


  _self.viewDetails = function(){
    $('.ui.small.dropdown').dropdown('restore defaults')
    _self.modalInstance = $uibModal.open({
     animation: true,
     templateUrl: 'view.html',
     backdrop: 'static',
     scope: $scope
    })
    _self.modalInstance.opened.then(function(response){
      _self.viewSelected = 'Data Mapping'
    })
  }

  _self.resumeFlow =function(value){
    var tempForm = {
      "ingest_name" : value.ingest_name,
      "source_uid"  : value.source_uid
    }
    MDMService.resumeFlow(tempForm).then(function(response){
      console.log(response);
      if(response.Failure){
        toaster.error("Error",response.Failure)
      }
      else {
        if(value.status_flag == 5){
          $window.location.href = "#/" + $rootScope.entityInUse + "/validation";
        }
        else if(value.status_flag == 6){
          $window.location.href = "#/" + $rootScope.entityInUse + "/rule";
        }
      }
    })
  }


  _self.createSchedule = function(){
    _self.modalInstance = $uibModal.open({
     animation: true,
     templateUrl: 'schedule.html',
     backdrop : 'static',
     keyboard : false,
     scope: $scope
    })

    _self.schedule.end_date = ''
  }

  _self.scheduleTheseIngestions = function(){
    // MDMService.scheduleTheseIngestions(data).then(function(response){
    //   console.log(response);
    // })
  var tempForm = {}

    if(_self.schedule.frequency == 'Hourly' ||  _self.schedule.frequency == 'Daily'){
      var tempForm   = {
        'name'         : _self.schedule.name,
        'start_date'   : _self.schedule.start_date,
        'end_date'     : _self.schedule.end_date,
        'frequency'    : _self.schedule.frequency,
        'hour'         : _self.schedule.hour,
        'minutes'      : _self.schedule.minutes,
        'ingestions'   : _self.selectedIngestions
      }
      console.log(tempForm);
    }
    // else if (_self.schedule.frequency == 'Daily') {
    //   var tempForm   = {
    //     'name'         : _self.schedule.name,
    //     'start_date'   : _self.schedule.start_date,
    //     'end_date'     : _self.schedule.end_date,
    //     'frequency'    : _self.schedule.frequency,
    //     'time'         : _self.schedule.time,
    //     'ingestions'   : _self.selectedIngestions
    //   }
    //   console.log(tempForm);
    // }

    else if(_self.schedule.frequency == 'Weekly'){
      var tempForm   = {
        'name'         : _self.schedule.name,
        'start_date'   : _self.schedule.start_date,
        'end_date'     : _self.schedule.end_date,
        'frequency'    : _self.schedule.frequency,
        'time'         : _self.schedule.days,
        'ingestions'   : _self.selectedIngestions
      }
      console.log(tempForm);
    }
    else if(_self.schedule.frequency == 'Monthly'){
      console.log(_self.monthlyDays);
      if(_self.monthlyDays == true){
        var tempForm   = {
          'name'         : _self.schedule.name,
          'start_date'   : _self.schedule.start_date,
          'end_date'     : _self.schedule.end_date,
          'frequency'    : _self.schedule.frequency,
          'time'          : _self.ofEveryMonth,
          'ingestions'   : _self.selectedIngestions
        }
        console.log(tempForm);
      }
      else {
          var tempForm   = {
            'name'         : _self.schedule.name,
            'start_date'   : _self.schedule.start_date,
            'end_date'     : _self.schedule.end_date,
            'frequency'    : _self.schedule.frequency,
            'time'          : [],
            'ingestions'   : _self.selectedIngestions
          }
          tempForm.time.push(_self.ofEvery)
          tempForm.time.push(_self.onDay)
          console.log(tempForm);
      }
    }

    console.log(tempForm)
      MDMService.scheduleNow(tempForm).then(function(response){
        console.log(response);
        if(response.Success){
          _self.modalInstance.dismiss();
          toaster.success('Success', 'Scheduling Successful')
          _self.selectedIngestions = []
          _self.masterCheckbox = 'NO'
        }
      })
  }

  _self.addIngestions = function(x){
    if(x == 'all'){
      if(_self.masterCheckbox == 'NO'){
        _self.selectedIngestions = []
      }
      else {
        angular.forEach(_self.ingestionList.list,function(value,key){
          if(_self.selectedIngestions.includes(value.ingest_name)){
            // var tempIndex = _self.selectedIngestions.indexOf(value.ingest_name)
            // _self.selectedIngestions.splice(tempIndex,1)
          }
          else {
            _self.selectedIngestions.push(value.ingest_name)
          }
        })
      }
    }
    else {
      if(_self.selectedIngestions.includes(x.ingest_name)){
        // _self.selectedIngestions.
        var tempIndex = _self.selectedIngestions.indexOf(x.ingest_name)
        _self.selectedIngestions.splice(tempIndex,1)
      }
      else {
        _self.selectedIngestions.push(x.ingest_name)
      }
    }

  }



  _self.editSources = function(value){
    console.log(value);
    _self.sourceToModify = value
    _self.deleteSourceForm = {
      "ingest_name" : value.ingest_name,
      "source_uid" : value.source_uid,
      "sources" : []
    }
    _self.modalInstance = $uibModal.open({
      animation: true,
      templateUrl: 'sources.html',
      backdrop: 'static',
      size: 'md',
      scope: $scope
    })
    _self.modalInstance.opened.then(function(response){
      setTimeout(function(){
        $('.ui.small.dropdown').dropdown('restore defaults')
      }, 200);
    })
  }


  _self.createingestion = function() {
    _self.modalInstance = $uibModal.open({
     animation: true,
     templateUrl: 'ingestionModal.html',
     backdrop: 'static',
     keyboard  : false,
     scope: $scope
    })
    // _self.modalInstance.closed.then(function(){
    //   _self.formError = false
    //   _self.formData.ingest_name = ''
    //   _self.selectedDataManager.data_manager_id = ''
    // })
  }

  _self.addToSelected = function(value){
    if(_self.selected.includes(value)){
      var index = _self.selected.indexOf(value)
      _self.selected.splice(index,1)
    }
    else {
      _self.selected.push(value)
    }
    console.log(_self.selected);
  }



  _self.showMappings = function(value) {
    _self.requestInProgress = true
    var tempForm = {
      "ingest_name" : value.ingest_name,
      "source_uid" : value.source_uid
    }
    if((_self.selfInfo.role.includes(2) && value.status_flag < 4 ) || (_self.selfInfo.role.includes(1) && value.status_flag < 4 )){
      MDMService.setCurrentIngestion(value.ingest_name).then(function(response){
        $window.location.href = "#/" + $rootScope.entityInUse + "/datamap";
      })
    }
    else{
      MDMService.getmappings(tempForm).then(function(response) {
        _self.requestInProgress = false
        console.log(response);
        _self.mappings = response
        _self.modalInstance = $uibModal.open({
          animation: true,
          templateUrl: 'mappingsModal.html',
          backdrop: 'static',
          size: 'lg',
          scope: $scope
        })
        $('.ui.small.dropdown').dropdown('restore defaults')

      })
    }
  }

  _self.submit  = function(){
    _self.creatingIngestion = true
    if(_self.selectedOrg != ''){
      $rootScope.entityInUse = _self.selectedOrg
      $http.defaults.headers.common.entity = _self.selectedOrg
    }
    _self.formData.ingest_name = _self.formData.ingest_name.toUpperCase()
    console.log(_self.formData);
    MDMService.sendDataManager(_self.selectedDataManager).then(function(response) {
      console.log(response);
      MDMService.createingestion(_self.formData).then(function(response){
        console.log(response);
        if(response.ok) {
            toaster.success("Success","Ingestion created successfully");
          _self.cancel()
          $window.location.href = "#/" + $rootScope.entityInUse + "/connection";
        } else {
          _self.formError = true
          _self.creatingIngestion = false
          toaster.error("Failure",response.failure)
        }
      })
    })
  }
  _self.useThisIngestion = function(value){
    // _self.applyingFlow = true
    // _self.selectedDataSteward['ingest_name'] = value.ingest_name
    // _self.selectedDataSteward['source_uid'] = value.source_uid
    _self.sourceDetailForm.source_name = value.ingest_name
    _self.sourceDetailForm.source_uid = value.source_uid
    // console.log(_self.selectedDataSteward);
    // MDMService.sendSteward(_self.selectedDataSteward).then(function(response){
      MDMService.useThisIngestion(_self.sourceDetailForm).then(function(response){
        // _self.applyingFlow = false
        // _self.modalInstance.dismiss();
        if(response.ok){
          $window.location.href = "#/" + $rootScope.entityInUse + "/flow";
          toaster.success("Success",value.ingest_name + " is now being used.")
        }
        else {
          toaster.error("Error",response.failure)
        }
      })
    // })
  }
  _self.cancel = function () {
      _self.resetValues()
      _self.modalInstance.dismiss();
      _self.allowUpload = false
      if(_self.instance){
        _self.instance.close()
      }
  };

  _self.closeModal = function(){
    if (_self.formData.ingest_name == '' && _self.selectedDataManager.data_manager_id == '') {
      _self.cancel()
    }
    else {
      _self.openWarning()
    }
  }


  _self.check = function(){
    console.log(_self.something);
  }

  _self.openWarning = function(){
    _self.instance = ngDialog.open(
      { template: 'warning.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }

  _self.deleteConfirmation = function(){
    _self.instance = ngDialog.open({
        template: 'confirmation.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }

  _self.deleteSourceConfirmation = function(){
    _self.instance = ngDialog.open(
      { template: 'confirmationSource.html',
        scope:$scope,
        className: 'ngdialog-theme-plain',
        closeByDocument : false,
        showClose : false,
        closeByNavigation :true
      });
  }

  _self.closeConfirmation = function(){
    $('.ui.small.dropdown').dropdown('restore defaults')
    _self.instance.close()

  }

  _self.deleteIngestion = function(){
    _self.instance.close()
    _self.requestInProgress = true
      _self.tempForm = {
        "ingest_name" : _self.selectedIngestionDetails.ingest_name
      }
      MDMService.deleteIngestion(_self.tempForm).then(function(response){
        _self.requestInProgress = false
        console.log(response);
        $('.ui.small.dropdown').dropdown('restore defaults')
        if(response.ok){
          toaster.success("Success",response.ok)
          MDMService.ingestionList(1).then(function(response){
            _self.ingestionList = response
        })
      }
    })
  }


  _self.matchType = function(key,index){
    if(_self.ingestionData['Matching Rules'].rules[key].match_type[index] == 'Exact'){
      return 'green'
    }

    else if(_self.ingestionData['Matching Rules'].rules[key].match_type[index] == 'Partial'){
      return 'lightgrey'
    }
  }


  _self.resetValues = function(){
    _self.formError = false
    _self.selectedDataManager = {
      'data_manager_id' : ''
    }
    $('.ui.search.dropdown').dropdown('clear')

    _self.selectedIngestionDetails = ''
    _self.selectedDataManager = {
      'data_manager_id' : ''
    }

    _self.selectedDataSteward = {
      'steward_id' : ''
    }
    _self.formData = {
      "ingest_name" : ''
    }
  }


  _self.toScroll = function(index){
    if (index == 9 || index == 8 || index == 7){
      setTimeout(function(){
        var wtf    = $('#scroll');
        var height = wtf[0].scrollHeight;
        console.log(wtf);
        console.log(height);
          if(_self.initialHeight != height){
            wtf.scrollTop(height);
            console.log("scrolled");
         }
       }, 230);
     }
  }



}])
