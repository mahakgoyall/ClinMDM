angular.module('mdm').controller('BaseIngestionController', ['$window','MDMService','toaster','$uibModal','$scope','scheduleDetail','$rootScope', function($window,MDMService,toaster,$uibModal,$scope,scheduleDetail,$rootScope) {
  var _self = this

  console.log(scheduleDetail);
  _self.actions = ['Error Log','Reports']
  _self.scheduleDetail = angular.copy(scheduleDetail.ui_info)
  _self.showProgress = false


  _self.back = function(){
    $window.location.href = "#/" + $rootScope.entityInUse + "/scheduler"
  }
  _self.performAction = function(x){
    if(_self.selected == 'Reports'){
      $window.location.href = "#/" + $rootScope.entityInUse + "/scheduler/reports/" + x.ingest_name

    }
  }

}])
