// angular.module('mdm').controller('LoggerController', ['$window','$scope','MDMService','ErrorIngestions','$uibModal', function($window,$scope,MDMService,ErrorIngestions,$uibModal) {
angular.module('mdm').controller('LogController', ['$window','MDMService','$uibModal','$scope','toaster','$interval','selfInfo','ngDialog','$rootScope','$http','ErrorIngestions',function($window,MDMService,$uibModal,$scope,toaster,$interval,selfInfo,ngDialog,$rootScope,$http,ErrorIngestions) {
  var _self = this
  console.log("hello");
  console.log(ErrorIngestions);
  _self.erroringestionlist = ErrorIngestions
  _self.requestInProgress = false
  _self.pageNumber = 1
  _self.selectedIngestion = ''
  var formdata = {}
  $scope.Math = window.Math;

  _self.getErrorLogs = function (ingest_name) {
    _self.requestInProgress = true
    _self.selectedIngestion = ingest_name
    formdata = {
      "ingest_id" : ingest_name.ingestion_id
    }
    MDMService.getErrorLogs(formdata).then(function (response) {
      _self.requestInProgress = false
      console.log(response);
      _self.logsAre = response
      _self.modalInstance = $uibModal.open({
       animation: true,
       templateUrl: 'LogScreen.html',
       backdrop: 'static',
       size: 'lg',
       scope: $scope
      })
    })
  }
  _self.cancel = function () {
      _self.modalInstance.dismiss();
  }
  _self.changePage = function (pageNumber) {
    MDMService.FindErrorIngest(pagenumber).then(function (response) {
      _self.erroringestionlist = response
    })
  }
}])
