from django.db import connection
from rest_framework.views import APIView
from django.http import JsonResponse
from django.conf import settings
import json
import logging

logger = logging.getLogger("mdm_logging")

def convert_to_alias(names, entity_name):
    if entity_name == 'study':
        alias_to_columns = settings.STUDY_COLUMN_DICT
    elif entity_name == 'investigator':
        alias_to_columns = settings.COLUMN_DICT
    else:
        alias_to_columns = settings.ORG_COLUMN_DICT

    columns_to_alias = dict()
    for k, v in alias_to_columns.items():
        columns_to_alias[v] = k
    result = list()
    for name in names:
        if name in columns_to_alias:
            result.append(columns_to_alias[name].upper())
        else:
            result.append(name.upper())
    return result


class StagingAnalysis(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_id = data['ingest_id']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'no data found in StagingAnalysis'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        # try:
        #     entity_name = request.META['HTTP_ENTITY']
        #     logger.info("Entity name in data profiling: " + str(entity_name))
        # except Exception as e:
        #     logger.info(str(e))
        #     return JsonResponse({'failure': 'No data in request in StagingAnalysis'})
        context = {}
        try:
            if entity_name == 'investigator':
                stage_table_name = 'stage_investigator'
            elif entity_name == 'study':
                logger.info("Inside the entity study")
                stage_table_name = 'stage_study'
            elif entity_name == 'org':
                logger.info("Inside the entity org")
                stage_table_name = 'stage_org'
            else:
                logger.info("No entity is selected")
                return JsonResponse({'failure': 'due to no entity selected'})

            source_details = {}
            try:
                cursor = connection.cursor()
                cursor.execute("""SELECT count(DISTINCT(stage_id)) FROM "{}" WHERE ingest_id = '{}'"""
                               .format(stage_table_name, ingest_id))
                data_stage_count = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("data_stage_count: " + str(data_stage_count))
            source_details['staging_data_count'] = data_stage_count
            try:
                cursor = connection.cursor()
                cursor.execute("""SELECT count(DISTINCT(stage_id)) FROM "{}" WHERE ingest_id = '{}'"""
                               .format(stage_table_name, ingest_id))
                data_stage_count = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("data_stage_count: " + str(data_stage_count))
            source_details['staging_data_count'] = data_stage_count

            logger.info("inside the main logic!!")
            try:
                cursor = connection.cursor()
                cursor.execute(""" SELECT contact_type, count(contact_type) from "{}" WHERE ingest_id = '{}' and 
                                 contact_type is NOT NULL GROUP BY contact_type""".format(stage_table_name, ingest_id))
                contact_type_count = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("contact_type_data: " + str(contact_type_count))
            contact_record_details = []
            for contact_type_counts in contact_type_count:
                contact_type = {}
                contact_type['contact_type'] = contact_type_counts[0]
                contact_type['contact_count'] = contact_type_counts[1]
                contact_record_details.append(contact_type)
            source_details['contact_type_data'] = contact_record_details

            # cursor = connection.cursor()
            # cursor.execute("""SELECT * FROM "{}" WHERE ingest_id = '{}' """.format(stage_table_name, ingest_id))
            # all_count = cursor.fetchall()
            # logger.info("all count: " + str(all_count))
            try:
                cursor = connection.cursor()
                cursor.execute("""SELECT count(*) FROM "{}" WHERE valid_flag is NULL and ingest_id = '{}' """.format(
                    stage_table_name, ingest_id))
                valid_flag_count = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("valid_flag_count: " + str(valid_flag_count))
            source_details['valid_flag_count'] = valid_flag_count
            try:
                cursor = connection.cursor()
                cursor.execute("""SELECT reason, count(reason) from "{}" where valid_flag IS NULL 
                               AND ingest_id = '{}' group by reason""".format(stage_table_name, ingest_id))
                reason_data = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("reason_data" + str(reason_data))
            reason_data_details = []
            for reason in reason_data:
                reason_data_dict = {}
                reason_data_dict['reason_data'] = reason[0]
                reason_data_dict['reason_count'] = reason[1]
                reason_data_details.append(reason_data_dict)
            source_details['reason_data'] = reason_data_details

            context['staging_data_details'] = source_details
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


class AllRuleMatcherGraph(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_name = data['ingest_name']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            ui_information = dict()
            try:
                cursor = connection.cursor()
                cursor.execute("select exact_count, partial_count, nomatch_count from rule_matcher_dashboard_meta where ingest_name = '{}'"
                               .format(ingest_name))
                count = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for match_data in count:
                ui_information['exact_match'] = match_data[0]
                ui_information['partial_match'] = match_data[1]
                ui_information['nomatch_match'] = match_data[2]
            return JsonResponse(ui_information)

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})


class AllDataValidationGraph(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            source_uid = data['source_uid']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            ingest_name = data['ingest_name']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in request'})
        try:
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT source_name, total_count, total_validated_count, total_rejected_count FROM "
                               "data_validation_dashboard_meta WHERE ingest_id=(SELECT ingest_id FROM ingestion WHERE "
                               "ingest_name='{}' AND uid='{}')".format(ingest_name, source_uid))

                data = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            ui_information = dict()
            for idx, tup in enumerate(data):
                d = dict()
                d['total'] = tup[1]
                d['accepted'] = tup[2]
                d['rejected'] = tup[3]
                ui_information[tup[0]] = d
                # if (tup[0].split('.')[-1]).lower() == "csv":
                #     ui_information['.'.join(str(tup[0]).split('.')[:-1])] = d
                # else:
                #     l = tup[0].split(',')
                #     ui_information[l[0]] = d

            return JsonResponse(ui_information)

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})


class StewardCumulativeAnalysisGraph(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        try:
            user_id = request.session.get('user_id', False)
            if user_id:
                cursor = connection.cursor()
                cursor.execute("select role from users where user_id = '{}'".format(user_id))
                user_role = cursor.fetchall()
                logger.error("user is: " + str(user_role[0][0]))
                if user_role and '3' in str(user_role[0][0]):
                    pass
                else:
                    return JsonResponse({'failure': 'You do not have permission to access this Page.'})
            else:
                return JsonResponse({'failure': 'No user in session.'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure.'})
        try:
            steward_id = request.session.get('user_id', False)
            if steward_id:
                context = {}
                cursor = connection.cursor()
                logger.error("select sum(A.count)::int as total,ingest_id , ingest_name from "
                               "((SELECT i.ingest_name,p.ingest_id, p.task_id, p.status, count(p.ingest_id) FROM "
                               "partial_ref as p join ingestion as i on p.ingest_id = i.ingest_id WHERE"
                               " p.steward_id = '{}' AND p.task_id IS NOT NULL GROUP BY p.ingest_id, p.task_id, status, i.ingest_name)) "
                               "as A GROUP BY A.ingest_id, A.ingest_name".format(steward_id))
                cursor.execute("select sum(A.count)::int as total,ingest_id , ingest_name from "
                               "((SELECT i.ingest_name,p.ingest_id, p.task_id, p.status, count(p.ingest_id) FROM "
                               "partial_ref as p join ingestion as i on p.ingest_id = i.ingest_id WHERE"
                               " p.steward_id = '{}' AND p.task_id IS NOT NULL GROUP BY p.ingest_id, p.task_id, status, i.ingest_name)) "
                               "as A GROUP BY A.ingest_id, A.ingest_name".format(steward_id))
                total_records = cursor.fetchall()
                logger.error('total records: ' + str(total_records))
                context['total_record_count'] = len(total_records)

                cursor = connection.cursor()
                cursor.execute("select sum(A.count)::INT as pending,ingest_id , ingest_name from (SELECT i.ingest_name, "
                               "p.ingest_id, p.task_id, p.status, count(p.ingest_id) FROM partial_ref as p join ingestion "
                               "as i on p.ingest_id = i.ingest_id WHERE p.steward_id = '{}' and p.status in ('9') and "
                               "p.task_id IS NOT NULL GROUP BY p.ingest_id, p.task_id, status, i.ingest_name) as A GROUP BY A.ingest_id, "
                               "A.ingest_name".format(steward_id))
                pending_records = cursor.fetchall()
                logger.error('pending records: ' + str(pending_records))
                context['total_pending_records'] = len(pending_records)

                cursor = connection.cursor()
                cursor.execute("select sum(A.count)::INT as completed,ingest_id , ingest_name from (SELECT i.ingest_name, "
                               "p.ingest_id, p.task_id, p.status, count(p.ingest_id) FROM partial_ref as p join ingestion "
                               "as i on p.ingest_id = i.ingest_id WHERE p.steward_id = '{}' and p.status in ('10','11','12') and "
                               "p.task_id IS NOT NULL GROUP BY p.ingest_id, p.task_id, status, i.ingest_name) as A GROUP BY A.ingest_id, "
                               "A.ingest_name".format(steward_id))
                completed_records = cursor.fetchall()
                logger.error('completed records: ' + str(completed_records))
                context['total_completed_records'] = len(completed_records)
                rec_list = []
                c_flag = 0
                p_flag = 0
                for i in total_records:
                    logger.error("total records loop: " + str(i))
                    dict = {}
                    for j in pending_records:
                        logger.error("pending records loop: " + str(j))
                        if i[1] == j[1]:
                            dict['pending_count'] = j[0]
                            p_flag = 1
                            break
                    if p_flag == 1:
                        p_flag = 0
                    else:
                        dict['pending_count'] = 0
                    for k in completed_records:
                        logger.error("completed records loop: " + str(k))
                        if i[1] == k[1]:
                            dict['completed_count'] = k[0]
                            c_flag = 1
                            break
                    if c_flag == 1:
                        c_flag = 0
                    else:
                        dict['completed_count'] = 0
                    dict['total_count'] = i[0]
                    dict['ingest_name'] = i[2]
                    dict['ingest_id'] = i[1]
                    rec_list.append(dict)
                context['data'] = rec_list
            else:
                return JsonResponse({'failure': 'user'})

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'databas failure.'})
        return JsonResponse(context)

class AllRejectionAnalysisGraph(APIView):
    """

    """
    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            entity_name = request.META['HTTP_ENTITY']
            # entity_name = 'investigator'
            logger.info(str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        try:
            ingest_name = data['ingest_name']
            source_uid = data['source_uid']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in request'})
        try:
            if entity_name == 'study':
                stage_table = 'stage_study'
            elif entity_name == 'investigator':
                stage_table = 'stage_investigator'
            else:
                stage_table = 'stage_org'
            try:
                cursor = connection.cursor()
                cursor.execute("select ingest_id from ingestion where ingest_name = '{}' "
                               "and uid = '{}' and entity = '{}' and delete_flag!='1'".format(ingest_name, source_uid, entity_name))
                ingest_id = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            ui_information = dict()
            try:
                cursor = connection.cursor()
                cursor.execute("select source_name from ingestion_sources where ingest_id = (select ingest_id from "
                               "ingestion where ingest_name = '{}'and uid = '{}' "
                               "and entity = '{}' and delete_flag!= '1')".format(ingest_name, source_uid, entity_name))
                sources = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            try:
                for s_name in sources:
                    ui_information[s_name[0]] = dict()
                    try:
                        logger.info("select i.reason, count(i.reason) from \"{}\" as i join "
                                    "ingestion_sources as j on i.ingest_source_id = j.source_id where i.ingest_id ='{}' and "
                                    "i.valid_flag is null and j.source_name like '%{}%' group by i.reason".format(
                            stage_table, ingest_id, s_name[0]))

                        cursor.execute("select i.reason, count(i.reason) from \"{}\" as i join "
                                       "ingestion_sources as j on i.ingest_source_id = j.source_id where i.ingest_id ='{}' and "
                                       "i.valid_flag is null and j.source_name like '%{}%' "
                                       "group by i.reason".format(stage_table, ingest_id, s_name[0]))
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    for reasons in cursor.fetchall():
                        ui_information[s_name[0]][reasons[0]] = reasons[1]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            print("ui_information: ")
            print(ui_information)
            return JsonResponse(ui_information)

            #
            # if len(data) == 0:
            #     return JsonResponse({'failure': 'No data found.'})
            # ui_information = dict()
            #
            # reason_set = set()
            # for tup in data:
            #     source_name = tup[0]
            #     reason = str(tup[1])
            #     reason_set.add(reason)
            #     count = int(tup[2])
            #     if source_name in ui_information:
            #         ui_information[source_name][reason] = count
            #     else:
            #         ui_information[source_name] = {reason: count}
            #
            # logger.info(str(ui_information))
            # return JsonResponse(ui_information)

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})

    @staticmethod
    def get(entity_name, stage_table, ingest_name, source_uid):
        """

        :param entity_name:
        :param stage_table:
        :param ingest_name:
        :param source_uid:
        :return:
        """
        try:
            logger.info("dashboard get called")

            # entity_name = 'investigator'
            logger.info("ingestion name: " + str(ingest_name))
            logger.info("stage table name in the rejection analysis graph: " + str(stage_table))
            cursor = connection.cursor()
            cursor.execute("select ingest_id from ingestion where ingest_name = '{}' "
                           "and uid = '{}' and entity = '{}' and delete_flag != '1'".format(ingest_name, source_uid,
                                                                                           entity_name))
            ingest_id = cursor.fetchall()[0][0]
            ui_information = dict()
            cursor = connection.cursor()
            cursor.execute("select source_name from ingestion_sources where ingest_id = (select ingest_id from "
                           "ingestion where ingest_name = '{}'and uid = '{}' "
                           "and entity = '{}' and delete_flag != '1')".format(ingest_name, source_uid, entity_name))
            sources = cursor.fetchall()
            for s_name in sources:
                ui_information[s_name[0]] = dict()
                logger.info("select i.reason, count(i.reason) from \"{}\" as i join "
                            "ingestion_sources"
                            " as j on i.ingest_source_id = j.source_id where i.ingest_id ='{}'  and i.valid_flag is "
                            "null  and j.source_name like '%{}%' group by i.reason".format(stage_table,
                                                                                           ingest_id, s_name[0]))
                cursor.execute("select i.reason, count(i.reason) from \"{}\" as i join "
                               "ingestion_sources"
                               " as j on i.ingest_source_id = j.source_id where i.ingest_id ='{}'  and i.valid_flag is "
                               "null  and j.source_name like '%{}%' group by i.reason".format(stage_table,
                                                                                              ingest_id, s_name[0]))
                for reasons in cursor.fetchall():
                    ui_information[s_name[0]][reasons[0]] = reasons[1]
                logger.info("rejected_analysis: " + str(ui_information))
            return ui_information
        except Exception as e:
            logger.error(str(e))
            return JsonResponse({'failure': 'Database Failure'})


# class SourceList(APIView):
#
#     @staticmethod
#     def post(request):
#         try:
#             data = json.loads(request.read().decode('utf-8'))
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data found in body.'})
#         try:
#             ingest_name = data['ingest_name']
#             username = request.session['username']
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'Cannot find variables in request.'})
#         try:
#             source_dict = dict()
#             cursor = connection.cursor()
#             # cursor.execute("SELECT source_name FROM ingestion_sources where ingest_name='{}'"
#             #                "AND uid = (SELECT uid from users where username = '{}' "
#             #                "AND delete_flag = '0')".format(ingest_name, username))
#             cursor.execute("SELECT s.source_name FROM ingestion AS i JOIN ingestion_sources AS s ON "
#                            "i.ingest_id=s.ingest_id WHERE i.ingest_name='{}' AND i.uid=("
#                            "SELECT user_id from users where username = '{}' and delete_flag = '1')".format(ingest_name,username))
#
#             source_list = cursor.fetchall()
#             for source in source_list:
#                 logger.info(str(source))
#                 if (source[0].split('.')[-1]).lower() == "csv":
#                     source_name = '.'.join((str(source[0]).split('/')[-1]).split('.')[:-1])
#                 else:
#                     l = source[0].split(',')
#                     source_name = l[1].split(':')[1][1:-1] + ':' + l[2].split(':')[1][1:-1]
#                 if 'source_list' in source_dict:
#                     source_dict['source_list'].append(source_name)
#                 else:
#                     source_dict['source_list'] = [source_name]
#
#             # logger.info("Sources are : "str(source_dict['source_list']))
#             return JsonResponse({'source_list': source_dict})
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'Error in fetching source list.'})
#
#     @staticmethod
#     def get(request):
#         return JsonResponse({'error': 'POST method not supported.'})
#
#
# class SourceRuleValidationGraph(APIView):
#
#     @staticmethod
#     def post(request):
#         """
#         This Api returns the count of partial, no match and exact match for a particular source.
#         :param request:
#         :return: dict
#         """
#         try:
#             data = json.loads(request.read().decode('utf-8'))
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data found in body.'})
#         try:
#             source_name = data['source_name']
#             ingest_name = data['ingest_name']
#             username = request.session['username']
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'Request body not found.'})
#         try:
#             cursor = connection.cursor()
#             cursor.execute("SELECT DISTINCT (ingest_id) FROM ingestion WHERE ingest_name='{}' AND "
#                            "uid=(select user_id from users where username = '{}' and "
#                            " delete_flag = '1')".format(ingest_name, username))
#             ingest_id = cursor.fetchall()[0][0]
#             logger.info("ingest id: " + str(ingest_id))
#
#             path = getattr(settings, "MEDIA_ROOT", settings.BASE_DIR + "/media/")
#
#             ui_information = dict()
#
#             for table_name in ['partial_ref', 'exact_ref', 'nomatch_ref']:
#                 if ":" in source_name:
#                     source = '"database_name":"' + source_name.split(":")[0] + '", '
#                     source = source + '"table_name":"' + source_name.split(":")[1] + '"'
#                     cursor = connection.cursor()
#                     cursor.execute("SELECT COUNT(e.ingest_source_id) FROM \"{}\" AS e JOIN ingestion_sources AS i ON "
#                                    "i.source_id = e.ingest_source_id WHERE i.source_name LIKE  "
#                                    "'%{}%' GROUP BY e.ingest_source_id ".format(table_name, source))
#                 else:
#                     cursor = connection.cursor()
#                     cursor.execute("SELECT count(e.ingest_source_id) FROM {} AS e JOIN ingestion_sources AS i ON "
#                                    "i.source_id = e.ingest_source_id WHERE e.ingest_id = '{}' AND i.source_name = '{}' GROUP BY "
#                                    "e.ingest_source_id".format(table_name, ingest_id, path + source_name + '.csv'))
#                 data = cursor.fetchall()
#                 logger.info("Data: " + str(data))
#                 if len(data):
#                     ui_information[table_name] = data[0][0]
#                 else:
#                     ui_information[table_name] = 0
#
#             logger.info(str(ui_information))
#
#             return JsonResponse(ui_information)
#
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'DB query failure'})
#
#     @staticmethod
#     def get(request):
#         return JsonResponse({'failure': 'Api not supported'})
#
#
# class SourceRejectionAnalysisGraph(APIView):
#
#     @staticmethod
#     def get(request):
#         return JsonResponse({'failure': 'Api not supported'})
#
#     @staticmethod
#     def post(request):
#         """
#         This API creates a csv for a particular source for the reason of rejection and their count.
#         :param request:
#         :return:
#         """
#         try:
#             data = json.loads(request.read().decode('utf-8'))
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data found in body.'})
#         try:
#             username = request.session['username']
#             ingest_name = data['ingest_name']
#             source_name = data['source_name']
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data in request'})
#         try:
#             cursor = connection.cursor()
#             cursor.execute("SELECT uid, ingest_id FROM ingestion WHERE ingest_name='{}' AND "
#                            "uid=(select user_id from users where username = '{}' and delete_flag = "
#                            "'1') ".format(ingest_name, username))
#             uid, ingest_id = cursor.fetchall()[0]
#
#             path = getattr(settings, "MEDIA_ROOT", settings.BASE_DIR + "/media/")
#             if ":" in source_name:
#                 source = '"database_name":"' + source_name.split(":")[0] + '", '
#                 source = source + '"table_name":"' + source_name.split(":")[1] + '"'
#                 cursor = connection.cursor()
#                 cursor.execute(
#                     "SELECT a.source_name, c.reason, count(c.reason) FROM ingestion_sources AS a JOIN ingestion "
#                     "b ON a.ingest_id = b.ingest_id JOIN \"stage_{}_{}\" c ON a.source_id = c.ingest_source_id "
#                     "WHERE b.ingest_name = '{}' AND c.valid_flag IS NULL AND b.username = '{}' AND a.source_name LIKE "
#                     "'%{}%' GROUP BY c.reason, a.source_name, a.source_id, b.ingest_name".format(uid, ingest_id,
#                                                                                                  ingest_name, username,
#                                                                                                  source))
#                 # cursor = connection.cursor()
#                 # cursor.execute("SELECT source_name, total_count, total_validated_count, total_rejected_count FROM "
#                 #                "data_validation_dashboard_meta WHERE ingest_name='{}' AND username='{}' AND "
#                 #                "source_name like '{}'".format(ingest_name, username, source))
#             else:
#                 cursor = connection.cursor()
#                 cursor.execute("SELECT a.source_name, c.reason, count(c.reason) FROM ingestion_sources AS a JOIN "
#                                "ingestion b ON a.ingest_id = b.ingest_id JOIN \"stage_{}_{}\" c ON "
#                                "a.source_id = c.ingest_source_id WHERE b.ingest_name = '{}' AND a.source_name='{}' AND "
#                                "b.username='{}' AND c.valid_flag IS NULL GROUP BY c.reason, a.source_id, b.ingest_name,"
#                                " a.source_name".format(uid, ingest_id, ingest_name, path + source_name + ".csv",
#                                                        username))
#             data = cursor.fetchall()
#
#             csv_name = '{}_{}_source_rejection_analysis.csv'.format(ingest_name, username)
#             path = getattr(settings, "STATIC_ROOT", settings.BASE_DIR + "/static")
#             path += '/validator/data/'
#
#             ui_information = dict()
#             reason_set = set()
#             for tup in data:
#                 if "/" in tup[0]:
#                     source_name = str(tup[0]).split('/').pop()
#                 else:
#                     foo = json.loads(tup[0])
#                     source_name = foo['database_name'] + ':' + foo['table_name']
#                 reason = str(tup[1])
#                 reason_set.add(reason)
#                 count = str(tup[2])
#                 if source_name in ui_information:
#                     ui_information[source_name][reason] = count
#                 else:
#                     ui_information[source_name] = {reason: count}
#
#             with open(path + csv_name, 'w') as f:
#                 f.write('source_name')
#                 for reason in reason_set:
#                     f.write(',' + str(reason))
#                 f.write('\n')
#                 for source_name, value in ui_information.items():
#                     f.write(source_name)
#                     for reason in reason_set:
#                         f.write(',')
#                         if reason in value:
#                             f.write(str(value[reason]))
#                         else:
#                             f.write('0')
#                     f.write('\n')
#
#             return JsonResponse({'csv_name': csv_name})
#
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'Database Failure'})
#
#
# class SourceDataValidationGraph(APIView):
#
#     @staticmethod
#     def get(request):
#         return JsonResponse({'failure': 'Api not supported'})
#
#     @staticmethod
#     def post(request):
#         try:
#             data = json.loads(request.read().decode('utf-8'))
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data found in body.'})
#         try:
#             username = request.session['username']
#             source_name = data['source_name']
#             ingest_name = data['ingest_name']
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'No data in request'})
#         try:
#             if ":" in source_name:
#                 source = source_name
#                 cursor = connection.cursor()
#                 logger.info("SELECT source_name, total_count, total_validated_count, total_rejected_count FROM "
#                                "data_validation_dashboard_meta WHERE ingest_name='{}' AND username='{}' AND "
#                                "source_name = '{}'".format(ingest_name, username, source))
#                 cursor.execute("SELECT source_name, total_count, total_validated_count, total_rejected_count FROM "
#                                "data_validation_dashboard_meta WHERE ingest_name='{}' AND username='{}' AND "
#                                "source_name = '{}'".format(ingest_name, username, source))
#             else:
#                 cursor = connection.cursor()
#                 cursor.execute("SELECT source_name, total_count, total_validated_count, total_rejected_count FROM "
#                                "data_validation_dashboard_meta WHERE ingest_name='{}' AND username='{}' AND "
#                                "source_name='{}'".format(ingest_name, username, source_name + ".csv"))
#             csv_name = '{}_{}_source_validation_analysis.csv'.format(ingest_name, username)
#             data = cursor.fetchall()
#
#             path = getattr(settings, "STATIC_ROOT", settings.BASE_DIR + "/static")
#             path += '/validator/data/'
#
#             with open(path + csv_name, 'w') as f:
#                 f.write('source_name,Total,Accepted,Rejected\n')
#                 for tup in data:
#                     if ":" in source_name:
#                         pass
#                     else:
#                         source_name = '.'.join(str(tup[0]).split('.')[:-1])
#                     f.write(str(source_name) + ', ' + str(tup[1]) + ', ' + str(tup[2]) + ', ' + str(tup[3]) + '\n')
#
#             return JsonResponse({'csv_name': csv_name})
#
#         except Exception as e:
#             logger.info(str(e))
#             return JsonResponse({'failure': 'Database Failure'})


class DashboardCirclesData(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})
    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        try:
            data = json.loads(request.read().decode('utf-8'))
            user_id = data["userid"]
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        context = {}
        try:
            titles = [('investigator', ''), ('org', 'sponsor', 'site'), ('study', '')]
            for title in titles:
                try:
                    cursor = connection.cursor()
                    logger.error(
                        "select count(ingest_id) from ingestion where (uid = '{}' or"
                        " data_manager_id = '{}' or steward_id = '{}') AND entity IN {}"
                        "and delete_flag != '1'".format(user_id, user_id, user_id, title))
                    cursor.execute(
                        "select count(ingest_id) from ingestion where (uid = '{}' or"
                        " data_manager_id = '{}' or steward_id = '{}') AND entity IN {}"
                        "and delete_flag != '1'".format(user_id, user_id, user_id, title))
                    total_ingetions = cursor.fetchall()[0][0]
                    logger.error('total_ing: ' + str(total_ingetions))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                try:
                    logger.error('user ki id: ' + str(user_id))
                    cursor = connection.cursor()
                    logger.error("SELECT COUNT(ingest_id) FROM ingestion "
                                   "WHERE uid = '{}' AND status_flag < '4' AND "
                                   "entity IN {} and delete_flag != '1'".format(user_id, title))
                    cursor.execute("SELECT COUNT(ingest_id) FROM ingestion "
                                   "WHERE uid = '{}' AND status_flag < '4' AND "
                                   "entity IN {} and delete_flag != '1'".format(user_id, title))
                    source_user = cursor.fetchall()[0][0]
                    logger.error('source user: ' + str(source_user))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                try:
                    cursor = connection.cursor()
                    logger.error("select count(ingest_id) from ingestion "
                                   "where data_manager_id = '{}' and status_flag >= '4' and status_flag < '7' "
                                   "AND entity IN {} and delete_flag != '1'".format(
                        user_id, title))
                    cursor.execute("select count(ingest_id) from ingestion "
                                   "where data_manager_id = '{}' and status_flag >= '4' and status_flag < '7' "
                                   "AND entity IN {} and delete_flag != '1'".format(
                        user_id, title))
                    data_manager = cursor.fetchall()[0][0]
                    logger.error('data manager: ' + str(data_manager))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                try:
                    cursor = connection.cursor()
                    cursor.execute("select count(ingest_id) from ingestion "
                                   "where steward_id = '{}' and status_flag > '7' AND entity IN {} "
                                   "and delete_flag != '1'".format(user_id, title))
                    data_steward = cursor.fetchall()[0][0]
                    logger.error('data steward: ' + str(data_steward))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                title_details = dict()
                title_details['source_user'] = source_user
                title_details['data_manager'] = data_manager
                title_details['data_steward'] = data_steward
                title_details['total_injections'] = total_ingetions

                context[title[0]] = title_details
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


class StewardAnalysisData(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            user_id = request.session.get('user_id', False)
            if user_id:
                cursor = connection.cursor()
                cursor.execute("select role from users where user_id = '{}'".format(user_id))
                user_role = cursor.fetchall()
                logger.error("user is: " + str(user_role[0][0]))
                if user_role and str(user_role[0][0]) == '3':
                    pass
                else:
                    return JsonResponse({'failure': 'You do not have permission to access this Page.'})
            else:
                return JsonResponse({'failure': 'No user in session.'})
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure.'})
        try:
            data = json.loads(request.read().decode('utf-8'))
            steward_id = data["steward_id"]
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in body.'})
        if steward_id:
            try:
                graph_display = dict()
                pending_ingestion = []
                completed_ingestion = []
                try:
                    cursor = connection.cursor()
                    cursor.execute("select count(DISTINCT(ingest_id)) from partial_ref where steward_id = '{}'"
                                   .format(steward_id))
                    total_ingestion = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                graph_display['Total_ingestions'] = total_ingestion
                try:
                    cursor = connection.cursor()

                    cursor.execute("select count(distinct(ingest_id)) from partial_ref where steward_id = '{}' and "
                                   "status in ('9')".format(steward_id))
                    pending_ingest = cursor.fetchall()[0][0]
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                graph_display['Pending_ingestions'] = pending_ingest
                try:
                    cursor = connection.cursor()
                    cursor.execute("select distinct(ingest_id) from partial_ref where steward_id = '{}' and "
                                   "status in ('9')".format(steward_id))
                    pending_ingest_ids = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                for pending_ingest_id in pending_ingest_ids:
                    pending_ingest_name = {}
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select ingest_name from ingestion where ingest_id = '{}'"
                                       .format(pending_ingest_id[0]))
                        name_pending_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    pending_ingest_name['name_pending_ingestions'] = name_pending_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}'"
                                       .format(pending_ingest_id[0]))
                        total_pending_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    pending_ingest_name['total_pending_ingestions'] = total_pending_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('9')".format(pending_ingest_id[0]))
                        unresolved_pending_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    pending_ingest_name['unresolved_pending_ingestions'] = unresolved_pending_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('10','12')".format(pending_ingest_id[0]))
                        resolved_pending_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    pending_ingest_name['resolved_pending_ingestions'] = resolved_pending_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('11')".format(pending_ingest_id[0]))
                        discarded_pending_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    pending_ingest_name['discarded_pending_ingestions'] = discarded_pending_ingest[0][0]

                    pending_ingestion.append(pending_ingest_name)
                    context['Pending_Ingest'] = pending_ingestion
                try:
                    cursor = connection.cursor()
                    cursor.execute("select count(distinct(ingest_id)) from partial_ref where steward_id = '{}' and "
                                   "status in ('10','11','12')".format(steward_id))
                    completed_ingestions = cursor.fetchall()[0][0]

                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                graph_display['Completed_ingestions'] = completed_ingestions
                try:
                    cursor = connection.cursor()
                    cursor.execute("select distinct(ingest_id) from partial_ref where steward_id = '{}' and "
                                   "status in ('10','11','12')".format(steward_id))
                    completed_ingest_ids = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                for completed_ingest_id in completed_ingest_ids:
                    complete_ingest_name = {}
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select ingest_name from ingestion where ingest_id = '{}'"
                                       .format(completed_ingest_id[0]))
                        name_completed_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    complete_ingest_name['name_completed_ingestions'] = name_completed_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}'"
                                       .format(completed_ingest_id[0]))
                        total_completed_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    complete_ingest_name['total_completed_ingestions'] = total_completed_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('9')".format(completed_ingest_id[0]))
                        unresolved_completed_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    complete_ingest_name['unresolved_completed_ingestions'] = unresolved_completed_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('10','12')".format(completed_ingest_id[0]))
                        resolved_completed_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    complete_ingest_name['resolved_completed_ingestions'] = resolved_completed_ingest[0][0]
                    try:
                        cursor = connection.cursor()
                        cursor.execute("select count(distinct(task_id)) from partial_ref where ingest_id = '{}' and "
                                       "status in ('11')".format(completed_ingest_id[0]))
                        discarded_completed_ingest = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    complete_ingest_name['discarded_completed_ingestions'] = discarded_completed_ingest[0][0]
                    completed_ingestion.append(complete_ingest_name)
                    context['Complete_Ingestions'] = completed_ingestion
                context['Steward_graph'] = graph_display
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
                return JsonResponse({'failure': 'Database Failure'})
            return JsonResponse(context)
        return JsonResponse({'failure': 'Steward Id is not given.'})


class IngestionBySourceReports(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            user_id = request.session.get('user_id', False)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in session'})
        if not user_id:
            logger.info("user id not found" + str(user_id))
            return JsonResponse({'failure': 'user id can not be found'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in request in reports'})

        if entity_name == 'org':
            where_string = "org' or entity = 'site' or entity = 'sponsor"
        else:
            where_string = entity_name

        try:
            record_details = []
            try:
                cursor = connection.cursor()
                cursor.execute("SELECT source_root_id, source_root_name FROM admin_sources where delete_flag != '1'")
                source_root_data = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("source root data" + str(source_root_data))

            for source_root_id in source_root_data:
                source_details = {}
                ingestion_dict = []
                logger.info("source id: " + str(source_root_id[0]))
                source_details['source_name'] = source_root_id[1]
                try:
                    cursor = connection.cursor()
                    cursor.execute(
                        "select DISTINCT (i.ingest_id, i.ingest_name), i.uid from ingestion as i join ingestion_sources "
                        "as j  on i.ingest_id = j.ingest_id where j.source_root_id = '{}' and entity = '{}' and "
                        "(i.uid = '{}' or i.data_manager_id = '{}' or i.steward_id = '{}')"
                        .format(source_root_id[0], where_string, user_id, user_id, user_id))
                    ingestion_ids = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                logger.info("Ingestion ids and name:" + str(ingestion_ids))

                for ingestion_id in ingestion_ids:
                    ingestion_list = {}

                    string = ingestion_id[0].replace('(', '')
                    string = string.replace(')', '').split(',')

                    ingestion_list['ingestion_id'] = int(string[0])
                    ingestion_list['ingestion_name'] = string[1]
                    ingestion_list['source_uid'] = ingestion_id[1]
                    ingestion_dict.append(ingestion_list)
                    logger.info(str(ingestion_dict))
                source_details['ingestion_list'] = ingestion_dict

                record_details.append(source_details)
                context['ingestion_details'] = record_details
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


class ReportsGraphLanding(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_id = data['ingest_id']
            request.session['ingest_id'] = ingest_id
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in headers'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        try:
            record_details = []

            # Todo: fetch for all other and make the variables to fire in query
            if entity_name == 'investigator':
                landing_table = 'landing_investigator'
            elif entity_name == 'study':
                landing_table = 'landing_study'
            else:
                landing_table = 'landing_org'

            source_details = {}
            try:
                cursor = connection.cursor()
                cursor.execute("select count(DISTINCT(landing_record_id)) from {} where ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                count_total_records = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("total_count_records: " + str(count_total_records))
            source_details['total_records'] = count_total_records

            cursor = connection.cursor()
            cursor.execute("select count(distinct(source_id)) from {} where ingest_id = '{}'"
                           .format(landing_table, ingest_id))
            count_distinct_records = cursor.fetchall()[0][0]
            source_details['distinct_records'] = count_distinct_records
            try:
                cursor = connection.cursor()
                cursor.execute(""" SELECT contact_type, count(contact_type) from "{}" WHERE ingest_id = '{}' and 
                              contact_type is NOT NULL GROUP BY contact_type""".format(landing_table, ingest_id))
                contact_type_count = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("contact_type_data: " + str(contact_type_count))
            contact_record_details = []
            for contact_type_counts in contact_type_count:
                contact_type = {}
                contact_type['contact_type'] = contact_type_counts[0]
                contact_type['contact_count'] = contact_type_counts[1]
                contact_record_details.append(contact_type)
            source_details['contact_type_data'] = contact_record_details
            details_display = []
            store_values = {}
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE fst_name = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_fst_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_fst_name'] = empty_fst_name
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE fst_name IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_fst_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_fst_name'] = null_fst_name
            valued_fst_name = count_total_records - (null_fst_name + empty_fst_name)
            store_values['valued_fst_name'] = valued_fst_name
            details_display.append(store_values)
            source_details['first_name_details'] = details_display

            details_display = []
            store_values = {}
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE email_address = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_email_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_email_address'] = empty_email_name
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE email_address IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_mail_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_email_address'] = null_mail_name
            valued_email_name = count_total_records - (null_mail_name + empty_email_name)
            store_values['valued_email_address'] = valued_email_name
            details_display.append(store_values)
            source_details['email_address_details'] = details_display

            details_display = []
            store_values = {}
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE work_phone1 = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_work_number = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_work_number'] = empty_work_number
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE work_phone1 IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_work_number = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_work_number'] = null_work_number
            valued_work_number = count_total_records - (null_work_number + empty_work_number)
            store_values['valued_work_number'] = valued_work_number
            details_display.append(store_values)
            source_details['work_number_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE last_name = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_last_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_last_name'] = empty_last_name
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE last_name IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_last_name = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_last_name'] = null_last_name
            valued_last_name = count_total_records - (null_last_name + empty_last_name)
            store_values['valued_last_name'] = valued_last_name
            details_display.append(store_values)
            source_details['last_name_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE job_title = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_job_title = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_job_title'] = empty_job_title
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE job_title IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_job_title = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_job_title'] = null_job_title
            valued_job_title = count_total_records - (null_job_title + empty_job_title)
            store_values['valued_job_title'] = valued_job_title
            details_display.append(store_values)
            source_details['job_title_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE primary_mobile_num = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_primary_num = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_primary_num'] = empty_primary_num
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE primary_mobile_num IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_primary_num = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_primary_num'] = null_primary_num
            valued_primary_num = count_total_records - (null_primary_num + empty_primary_num)
            store_values['valued_primary_num'] = valued_primary_num
            details_display.append(store_values)
            source_details['primary_number_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE gender = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_gender = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_gender_value'] = empty_gender
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE gender IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_gender = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_gender_value'] = null_gender
            valued_gender = count_total_records - (null_gender + empty_gender)
            store_values['valued_gender_value'] = valued_gender
            details_display.append(store_values)
            source_details['gender_value_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE marital_status = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_marital_status = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_marital_status'] = empty_marital_status
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE marital_status IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_marital_status = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_marital_status'] = null_marital_status
            valued_marital_status = count_total_records - (null_marital_status + empty_marital_status)
            store_values['valued_marital_status'] = valued_marital_status
            details_display.append(store_values)
            source_details['marital_status_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE fax_ph_num1 = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_fax_num = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_fax_num'] = empty_fax_num
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE fax_ph_num1 IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_fax_num = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_fax_num'] = null_fax_num
            valued_fax_num = count_total_records - (null_fax_num + empty_fax_num)
            store_values['valued_fax_num'] = valued_fax_num
            details_display.append(store_values)
            source_details['fax_number_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE primary_specialty = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_primary_speciality = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_primary_speciality'] = empty_primary_speciality
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE primary_specialty IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_primary_speciality = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_primary_speciality'] = null_primary_speciality
            valued_primary_speciality = count_total_records - (null_primary_speciality + empty_primary_speciality)
            store_values['valued_primary_speciality'] = valued_primary_speciality
            details_display.append(store_values)
            source_details['primary_speciality_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE country = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_country = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_country'] = empty_country
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE country IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_country = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_country'] = null_country
            valued_country = count_total_records - (null_country + empty_country)
            store_values['valued_country'] = valued_country
            details_display.append(store_values)
            source_details['country_details'] = details_display

            store_values = {}
            details_display = []
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE state = '' and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                empty_state = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['empty_state'] = empty_state
            try:
                cursor = connection.cursor()
                cursor.execute("select count(*) from {} WHERE state IS NULL and ingest_id = '{}'"
                               .format(landing_table, ingest_id))
                null_state = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            store_values['null_state'] = null_state
            valued_state = count_total_records - (null_state + empty_state)
            store_values['valued_state'] = valued_state
            details_display.append(store_values)
            source_details['state_details'] = details_display

            record_details.append(source_details)
            context['report_details'] = record_details
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


class MDMHubReportsData(APIView):
    """


    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_id = data['ingest_id']
            request.session['ingest_id'] = ingest_id
            logger.info("ingestion id:" + str(ingest_id))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in headers'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        if entity_name == 'investigator':
            logger.info("Inside the entity investigator")
            mdm_table = 'mdm_golden'
        elif entity_name == 'study':
            logger.info("Inside the entity study")
            mdm_table = 'mdm_study'
        elif entity_name == 'org':
            logger.info("Inside the entity org")
            mdm_table = 'mdm_org'
        else:
            logger.info("entity is incorrect or not found.")
            return JsonResponse({'failure': 'Incorrect entity.'})
        try:
            record_details = {}
            try:
                cursor = connection.cursor()
                cursor.execute("select count(n.mdm_id) from nomatch_ref as n join {} as m on "
                               "n.mdm_id = m.mdm_id where n.ingest_id = '{}'".format(mdm_table, ingest_id))
                total_nomatch_data_count = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("total_nomatch_data_count: " + str(total_nomatch_data_count))
            try:
                cursor = connection.cursor()
                cursor.execute("select count(n.mdm_id) from partial_ref as n join {} as m on "
                               "n.mdm_id = m.mdm_id where n.ingest_id = '{}' and n.status = '12'"
                               .format(mdm_table, ingest_id))
                total_partialmatch_data_count = cursor.fetchall()[0][0]
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("total_partialmatch_data_count: " + str(total_partialmatch_data_count))
            total_data_count = total_nomatch_data_count + total_partialmatch_data_count
            record_details['total_records_count'] = total_data_count
            try:
                cursor = connection.cursor()
                cursor.execute("select m.contact_type, count(m.contact_type) from nomatch_ref as n join {} as m "
                               "on n.mdm_id = m.mdm_id where n.ingest_id = '{}' AND m.contact_type IS NOT NULL "
                               "GROUP BY  m.contact_type"
                               .format(mdm_table, ingest_id))
                contact_type_nomatch_count = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("contact_type_nomatch_count: " + str(contact_type_nomatch_count))
            try:
                cursor = connection.cursor()
                cursor.execute("select m.contact_type, count(m.contact_type) from partial_ref as n join {} as m "
                               "on n.mdm_id = m.mdm_id where n.ingest_id = '{}' AND m.contact_type IS NOT NULL"
                               " GROUP BY  m.contact_type"
                               .format(mdm_table, ingest_id))
                contact_type_partialmatch_count = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.info("contact_type_partialmatch_count: " + str(contact_type_partialmatch_count))
            contact_record_details = []
            for contact_type_counts in contact_type_nomatch_count:
                contact_type = {}
                contact_type['contact_type'] = contact_type_counts[0]
                contact_type['contact_count'] = contact_type_counts[1]
                contact_record_details.append(contact_type)
            for contact_type_counts in contact_type_partialmatch_count:
                contact_type = {}
                contact_type['contact_type'] = contact_type_counts[0]
                contact_type['contact_count'] = contact_type_counts[1]
                contact_record_details.append(contact_type)
            record_details['contact_type_data'] = contact_record_details

            context['mdm_hub_details'] = record_details

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


class AutoMergeRecordsReports(APIView):
    """

    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in headers'})
        try:
            ingest_id = data['ingest_id']
            request.session['ingest_id'] = ingest_id
            logger.info("ingestion id:" + str(ingest_id))
            page_no = data['page_no']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'At least one field is missing.'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        if entity_name == 'investigator':
            logger.info("Inside the entity investigator")
            mdm_table = 'mdm_golden'
        elif entity_name == 'study':
            logger.info("Inside the entity study")
            mdm_table = 'mdm_study'
        elif entity_name == 'org':
            logger.info("Inside the entity org")
            mdm_table = 'mdm_org'
        else:
            logger.info("entity is incorrect or not found.")
            return JsonResponse({'failure': 'Incorrect entity.'})
        try:
            master_col_without_quote = list()
            cursor = connection.cursor()
            cursor.execute("""select count(DISTINCT (mdm_id)) from ref_data where reason = 'Update from exact record' 
                        and ingest_id = '{}'""".format(ingest_id))
            count = cursor.fetchall()[0][0]
            context['count'] = count
            # cursor = connection.cursor()
            # cursor.execute("SELECT column_name from information_schema.columns where "
            #                "table_name = '{}'".format(mdm_table))
            # master_col_names = cursor.fetchall()
            master_col_names = settings.COLUMN_LIST
            master_col_with_quote = ''
            for col in master_col_names:
                master_col_with_quote += '"' + str(col) + '" , '
            # context['mdm_columns'] = master_col_without_quote
            mdm_col_names = convert_to_alias(master_col_names, entity_name)
            context['master_columns'] = mdm_col_names
            cursor = connection.cursor()
            cursor.execute("""select DISTINCT (mdm_id) from ref_data where reason = 'Update from exact record'
                      and ingest_id = '{}' limit 10 offset {}""".format(ingest_id,
                                                                        str((int(page_no) - 1) * 10)))
            mdm_ids = cursor.fetchall()
            logger.error('mdm_ids for report: ' + str(mdm_ids))
            mdm_record_dict = []
            for mdm_id in mdm_ids:
                mdm_record = {}
                try:
                    cursor = connection.cursor()
                    cursor.execute("select {} from {} where mdm_id = '{}'".format(master_col_with_quote[:-2], mdm_table, mdm_id[0]))
                    logger.error("select {} from {} where mdm_id = '{}'".format(master_col_with_quote[:-2], mdm_table, mdm_id[0]))
                    data = cursor.fetchall()
                    logger.error('data in auto merge:' + str(data))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                for d in data:
                    mdm_record['data'] = d
                    mdm_record_dict.append(mdm_record)
            context['mdm_record'] = mdm_record_dict

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})

        return JsonResponse(context)


class ManuallyMergeRecords(APIView):
    """

    """
    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        try:
            data = json.loads(request.read().decode('utf-8'))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in headers'})
        try:
            ingest_id = data['ingest_id']
            request.session['ingest_id'] = ingest_id
            logger.info("ingestion id:" + str(ingest_id))
            page_no = data['page_no']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'At least one field is missing.'})
        try:
            entity_name = request.META['HTTP_ENTITY']
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        if entity_name == 'investigator':
            logger.info("Inside the entity investigator")
            mdm_table = 'mdm_golden'
        elif entity_name == 'study':
            logger.info("Inside the entity study")
            mdm_table = 'mdm_study'
        elif entity_name == 'org':
            logger.info("Inside the entity org")
            mdm_table = 'mdm_org'
        else:
            logger.info("entity is incorrect or not found.")
            return JsonResponse({'failure': 'Incorrect entity.'})
        try:
            master_col_without_quote = list()
            cursor = connection.cursor()
            try:
                cursor.execute(
                    "select count(DISTINCT (mdm_id)) from ref_data WHERE reason in ('Update by steward', 'Insert by steward') "
                    " and ingest_id = '{}'".format(ingest_id))
                count = cursor.fetchall()[0][0]
                context['count'] = count
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            cursor = connection.cursor()
            # try:
            #     cursor.execute("SELECT column_name from information_schema.columns where "
            #                    "table_name = '{}'".format(mdm_table))
            #     master_col_names = cursor.fetchall()
            # except Exception as e:
            #     logger.error(str(e))
            #     k = dict()
            #     k['Error'] = str(e).replace("'", '"')
            #     # k = json.dumps(k)
            #     cursor = connection.cursor()
            #     logger.error(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            #     cursor.execute(
            #         """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
            #             request.session.get('ingest_id', -1),
            #             request.session.get('user_id', -1), json.dumps(k)))
            #     connection.commit()
            # for col in master_col_names[1:-2]:
            #     master_col_without_quote.append(str(col[0]))
            # context['mdm_columns'] = master_col_without_quote
            # mdm_col_names = convert_to_alias(context['mdm_columns'], entity_name)
            # context['master_columns'] = mdm_col_names
            master_col_names = settings.COLUMN_LIST
            master_col_with_quote = ''
            for col in master_col_names:
                master_col_with_quote += '"' + str(col) + '" , '
            # context['mdm_columns'] = master_col_without_quote
            mdm_col_names = convert_to_alias(master_col_names, entity_name)
            context['master_columns'] = mdm_col_names
            cursor = connection.cursor()
            try:
                cursor.execute("select DISTINCT (mdm_id) from ref_data WHERE (reason = 'Update by steward' or "
                               "reason = 'Insert by steward') and ingest_id = '{}' limit 10 offset {}"
                               .format(ingest_id, str((int(page_no) - 1) * 10)))
                mdm_ids = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            logger.error('mdm_ids for report manual merge: ' + str(mdm_ids))
            mdm_rec_dict = []
            for mdm_id in mdm_ids:
                mdm_record = {}
                try:
                    cursor = connection.cursor()
                    cursor.execute("select {} from {} where mdm_id = '{}'".format(master_col_with_quote[:-2], mdm_table, mdm_id[0]))
                    logger.error("select {} from {} where mdm_id = '{}'".format(master_col_with_quote[:-2], mdm_table, mdm_id[0]))
                    data = cursor.fetchall()
                    logger.error('manual merge data: ' + str(data))
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                for d in data:
                    mdm_record['data'] = d
                    mdm_rec_dict.append(mdm_record)
            context['mdm_record'] = mdm_rec_dict
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database failure'})
        return JsonResponse(context)


class ReferentialAnalysisReports(APIView):
    """

    """

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def get(request, page_number):
        """

        :param request:
        :param page_number:
        :return:
        """
        context = {}
        data_dictionary = []
        try:
            entity_name = 'investigator'
            logger.info("Entity name in reports: " + str(entity_name))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No entity data in request headers'})
        if entity_name == 'investigator':
            logger.info("Inside the entity investigator")
            mdm_table = 'mdm_golden'
            stage_table = 'stage_investigator'
        elif entity_name == 'study':
            logger.info("Inside the entity study")
            mdm_table = 'mdm_study'
            stage_table = 'stage_study'
        elif entity_name == 'org':
            logger.info("Inside the entity org")
            mdm_table = 'mdm_org'
            stage_table = 'stage_org'
        else:
            logger.info("entity is incorrect or not found.")
            return JsonResponse({'failure': 'Incorrect entity.'})
        try:
            # master_col_without_quote = list()
            # cursor = connection.cursor()
            # cursor.execute("SELECT column_name from information_schema.columns where "
            #                "table_name = '{}'".format(mdm_table))
            # master_col_names = cursor.fetchall()
            # for col in master_col_names[1:-2]:
            #     master_col_without_quote.append(str(col[0]))
            # context['mdm_columns'] = master_col_without_quote
            # mdm_col_names = convert_to_alias(context['mdm_columns'], entity_name)
            master_col_names = settings.COLUMN_LIST
            master_col_with_quote = ''
            for col in master_col_names:
                master_col_with_quote += '"' + str(col) + '" , '
            # context['mdm_columns'] = master_col_without_quote
            mdm_col_names = convert_to_alias(master_col_names, entity_name)
            context['master_columns'] = mdm_col_names
            logger.error("column names in referential analysis: " + str(mdm_col_names))
            try:
                cursor = connection.cursor()
                cursor.execute("select count(distinct(mdm_id)) from ref_data ")
                mdm_id_count = cursor.fetchall()[0][0]
                logger.error("mdm id count: " + str(mdm_id_count))
                context['total_record_count'] = mdm_id_count
                cursor = connection.cursor()
                cursor.execute("select distinct(mdm_id) from ref_data limit 10 offset {}"
                               .format(str((int(page_number) - 1) * 10)))
                mdm_ids = cursor.fetchall()
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            for mdm_id in mdm_ids:
                data_dict = {}
                source_rec = []
                data_dict['mdm_id'] = mdm_id[0]
                try:
                    context['mdm_column_names'] = mdm_col_names
                    cursor = connection.cursor()
                    cursor.execute("select {} from {} where mdm_id = '{}'".format(master_col_with_quote[:-2], mdm_table, mdm_id[0]))
                    mdm_data = cursor.fetchall()
                    data_dict['mdm_data'] = mdm_data
                    cursor = connection.cursor()
                    cursor.execute("select source_id from ref_data where mdm_id = '{}'".format(mdm_id[0]))
                    source_ids = cursor.fetchall()
                except Exception as e:
                    logger.error(str(e))
                    k = dict()
                    k['Error'] = str(e).replace("'", '"')
                    # k = json.dumps(k)
                    cursor = connection.cursor()
                    logger.error(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                    cursor.execute(
                        """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                            request.session.get('ingest_id', -1),
                            request.session.get('user_id', -1), json.dumps(k)))
                    connection.commit()
                for source_id in source_ids:
                    source_records = {}
                    stage_col_string = ''
                    source_records['source_id'] = source_id[0]
                    try:
                        stage_col_without_quote = list()
                        cursor = connection.cursor()
                        cursor.execute("SELECT column_name from information_schema.columns where "
                                       "table_name = '{}'".format(stage_table))
                        stage_col_names = cursor.fetchall()
                        for col in stage_col_names:
                            stage_col_without_quote.append(str(col[0]))
                        context['stage_columns'] = stage_col_without_quote
                        stage_col_sliced = stage_col_without_quote[5:-5]
                        for stage_col in stage_col_sliced:
                            stage_col_string += 'b."' + str(stage_col) + '",'
                        stage_col_string = stage_col_string[:-1]
                        stage_col_names = convert_to_alias(context['stage_columns'], entity_name)
                        stage_col_names = stage_col_names[5:-5]
                        stage_col_names.insert(0, "REASON")
                        context['stage_column_names'] = stage_col_names

                        cursor = connection.cursor()
                        cursor.execute("select distinct a.reason, {} from ref_data as a join {} as b ON "
                                       "a.source_id = b.source_id where a.source_id = '{}'"
                                       .format(stage_col_string, stage_table, source_id[0]))
                        record_details = cursor.fetchall()
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    source_records['relevant_record'] = record_details
                    source_rec.append(source_records)
                data_dict['source_records'] = source_rec
                data_dictionary.append(data_dict)

            context['data'] = data_dictionary
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)


# class CrossMatchingAnalysis(APIView):
#     """
#
#     """
#     @staticmethod
#     def post(request):
#         """
#
#         :param request:
#         :return:
#         """
#         return JsonResponse({'failure': 'Api not supported'})
#
#     @staticmethod
#     def get(request):
#         """
#
#         :param request:
#         :return:
#         """
#         context = {}
#         dict_data = []
#         try:
#             cursor = connection.cursor()
#             cursor.execute("select investigator_source_id from investigator_study_bridge")
#             source_ids = cursor.fetchall()
#             for source_id in source_ids:
#                 bridge_records = {}
#                 logger.error('investigator id from bridge table: ' + str(source_id[0]))
#                 bridge_records['investigator_source_id'] = source_id[0]
#                 var = source_id[0]
#                 print(type(var))
#                 logger.error(str(bridge_records) + ' '+str(var))
#                 try:
#                     cursor = connection.cursor()
#                     cursor.execute("select mdm_id from ref_data where source_id = '{}'".format(var))
#                     logger.error("select mdm_id from ref_data where source_id = '{}'".format(var))
#                     mdm_id = cursor.fetchall()
#                 except Exception as e:
#                     logger.error(str(e))
#                 if mdm_id:
#                     cursor = connection.cursor()
#                     cursor.execute("select * from mdm_golden where mdm_id = '{}'".format(mdm_id[0][0]))
#                     investigator_data = cursor.fetchall()
#                     bridge_records['investigator_mdm_record'] = investigator_data
#                 cursor = connection.cursor()
#                 cursor.execute("select study_source_id from investigator_study_bridge where investigator_source_id = '{}'"
#                                .format(source_id[0]))
#                 study_source_ids = cursor.fetchall()
#                 study_dict = []
#                 for study_source_id in study_source_ids:
#                     study_records = {}
#                     logger.error('study id from bridge table: ' + str(study_source_id))
#                     cursor = connection.cursor()
#                     cursor.execute("select mdm_id from ref_data where source_id = '{}'"
#                                    .format(study_source_id[0]))
#                     study_mdm_id = cursor.fetchall()
#                     if study_mdm_id:
#                         cursor = connection.cursor()
#                         cursor.execute("select * from mdm_study where mdm_id = '{}'".format(study_mdm_id[0][0]))
#                         study_data = cursor.fetchall()
#                         study_records['study_table_records'] = study_data
#                     study_dict.append(study_records)
#                 bridge_records['study_records'] = study_dict
#                 dict_data.append(bridge_records)
#             context['data'] = dict_data
#
#         except Exception as e:
#             logger.error(str(e))
#             return JsonResponse({'failure': 'Database Failure'})
#         return JsonResponse(context)


class CrossMatchingAnalysis(APIView):
    """

    """

    @staticmethod
    def get(request):
        """

        :param request:
        :return:
        """
        return JsonResponse({'failure': 'Api not supported'})

    @staticmethod
    def post(request):
        """

        :param request:
        :return:
        """
        context = {}
        mdm_records = {}
        study_data_dict = []
        try:
            data = json.loads(request.read().decode('utf-8'))
            investigator_mdm_id = data['investigator_mdm_id']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data in headers'})
        try:
            study_record_dict = ['mdm_id','mdm_org_id','study_code','study_name','study_full_name','study_purpose',
                                 'study_title','study_type','study_phase_code','study_diagnosis','ptcl_num','therapy_area',
                                 'sponsor','org_type','study_comments','study_start_dt','study_end_dt']
            mdm_records['investigator_mdm_id'] = investigator_mdm_id
            try:
                study_source_ids = None
                cursor = connection.cursor()
                cursor.execute("select source_id from ref_data where mdm_id = '{}' and reason='New Record'".format(investigator_mdm_id))
                investigator_source_id = cursor.fetchall()
                cursor = connection.cursor()
                if investigator_source_id:
                    cursor.execute(
                        "select study_source_id from investigator_study_bridge where investigator_source_id = '{}'"
                        .format(investigator_source_id[0][0]))
                    study_source_ids = cursor.fetchall()
                    logger.error('source ids of study per investigator source id' + str(study_source_ids))
            except Exception as e:
                logger.error(str(e))
                k = dict()
                k['Error'] = str(e).replace("'", '"')
                # k = json.dumps(k)
                cursor = connection.cursor()
                logger.error(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
                cursor.execute(
                    """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                        request.session.get('ingest_id', -1),
                        request.session.get('user_id', -1), json.dumps(k)))
                connection.commit()
            if study_source_ids:
                mdm_records['column_names'] = study_record_dict
                for study_source_id in study_source_ids:
                    logger.error('study_source_id' + str(study_source_id))
                    try:
                        study_dict = {}
                        flag = 0
                        cursor = connection.cursor()
                        cursor.execute("select mdm_id from ref_data where source_id = '{}' and entity = 'study'"
                                       .format(study_source_id[0]))
                        logger.error("select mdm_id from ref_data where source_id = '{}' and entity = 'study'"
                                     .format(study_source_id[0]))
                        study_mdm_id = cursor.fetchall()
                        if study_mdm_id:
                            logger.error("study_mdm_id: " + str(study_mdm_id[0][0]))
                            string = " "
                            for i in study_record_dict:
                                string += i + ' , '
                            string = string[:-2]
                            cursor = connection.cursor()
                            cursor.execute("select {} from mdm_study where mdm_id = '{}'"
                                           .format(string, study_mdm_id[0][0]))
                            logger.error("select {} from mdm_study where mdm_id = '{}'"
                                         .format(string, study_mdm_id[0][0]))
                            study_mdm_record = cursor.fetchall()
                            if study_mdm_record:
                                flag = 1
                                logger.error("study mdm record: " + str(study_mdm_record[0][0]))
                            study_dict['study_records'] = study_mdm_record
                    except Exception as e:
                        logger.error(str(e))
                        k = dict()
                        k['Error'] = str(e).replace("'", '"')
                        # k = json.dumps(k)
                        cursor = connection.cursor()
                        logger.error(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1), request.session.get('user_id', -1),
                                json.dumps(k)))
                        cursor.execute(
                            """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                                request.session.get('ingest_id', -1),
                                request.session.get('user_id', -1), json.dumps(k)))
                        connection.commit()
                    if flag == 1:
                        study_data_dict.append(study_dict)
                mdm_records['relevant_study_records'] = study_data_dict
                context['data'] = mdm_records

        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'Database Failure'})
        return JsonResponse(context)
