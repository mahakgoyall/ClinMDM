from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^info_rule_matcher_graph/$', views.AllRuleMatcherGraph.as_view(), name='rule matcher data graph'),
    url(r'^info_data_validation_graph/$', views.AllDataValidationGraph.as_view(), name='data validation graph'),
    url(r'^rejection_analysis_graph/$', views.AllRejectionAnalysisGraph.as_view(), name='rejection analysis graph'),
    url(r'^steward_cumulative_analysis_graph/$', views.StewardCumulativeAnalysisGraph.as_view(), name='Steward '
                                                                                                      'cumulative '
                                                                                                      'analysis graph'),
    # url(r'^source_rule_graph/$', views.SourceRuleValidationGraph.as_view(), name='source rule graph'),
    # url(r'^source_data_validation_graph/$', views.SourceDataValidationGraph.as_view(), name='source validation graph'),
    # url(r'^source_rejection_graph/$', views.SourceRejectionAnalysisGraph.as_view(), name='source rejection graph'),
    # url(r'^source_list/$', views.SourceList.as_view(), name='source list'),
    url(r'^dashboard_circles/$', views.DashboardCirclesData.as_view(), name='dashboard_circles'),
    url(r'^steward_analysis/$', views.StewardAnalysisData.as_view(), name='steward_analysis'),
    url(r'^staging_analysis/$', views.StagingAnalysis.as_view(), name='StagingAnalysis'),
    url(r'^ingestion_list/$', views.IngestionBySourceReports.as_view(), name='ingestion_list_details'),
    url(r'^landing_report_data/$', views.ReportsGraphLanding.as_view(), name='landing_report_data'),
    url(r'^mdm_hub_analysis/$', views.MDMHubReportsData.as_view(), name='MdmHubAnalysis'),
    url(r'^auto_merge_report/$', views.AutoMergeRecordsReports.as_view(), name='AutoMerge Report data'),
    url(r'^manually_merge_report/$', views.ManuallyMergeRecords.as_view(), name='Manually Merge record Reports'),
    url(r'^referential_analysis_data/(?P<page_number>[0-9]+)/$', views.ReferentialAnalysisReports.as_view(), name='referential'),
    url(r'^cross_matching_analysis/$', views.CrossMatchingAnalysis.as_view(), name='cross matching analysis')
]
