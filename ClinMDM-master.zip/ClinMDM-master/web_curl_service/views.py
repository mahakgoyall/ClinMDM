from django.db import connection
from rest_framework.views import APIView
from django.http import JsonResponse
import json
import logging
# from connections.views import create_ingestion, UseExistingFlow

logger = logging.getLogger("mdm_logging")


class FlowStatus(APIView):

    @staticmethod
    def post(request):
        try:
            data = json.loads(request.read().decode('utf-8'))
            ingest_name = data['ingest_name']
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({'failure': 'No data found in the request.'})
        try:
            table_name = "ingestion"
            cursor = connection.cursor()
            cursor.execute("SELECT status_flag FROM {} WHERE ingest_name = '{}' AND uid = '{}'".format(table_name,
                                                                                                       ingest_name,
                                                                                                       request.session['user_id']))
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
        try:
            ui_information = dict()
            # names = ["ingestion_flag", "connection_flag", "mapping_flag", "flow_flag", "validation_flag", "rules_flag"]
            # lst = cursor.fetchall()[0]
            # for idx, flag in enumerate(names):
            #     ui_information[flag] = lst[idx]
            return JsonResponse(ui_information)
        except Exception as e:
            logger.error(str(e))
            k = dict()
            k['Error'] = str(e).replace("'", '"')
            # k = json.dumps(k)
            cursor = connection.cursor()
            logger.error(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1), request.session.get('user_id', -1), json.dumps(k)))
            cursor.execute(
                """INSERT INTO clinmdm_logs_per_ingestion(ingest_id, uid, log) values({}, {}, '{}')""".format(
                    request.session.get('ingest_id', -1),
                    request.session.get('user_id', -1), json.dumps(k)))
            connection.commit()
            return JsonResponse({"failure": "DB failure."})

    @staticmethod
    def get(request):
        return JsonResponse({'failure': 'API not supported.'})


def flow_flags(ingestion_id, uid, type_of_flag='1', table_name=None, source_id=None):
    try:
        logger.error("in the flow flag")
        cursor = connection.cursor()
        if not table_name and not source_id:
            table_name = "ingestion"
            logger.error("UPDATE \"{}\" SET status_flag='{}' WHERE uid='{}' AND ingest_id='{}'".format(table_name,
                                                                                                         type_of_flag,
                                                                                                         uid,
                                                                                                         ingestion_id))
            cursor.execute("UPDATE \"{}\" SET status_flag='{}' WHERE uid='{}' AND ingest_id='{}'".format(table_name,
                                                                                                         type_of_flag,
                                                                                                         uid,
                                                                                                         ingestion_id))
        else:
            logger.error("UPDATE \"{}\" SET status_flag='{}' WHERE uid='{}' AND ingest_id='{}' AND "
                           "source_id='{}'".format(table_name, type_of_flag, uid, ingestion_id, source_id))
            cursor.execute("UPDATE \"{}\" SET status_flag='{}' WHERE uid='{}' AND ingest_id='{}' AND "
                           "source_id='{}'".format(table_name, type_of_flag, uid, ingestion_id, source_id))
        connection.commit()
        logger.error("successful in flow flag step")
        return "Success"
    except Exception as e:
        logger.error(str(e))
        connection.rollback()
        logger.error("Rollback from flow flags")
        return "failure"
