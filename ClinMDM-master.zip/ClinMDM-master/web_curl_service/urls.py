from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    # url(r'^webservice/$', views.WebService.as_view(), name='web service'),
    url(r'^flow_status/$', views.FlowStatus.as_view(), name='FlowStatus')
]
