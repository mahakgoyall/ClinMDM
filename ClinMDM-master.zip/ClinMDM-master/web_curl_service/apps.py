from __future__ import unicode_literals

from django.apps import AppConfig


class WebCurlServiceConfig(AppConfig):
    name = 'web_curl_service'
